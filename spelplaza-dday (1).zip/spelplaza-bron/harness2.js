// Multiplayer test harness: local PeerJS signaling server + N headless pages (host + joiners).
// Usage:
//   node harness2.js <mpId> [players=2]      -> builds, opens a room with the game, mashes input on every page, reports errors, saves shots/mp-<id>-p<k>.png
//   node harness2.js all                     -> every MP game at its minimum player count
// From code:
//   const {openRoom}=require('./harness2'); const r=await openRoom('pong',{players:2});
//   r.pages[0] is the host page (playwright Page), r.pages[1..] joiners; r.errors (per page); r.sc(k) score line; r.shot(k,tag); r.close()
const { chromium } = require('playwright-core');
const path = require('path'), fs = require('fs'), { execSync, spawn } = require('child_process');
const ROOT = __dirname;
const EXE = '/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell';
const ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required', '--mute-audio', '--allow-file-access-from-files'];
const PORT = 9123;
let server = null;
async function probe() { try { const r = await fetch('http://127.0.0.1:' + PORT + '/peerjs/id'); return r.ok; } catch (e) { return false; } }
async function startServer() {
  if (server) return;
  if (await probe()) return; // a shared server is already running (started by someone else) - use it, never kill it
  server = spawn(path.join(ROOT, 'node_modules/.bin/peerjs'), ['--host', '127.0.0.1', '--port', String(PORT), '--path', '/'], { stdio: 'ignore' });
  await new Promise(r => setTimeout(r, 900));
}
function stopServer() { if (server) { try { server.kill(); } catch (e) {} server = null; } }

async function launchBrowser() { return chromium.launch({ executablePath: EXE, headless: true, args: ARGS }); }

async function newPage(browser, opts, label) {
  const ctx = await browser.newContext({ viewport: opts.viewport || { width: 420, height: 800 }, hasTouch: !!opts.touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(label + ' PAGEERROR: ' + (e.stack || e.message)));
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(label + ' ' + m.type().toUpperCase() + ': ' + m.text()); });
  await page.addInitScript(p => { window.SPZ_PEER = { host: '127.0.0.1', port: p, path: '/', secure: false, debug: 0 }; }, PORT);
  await page.goto('file://' + (process.env.SPZ_OUT ? path.resolve(ROOT, process.env.SPZ_OUT) : path.join(ROOT, 'dist', 'spelplaza.html')));
  await page.waitForTimeout(250);
  return { page, ctx, errors };
}

// Opens a room: host page creates it, (players-1) joiners join, host starts `id`. Resolves when every page shows the game.
async function openRoom(id, opts = {}) {
  await startServer();
  const n = opts.players || 2;
  const browser = opts.browser || await launchBrowser();
  const views = [];
  const host = await newPage(browser, opts, 'host'); views.push(host);
  await host.page.click('#mpbtn'); await host.page.fill('#mpn', 'Host'); await host.page.click('#mkh');
  await host.page.waitForSelector('#mp .code b', { timeout: 15000 });
  const code = await host.page.$eval('#mp .code b', e => e.textContent.trim());
  for (let k = 1; k < n; k++) {
    const v = await newPage(browser, opts, 'p' + k); views.push(v);
    await v.page.click('#mpbtn'); await v.page.fill('#mpn', 'Speler' + k); await v.page.fill('#mpc', code); await v.page.click('#mkj');
    await v.page.waitForSelector('#mp .code b', { timeout: 15000 });
  }
  await host.page.waitForFunction(n => NET.players.length === n, n, { timeout: 10000 });
  await host.page.evaluate(id => NET.start(id), id);
  for (const v of views) await v.page.waitForFunction(() => document.querySelector('#play').style.display === 'block' && document.querySelector('#stage').children.length > 0, null, { timeout: 10000 });
  await host.page.waitForTimeout(opts.wait || 800);
  const r = {
    code, browser, views, pages: views.map(v => v.page), errors: views.map(v => v.errors),
    allErrors: () => views.flatMap(v => [...new Set(v.errors)]),
    sc: k => views[k].page.evaluate(() => (document.querySelector('#stage .sc') || {}).textContent || ''),
    stage: k => views[k].page.evaluate(() => document.querySelector('#stage').innerText),
    shot: async (k, tag) => { const f = path.join(ROOT, 'shots', `mp-${id}-p${k}${tag ? '-' + tag : ''}.png`); await views[k].page.screenshot({ path: f }); return f; },
    canvasBox: k => views[k].page.evaluate(() => { const c = document.querySelector('#stage canvas'); if (!c) return null; const r = c.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; }),
    stageBox: k => views[k].page.evaluate(() => { const r = document.querySelector('#stage').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; }),
    restart: () => host.page.evaluate(id => NET.start(id), id),
    close: async () => { for (const v of views) await v.ctx.close(); if (!opts.browser) await browser.close(); },
  };
  return r;
}

async function smoke(id, players, browser) {
  const r = await openRoom(id, { players, browser, touch: true });
  for (let k = 0; k < r.pages.length; k++) await r.shot(k, '1');
  // generic input on every page: pointer drag/click on canvas or stage + keys
  for (let round = 0; round < 2; round++) for (let k = 0; k < r.pages.length; k++) {
    const p = r.pages[k];
    const cb = (await r.canvasBox(k)) || (await r.stageBox(k));
    if (cb) { const cx = cb.x + cb.w / 2, cy = cb.y + cb.h / 2; await p.mouse.move(cx, cy); await p.mouse.down(); await p.mouse.move(cx + 40, cy + 10, { steps: 5 }); await p.mouse.up(); await p.mouse.click(cx, cy); }
    for (const key of ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space']) { await p.keyboard.press(key); await p.waitForTimeout(60); }
  }
  await r.pages[0].waitForTimeout(1200);
  for (let k = 0; k < r.pages.length; k++) await r.shot(k, '2');
  // host restarts, then everyone back to lobby and start again (cleanup check)
  await r.restart(); await r.pages[0].waitForTimeout(600);
  await r.pages[0].evaluate(() => NET.toLobby()); await r.pages[0].waitForTimeout(500);
  await r.pages[0].evaluate(id => NET.start(id), id); await r.pages[0].waitForTimeout(800);
  const errs = r.allErrors();
  await r.close();
  return { id, errs };
}

if (require.main === module) {
  (async () => {
    let ids = process.argv.slice(2);
    const subset = ids.length && ids[0] !== 'all';
    const players = subset && /^\d+$/.test(ids[ids.length - 1]) ? +ids.pop() : null;
    execSync('node ' + path.join(ROOT, 'build.js') + (subset ? ' ' + ids.join(' ') : ''), { stdio: 'inherit' });
    await startServer();
    const browser = await launchBrowser();
    let list;
    {
      const v = await newPage(browser, {}, 'x');
      list = await v.page.evaluate(() => MP.map(m => ({ id: m.id, min: m.min })));
      await v.ctx.close();
    }
    if (!subset) ids = list.map(m => m.id);
    let bad = 0;
    for (const id of ids) {
      const m = list.find(x => x.id === id);
      if (!m) { console.log('✗ ' + id + ': not in MP'); bad++; continue; }
      try {
        const r = await smoke(id, players || m.min, browser);
        if (r.errs.length) { bad++; console.log(`✗ ${id}\n   ` + r.errs.join('\n   ')); } else console.log(`✓ ${id}  (${players || m.min} spelers)`);
      } catch (e) { bad++; console.log(`✗ ${id} harness failure: ${e.message.split('\n')[0]}`); }
    }
    await browser.close(); stopServer();
    console.log(bad ? `${bad} game(s) with problems` : 'all clean');
    process.exit(bad ? 1 : 0);
  })();
}
module.exports = { openRoom, launchBrowser, startServer, stopServer, newPage };
