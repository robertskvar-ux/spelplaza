{id:'mole',n:'Mep de Mol',e:'🔨',c:'Arcade',g:'#56ab2f,#a8e063',run(st){
 const W=360,H=400,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Tik op de mollen · 🌟 gouden mol = +5 · mis je, dan −1 · toetsen 1–9 (numpad) of Q W E / A S D / Z X C'));
 const HX=[70,180,290],HY=[130,235,340],LEN=25;
 const KM={'7':0,'8':1,'9':2,'4':3,'5':4,'6':5,'1':6,'2':7,'3':8,q:0,w:1,e:2,a:3,s:4,d:5,z:6,x:7,c:8};
 let holes,score,lvl,lvScore,tl,state,stT,spawnT,parts,texts,t,shake,hits,miss;
 const target=()=>6+lvl*6;
 function init(){holes=Array.from({length:9},()=>({p:0,up:0,st:0,g:0,hit:0}));score=0;lvl=1;state=0;stT=0;parts=[];texts=[];t=0;shake=0;startLv(0);overlay(st,c,'')}
 function startLv(go){lvScore=0;tl=LEN;spawnT=.6;hits=0;miss=0;holes.forEach(h=>{h.p=0;h.up=0;h.hit=0});if(go)state=1}
 function spawn(){const free=holes.filter(h=>h.p<=0&&!h.up);if(!free.length)return;const active=holes.filter(h=>h.up||h.p>0).length;if(active>=Math.min(3,1+(lvl>>1)))return;
  const h=free[R(free.length)];h.up=1;h.hit=0;h.g=Math.random()<.08+lvl*.01;h.st=Math.max(.5,1.25-lvl*.1)*(h.g?.7:1)}
 function whack(i){if(state===0){state=1;beep(520,.08,'triangle',.04);return}if(state===3){if(stT>.6)init();return}if(state!==1)return;
  const h=holes[i];if(h.up&&h.p>.45&&!h.hit){h.hit=1;h.up=0;const v=h.g?5:1;score+=v;lvScore+=v;hits++;shake=.12;
   beep(h.g?1046:660,.08,h.g?'triangle':'square',.04);if(h.g)setTimeout(()=>beep(1318,.1,'triangle',.04),70);
   for(let k=0;k<(h.g?16:9);k++){const a=Math.random()*7,s=60+Math.random()*120;parts.push({x:HX[i%3],y:HY[i/3|0]-30,vx:Math.cos(a)*s,vy:Math.sin(a)*s-60,l:.5,c:h.g?'#ffd700':'#fff3b0'})}
   texts.push({x:HX[i%3],y:HY[i/3|0]-60,s:'+'+v,c:h.g?'#ffd700':'#fff',l:.8})}
  else if(!h.up||h.p<.2){score=Math.max(0,score-1);lvScore=Math.max(0,lvScore-1);miss++;beep(140,.08,'sawtooth',.03);texts.push({x:HX[i%3],y:HY[i/3|0]-30,s:'−1',c:'#ff6b6b',l:.7})}}
 function at(px,py){for(let i=0;i<9;i++){const dx=px-HX[i%3],dy=py-(HY[i/3|0]-25);if(Math.abs(dx)<52&&dy>-60&&dy<45)return i}return -1}
 c.onpointerdown=e=>{e.preventDefault();const r=c.getBoundingClientRect(),i=at((e.clientX-r.left)*W/r.width,(e.clientY-r.top)*H/r.height);if(i>=0||state!==1)whack(Math.max(0,i))};
 const inp=input(st,[],k=>{const i=KM[k.toLowerCase()];if(i!=null)whack(i);else if((k===' '||k==='Enter')&&state!==1)whack(0)});
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function mole(cx,cy,h){const rise=h.p,y=cy+48-rise*58;x.save();x.beginPath();x.rect(cx-60,cy-130,120,130);x.clip();
  x.fillStyle=h.g?'#e6b422':'#8a5a35';x.beginPath();x.ellipse(cx,y,32,38,0,0,7);x.fill();
  x.fillStyle=h.g?'#ffe58a':'#c48b5c';x.beginPath();x.ellipse(cx,y+12,20,22,0,0,7);x.fill();
  const d=h.hit;x.fillStyle='#1b1b2f';if(d){x.strokeStyle='#1b1b2f';x.lineWidth=3;for(const s of[-1,1]){x.beginPath();x.moveTo(cx+s*12-5,y-14);x.lineTo(cx+s*12+5,y-6);x.moveTo(cx+s*12+5,y-14);x.lineTo(cx+s*12-5,y-6);x.stroke()}}
  else for(const s of[-1,1]){x.beginPath();x.arc(cx+s*12,y-10,4.5,0,7);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(cx+s*12+1.5,y-11.5,1.5,0,7);x.fill();x.fillStyle='#1b1b2f'}
  x.fillStyle='#ff8fa3';x.beginPath();x.ellipse(cx,y+2,7,5,0,0,7);x.fill();
  x.fillStyle='#fff';x.fillRect(cx-5,y+8,4,6);x.fillRect(cx+1,y+8,4,6);
  if(h.g){x.fillStyle='#fff8';x.beginPath();x.arc(cx-14,y-24,5,0,7);x.fill()}
  x.restore()}
 const stopLoop=loop(dt=>{t+=dt;stT+=dt;shake=Math.max(0,shake-dt);
  if(state===1){tl-=dt;spawnT-=dt;if(spawnT<=0){spawn();spawnT=Math.max(.3,.85-lvl*.07)*(.6+Math.random()*.8)}
   for(const h of holes){if(h.up){h.p=Math.min(1,h.p+dt*7);h.st-=dt;if(h.st<=0)h.up=0}else h.p=Math.max(0,h.p-dt*(h.hit?4:6))}
   if(tl<=0){tl=0;if(lvScore>=target()){state=2;stT=0;best('mole',score);[523,659,784].forEach((f,k)=>setTimeout(()=>beep(f,.12,'triangle',.05),k*100));ov(`⭐ Level ${lvl} gehaald!<br><span style="font-size:15px;font-weight:600">${lvScore} punten · ${hits} raak · ${miss} mis</span>`)}
    else{state=3;stT=0;best('mole',score);beep(120,.5,'sawtooth',.05);ov(`⏰ Tijd op!<br><span style="font-size:15px;font-weight:600">Level ${lvl}: ${lvScore}/${target()} punten<br>Totaal ${score} · Beste ${best('mole',score)}<br>Tik om opnieuw te spelen</span>`)}}}
  else if(state===2){for(const h of holes)h.p=Math.max(0,h.p-dt*6);if(stT>1.8){lvl++;startLv(1);ov('')}}
  else if(state!==1)for(const h of holes)h.p=Math.max(0,h.p-dt*6);
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=400*dt;p.l-=dt}parts=parts.filter(p=>p.l>0);for(const q of texts){q.y-=50*dt;q.l-=dt}texts=texts.filter(q=>q.l>0);
  // draw
  x.save();if(shake>0)x.translate((Math.random()-.5)*5,(Math.random()-.5)*5);
  const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#16324a');g.addColorStop(.18,'#1d4d33');g.addColorStop(1,'#123020');x.fillStyle=g;x.fillRect(-6,-6,W+12,H+12);
  x.fillStyle='#2a6a40';for(let i=0;i<40;i++){const gx=(i*53)%W,gy=70+(i*37)%320;x.beginPath();x.moveTo(gx,gy);x.lineTo(gx+3,gy-9);x.lineTo(gx+6,gy);x.fill()}
  for(let i=0;i<9;i++){const cx=HX[i%3],cy=HY[i/3|0];x.fillStyle='#3d2817';x.beginPath();x.ellipse(cx,cy,48,16,0,0,7);x.fill();x.fillStyle='#0d0a07';x.beginPath();x.ellipse(cx,cy,40,12,0,0,7);x.fill()}
  for(let i=0;i<9;i++){const h=holes[i];if(h.p>0)mole(HX[i%3],HY[i/3|0],h)}
  for(let i=0;i<9;i++){const cx=HX[i%3],cy=HY[i/3|0];x.fillStyle='#5a3a20';x.beginPath();x.ellipse(cx,cy+4,48,12,0,0,Math.PI);x.fill()}
  for(const p of parts){x.globalAlpha=Math.max(0,p.l*2);x.fillStyle=p.c;x.fillRect(p.x-2,p.y-2,4,4)}x.globalAlpha=1;
  x.textAlign='center';for(const q of texts){x.globalAlpha=Math.min(1,q.l*2);x.fillStyle=q.c;x.font='900 22px system-ui,sans-serif';x.fillText(q.s,q.x,q.y)}x.globalAlpha=1;x.restore();
  // HUD
  x.fillStyle='#0e1020cc';x.fillRect(0,0,W,52);x.fillStyle='#fff';x.font='800 15px system-ui,sans-serif';x.textAlign='left';x.fillText('Level '+lvl,12,22);
  x.fillStyle='#b9f6ca';x.font='600 12px system-ui,sans-serif';x.fillText('Doel: '+lvScore+' / '+target(),12,40);
  x.textAlign='right';x.fillStyle=tl<5&&state===1?'#ff6b6b':'#fff';x.font='800 15px system-ui,sans-serif';x.fillText('⏱ '+Math.ceil(tl)+'s',W-12,22);
  x.fillStyle='#2a2f58';x.fillRect(W-132,32,120,8);x.fillStyle=lvScore>=target()?'#38ef7d':'#ffd86b';x.fillRect(W-132,32,120*Math.min(1,lvScore/target()),8);
  if(state===0){x.fillStyle='rgba(14,16,32,.65)';x.fillRect(0,H/2-50,W,100);x.fillStyle='#fff';x.textAlign='center';x.font='900 24px system-ui,sans-serif';x.fillText('Tik om te starten',W/2,H/2-6);x.font='600 13px system-ui,sans-serif';x.fillStyle='#cfd3f5';x.fillText('Haal per level het doel binnen '+LEN+' seconden',W/2,H/2+20)}
  sc.textContent='Score: '+score+' · Beste: '+best('mole',score)+' · Level '+lvl;
 });
 st.t={get holes(){return holes},get state(){return state},whack};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=null}}},
