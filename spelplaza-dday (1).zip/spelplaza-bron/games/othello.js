{id:'othello',n:'Othello',e:'⚪',c:'Bord',g:'#134e5e,#71b280',nw:1,run(st){
 // Othello / Reversi 8x8. Human = black (begins, as in the official rules), computer = white.
 const sc=E('div','sc');st.append(sc);
 const info=E('div','hint');info.style.minHeight='20px';
 const bd=E('div','bdr');bd.style.cssText+='grid-template-columns:repeat(8,1fr);width:min(380px,100%);gap:3px;padding:5px;background:#0f5a33;border-radius:10px;box-shadow:0 4px 14px rgba(0,0,0,.35)';
 const hint=E('div','hint','Tik op een stip om een schijf te leggen · wie de meeste schijven heeft, wint');
 st.append(info,bd,hint);
 const sq=[],disc=[],dot=[];
 for(let i=0;i<64;i++){const d=E('div');d.style.cssText='background:#2a9d5c;border-radius:4px;position:relative';
  const p=E('span');p.style.cssText='display:none;width:84%;height:84%;border-radius:50%;box-shadow:0 2px 4px rgba(0,0,0,.5);transition:transform .45s ease,background .4s;pointer-events:none;will-change:transform';
  const o=E('span');o.style.cssText='display:none;width:26%;height:26%;border-radius:50%;background:rgba(0,0,0,.35);pointer-events:none';
  d.append(p,o);disc.push(p);dot.push(o);d.onpointerdown=e=>{e.preventDefault();tap(i)};sq.push(d);bd.append(d)}
 // ---------- rules ----------
 const DIRS=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,1],[1,0]];
 function flips(b,i,p){if(b[i])return[];const r=i>>3,c=i&7,out=[];
  for(const[dr,dc]of DIRS){let R=r+dr,C=c+dc,n=0;while(R>=0&&R<8&&C>=0&&C<8&&b[R*8+C]===-p){R+=dr;C+=dc;n++}
   if(n&&R>=0&&R<8&&C>=0&&C<8&&b[R*8+C]===p){R-=dr;C-=dc;while(n--){out.push(R*8+C);R-=dr;C-=dc}}}
  return out}
 function legal(b,p){const m=[];for(let i=0;i<64;i++)if(!b[i]&&flips(b,i,p).length)m.push(i);return m}
 function play(b,i,p){const nb=b.slice(),f=flips(b,i,p);nb[i]=p;for(const j of f)nb[j]=p;return nb}
 // ---------- AI ----------
 const W=[100,-25,12,6,6,12,-25,100,-25,-45,-3,-2,-2,-3,-45,-25,12,-3,2,1,1,2,-3,12,6,-2,1,0,0,1,-2,6,6,-2,1,0,0,1,-2,6,12,-3,2,1,1,2,-3,12,-25,-45,-3,-2,-2,-3,-45,-25,100,-25,12,6,6,12,-25,100];
 const CN=[[0,[1,8,9]],[7,[6,14,15]],[56,[48,49,57]],[63,[54,55,62]]];
 function evalB(b,p){let e=0,cnt=0;for(let i=0;i<64;i++){const v=b[i];if(v){e+=v*p*W[i];cnt++}}
  for(const[c,ns]of CN)if(b[c])for(const n of ns)e-=b[n]*p*W[n];// corner taken: X/C squares are no longer bad
  e+=6*(legal(b,p).length-legal(b,-p).length);
  if(cnt>50){let d=0;for(const v of b)d+=v;e+=3*d*p}
  return e}
 function final(b,p){let d=0;for(const v of b)d+=v;d*=p;return d>0?10000+d:d<0?-10000+d:0}
 let nodes=0;
 function search(b,p,d,a,be,ex){nodes++;const ms=legal(b,p);
  if(!ms.length){if(!legal(b,-p).length)return final(b,p);return-search(b,-p,d,-be,-a,ex)}
  if(d<=0)return evalB(b,p);
  if(ms.length>1)ms.sort((x,y)=>W[y]-W[x]);
  let best=-Infinity;for(const i of ms){const v=-search(play(b,i,p),-p,d-1,-be,-a,ex);if(v>best)best=v;if(v>a)a=v;if(a>=be)break}return best}
 let depth=4,lastMs=0;
 function root(b,p,ms,D){let bm=ms[0],bv=-Infinity,a=-Infinity;
  for(const i of ms){const v=-search(play(b,i,p),-p,D-1,-Infinity,-a,0);if(v>bv){bv=v;bm=i}if(v>a)a=v}
  return bm}
 function bestMove(b,p,fd){nodes=0;const ms=legal(b,p);if(!ms.length)return-1;if(ms.length===1)return ms[0];
  let empt=0;for(const v of b)if(!v)empt++;for(let i=ms.length-1;i>0;i--){const j=R(i+1);[ms[i],ms[j]]=[ms[j],ms[i]]}ms.sort((x,y)=>W[y]-W[x]);// shuffle, then stable sort = variety among equal moves
  const t0=performance.now();depth=fd||(empt<=12?empt:4);let m=root(b,p,ms,depth);// exact search in the last 12 empties
  if(!fd&&depth===4&&performance.now()-t0<20){depth=5;m=root(b,p,ms,5)}// cheap position: one ply deeper
  return m}
 // ---------- state ----------
 let b,t,over,lastI,lastF,busy,tm=0,flipN;
 const cnt=p=>b.reduce((n,v)=>n+(v===p),0);
 function draw(){const lg=t===1&&!busy&&!over?legal(b,1):[];
  for(let i=0;i<64;i++){const v=b[i],p=disc[i];sq[i].style.boxShadow=i===lastI?'inset 0 0 0 3px #ffd54a':'none';
   if(!v){p.style.display='none';p.dataset.v='';dot[i].style.display=lg.includes(i)?'block':'none';continue}
   dot[i].style.display='none';
   const was=p.dataset.v;p.dataset.v=v;const bg=v===1?'radial-gradient(circle at 35% 35%,#555,#1a1a1a 60%,#000)':'radial-gradient(circle at 35% 35%,#fff,#e4e4e4 60%,#a8a8a8)';
   if(!was){p.style.display='block';p.style.transition='none';p.style.transform='scale(0)';p.style.background=bg;void p.offsetWidth;p.style.transition='transform .3s ease,background .4s';p.style.transform='scale(1)'}
   else if(+was!==v){flipN[i]=(flipN[i]||0)+1;p.style.transform='rotateY('+flipN[i]*180+'deg)';p.style.background=bg}}
  const B=cnt(1),Wc=cnt(-1);
  sc.textContent='⚫ Jij '+B+' – '+Wc+' Computer ⚪ · '+(over?over:busy?'🤖 Computer denkt…':'Jij bent aan zet')}
 function tap(i){if(over||busy||t!==1||b[i])return;if(!flips(b,i,1).length)return;move(i)}
 function move(i){b=play(b,i,t);lastI=i;beep(t===1?520:400,.05,'square',.03);t=-t;next()}
 function next(){const my=legal(b,t).length,th=legal(b,-t).length;
  if(!my&&!th){const B=cnt(1),Wc=cnt(-1);over=B>Wc?'Jij wint! 🎉':Wc>B?'De computer wint 🤖':'Gelijkspel';beep(B>Wc?880:B<Wc?160:330,.35,B>Wc?'triangle':'sawtooth',.05);busy=0;info.textContent='Eindstand '+B+' – '+Wc;draw();return}
  if(!my){info.textContent=t===1?'Je kunt niet zetten – je moet passen.':'De computer kan niet zetten en past.';t=-t;if(t===-1){busy=1;draw();tm=setTimeout(aiMove,900);return}busy=0;draw();return}
  info.textContent='';
  if(t===-1){busy=1;draw();tm=setTimeout(aiMove,300)}else{busy=0;draw()}}
 function aiMove(){tm=0;const t0=performance.now();const i=bestMove(b,-1);lastMs=performance.now()-t0;busy=0;if(i<0){t=1;next();return}move(i)}
 function init(){clearTimeout(tm);tm=0;b=Array(64).fill(0);b[27]=-1;b[36]=-1;b[28]=1;b[35]=1;t=1;over='';lastI=-1;busy=0;flipN={};info.textContent='';
  disc.forEach(p=>{p.dataset.v='';p.style.display='none'});draw()}
 window._oth={auto:1,board:()=>b.slice(),legal:()=>legal(b,t),state:()=>({over,turn:t,busy}),
  move(i){if(over||busy||b[i]||!flips(b,i,t).length)return false;b=play(b,i,t);lastI=i;t=-t;if(this.auto)next();else draw();return true},
  set(arr,side){clearTimeout(tm);b=arr.slice();t=side;over='';busy=0;lastI=-1;if(this.auto)next();else draw()},
  ai(d){clearTimeout(tm);const t0=performance.now();const i=bestMove(b,t,d);const ms=performance.now()-t0;if(i>=0){b=play(b,i,t);lastI=i;t=-t;draw()}return{ms,nodes,i,depth}}};
 init();cur.reset=init;return()=>{clearTimeout(tm);tm=0;delete window._oth}}},
