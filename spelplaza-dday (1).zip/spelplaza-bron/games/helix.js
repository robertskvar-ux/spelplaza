{id:'helix',n:'Helix Spring',e:'🌀',c:'3D',g:'#ff5f6d,#ffc371',nw:1,run(st){
 const W=360,H=520,T=three(st,W,H,{fov:55,far:90}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','Sleep of ◀ ▶ = toren draaien · val door de gaten · rood = af · 3 ringen in één val = 🔥 smash'));
 const BG=0xffe0c8;S.background=new THREE.Color(BG);S.fog=new THREE.Fog(BG,9,30);
 const sun=new THREE.DirectionalLight(0xfff6ea,2.6);sun.position.set(4,8,7);S.add(sun,new THREE.HemisphereLight(0xfff0e0,0x7a4455,.9));
 const M=(col,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:col,roughness:.6,metalness:.05},o));
 const N=8,TH=Math.PI*2/N,RO=2.3,RI=.62,RH=.42,GAP=3.3,NR=14,BR=.33,BZ=1.45;
 const shape=new THREE.Shape();shape.absarc(0,0,RO,.012,TH-.012,false);shape.absarc(0,0,RI,TH-.012,.012,true);
 const segG=new THREE.ExtrudeGeometry(shape,{depth:RH,bevelEnabled:false,curveSegments:10});segG.rotateX(Math.PI/2);
 const redM=M(0xe63946,{roughness:.5}),splatG=new THREE.CircleGeometry(.28,14),splatM=new THREE.MeshBasicMaterial({color:0xff4f6d,transparent:true,opacity:.9});
 const tower=new THREE.Group();S.add(tower);
 const pillar=new THREE.Mesh(new THREE.CylinderGeometry(RI-.06,RI-.06,80,24),M(0xfaf3ec,{roughness:.8}));S.add(pillar);
 const rings=[];for(let i=0;i<NR;i++){const g=new THREE.Group(),m=M(0x88aaff),segs=[];for(let k=0;k<N;k++){const s=new THREE.Mesh(segG,m);s.rotation.y=-k*TH;g.add(s);segs.push(s)}
  const sp=new THREE.Mesh(splatG,splatM);sp.rotation.x=-Math.PI/2;sp.position.y=.012;sp.visible=false;g.add(sp);g.userData={segs,m,sp,t:[],idx:i,broken:0,bt:0};tower.add(g);rings.push(g)}
 const ballM=M(0xff4f6d,{roughness:.35,emissive:0x000000}),ball=new THREE.Mesh(new THREE.SphereGeometry(BR,22,16),ballM);S.add(ball);
 const trail=[];for(let i=0;i<7;i++){const t=new THREE.Mesh(new THREE.SphereGeometry(BR*(.8-i*.09),10,8),new THREE.MeshBasicMaterial({color:0xffa94d,transparent:true,opacity:.5-i*.06}));t.visible=false;S.add(t);trail.push(t)}
 let by,vy,score,over,sq,fallN,smash,camY,drag,dead,t,pbot,bestS,deadAt=0;const canRe=()=>over&&performance.now()-deadAt>700;
 function conf(g,idx){const u=g.userData;u.idx=idx;u.broken=0;u.bt=0;g.position.y=-idx*GAP;u.sp.visible=false;u.m.color.setHSL((.56+idx*.045)%1,.6,.58);
  const tp=new Array(N).fill(1),g0=idx?R(N):3+R(N-2),gw=idx>4&&Math.random()<.35?2:1;for(let k=0;k<gw;k++)tp[(g0+k)%N]=0;
  const nr=idx===0?0:idx<5?(Math.random()<.6?1:0):1+(Math.random()<.5?1:0);for(let k=0;k<nr;k++){const p=(g0+gw+R(N-gw))%N;if(tp[p]===1)tp[p]=2}
  u.t=tp;u.segs.forEach((s,k)=>{s.visible=tp[k]>0;s.material=tp[k]===2?redM:u.m;s.position.set(0,0,0);s.rotation.set(0,-k*TH,0);s.scale.setScalar(1)})}
 function init(){by=1.4;vy=0;score=0;over=0;sq=0;fallN=0;smash=0;camY=0;drag=0;dead=0;t=0;pbot=by;tower.rotation.y=0;bestS=best('helix',0);
  rings.forEach((g,i)=>conf(g,i));ball.scale.setScalar(1);ballM.color.set(0xff4f6d);ballM.emissive.set(0);trail.forEach(x=>x.visible=false);overlay(st,c,'')}
 const segAt=()=>{let a=Math.PI/2+tower.rotation.y;a=((a%(2*Math.PI))+2*Math.PI)%(2*Math.PI);return Math.floor(a/TH)};
 function splat(g){const u=g.userData,v=tower.worldToLocal(new THREE.Vector3(0,0,BZ));u.sp.position.x=v.x;u.sp.position.z=v.z;u.sp.visible=true;u.sp.rotation.z=Math.random()*6}
 function breakRing(g){const u=g.userData;u.broken=1;u.bt=0;beep(220,.12,'square',.05);setTimeout(()=>beep(330,.1,'square',.04),60)}
 function die(){over=1;dead=0;deadAt=performance.now();best('helix',score);beep(110,.35,'sawtooth',.06);ballM.color.set(0x8a2a3a);
  overlay(st,c,`💥 Rood!<br><span style="font-size:15px;font-weight:600">${score} ${score===1?'ring':'ringen'} · Beste ${best('helix',score)}<br>Tik of druk op een toets om opnieuw te spelen</span>`).style.pointerEvents='none'}
 const inp=input(st,[['◀','ArrowLeft'],['▶','ArrowRight']],k=>{if(canRe())init()});
 let lx=0,mv=0;const scale=()=>W/c.getBoundingClientRect().width;
 c.onpointerdown=e=>{e.preventDefault();try{c.setPointerCapture(e.pointerId)}catch(x){}drag=1;lx=e.clientX;mv=0};
 c.onpointermove=e=>{if(!drag)return;const dx=(e.clientX-lx)*scale();lx=e.clientX;mv+=Math.abs(dx);if(!over)tower.rotation.y+=dx*.011};
 c.onpointerup=c.onpointercancel=e=>{if(!drag)return;drag=0;if(mv<8&&canRe())init()};
 const stopLoop=loop(dt=>{t+=dt;
  if(!over){if(inp.has('ArrowLeft')||inp.has('a'))tower.rotation.y+=3.2*dt;if(inp.has('ArrowRight')||inp.has('d'))tower.rotation.y-=3.2*dt;
   vy-=22*dt;by+=vy*dt;
   if(vy<0){for(const g of rings){const u=g.userData;if(u.broken)continue;const top=g.position.y;if(pbot>=top&&by<top){const k=segAt();
     if(u.t[k]===0){const n=u.idx+1;if(n>score){score=n;fallN++;beep(660+Math.min(6,fallN)*60,.05,'sine',.03)}if(fallN>=3&&!smash){smash=1;ballM.emissive.set(0xff6a00);ballM.color.set(0xffb347)}}
     else if(smash){breakRing(g);score=Math.max(score,u.idx+1);fallN=0;smash=0;ballM.emissive.set(0);ballM.color.set(0xff4f6d)}
     else if(u.t[k]===2){by=top;die();break}
     else{by=top;vy=8.6;sq=1;fallN=0;splat(g);beep(420+u.idx%5*40,.06,'triangle',.04)}
     break}}}
   pbot=by;
   const cur=Math.floor(-by/GAP);for(const g of rings){const u=g.userData;if(u.idx<cur-2)conf(g,u.idx+NR)}
   camY=Math.min(camY,by)}
  else dead+=dt;
  sq=Math.max(0,sq-dt*6);const ss=over?.45:1-sq*.42;ball.scale.set(over?1.5:1+sq*.3,ss,over?1.5:1+sq*.3);ball.position.set(0,by+BR*ss,BZ);
  for(const g of rings){const u=g.userData;if(u.broken&&u.bt<1.2){u.bt+=dt;u.segs.forEach((s,k)=>{if(!s.visible)return;const a=k*TH+TH/2;s.position.x+=Math.cos(a)*dt*4;s.position.z+=Math.sin(a)*dt*4;s.position.y-=u.bt*u.bt*9*dt;s.rotation.x+=dt*3;if(u.bt>1.15)s.visible=false})}}
  if(smash&&!over){for(let i=trail.length-1;i>0;i--){trail[i].position.copy(trail[i-1].position);trail[i].visible=trail[i-1].visible}trail[0].position.set(0,by+BR+.1,BZ);trail[0].visible=true}else trail.forEach(x=>x.visible=false);
  pillar.position.y=by-20;
  cam.position.y+=((camY+3.6)-cam.position.y)*Math.min(1,dt*5);cam.position.set(0,cam.position.y,8.6);cam.lookAt(0,cam.position.y-4.4,0);
  sc.textContent='Ringen: '+score+(smash?' 🔥':'')+' · Beste: '+Math.max(bestS,score)+(over?' · Af':'');
  T.r.render(S,cam)});
 init();cur.reset=init;
 return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;T.dispose()}}},
