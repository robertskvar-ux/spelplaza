{id:'bubble',n:'Bellenschieter',e:'🫧',c:'Arcade',g:'#00c6ff,#7b2ff7',nw:1,run(st){
 // Bubble shooter: hex-rooster, mikken met slepen / ◀▶, schieten bij loslaten / spatie, 3+ gelijk knalt, losse bellen vallen (bonus).
 const W=360,H=480,BR=15,RH=26,CO=12,DEAD=15,NR=DEAD+2,SX=180,SY=446,NX=86,NY=458;
 const c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);c.style.cssText='display:block;margin:0 auto';
 const COL=['#ff4d6d','#3a8bff','#2ee59d','#ffd23f','#b56bff','#ff8c42'];
 // vooraf getekende bel-sprites
 const SPR=COL.map(col=>{const o=document.createElement('canvas');o.width=o.height=34;const q=o.getContext('2d'),gr=q.createRadialGradient(12,11,2,17,17,17);
  gr.addColorStop(0,'#fff');gr.addColorStop(.22,col);gr.addColorStop(1,'rgba(0,0,0,.55)');q.fillStyle=gr;q.beginPath();q.arc(17,17,BR,0,7);q.fill();
  q.strokeStyle='rgba(255,255,255,.28)';q.lineWidth=1.2;q.stroke();q.fillStyle='rgba(255,255,255,.55)';q.beginPath();q.ellipse(12,10,4.5,2.6,-.6,0,7);q.fill();return o});
 let g,par,score,level,left,per,ang,cu,nx,shot,pops,falls,parts,over,msg,msgT,aiming,shiftY,nextLvl,nc,swapA,tm=0;
 const off=r=>(r+par)&1,ncol=r=>off(r)?CO-1:CO,cxp=(r,k)=>BR+k*2*BR+(off(r)?BR:0),cyp=r=>BR+r*RH+shiftY;
 const emptyRow=()=>Array(CO).fill(-1);
 function nbr(r,k){const o=off(r),L=[[r,k-1],[r,k+1],[r-1,k-(o?0:1)],[r-1,k+(o?1:0)],[r+1,k-(o?0:1)],[r+1,k+(o?1:0)]];return L.filter(([a,b])=>a>=0&&a<NR&&b>=0&&b<ncol(a))}
 function present(){const s=new Set;for(const row of g)for(const v of row)if(v>=0)s.add(v);return[...s]}
 function pick(){const p=present();return p.length?p[R(p.length)]:R(nc)}
 function randRow(r){const row=emptyRow();for(let k=0;k<ncol(r);k++){row[k]=Math.random()<.45&&k>0?row[k-1]:R(nc)}return row}
 function newLevel(){par=0;shiftY=0;nc=Math.min(6,4+((level-1)>>1));per=Math.max(3,7-level);left=per;g=[];const rows=Math.min(4+level,9);
  for(let r=0;r<NR;r++){if(r<rows){const row=randRow(r);if(r>0)for(let k=0;k<ncol(r);k++)if(Math.random()<.35){const up=g[r-1][Math.min(k,ncol(r-1)-1)];if(up>=0)row[k]=up}g.push(row)}else g.push(emptyRow())}
  cu=pick();nx=pick();shot=null;nextLvl=0}
 function init(){score=0;level=1;over=0;ang=0;pops=[];falls=[];parts=[];msg='Level 1';msgT=1.2;aiming=0;swapA=0;newLevel();overlay(st,c,'')}
 function addRow(){const t=g.pop();if(t.some(v=>v>=0)){gameOver();return}par^=1;g.unshift(emptyRow());g[0]=randRow(0);shiftY=-RH;beep(140,.12,'triangle',.05);check()}
 function flood(r,k,same){const seen=new Set([r*CO+k]),st2=[[r,k]],out=[];while(st2.length){const[a,b]=st2.pop();out.push([a,b]);for(const[p,q]of nbr(a,b)){const id=p*CO+q;if(seen.has(id)||g[p][q]<0)continue;if(same&&g[p][q]!==g[r][k])continue;seen.add(id);st2.push([p,q])}}return out}
 function snap(px,py){let bst=null,bd=1e9;const r0=Math.round((py-shiftY-BR)/RH);
  for(let r=Math.max(0,r0-1);r<=Math.min(NR-1,r0+1);r++)for(let k=0;k<ncol(r);k++){if(g[r][k]>=0)continue;if(r>0&&!nbr(r,k).some(([a,b])=>g[a][b]>=0))continue;
   const d=Math.hypot(cxp(r,k)-px,cyp(r)-py);if(d<bd){bd=d;bst=[r,k]}}return bst}
 function hits(px,py){if(py<=BR+shiftY)return 1;const r0=Math.round((py-shiftY-BR)/RH);for(let r=Math.max(0,r0-1);r<=Math.min(NR-1,r0+1);r++)for(let k=0;k<ncol(r);k++)if(g[r][k]>=0&&Math.hypot(cxp(r,k)-px,cyp(r)-py)<2*BR-5)return 1;return 0}
 function land(px,py,col){const s=snap(px,py);if(!s){gameOver();return}const[r,k]=s;g[r][k]=col;
  const cl=flood(r,k,1);if(cl.length>=3){for(const[a,b]of cl){pops.push({x:cxp(a,b),y:cyp(a),c:g[a][b],t:0});burst(cxp(a,b),cyp(a),g[a][b],5);g[a][b]=-1}score+=cl.length*10;beep(520+Math.min(cl.length,8)*50,.07,'triangle',.04);
   const keep=new Set;for(let k2=0;k2<ncol(0);k2++)if(g[0][k2]>=0)for(const[a,b]of flood(0,k2,0))keep.add(a*CO+b);let nf=0;
   for(let a=0;a<NR;a++)for(let b=0;b<ncol(a);b++)if(g[a][b]>=0&&!keep.has(a*CO+b)){falls.push({x:cxp(a,b),y:cyp(a),vx:(Math.random()-.5)*120,vy:-Math.random()*150,c:g[a][b]});g[a][b]=-1;nf++}
   if(nf){const b=nf*20*(nf>=6?2:1);score+=b;msg='Vallers +'+b;msgT=.9;tm=setTimeout(()=>beep(880,.1,'sine',.04),90)}}
  else{beep(300,.04,'sine',.03);left--;if(left<=0){left=per;addRow();if(over)return}}
  check()}
 function check(){if(over)return;for(let r=DEAD;r<NR;r++)if(g[r].some(v=>v>=0)){gameOver();return}
  if(!present().length&&!nextLvl){const b=500*level;score+=b;msg='Level '+level+' gehaald! +'+b;msgT=1.6;nextLvl=1.6;beep(660,.12,'triangle',.05);tm=setTimeout(()=>beep(990,.2,'triangle',.05),140);return}
  const p=present();if(p.length){if(!p.includes(cu))cu=pick();if(!p.includes(nx))nx=pick()}}
 function gameOver(){over=1;shot=null;beep(150,.4,'sawtooth',.05);const b=best('bubble',score);
  const o=overlay(st,c,`De bellen zijn te laag! 🫧<br><span style="font-size:15px;font-weight:600">Level ${level} · Score ${score} · Beste ${b}<br>Tik of druk op spatie om opnieuw te spelen</span>`);o.onpointerdown=e=>{e.preventDefault();init()}}
 function burst(px,py,col,n){for(let i=0;i<n;i++)parts.push({x:px,y:py,vx:(Math.random()-.5)*240,vy:(Math.random()-.7)*240,l:.3+Math.random()*.3,c:COL[col]})}
 function fire(){if(over||shot||nextLvl||shiftY<0)return;shot={x:SX,y:SY,vx:Math.sin(ang)*720,vy:-Math.cos(ang)*720,c:cu};cu=nx;nx=pick();beep(700,.03,'square',.025)}
 function swap(){if(over||nextLvl)return;[cu,nx]=[nx,cu];swapA=1;beep(440,.04,'sine',.03)}
 const clampA=a=>Math.max(-1.4,Math.min(1.4,a));
 function aimAt(px,py){ang=clampA(Math.atan2(px-SX,SY-py))}
 function pt(e){const b=c.getBoundingClientRect();return[(e.clientX-b.left)*W/b.width,(e.clientY-b.top)*H/b.height]}
 c.onpointerdown=e=>{e.preventDefault();if(over){init();return}const[px,py]=pt(e);if(Math.hypot(px-NX,py-NY)<26){swap();return}aiming=1;try{c.setPointerCapture(e.pointerId)}catch(_){}if(py<SY-8)aimAt(px,py)};
 c.onpointermove=e=>{if(!aiming)return;const[px,py]=pt(e);if(py<SY-8)aimAt(px,py)};
 c.onpointerup=e=>{if(!aiming)return;aiming=0;const[,py]=pt(e);if(py<SY-8)fire()};c.onpointercancel=()=>{aiming=0};
 function press(k){if(over){if(k===' '||k==='Enter')init();return}if(k===' '||k==='ArrowUp'||k==='Enter')fire();else if(k==='ArrowDown'||k==='s')swap()}
 const inp=input(st,[['◀','ArrowLeft'],['🔄','ArrowDown'],['🔥',' '],['▶','ArrowRight']],press);
 st.append(E('div','hint','Sleep op het speelveld om te mikken, loslaten = schieten · tik op de volgende bel (of ↓) om te wisselen · ◀ ▶ + spatie'));
 // ---------- tekenen ----------
 function guide(){let px=SX,py=SY,vx=Math.sin(ang)*6,vy=-Math.cos(ang)*6,d=0;x.fillStyle='#fff';
  for(let i=0;i<260;i++){px+=vx;py+=vy;if(px<BR){px=2*BR-px;vx=-vx}if(px>W-BR){px=2*(W-BR)-px;vx=-vx}if(hits(px,py))break;
   if(i%3===0&&i>3){x.globalAlpha=.55*(1-i/260);x.beginPath();x.arc(px,py,2.2,0,7);x.fill()}}x.globalAlpha=1;
  const s=snap(px,py);if(s){x.strokeStyle='rgba(255,255,255,.35)';x.setLineDash([3,3]);x.lineWidth=1.5;x.beginPath();x.arc(cxp(s[0],s[1]),cyp(s[0]),BR-1,0,7);x.stroke();x.setLineDash([])}}
 const spr=(col,px,py,s=1)=>{const d=34*s;x.drawImage(SPR[col],px-d/2,py-d/2,d,d)};
 function draw(){const bg=x.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#141a3a');bg.addColorStop(1,'#0e1020');x.fillStyle=bg;x.fillRect(0,0,W,H);
  x.fillStyle='rgba(255,255,255,.05)';x.fillRect(0,0,W,3);
  const dl=BR+DEAD*RH-BR+4;x.strokeStyle='rgba(255,77,109,.45)';x.setLineDash([6,6]);x.lineWidth=1.5;x.beginPath();x.moveTo(0,dl);x.lineTo(W,dl);x.stroke();x.setLineDash([]);
  for(let r=0;r<NR;r++)for(let k=0;k<ncol(r);k++)if(g[r][k]>=0)spr(g[r][k],cxp(r,k),cyp(r));
  if(!over&&!shot&&!nextLvl)guide();
  for(const p of pops){x.globalAlpha=1-p.t/.2;spr(p.c,p.x,p.y,1+p.t*2.5)}x.globalAlpha=1;
  for(const f of falls)spr(f.c,f.x,f.y);
  for(const p of parts){x.globalAlpha=Math.min(1,p.l*3);x.fillStyle=p.c;x.beginPath();x.arc(p.x,p.y,2.2,0,7);x.fill()}x.globalAlpha=1;
  if(shot)spr(shot.c,shot.x,shot.y);
  // kanon
  x.save();x.translate(SX,SY);x.rotate(ang);const cg=x.createLinearGradient(-9,0,9,0);cg.addColorStop(0,'#5b6cff');cg.addColorStop(1,'#a77bff');x.fillStyle=cg;x.beginPath();x.roundRect(-8,-38,16,34,5);x.fill();x.restore();
  x.fillStyle='#262c56';x.beginPath();x.arc(SX,SY+6,24,Math.PI,0);x.fill();
  if(!over)spr(cu,SX,SY,1+(swapA>0?swapA*.3:0));
  x.fillStyle='rgba(255,255,255,.08)';x.beginPath();x.arc(NX,NY,19,0,7);x.fill();spr(nx,NX,NY,.8);
  x.fillStyle='rgba(255,255,255,.6)';x.font='bold 10px system-ui,sans-serif';x.textAlign='center';x.fillText('VOLGENDE',NX,NY-22);
  // misser-teller tot de plafonddaling
  x.textAlign='left';x.fillText('ZAKT OVER',258,NY-22);for(let i=0;i<per;i++){x.fillStyle=i<left?'#ffd23f':'rgba(255,255,255,.15)';x.beginPath();x.arc(262+i*14,NY-6,4.5,0,7);x.fill()}
  if(msgT>0){const a=Math.min(1,msgT*3);x.fillStyle=`rgba(14,16,32,${.75*a})`;x.fillRect(0,H/2-24,W,48);x.fillStyle=`rgba(255,255,255,${a})`;x.font='bold 22px system-ui,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(msg,W/2,H/2);x.textBaseline='alphabetic'}
  sc.textContent='Level '+level+' · Score '+score+' · Beste: '+best('bubble',score)}
 const stopLoop=loop(dt=>{
  if(msgT>0)msgT-=dt;if(swapA>0)swapA=Math.max(0,swapA-dt*5);if(shiftY<0)shiftY=Math.min(0,shiftY+RH*dt*4);
  if(nextLvl){nextLvl-=dt;if(nextLvl<=0){level++;newLevel();msg='Level '+level;msgT=1}}
  if(!over){if(inp.has('ArrowLeft'))ang=clampA(ang-1.8*dt);if(inp.has('ArrowRight'))ang=clampA(ang+1.8*dt)}
  if(shot){const n=Math.ceil(Math.hypot(shot.vx,shot.vy)*dt/4);for(let i=0;i<n&&shot;i++){shot.x+=shot.vx*dt/n;shot.y+=shot.vy*dt/n;
    if(shot.x<BR){shot.x=2*BR-shot.x;shot.vx*=-1;beep(900,.015,'sine',.015)}if(shot.x>W-BR){shot.x=2*(W-BR)-shot.x;shot.vx*=-1;beep(900,.015,'sine',.015)}
    if(hits(shot.x,shot.y)){const s=shot;shot=null;land(s.x,s.y,s.c)}}}
  pops=pops.filter(p=>(p.t+=dt)<.2);falls=falls.filter(f=>{f.vy+=1100*dt;f.x+=f.vx*dt;f.y+=f.vy*dt;return f.y<H+30});
  parts=parts.filter(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=600*dt;p.l-=dt;return p.l>0});
  draw()});
 window._bub={state:()=>({score,level,left,over,cu,nx,shot:!!shot,n:g.flat().filter(v=>v>=0).length}),grid:()=>g.map(r=>r.slice()),par:()=>par,aim:a=>{ang=clampA(a)},fire,set(r,k,v){g[r][k]=v},pos:(r,k)=>[cxp(r,k),cyp(r)],setCur(v){cu=v}};
 init();cur.reset=init;
 return()=>{stopLoop();clearTimeout(tm);inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;delete window._bub}}},
