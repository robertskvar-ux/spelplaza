{id:'towerdef',n:'Torenverdediging',e:'🏰',c:'Arcade',g:'#56ab2f,#a8e063',nw:1,run(st){
 // Tower defense: 12x14 tegels, 4 torens (pijl, kanon, ijs, laser), upgrades, 20 golven met snelle, tank-, vlieg- en baasvijanden.
 const W=360,H=480,T=30,CO=12,RO=14,MH=RO*T,MAXW=20;
 const c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);c.style.cssText='display:block;margin:0 auto';
 const bar=E('div');bar.style.cssText='display:flex;gap:8px;justify-content:center;margin-top:8px';
 const bN=E('button','btn','▶ Volgende golf'),bF=E('button','btn','⏩ ×1');bar.append(bN,bF);
 st.append(bar,E('div','hint','Kies onderaan een toren en tik op het gras · tik op een toren om te verbeteren of te verkopen · 1-4 kies, pijltjes + spatie plaatsen, u/v, n = golf, f = snelheid'));
 const WP=[[1,-1],[1,2],[10,2],[10,5],[2,5],[2,8],[9,8],[9,11],[4,11],[4,14.2]].map(([a,b])=>[a*T+T/2,b*T+T/2]);
 const path=new Set,cum=[0];for(let i=1;i<WP.length;i++){const[a,b]=WP[i-1],[p,q]=WP[i];cum.push(cum[i-1]+Math.hypot(p-a,q-b));
  const n=Math.ceil(Math.hypot(p-a,q-b)/T);for(let k=0;k<=n;k++){const cx=Math.floor((a+(p-a)*k/n)/T),cy=Math.floor((b+(q-b)*k/n)/T);if(cy>=0&&cy<RO)path.add(cy*CO+cx)}}
 const LEN=cum[cum.length-1];
 function at(d){let i=1;while(i<cum.length-1&&cum[i]<d)i++;const f=(d-cum[i-1])/(cum[i]-cum[i-1]);return[WP[i-1][0]+(WP[i][0]-WP[i-1][0])*f,WP[i-1][1]+(WP[i][1]-WP[i-1][1])*f]}
 const TT=[{n:'Pijl',col:'#3ad07a',cost:50,rng:82,rate:1.7,dmg:9,air:1},{n:'Kanon',col:'#ff8c42',cost:90,rng:74,rate:.65,dmg:24,spl:38,air:0},
  {n:'IJs',col:'#5ad8ff',cost:70,rng:66,rate:1,dmg:4,spl:26,slow:1.6,air:1},{n:'Laser',col:'#ff4dd2',cost:140,rng:100,dps:26,air:1}];
 const ET={n:{hp:30,sp:42,r:8,col:'#ff5a5a',rw:5},s:{hp:18,sp:84,r:6,col:'#ffd23f',rw:6},t:{hp:130,sp:25,r:11,col:'#9b6bff',rw:14},f:{hp:42,sp:52,r:8,col:'#7fe6ff',rw:10,fly:1},b:{hp:1400,sp:19,r:15,col:'#ff3b7a',rw:120}};
 // achtergrond één keer tekenen
 const bgc=document.createElement('canvas');bgc.width=W;bgc.height=MH;{const q=bgc.getContext('2d');for(let r=0;r<RO;r++)for(let k=0;k<CO;k++){q.fillStyle=(r+k)%2?'#2f6b3a':'#2b6435';q.fillRect(k*T,r*T,T,T)}
  let s=7;const rn=()=>(s=(s*16807)%2147483647)/2147483647;for(let i=0;i<140;i++){q.fillStyle=rn()<.5?'rgba(160,230,120,.18)':'rgba(10,40,15,.25)';q.fillRect(rn()*W,rn()*MH,2,3)}
  q.lineCap='round';q.lineJoin='round';q.strokeStyle='#6b4e2e';q.lineWidth=T+2;q.beginPath();WP.forEach(([a,b],i)=>i?q.lineTo(a,b):q.moveTo(a,b));q.stroke();
  q.strokeStyle='#c9a56a';q.lineWidth=T-6;q.stroke();q.strokeStyle='rgba(255,255,255,.08)';q.lineWidth=2;q.setLineDash([4,8]);q.stroke()}
 let hv=null,tw,en,pr,fx,money,lives,wave,queue,spT,score,over,won,sel,shop,spd,cx0,cy0,kbOn,msg,msgT,active,tm=0;
 function init(){tw=[];en=[];pr=[];fx=[];money=160;lives=20;wave=0;queue=[];spT=0;score=0;over=0;won=0;sel=null;shop=0;spd=1;cx0=5;cy0=0;kbOn=0;msg='Bouw torens en start de golf!';msgT=2.5;active=0;bF.textContent='⏩ ×1';overlay(st,c,'')}
 const hpMul=w=>Math.pow(1.21,w-1)*(1+w*.03);
 function startWave(){if(over||wave>=MAXW||queue.length)return;if(active&&en.length){money+=10;fx.push({t:'txt',x:W/2,y:200,s:'Vroeg! +10',l:1})}
  wave++;active=1;const n=8+wave*2;queue=[];for(let i=0;i<n;i++){let k='n';const r=Math.random();if(wave>=3&&r<.3)k='s';if(wave>=5&&r>.78)k='t';if(wave>=7&&r>.55&&r<.72)k='f';queue.push({k,dl:k==='s'?.42:.75})}
  if(wave%10===0)queue.push({k:'b',dl:1.2});msg='Golf '+wave+(wave%10===0?' — BAAS!':'');msgT=1.4;beep(330,.1,'triangle',.04);tm=setTimeout(()=>beep(440,.12,'triangle',.04),110)}
 function spawn(k){const e=ET[k];en.push({k,hp:e.hp*hpMul(wave),mx:e.hp*hpMul(wave),sp:e.sp,r:e.r,col:e.col,rw:e.rw,fly:!!e.fly,d:0,sl:0,ph:Math.random()*6})}
 const costUp=t=>Math.round(TT[t.ty].cost*.75*t.lv),sellV=t=>Math.round(t.inv*.6);
 const stat=t=>{const b=TT[t.ty],m=Math.pow(1.55,t.lv-1);return{rng:b.rng+(t.lv-1)*12,rate:(b.rate||0)*(1+(t.lv-1)*.15),dmg:(b.dmg||0)*m,dps:(b.dps||0)*m,spl:b.spl,slow:b.slow,air:b.air}};
 const towerAt=(k,r)=>tw.find(t=>t.c===k&&t.r===r);
 function place(k,r){if(over)return;const t=towerAt(k,r);if(t){sel=sel===t?null:t;beep(500,.03,'sine',.02);return}sel=null;
  if(r<0||r>=RO||k<0||k>=CO||path.has(r*CO+k))return;const b=TT[shop];if(money<b.cost){msg='Te weinig geld';msgT=.9;beep(150,.08,'square',.03);return}
  money-=b.cost;tw.push({ty:shop,c:k,r,lv:1,inv:b.cost,cd:0,a:-Math.PI/2,tg:null});beep(600,.05,'triangle',.04);fx.push({t:'ring',x:k*T+T/2,y:r*T+T/2,l:.4})}
 function upgrade(){const t=sel;if(!t||t.lv>=3)return;const cst=costUp(t);if(money<cst){msg='Te weinig geld';msgT=.9;beep(150,.08,'square',.03);return}money-=cst;t.inv+=cst;t.lv++;beep(780,.08,'triangle',.04);fx.push({t:'ring',x:t.c*T+T/2,y:t.r*T+T/2,l:.4})}
 function sell(){const t=sel;if(!t)return;money+=sellV(t);tw=tw.filter(q=>q!==t);sel=null;beep(300,.06,'sine',.035)}
 function panel(t){const px=Math.max(4,Math.min(W-124,t.c*T+T/2-60)),py=t.r*T<70?t.r*T+T+6:t.r*T-46;return{x:px,y:py,w:120,h:40}}
 function hurt(e,dm){if(e.hp<=0)return;e.hp-=dm;if(e.hp<=0){money+=e.rw;score+=e.rw*10;fx.push({t:'txt',x:e.x,y:e.y,s:'+'+e.rw,l:.8});for(let i=0;i<8;i++)fx.push({t:'p',x:e.x,y:e.y,vx:(Math.random()-.5)*160,vy:(Math.random()-.5)*160,l:.4,col:e.col});beep(e.k==='b'?120:700+R(200),.03,'square',.02)}}
 function boom(px,py,s,b){for(const e of en)if(Math.hypot(e.x-px,e.y-py)<s.spl+e.r&&(b.air||!e.fly)){hurt(e,s.dmg);if(s.slow)e.sl=s.slow}fx.push({t:'boom',x:px,y:py,r:s.spl,l:.25,col:b.col})}
 function step(dt){if(queue.length){spT-=dt;if(spT<=0){const q=queue.shift();spawn(q.k);spT=q.dl}}
  for(const e of en){const f=e.sl>0?.5:1;e.sl-=dt;e.d+=e.sp*f*dt;const[px,py]=at(e.d);e.x=px;e.y=py-(e.fly?6+Math.sin(e.ph+e.d*.05)*3:0);if(e.d>=LEN){e.hp=0;e.gone=1;lives-=e.k==='b'?5:1;beep(110,.15,'sawtooth',.04);fx.push({t:'flash',l:.3})}}
  for(const t of tw){const s=stat(t),b=TT[t.ty],tx=t.c*T+T/2,ty=t.r*T+T/2;let tg=null,bd=-1;for(const e of en)if(e.hp>0&&(s.air||!e.fly)&&Math.hypot(e.x-tx,e.y-ty)<s.rng+e.r&&e.d>bd){bd=e.d;tg=e}
   t.tg=tg;if(tg)t.a=Math.atan2(tg.y-ty,tg.x-tx);if(t.ty===3){if(tg)hurt(tg,s.dps*dt);continue}
   t.cd-=dt;if(tg&&t.cd<=0){t.cd=1/s.rate;pr.push({ty:t.ty,x:tx+Math.cos(t.a)*12,y:ty+Math.sin(t.a)*12,tg,tx:tg.x,ty2:tg.y,s,b});if(t.ty===1)beep(140,.04,'triangle',.03)}}
  for(const p of pr){const sp=p.ty===1?240:p.ty===2?300:420;if(p.ty!==1&&p.tg.hp>0){p.tx=p.tg.x;p.ty2=p.tg.y}const dx=p.tx-p.x,dy=p.ty2-p.y,d=Math.hypot(dx,dy);
   if(d<sp*dt+2){p.done=1;if(p.ty===0)hurt(p.tg,p.s.dmg);else boom(p.tx,p.ty2,p.s,p.b)}else{p.x+=dx/d*sp*dt;p.y+=dy/d*sp*dt}}
  pr=pr.filter(p=>!p.done);en=en.filter(e=>e.hp>0);if(sel&&!tw.includes(sel))sel=null;
  if(active&&!queue.length&&!en.length){active=0;const b=15+wave*3;money+=b;score+=wave*50;msg='Golf '+wave+' gehaald! +'+b+' 💰';msgT=1.5;beep(660,.1,'triangle',.04);
   if(wave>=MAXW){won=1;end()}}
  if(lives<=0&&!over){lives=0;end()}}
 function end(){over=1;if(won)score+=lives*100;const b=best('towerdef',score);
  const o=overlay(st,c,(won?'🏆 Gewonnen! Alle 20 golven':'💥 Het kasteel is gevallen')+`<br><span style="font-size:15px;font-weight:600">Golf ${wave} · Score ${score} · Beste ${b}<br>Tik of druk op spatie om opnieuw te spelen</span>`);
  o.onpointerdown=e=>{e.preventDefault();init()};beep(won?880:140,.4,won?'triangle':'sawtooth',.05)}
 // ---------- invoer ----------
 c.onpointerdown=e=>{e.preventDefault();if(over){init();return}const b=c.getBoundingClientRect(),px=(e.clientX-b.left)*W/b.width,py=(e.clientY-b.top)*H/b.height;kbOn=0;
  if(sel){const p=panel(sel);if(px>=p.x&&px<=p.x+p.w&&py>=p.y&&py<=p.y+p.h){if(px<p.x+p.w/2)upgrade();else sell();return}}
  if(py>=MH){shop=Math.min(3,Math.floor(px/(W/4)));sel=null;beep(520,.03,'sine',.02);return}place(Math.floor(px/T),Math.floor(py/T))};
 c.onpointermove=e=>{if(e.pointerType!=='mouse'){hv=null;return}const b=c.getBoundingClientRect(),px=(e.clientX-b.left)*W/b.width,py=(e.clientY-b.top)*H/b.height;hv=py<MH?[Math.floor(px/T),Math.floor(py/T)]:null;if(hv)kbOn=0};c.onpointerleave=()=>{hv=null};
 bN.onclick=startWave;bF.onclick=()=>{spd=spd===1?2:1;bF.textContent='⏩ ×'+spd};
 const inp=input(st,[],k=>{if(over){if(k===' '||k==='Enter')init();return}const lk=k.toLowerCase();
  if('1234'.includes(k)&&k.length===1){shop=+k-1;sel=null}else if(lk==='n')startWave();else if(lk==='f')bF.onclick();else if(lk==='u')upgrade();else if(lk==='v')sell();
  else{const d={ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0]}[k];if(d){kbOn=1;cx0=(cx0+d[0]+CO)%CO;cy0=(cy0+d[1]+RO)%RO}else if(k===' '||k==='Enter'){kbOn=1;place(cx0,cy0)}}});
 // ---------- tekenen ----------
 function drawTower(t){const px=t.c*T+T/2,py=t.r*T+T/2,b=TT[t.ty];x.fillStyle='rgba(0,0,0,.3)';x.beginPath();x.ellipse(px+2,py+4,12,8,0,0,7);x.fill();
  x.fillStyle='#4a4f6a';x.beginPath();x.roundRect(px-12,py-12,24,24,6);x.fill();x.fillStyle=b.col;x.beginPath();x.arc(px,py,8,0,7);x.fill();
  x.save();x.translate(px,py);x.rotate(t.a);x.fillStyle='#e9ecff';
  if(t.ty===0){x.fillRect(0,-2,13,4)}else if(t.ty===1){x.fillStyle='#2b2f45';x.fillRect(0,-4.5,14,9)}else if(t.ty===2){x.beginPath();x.moveTo(14,0);x.lineTo(2,-5);x.lineTo(2,5);x.fill()}else{x.fillStyle='#ffd1f5';x.fillRect(0,-3,12,6)}
  x.restore();x.fillStyle='#fff';for(let i=0;i<t.lv;i++){x.beginPath();x.arc(px-6+i*6,py+9,1.8,0,7);x.fill()}
  if(t.ty===3&&t.tg){const g=x.createLinearGradient(px,py,t.tg.x,t.tg.y);g.addColorStop(0,'#fff');g.addColorStop(1,b.col);x.strokeStyle=g;x.lineWidth=2+t.lv+Math.sin(performance.now()/40);x.beginPath();x.moveTo(px+Math.cos(t.a)*12,py+Math.sin(t.a)*12);x.lineTo(t.tg.x,t.tg.y);x.stroke()}}
 function drawEnemy(e){const t=performance.now()/1000;if(!e.fly){x.fillStyle='rgba(0,0,0,.3)';x.beginPath();x.ellipse(e.x,e.y+e.r*.7,e.r,e.r*.45,0,0,7);x.fill()}
  x.fillStyle=e.sl>0?'#bff4ff':e.col;x.beginPath();if(e.fly){const w=Math.sin(t*14+e.ph)*5;x.moveTo(e.x-e.r-6,e.y-w);x.lineTo(e.x,e.y+2);x.lineTo(e.x+e.r+6,e.y-w);x.lineTo(e.x,e.y-3);x.fill();x.beginPath()}
  x.arc(e.x,e.y,e.r,0,7);x.fill();if(e.k==='t'){x.strokeStyle='rgba(0,0,0,.35)';x.lineWidth=2;x.stroke()}
  x.fillStyle='#fff';x.beginPath();x.arc(e.x-e.r*.3,e.y-e.r*.2,e.r*.25,0,7);x.arc(e.x+e.r*.3,e.y-e.r*.2,e.r*.25,0,7);x.fill();x.fillStyle='#111';x.fillRect(e.x-e.r*.35,e.y-e.r*.25,2,2);x.fillRect(e.x+e.r*.25,e.y-e.r*.25,2,2);
  if(e.hp<e.mx){const w=e.r*2+4;x.fillStyle='rgba(0,0,0,.6)';x.fillRect(e.x-w/2,e.y-e.r-7,w,3);x.fillStyle=e.hp/e.mx>.4?'#4dff88':'#ff5a5a';x.fillRect(e.x-w/2,e.y-e.r-7,w*e.hp/e.mx,3)}}
 function draw(){x.drawImage(bgc,0,0);
  // kasteel bij de uitgang
  x.font='22px system-ui';x.textAlign='center';x.textBaseline='middle';x.fillText('🏰',WP[WP.length-1][0]+28,MH-16);
  const hov=kbOn?[cx0,cy0]:hv&&!sel?hv:null;if(hov&&!over){const ok=!path.has(hov[1]*CO+hov[0])&&!towerAt(hov[0],hov[1]);x.strokeStyle=ok?'rgba(255,255,255,.8)':'rgba(255,90,90,.8)';x.lineWidth=2;x.strokeRect(hov[0]*T+1,hov[1]*T+1,T-2,T-2);
   if(ok){x.strokeStyle='rgba(255,255,255,.25)';x.beginPath();x.arc(hov[0]*T+T/2,hov[1]*T+T/2,TT[shop].rng,0,7);x.stroke()}}
  if(sel){const s=stat(sel);x.fillStyle='rgba(255,255,255,.08)';x.strokeStyle='rgba(255,255,255,.4)';x.lineWidth=1.5;x.beginPath();x.arc(sel.c*T+T/2,sel.r*T+T/2,s.rng,0,7);x.fill();x.stroke()}
  for(const e of en)if(!e.fly)drawEnemy(e);tw.forEach(drawTower);for(const e of en)if(e.fly)drawEnemy(e);
  for(const p of pr){x.fillStyle=p.ty===1?'#222':p.ty===2?'#bff4ff':'#fff';x.beginPath();x.arc(p.x,p.y,p.ty===1?4:2.5,0,7);x.fill()}
  for(const f of fx){x.globalAlpha=Math.max(0,Math.min(1,f.l*3));if(f.t==='p'){x.fillStyle=f.col;x.fillRect(f.x-2,f.y-2,4,4)}else if(f.t==='txt'){x.fillStyle='#ffd23f';x.font='bold 13px system-ui';x.fillText(f.s,f.x,f.y)}
   else if(f.t==='boom'){x.fillStyle=f.col;x.globalAlpha=f.l*2;x.beginPath();x.arc(f.x,f.y,f.r*(1-f.l*2),0,7);x.fill()}else if(f.t==='ring'){x.strokeStyle='#fff';x.lineWidth=2;x.beginPath();x.arc(f.x,f.y,20-f.l*30,0,7);x.stroke()}
   else if(f.t==='flash'){x.fillStyle='rgba(255,40,60,.35)';x.fillRect(0,0,W,MH)}}x.globalAlpha=1;
  if(sel){const p=panel(sel),mx=sel.lv>=3;x.fillStyle='rgba(14,16,32,.92)';x.beginPath();x.roundRect(p.x,p.y,p.w,p.h,8);x.fill();
   x.fillStyle=mx?'#555a77':money>=costUp(sel)?'#6c5ce7':'#4a4373';x.beginPath();x.roundRect(p.x+4,p.y+4,56,32,6);x.fill();x.fillStyle='#e05a5a';x.beginPath();x.roundRect(p.x+62,p.y+4,54,32,6);x.fill();
   x.fillStyle='#fff';x.font='bold 12px system-ui';x.fillText(mx?'MAX':'⬆ '+costUp(sel),p.x+32,p.y+20);x.fillText('💰 '+sellV(sel),p.x+89,p.y+20)}
  // winkel
  x.fillStyle='#161a33';x.fillRect(0,MH,W,H-MH);for(let i=0;i<4;i++){const b=TT[i],sx=i*90;if(i===shop){x.fillStyle='rgba(108,92,231,.45)';x.beginPath();x.roundRect(sx+3,MH+4,84,52,8);x.fill()}
   x.fillStyle=b.col;x.beginPath();x.arc(sx+20,MH+30,9,0,7);x.fill();x.fillStyle=money>=b.cost?'#fff':'#777c9a';x.textAlign='left';x.font='bold 13px system-ui';x.fillText(b.n,sx+34,MH+22);x.font='12px system-ui';x.fillText('💰 '+b.cost,sx+34,MH+40);x.textAlign='center'}
  if(msgT>0){const a=Math.min(1,msgT*3);x.fillStyle=`rgba(14,16,32,${.75*a})`;x.fillRect(0,MH/2-22,W,44);x.fillStyle=`rgba(255,255,255,${a})`;x.font='bold 19px system-ui';x.fillText(msg,W/2,MH/2)}
  sc.textContent='Golf '+wave+'/'+MAXW+' · 💰 '+money+' · ❤️ '+lives+' · Score '+score+' · Beste: '+best('towerdef',score);
  bN.disabled=!!(over||queue.length||wave>=MAXW);bN.style.opacity=bN.disabled?.5:1}
 const stopLoop=loop(dt=>{if(msgT>0)msgT-=dt;if(!over)for(let i=0;i<spd;i++)step(dt);
  fx=fx.filter(f=>{f.l-=dt;if(f.t==='p'){f.x+=f.vx*dt;f.y+=f.vy*dt}else if(f.t==='txt')f.y-=30*dt;return f.l>0});draw()});
 window._td={state:()=>({money,lives,wave,score,over,won,towers:tw.length,enemies:en.length,active,queue:queue.length}),path:(k,r)=>path.has(r*CO+k),setMoney(m){money=m},setWave(w){wave=w},kill(){lives=0},spd(n){spd=n},place(t,k,r){shop=t;place(k,r)},tw:()=>tw};
 init();cur.reset=init;
 return()=>{stopLoop();clearTimeout(tm);inp.stop();c.onpointerdown=c.onpointermove=c.onpointerleave=null;delete window._td}}},
