{id:'pacman',n:'Doolhofjager',e:'🟡',c:'Arcade',g:'#f7971e,#ffd200',nw:1,run(st){
 const T=18,CW=19,CH=21,W=CW*T,H=CH*T+18,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Pijltjes / vegen / knoppen = sturen · eet alle stipjes, vermijd de spoken'));
 const MAP=['###################','#........#........#','#o##.###.#.###.##o#','#.................#','#.##.#.#####.#.##.#','#....#...#...#....#','####.###.#.###.####','####.#.......#.####','####.#.##-##.#.####','    ...#   #...    ','####.#.#####.#.####','####.#.......#.####','####.#.#####.#.####','#........#........#','#.##.###.#.###.##.#','#o.#.....P.....#.o#','##.#.#.#####.#.#.##','#....#...#...#....#','#.######.#.######.#','#.................#','###################'];
 const DIRS=[[1,0],[0,1],[-1,0],[0,-1]],GC=['#ff3b3b','#ffb8ff','#4df0ff','#ffb852'],CORN=[[18,0],[0,0],[18,20],[0,20]],KEY={ArrowRight:0,ArrowDown:1,ArrowLeft:2,ArrowUp:3,d:0,s:1,a:2,w:3};
 const mz=document.createElement('canvas');mz.width=W;mz.height=H;const mx=mz.getContext('2d');
 const wall=(i,j)=>j>=0&&j<CH&&MAP[j][(i+CW)%CW]==='#';
 (function drawMaze(){mx.fillStyle='#0e1020';mx.fillRect(0,0,W,H);mx.fillStyle='#141c6e';for(let j=0;j<CH;j++)for(let i=0;i<CW;i++)if(wall(i,j))mx.fillRect(i*T,j*T,T,T);
  mx.strokeStyle='#4f6cff';mx.lineWidth=2;mx.beginPath();for(let j=0;j<CH;j++)for(let i=0;i<CW;i++){if(!wall(i,j))continue;const X=i*T,Y=j*T;
   if(!wall(i,j-1)){mx.moveTo(X,Y+1);mx.lineTo(X+T,Y+1)}if(!wall(i,j+1)){mx.moveTo(X,Y+T-1);mx.lineTo(X+T,Y+T-1)}if(!wall(i-1,j)&&i>0){mx.moveTo(X+1,Y);mx.lineTo(X+1,Y+T)}if(!wall(i+1,j)&&i<CW-1){mx.moveTo(X+T-1,Y);mx.lineTo(X+T-1,Y+T)}}mx.stroke();
  mx.fillStyle='#ffb8de';mx.fillRect(7*T+T,8*T+T/2-2,3*T,4)})();
 let dots,left,pl,gh,score,lives,level,over,overT,readyT,deathT,clearT,frT,chain,eatT,modeI,modeT,pops,t,ps,pmv,extra,nl;
 const MODES=[7,20,7,20,5,1e9];
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function open(i,j,e){if(j<0||j>=CH)return false;const ch=MAP[j][(i+CW)%CW];return ch!=='#'&&(ch!=='-'||(e&&(e.s==='exit'||e.s==='eyes')))}
 function resetPos(){nl=0;pl={tx:9,ty:15,d:2,nd:-1,p:0,mv:0,m:0};
  gh=[{tx:9,ty:7,s:'scatter',rel:0},{tx:9,ty:9,s:'house',rel:Math.max(.5,2-level*.3)},{tx:8,ty:9,s:'house',rel:Math.max(1,5-level*.5)},{tx:10,ty:9,s:'house',rel:Math.max(2,8-level*.7)}].map((g,i)=>Object.assign(g,{d:3,p:0,mv:0,ai:i}));
  frT=0;chain=0;eatT=0;modeI=0;modeT=MODES[0];readyT=1.6}
 function newLevel(){dots=MAP.map(r=>[...r]);left=0;for(const r of dots)for(const ch of r)if(ch==='.'||ch==='o')left++;resetPos();nl=1}
 function init(){score=0;lives=3;level=1;over=0;overT=0;deathT=0;clearT=0;pops=[];t=0;extra=0;newLevel();ov('')}
 function gameOver(){over=1;overT=0;best('pacman',score);ov(`💀 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('pacman',score)}<br>Tik of druk op een toets om opnieuw te spelen</span>`)}
 function setDir(d){if(over){if(overT>.5)init();return}pl.nd=d;if(pl.mv&&d===(pl.d+2)%4){const ox=pl.tx,oy=pl.ty;pl.tx=pl.nx;pl.ty=pl.ny;pl.nx=ox;pl.ny=oy;pl.p=1-pl.p;pl.d=d;pl.nd=-1}}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight']],k=>{if(KEY[k]!=null)setDir(KEY[k]);else if(over&&overT>.5)init()});
 const pt=e=>{const r=c.getBoundingClientRect();return[(e.clientX-r.left)*W/r.width,(e.clientY-r.top)*H/r.height]};
 c.onpointerdown=e=>{e.preventDefault();ps=pt(e);pmv=0;try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointermove=e=>{if(!ps)return;const p=pt(e),dx=p[0]-ps[0],dy=p[1]-ps[1];if(Math.max(Math.abs(dx),Math.abs(dy))>22){setDir(Math.abs(dx)>Math.abs(dy)?(dx>0?0:2):(dy>0?1:3));ps=p;pmv=1}};
 c.onpointerup=c.onpointercancel=()=>{if(ps&&!pmv&&over&&overT>.5)init();ps=null};
 function rev(e){if(e.mv){const ox=e.tx,oy=e.ty;e.tx=e.nx;e.ty=e.ny;e.nx=ox;e.ny=oy;e.p=1-e.p}e.d=(e.d+2)%4}
 function choose(e){const can=d=>open(e.tx+DIRS[d][0],e.ty+DIRS[d][1],e);
  if(e===pl){if(pl.nd>=0&&can(pl.nd)){const d=pl.nd;pl.nd=-1;return d}return can(pl.d)?pl.d:-1}
  const opts=[0,1,2,3].filter(d=>d!==(e.d+2)%4&&can(d));if(!opts.length)return can((e.d+2)%4)?(e.d+2)%4:-1;
  if(e.s==='fright'||(e.ai===2&&e.s==='chase'))return opts[R(opts.length)];
  let tg;if(e.s==='exit')tg=[9,7];else if(e.s==='eyes')tg=e.tx===9&&e.ty>=7&&e.ty<=9?[9,9]:[9,7];
  else if(e.s==='scatter')tg=CORN[e.ai];else if(e.ai===1)tg=[pl.tx+DIRS[pl.d][0]*4,pl.ty+DIRS[pl.d][1]*4];
  else if(e.ai===3)tg=Math.hypot(pl.tx-e.tx,pl.ty-e.ty)>8?[pl.tx,pl.ty]:CORN[3];else tg=[pl.tx,pl.ty];
  let bd=opts[0],bs=1e9;for(const d of opts){const nx=e.tx+DIRS[d][0],ny=e.ty+DIRS[d][1],s=(nx-tg[0])**2+(ny-tg[1])**2;if(s<bs){bs=s;bd=d}}return bd}
 function step(e,dist){while(dist>0){if(!e.mv){const d=choose(e);if(d<0){return}e.d=d;e.nx=e.tx+DIRS[d][0];e.ny=e.ty+DIRS[d][1];e.p=0;e.mv=1}
  const rem=1-e.p;if(dist<rem){e.p+=dist;dist=0}else{dist-=rem;e.tx=(e.nx+CW)%CW;e.ty=e.ny;e.p=0;e.mv=0;arrive(e)}}}
 function arrive(e){if(e===pl){const ch=dots[e.ty][e.tx];if(ch==='.'||ch==='o'){dots[e.ty][e.tx]=' ';left--;if(ch==='o'){score+=50;frT=Math.max(2.5,7-level*.6);chain=0;for(const g of gh)if(g.s==='chase'||g.s==='scatter'){g.s='fright';rev(g)}beep(200,.25,'sawtooth',.03)}else{score+=10;if(left%3===0)beep(left%2?420:330,.03,'square',.012)}}}
  else if(e.s==='exit'&&e.tx===9&&e.ty===7){e.s=modeI%2?'chase':'scatter'}else if(e.s==='eyes'&&e.tx===9&&e.ty===9){e.s='exit';e.d=3}}
 const pos=e=>e.mv?[(e.tx+DIRS[e.d][0]*e.p)*T+T/2,(e.ty+DIRS[e.d][1]*e.p)*T+T/2]:[e.tx*T+T/2,e.ty*T+T/2];
 const stopLoop=loop(dt=>{
  t+=dt;if(over)overT+=dt;const spd=Math.min(1.5,1+(level-1)*.09);
  if(!over){
   if(readyT>0)readyT-=dt;
   else if(clearT>0){clearT-=dt;if(clearT<=0){level++;newLevel();beep(880,.15,'square',.04)}}
   else if(deathT>0){const b=deathT;deathT-=dt;for(const th of[1.3,1,.7])if(b>th&&deathT<=th)beep(300-th*120,.12,'sawtooth',.04);if(deathT<=0){if(lives<=0)gameOver();else resetPos()}}
   else if(eatT>0)eatT-=dt;
   else{
    if(frT>0){frT-=dt;if(frT<=0)for(const g of gh)if(g.s==='fright')g.s=modeI%2?'chase':'scatter'}
    else{modeT-=dt;if(modeT<=0){modeI++;modeT=MODES[Math.min(modeI,MODES.length-1)];for(const g of gh)if(g.s==='chase'||g.s==='scatter'){g.s=modeI%2?'chase':'scatter';rev(g)}}}
    const pb=pl.mv||pl.nd>=0;step(pl,6*spd*dt);pl.m=pl.mv?pl.m+dt:pl.m;
    for(const g of gh){if(g.s==='house'){g.rel-=dt;if(g.rel<=0)g.s='exit';continue}
     let v=g.s==='eyes'?11:g.s==='fright'?3.4:g.s==='exit'?4:5.3*spd;if(g.ty===9&&(g.tx<4||g.tx>14))v*=.55;step(g,v*dt)}
    const[px,py]=pos(pl);for(const g of gh){if(g.s==='house'||g.s==='eyes')continue;const[gx,gy]=pos(g);if(Math.hypot(gx-px,gy-py)<T*.8){
     if(g.s==='fright'){const v=200<<chain;chain++;score+=v;g.s='eyes';eatT=.5;pops.push({x:gx,y:gy,tx:v,l:1});beep(900,.15,'square',.04)}
     else{deathT=1.5;beep(400,.1,'square',.03);lives--;break}}}
    if(score>=10000&&!extra){extra=1;lives++;beep(1200,.2,'square',.04)}
    if(left<=0&&clearT<=0&&deathT<=0){clearT=2;best('pacman',score)}
   }}
  for(const p of pops){p.y-=12*dt;p.l-=dt}pops=pops.filter(p=>p.l>0);
  // tekenen
  x.drawImage(mz,0,0);if(clearT>0&&Math.floor(t*6)%2){x.fillStyle='rgba(255,255,255,.18)';x.fillRect(0,0,W,CH*T)}
  x.fillStyle='#ffd7a8';for(let j=0;j<CH;j++)for(let i=0;i<CW;i++){const ch=dots[j][i];if(ch==='.')x.fillRect(i*T+T/2-2,j*T+T/2-2,4,4);else if(ch==='o'&&Math.floor(t*4)%2){x.beginPath();x.arc(i*T+T/2,j*T+T/2,6,0,7);x.fill()}}
  if(deathT<=0){const[px,py]=pos(pl);const m=pl.mv?Math.abs(Math.sin(pl.m*12))*.28*Math.PI+.04:.2;const an=pl.d*Math.PI/2;
   for(const ox of[0,px<T?W:px>W-T?-W:0]){x.fillStyle='#ffe13b';x.beginPath();x.moveTo(px+ox,py);x.arc(px+ox,py,8.5,an+m,an-m+Math.PI*2);x.closePath();x.fill()}}
  else{const[px,py]=pos(pl),k=Math.min(1,deathT<1.3?(1.3-deathT)/1.1:0);x.fillStyle='#ffe13b';x.beginPath();x.moveTo(px,py);x.arc(px,py,8.5*(1-k*.3),-Math.PI/2+k*Math.PI,-Math.PI/2-k*Math.PI+Math.PI*2);x.closePath();x.fill()}
  if(deathT<=0&&clearT<=0)for(const g of gh){const[gx,gy0]=pos(g),gy=gy0+(g.s==='house'?Math.sin(t*5+g.ai)*2:0);
   for(const ox of[0,gx<T?W:gx>W-T?-W:0]){const X=gx+ox;if(g.s!=='eyes'){const fr=g.s==='fright';x.fillStyle=fr?(frT<2&&Math.floor(t*8)%2?'#f5f5ff':'#2a3fd6'):GC[g.ai];
    x.beginPath();x.arc(X,gy-1,8.5,Math.PI,0);x.lineTo(X+8.5,gy+8);const w=Math.floor(t*8)%2;for(let i=0;i<3;i++){x.lineTo(X+8.5-(i*2+1)*8.5/3,gy+8-(w?(i%2?0:3):(i%2?3:0)));}x.lineTo(X-8.5,gy+8);x.closePath();x.fill();
    if(fr){x.fillStyle=frT<2&&Math.floor(t*8)%2?'#f33':'#fff';x.fillRect(X-4,gy-3,2,2);x.fillRect(X+2,gy-3,2,2);x.beginPath();for(let i=0;i<=4;i++)x[i?'lineTo':'moveTo'](X-5+i*2.5,gy+3+(i%2?-1.5:1.5));x.strokeStyle=x.fillStyle;x.lineWidth=1;x.stroke();continue}}
    const[dx,dy]=DIRS[g.d];x.fillStyle='#fff';x.beginPath();x.ellipse(X-3,gy-2,2.6,3.2,0,0,7);x.ellipse(X+3,gy-2,2.6,3.2,0,0,7);x.fill();x.fillStyle='#2233aa';x.beginPath();x.arc(X-3+dx*1.5,gy-2+dy*1.5,1.5,0,7);x.arc(X+3+dx*1.5,gy-2+dy*1.5,1.5,0,7);x.fill()}}
  x.font='bold 11px system-ui,sans-serif';x.textAlign='center';for(const p of pops){x.globalAlpha=Math.min(1,p.l*2);x.fillStyle='#4df0ff';x.fillText(p.tx,p.x,p.y)}x.globalAlpha=1;
  if(readyT>0&&!over){x.fillStyle='#ffe13b';x.font='bold 16px system-ui,sans-serif';x.fillText(nl&&level>1?'Level '+level:'Klaar?',W/2,11*T+T/2+5)}
  x.fillStyle='#ffe13b';for(let i=0;i<Math.max(0,lives);i++){x.beginPath();x.moveTo(14+i*18,CH*T+9);x.arc(14+i*18,CH*T+9,6,.6,-.6+Math.PI*2);x.closePath();x.fill()}
  x.fillStyle='#8a90b8';x.font='bold 12px system-ui,sans-serif';x.textAlign='right';x.fillText('LEVEL '+level,W-8,CH*T+13);
  sc.textContent='Score: '+score+' · Beste: '+best('pacman',score)+' · Level '+level+(over?' · Game over':'');
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
