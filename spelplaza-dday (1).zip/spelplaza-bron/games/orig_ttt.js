{id:'ttt',n:'Boter-kaas-eieren',e:'❌',c:'Bord',g:'#fa709a,#fee140',run(st){
 const W=330,CL=W/3,c=mkCanvas(st,W,W),x=c.getContext('2d'),sc=E('div','sc'),info=E('div','sc');st.prepend(sc);
 const opt=E('div');opt.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 10px;flex-wrap:wrap';sc.after(opt);info.style.cssText='min-height:24px;font-size:17px';opt.after(info);
 st.append(E('div','hint','Tik op een vak · of pijltjes + spatie · toetsen 1–9 · jij bent ❌'));
 const LV=['Makkelijk','Normaal','Onverslaanbaar'],L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
 let lv=1;try{lv=+(localStorage.getItem('sp_ttt_lv')??1)}catch(e){}if(!LV[lv])lv=1;
 let a,marks,end,wl,turn,first,wins,draws,losses,streak,cpuT,endT,cr,t;
 const win=b=>{for(const l of L)if(b[l[0]]&&b[l[0]]===b[l[1]]&&b[l[0]]===b[l[2]])return{w:b[l[0]],l};return b.every(Boolean)?{w:'T'}:null};
 function mm(b,p,d){const w=win(b);if(w)return w.w==='O'?10-d:w.w==='X'?d-10:0;let bs=p==='O'?-99:99;
  for(let i=0;i<9;i++)if(!b[i]){b[i]=p;const r=mm(b,p==='O'?'X':'O',d+1);b[i]=0;bs=p==='O'?Math.max(bs,r):Math.min(bs,r)}return bs}
 function free(){return a.map((v,i)=>v?-1:i).filter(i=>i>=0)}
 function finds(p){for(const i of free()){a[i]=p;const w=win(a);a[i]=0;if(w&&w.w===p)return i}return -1}
 function cpuMove(){const f=free();let m;
  if(lv===0){m=Math.random()<.35?finds('O'):-1;if(m<0)m=f[R(f.length)]}
  else if(lv===1){m=finds('O');if(m<0&&Math.random()<.8)m=finds('X');if(m<0)m=Math.random()<.5&&!a[4]?4:f[R(f.length)]}
  else{let bs=-999,bm=[];for(const i of f){a[i]='O';const r=mm(a,'X',1);a[i]=0;if(r>bs){bs=r;bm=[i]}else if(r===bs)bm.push(i)}m=bm[R(bm.length)]}
  place(m,'O')}
 function place(i,p){a[i]=p;marks.push({i,p,t:0});beep(p==='X'?620:420,.07,'triangle',.04);const w=win(a);
  if(w){end=1;endT=0;wl=w.l?{l:w.l,t:0}:null;
   if(w.w==='X'){wins++;streak++;best('ttt',streak);info.textContent='🎉 Jij wint!';[659,784,1047].forEach((f,k)=>setTimeout(()=>beep(f,.12,'triangle',.05),200+k*110))}
   else if(w.w==='O'){losses++;streak=0;info.textContent='🤖 De computer wint';setTimeout(()=>beep(180,.3,'sawtooth',.04),200)}
   else{draws++;info.textContent='🤝 Gelijkspel';setTimeout(()=>beep(330,.15,'sine',.04),200)}
   upd();return}
  turn=p==='X'?'O':'X';if(turn==='O')cpuT=.45+Math.random()*.3;info.textContent=turn==='X'?'Jouw beurt ❌':'Computer denkt na…';upd()}
 function upd(){sc.textContent=`Jij ${wins} · Gelijk ${draws} · Computer ${losses} · Reeks ${streak} · Beste: ${best('ttt',streak)}`}
 function drawOpt(){opt.innerHTML='';LV.forEach((l,i)=>{const b=E('button','btn',l);b.style.cssText='padding:6px 12px;font-size:12px;border-radius:99px;'+(i===lv?'':'background:var(--bg);color:var(--tx)');b.onclick=()=>{lv=i;try{localStorage.setItem('sp_ttt_lv',i)}catch(e){}init()};opt.append(b)})}
 function round(){a=Array(9).fill(0);marks=[];end=0;wl=null;endT=0;turn=first;cpuT=.6;info.textContent=turn==='X'?'Jouw beurt ❌':'Computer begint…';first=first==='X'?'O':'X';upd()}
 function init(){wins=draws=losses=streak=0;first='X';cr=4;drawOpt();round()}
 function tap(i){if(end){if(endT>.4)round();return}if(turn!=='X'||a[i])return;place(i,'X')}
 c.onpointerdown=e=>{e.preventDefault();const r=c.getBoundingClientRect(),X=(e.clientX-r.left)*W/r.width,Y=(e.clientY-r.top)*W/r.height;cr=-1;tap(Math.min(2,Y/CL|0)*3+Math.min(2,X/CL|0))};
 const inp=input(st,[],k=>{if(k>='1'&&k<='9'){tap(+k-1);return}if(cr<0)cr=4;
  if(k==='ArrowLeft'&&cr%3)cr--;else if(k==='ArrowRight'&&cr%3<2)cr++;else if(k==='ArrowUp'&&cr>2)cr-=3;else if(k==='ArrowDown'&&cr<6)cr+=3;else if(k===' '||k==='Enter')tap(cr)});
 t=0;
 const stopLoop=loop(dt=>{t+=dt;if(end)endT+=dt;
  if(!end&&turn==='O'){cpuT-=dt;if(cpuT<=0)cpuMove()}
  for(const m of marks)m.t=Math.min(1,m.t+dt*4);if(wl)wl.t=Math.min(1,wl.t+dt*2.5);
  x.fillStyle='#0e1020';x.fillRect(0,0,W,W);
  if(cr>=0&&!end&&turn==='X'){x.fillStyle='rgba(255,255,255,.06)';x.fillRect(cr%3*CL+6,(cr/3|0)*CL+6,CL-12,CL-12)}
  x.lineCap='round';x.strokeStyle='#3a3f72';x.lineWidth=6;
  for(let i=1;i<3;i++){x.beginPath();x.moveTo(i*CL,14);x.lineTo(i*CL,W-14);x.moveTo(14,i*CL);x.lineTo(W-14,i*CL);x.stroke()}
  for(const m of marks){const cx=m.i%3*CL+CL/2,cy=(m.i/3|0)*CL+CL/2,s=CL*.28,e=1-Math.pow(1-m.t,3);x.lineWidth=12;
   if(m.p==='X'){x.strokeStyle='#ff5c8a';x.shadowColor='#ff5c8a';x.shadowBlur=14;const e1=Math.min(1,e*2),e2=Math.max(0,e*2-1);
    x.beginPath();x.moveTo(cx-s,cy-s);x.lineTo(cx-s+2*s*e1,cy-s+2*s*e1);if(e2>0){x.moveTo(cx+s,cy-s);x.lineTo(cx+s-2*s*e2,cy-s+2*s*e2)}x.stroke()}
   else{x.strokeStyle='#4dd8ff';x.shadowColor='#4dd8ff';x.shadowBlur=14;x.beginPath();x.arc(cx,cy,s,-Math.PI/2,-Math.PI/2+e*Math.PI*2);x.stroke()}x.shadowBlur=0}
  if(wl){const p=i=>[i%3*CL+CL/2,(i/3|0)*CL+CL/2],[x0,y0]=p(wl.l[0]),[x1,y1]=p(wl.l[2]),e=wl.t,dx=(x1-x0)*.18,dy=(y1-y0)*.18;
   x.strokeStyle='#ffd86b';x.shadowColor='#ffd86b';x.shadowBlur=18;x.lineWidth=8;x.beginPath();x.moveTo(x0-dx,y0-dy);x.lineTo(x0-dx+(x1-x0+2*dx)*e,y0-dy+(y1-y0+2*dy)*e);x.stroke();x.shadowBlur=0}
  if(end&&endT>.6){x.fillStyle='rgba(14,16,32,.55)';x.fillRect(0,W-44,W,44);x.fillStyle='#fff';x.font='bold 15px system-ui,sans-serif';x.textAlign='center';x.fillText('Tik of druk op spatie voor de volgende ronde',W/2,W-17)}
  if(!end&&turn==='O'){x.fillStyle='#8a90b8';for(let i=0;i<3;i++){x.globalAlpha=.3+.7*Math.max(0,Math.sin(t*6-i));x.beginPath();x.arc(W/2-14+i*14,W-14,4,0,7);x.fill()}x.globalAlpha=1}
 });
 st.t={get a(){return a},get end(){return end},get turn(){return turn},tap};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=null}}},
