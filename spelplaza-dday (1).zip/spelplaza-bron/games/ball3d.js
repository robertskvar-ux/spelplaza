{id:'ball3d',n:'Rollende Bal',e:'🟢',c:'3D',g:'#1d976c,#93f9b9',nw:1,run(st){
 const W=360,H=480,T=three(st,W,H,{fov:50,far:80}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','◀ ▲ ▼ ▶ of sleep over het veld · pak alle 8 💎 · val niet in de gaten'));
 const BG=0x0f1b2d;S.background=new THREE.Color(BG);S.fog=new THREE.Fog(BG,14,30);
 const sun=new THREE.DirectionalLight(0xffffff,2.6);sun.position.set(4,9,5);S.add(sun,new THREE.HemisphereLight(0xcfe6ff,0x1a2a3a,1));
 const N=9,RB=.3,V3=THREE.Vector3,std=o=>new THREE.MeshStandardMaterial(o);
 // floor tiles: one instanced mesh (holes = missing instances)
 const tiles=new THREE.InstancedMesh(new THREE.BoxGeometry(.96,.4,.96),std({color:0xffffff,roughness:.85}),N*N);tiles.frustumCulled=false;S.add(tiles);
 const pool=(n,geo,mat,y)=>{const a=[];for(let i=0;i<n;i++){const m=new THREE.Mesh(geo,mat);m.visible=false;m.position.y=y;S.add(m);a.push(m)}return a};
 const walls=pool(12,new THREE.BoxGeometry(1,1,1),std({color:0xf4a261,roughness:.6}),.5);
 const bumps=pool(5,new THREE.CylinderGeometry(.38,.44,.6,20),std({color:0xff5d8f,emissive:0x7a1038,roughness:.4}),.3);
 const gems=pool(8,new THREE.OctahedronGeometry(.24),std({color:0xffd166,emissive:0x9a6a00,roughness:.3}),.5);gems.forEach(g=>g.scale.y=1.6);
 // distant stars for depth
 const sg=new THREE.BufferGeometry(),sp_=new Float32Array(1500);for(let i=0;i<500;i++){const a=Math.random()*6.283,b=(Math.random()-.5)*3,r=60;sp_[i*3]=Math.cos(a)*Math.cos(b)*r;sp_[i*3+1]=Math.sin(b)*r;sp_[i*3+2]=Math.sin(a)*Math.cos(b)*r}sg.setAttribute('position',new THREE.BufferAttribute(sp_,3));
 const stars=new THREE.Points(sg,new THREE.PointsMaterial({color:0xaac4ff,size:2,sizeAttenuation:false,fog:false,transparent:true,opacity:.85}));stars.frustumCulled=false;S.add(stars);
 // checkered ball so the rolling is visible
 const tc=document.createElement('canvas');tc.width=tc.height=64;const tx=tc.getContext('2d');tx.fillStyle='#f8f9fa';tx.fillRect(0,0,64,64);tx.fillStyle='#e63946';
 for(let i=0;i<4;i++)for(let j=0;j<4;j++)if((i+j)%2)tx.fillRect(i*16,j*16,16,16);
 const ball=new THREE.Mesh(new THREE.SphereGeometry(RB,24,16),std({map:new THREE.CanvasTexture(tc),roughness:.25,metalness:.1}));S.add(ball);
 const shadow=new THREE.Mesh(new THREE.CircleGeometry(.3,16),new THREE.MeshBasicMaterial({color:0,transparent:true,opacity:.35}));shadow.rotation.x=-Math.PI/2;S.add(shadow);
 let grid,score,lives,level,time,over,msgT,nextLvl,fall,left,px,py,pz,vx,vy,vz,t=0,p0=null;
 const drag={x:0,y:0},camT=new V3,look=new V3,ax=new V3,M=new THREE.Matrix4(),col=new THREE.Color(),START=4+7*N;
 function gen(tries=0){
  grid=new Array(N*N).fill(0);const keep=new Set([START,START-1,START+1,START-N,START-N-1,START-N+1]);
  const place=(k,cnt)=>{for(let i=0;i<400&&cnt;i++){const p=R(N*N);if(grid[p]||keep.has(p))continue;grid[p]=k;cnt--}};
  place(2,3+R(4));place(3,2+R(3));place(1,Math.min(28,4+level*3));
  const seen=new Set([START]),q=[START],reach=[];
  while(q.length){const p=q.pop();reach.push(p);const i=p%N,j=p/N|0;for(const [a,b] of [[i+1,j],[i-1,j],[i,j+1],[i,j-1]]){if(a<0||b<0||a>=N||b>=N)continue;const n=a+b*N;if(seen.has(n)||grid[n])continue;seen.add(n);q.push(n)}}
  const cand=reach.filter(p=>!keep.has(p));if(cand.length<14&&tries<30)return gen(tries+1);
  let n=0;for(let p=0;p<N*N;p++){if(grid[p]===1)continue;const i=p%N,j=p/N|0;M.makeTranslation(i-4,-.2,j-4);tiles.setMatrixAt(n,M);tiles.setColorAt(n,col.setHex((i+j)%2?0x2a9d8f:0x45c4b0));n++}
  tiles.count=n;tiles.instanceMatrix.needsUpdate=true;tiles.instanceColor.needsUpdate=true;
  let wi=0,bi=0;walls.forEach(m=>m.visible=false);bumps.forEach(m=>{m.visible=false;m.userData.p=0;m.scale.set(1,1,1)});
  for(let p=0;p<N*N;p++){const i=p%N,j=p/N|0;if(grid[p]===2&&wi<walls.length){const m=walls[wi++];m.visible=true;m.position.x=i-4;m.position.z=j-4}if(grid[p]===3&&bi<bumps.length){const m=bumps[bi++];m.visible=true;m.position.x=i-4;m.position.z=j-4}}
  for(let i=cand.length-1;i>0;i--){const k=R(i+1);[cand[i],cand[k]]=[cand[k],cand[i]]}
  gems.forEach((g,k)=>{const p=cand[k];g.visible=true;g.userData.on=1;g.position.x=p%N-4;g.position.z=(p/N|0)-4});left=8;
 }
 function respawn(){px=0;pz=3;py=RB;vx=vy=vz=0;fall=0;drag.x=drag.y=0;ball.rotation.set(0,0,0);cam.position.copy(camT.set(px,7,pz+5));look.set(px,0,pz-2)}
 function ov(html){const o=overlay(st,c,html);if(o)o.onpointerdown=e=>{e.preventDefault();if(over)init()}}
 function msg(html,sec,nl){msgT=sec;nextLvl=nl;ov(html)}
 function init(){score=0;lives=3;level=1;time=0;over=0;msgT=0;nextLvl=0;gen();respawn();overlay(st,c,'')}
 function levelDone(){score+=250;level++;beep(990,.2,'triangle',.05);msg(`✅ Niveau ${level-1} klaar!<br><span style="font-size:15px;font-weight:600">+250 bonus · niveau ${level} heeft meer gaten</span>`,1.6,1)}
 function gameOver(){over=1;best('ball3d',score);beep(140,.35,'sawtooth',.05);ov(`💀 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('ball3d',score)}<br>Tik of druk op een toets om opnieuw te spelen</span>`)}
 function loseLife(){lives--;if(lives<=0){gameOver();return}msg(`💔 Gevallen!<br><span style="font-size:15px;font-weight:600">Nog ${lives} ${lives===1?'leven':'levens'}</span>`,.9,0)}
 function collideBox(cx,cz,h){const nx=Math.max(cx-h,Math.min(px,cx+h)),nz=Math.max(cz-h,Math.min(pz,cz+h));let dx=px-nx,dz=pz-nz,d=Math.hypot(dx,dz);if(d>=RB)return;
  if(d<1e-4){dx=px-cx;dz=pz-cz;if(Math.abs(dx)>Math.abs(dz)){dx=dx<0?-1:1;dz=0}else{dz=dz<0?-1:1;dx=0}px=cx+dx*(h+RB);pz=cz+dz*(h+RB)}else{dx/=d;dz/=d;px=nx+dx*RB;pz=nz+dz*RB}
  const vn=vx*dx+vz*dz;if(vn<0){vx-=1.6*vn*dx;vz-=1.6*vn*dz;if(vn<-1.5)beep(260,.05,'square',.03)}}
 function collideBump(m){let dx=px-m.position.x,dz=pz-m.position.z,d=Math.hypot(dx,dz);const rr=.42+RB;if(d>=rr)return;if(d<1e-4){dx=1;dz=0}else{dx/=d;dz/=d}
  px=m.position.x+dx*rr;pz=m.position.z+dz*rr;const vn=vx*dx+vz*dz;if(vn<0){vx-=2*vn*dx;vz-=2*vn*dz}vx+=dx*3.5;vz+=dz*3.5;m.userData.p=1;beep(520,.07,'square',.04)}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight']],k=>{if(over)init()});
 c.onpointerdown=e=>{e.preventDefault();if(over){init();return}try{c.setPointerCapture(e.pointerId)}catch(x){}p0=[e.clientX,e.clientY];drag.x=drag.y=0};
 c.onpointermove=e=>{if(!p0)return;const r=c.getBoundingClientRect(),k=W/r.width/45;let dx=(e.clientX-p0[0])*k,dy=(e.clientY-p0[1])*k;const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l}drag.x=dx;drag.y=dy};
 c.onpointerup=c.onpointercancel=()=>{p0=null;drag.x=drag.y=0};
 const stopLoop=loop(dt=>{t+=dt;
  if(!over){
   if(msgT>0){msgT-=dt;if(msgT<=0){overlay(st,c,'');if(nextLvl)gen();respawn()}}
   else{time+=dt;
    if(!fall){let ix=(inp.has('ArrowRight')?1:0)-(inp.has('ArrowLeft')?1:0)+drag.x,iz=(inp.has('ArrowDown')?1:0)-(inp.has('ArrowUp')?1:0)+drag.y;const l=Math.hypot(ix,iz);if(l>1){ix/=l;iz/=l}
     vx+=ix*13*dt;vz+=iz*13*dt;const f=Math.exp(-2.2*dt);vx*=f;vz*=f;const sp=Math.hypot(vx,vz);if(sp>5.5){vx*=5.5/sp;vz*=5.5/sp}
     px+=vx*dt;pz+=vz*dt;
     walls.forEach(m=>m.visible&&collideBox(m.position.x,m.position.z,.5));bumps.forEach(m=>m.visible&&collideBump(m));
     const i=Math.round(px+4),j=Math.round(pz+4);
     if(i<0||j<0||i>=N||j>=N||grid[i+j*N]===1){fall=1;vy=0;beep(180,.3,'sawtooth',.04)}
     gems.forEach(g=>{if(g.userData.on&&Math.hypot(g.position.x-px,g.position.z-pz)<.55){g.userData.on=0;g.visible=false;score+=100;left--;beep(880,.08,'triangle',.05);if(!left)levelDone()}})
    }else{vy-=22*dt;py+=vy*dt;px+=vx*dt;pz+=vz*dt;if(py<-8)loseLife()}
    const sp=Math.hypot(vx,vz);if(sp>1e-3){ax.set(vz,0,-vx).normalize();ball.rotateOnWorldAxis(ax,sp*dt/RB)}
   }}
  ball.position.set(px,py,pz);shadow.position.set(px,.012,pz);shadow.visible=!fall;
  gems.forEach((g,k)=>{g.rotation.y+=dt*2.5;g.position.y=.5+Math.sin(t*3+k)*.08});
  bumps.forEach(m=>{if(m.userData.p>0){m.userData.p-=dt*4;const s=1+Math.max(0,m.userData.p)*.3;m.scale.set(s,1,s)}});
  camT.set(px,Math.max(py,0)+7,pz+5);cam.position.lerp(camT,1-Math.exp(-5*dt));look.lerp(ax.set(px,Math.min(py,0),pz-2),1-Math.exp(-6*dt));cam.lookAt(look);
  T.r.render(S,cam);
  const m=time/60|0,s=time%60|0;sc.textContent=`Score: ${score} · ${'❤️'.repeat(lives)||'💔'} · Lvl ${level} · ${m}:${s<10?'0':''}${s} · Beste: ${best('ball3d',score)}`;
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;T.dispose()}}},
