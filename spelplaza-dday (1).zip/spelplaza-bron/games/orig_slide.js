{id:'slide',n:'Schuifpuzzel',e:'🧩',c:'Puzzel',g:'#00b09b,#96c93d',run(st){
 const W=340,P=8,c=mkCanvas(st,W,W),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 const opt=E('div');opt.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 8px;flex-wrap:wrap';sc.after(opt);
 st.append(E('div','hint','Tik op een tegel naast (of in lijn met) het gat · pijltjes of vegen · zet alles op volgorde'));
 let N=3;try{N=+(localStorage.getItem('sp_slide_n')||3)}catch(e){}if(N!==3&&N!==4&&N!==5)N=3;
 let wt,a,mv,t0,tEnd,done,anim,T,glow,overT;
 const fmt=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
 const bk=()=>'sp_slide_m'+N,getBest=()=>{try{return+localStorage.getItem(bk())||0}catch(e){return 0}};
 function drawOpt(){opt.innerHTML='';[3,4,5].forEach(n=>{const q=E('button','btn',n+'×'+n);q.style.cssText='padding:6px 14px;font-size:12px;border-radius:99px;'+(n===N?'':'background:var(--bg);color:var(--tx)');q.onclick=()=>{N=n;try{localStorage.setItem('sp_slide_n',n)}catch(e){}init()};opt.append(q)})}
 const solved=()=>a.every((v,i)=>v===(i+1)%(N*N));
 function init(){T=(W-P*(N+1))/N;a=[...Array(N*N).keys()].map(i=>(i+1)%(N*N));let z=N*N-1,last=-1;
  for(let k=0;k<N*N*40;k++){const zx=z%N,zy=z/N|0,nb=[];if(zx>0)nb.push(z-1);if(zx<N-1)nb.push(z+1);if(zy>0)nb.push(z-N);if(zy<N-1)nb.push(z+N);const c2=nb.filter(i=>i!==last),i=c2[R(c2.length)];a[z]=a[i];a[i]=0;last=z;z=i}
  if(solved())return init();clearTimeout(wt);mv=0;t0=0;tEnd=0;done=0;anim=[];glow=0;overT=0;drawOpt();ov('');upd()}
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function upd(){const el=t0?((tEnd||performance.now())-t0)/1000:0,bb=getBest();sc.textContent=`Zetten: ${mv} · ⏱ ${fmt(el)}`+(bb?` · Beste: ${bb} zetten`:'')+` · ${N}×${N}`}
 function tap(i){if(done){if(overT>.5)init();return}const z=a.indexOf(0),zx=z%N,zy=z/N|0,ix=i%N,iy=i/N|0;if(i===z)return;
  if(ix!==zx&&iy!==zy){beep(130,.04,'triangle',.015);return}
  const st2=ix===zx?(iy>zy?N:-N):(ix>zx?1:-1);let cz=z;const moved=[];while(cz!==i){const nx=cz+st2;a[cz]=a[nx];a[nx]=0;moved.push({v:a[cz],from:nx,to:cz,t:0});cz=nx}
  anim=anim.filter(m=>!moved.some(q=>q.v===m.v)).concat(moved);mv++;if(!t0)t0=performance.now();beep(420+moved.length*40,.04,'triangle',.03);
  if(solved()){done=1;overT=0;tEnd=performance.now();glow=1;const o=getBest(),rec=!o||mv<o;if(rec)try{localStorage.setItem(bk(),mv)}catch(e){}
   [523,659,784,1047].forEach((f,k)=>setTimeout(()=>beep(f,.12,'triangle',.05),200+k*100));
   wt=setTimeout(()=>{if(done)ov(`🎉 Opgelost!<br><span style="font-size:15px;font-weight:600">${mv} zetten · ${fmt((tEnd-t0)/1000)}${rec?' · Nieuw record!':' · Beste '+getBest()}<br>Tik om opnieuw te spelen</span>`)},700)}
  upd()}
 function dirMove(k){const z=a.indexOf(0),zx=z%N,zy=z/N|0;// pijl = richting waarin een tegel schuift
  const m={ArrowLeft:[1,0],ArrowRight:[-1,0],ArrowUp:[0,1],ArrowDown:[0,-1]}[k];if(!m)return;const tx=zx+m[0],ty=zy+m[1];if(tx<0||ty<0||tx>=N||ty>=N)return;tap(ty*N+tx)}
 const inp=input(st,[],k=>{if(done){if(k===' '||k==='Enter'||k.startsWith('Arrow'))tap(0);return}dirMove(k)});
 let sx,sy;c.onpointerdown=e=>{e.preventDefault();sx=e.clientX;sy=e.clientY};
 c.onpointerup=e=>{if(sx==null)return;const dx=e.clientX-sx,dy=e.clientY-sy;sx=null;
  if(Math.max(Math.abs(dx),Math.abs(dy))>24){dirMove(Math.abs(dx)>Math.abs(dy)?(dx>0?'ArrowRight':'ArrowLeft'):(dy>0?'ArrowDown':'ArrowUp'));return}
  const r=c.getBoundingClientRect(),X=(e.clientX-r.left)*W/r.width,Y=(e.clientY-r.top)*W/r.height;tap(Math.min(N-1,Math.max(0,(Y-P/2)/(T+P)|0))*N+Math.min(N-1,Math.max(0,(X-P/2)/(T+P)|0)))};
 const pos=i=>[P+(i%N)*(T+P),P+(i/N|0)*(T+P)];
 const tick=setInterval(()=>{if(t0&&!done)upd()},500);
 const stopLoop=loop(dt=>{if(done)overT+=dt;for(const m of anim)m.t=Math.min(1,m.t+dt/.11);anim=anim.filter(m=>m.t<1);glow=Math.max(0,glow-dt*.6);
  x.fillStyle='#0e1020';x.fillRect(0,0,W,W);x.fillStyle='#161a3c';x.beginPath();x.roundRect?x.roundRect(0,0,W,W,12):x.rect(0,0,W,W);x.fill();
  x.fillStyle='#1e2350';for(let i=0;i<N*N;i++){const[px,py]=pos(i);x.fillRect(px+2,py+2,T-4,T-4)}
  for(let i=0;i<N*N;i++){const v=a[i];if(!v)continue;let[px,py]=pos(i);const m=anim.find(q=>q.v===v);
   if(m){const e=1-Math.pow(1-m.t,3),[fx,fy]=pos(m.from);px=fx+(px-fx)*e;py=fy+(py-fy)*e}
   const ok=v===i+1,h=((v-1)/(N*N-1))*220+150;const g=x.createLinearGradient(px,py,px,py+T);g.addColorStop(0,`hsl(${h},70%,${ok?62:56}%)`);g.addColorStop(1,`hsl(${h},70%,${ok?46:40}%)`);
   x.fillStyle=g;if(glow>0||ok){x.shadowColor=`hsl(${h},90%,60%)`;x.shadowBlur=ok?6+glow*20:0}x.beginPath();x.roundRect?x.roundRect(px,py,T,T,10):x.rect(px,py,T,T);x.fill();x.shadowBlur=0;
   x.fillStyle='rgba(255,255,255,.18)';x.fillRect(px+6,py+4,T-12,3);
   x.fillStyle='#fff';x.font=`900 ${T*.42}px system-ui,sans-serif`;x.textAlign='center';x.textBaseline='middle';x.fillText(v,px+T/2,py+T/2+2);x.textBaseline='alphabetic'}
 });
 st.t={get a(){return a},get done(){return done},tap,get N(){return N}};
 init();cur.reset=init;return()=>{stopLoop();clearInterval(tick);clearTimeout(wt);inp.stop();c.onpointerdown=c.onpointerup=null}}},
