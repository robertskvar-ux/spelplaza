{id:'cookie',n:'Koekjes Klikker',e:'🍪',c:'Arcade',g:'#c79081,#dfa579',nw:1,run(st){
 const B=[['👆','Cursor',15,.1],['👵','Oma',100,1],['🚜','Boerderij',1100,8],['⛏️','Mijn',12000,47],['🏭','Fabriek',130000,260],['🏦','Bank',1.4e6,1400],['🛕','Tempel',2e7,7800],['🌀','Portaal',3.3e8,44000]];
 const U=[['💪','Sterke duim',500,'Klikkracht ×2'],['✨','Gouden vinger',20000,'Klikkracht ×3'],['🪄','Koekjesmagie',500000,'Elke klik geeft ook 5% van je productie per seconde']];
 const KEY='sp_cookie_save';let S;
 const fmt=n=>{if(n<1000)return String(Math.floor(n));const u=['K','M','B','T','Qa','Qi'];let i=-1;while(n>=1000&&i<u.length-1){n/=1000;i++}return(n<100?n.toFixed(1):n.toFixed(0)).replace('.0','').replace('.',',')+' '+u[i]};
 const fmtD=n=>n<1000?(Number.isInteger(+n.toFixed(1))?String(Math.round(n)):n.toFixed(1).replace('.',',')):fmt(n);
 const cost=i=>Math.ceil(B[i][2]*Math.pow(1.15,S.b[i]));
 const cps=()=>B.reduce((s,b,i)=>s+b[3]*S.b[i],0);
 const perClick=()=>(S.u[0]?2:1)*(S.u[1]?3:1)+(S.u[2]?cps()*.05:0);
 const fresh=()=>({c:0,tot:0,clicks:0,b:B.map(()=>0),u:U.map(()=>0),t:Date.now()});
 function load(){try{const s=JSON.parse(localStorage.getItem(KEY));if(s&&s.b&&s.b.length===B.length)return s}catch(e){}return null}
 function save(){S.t=Date.now();try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
 // ---- UI ----
 const sc=E('div','sc'),sub=E('div','hint'),msg=E('div');msg.style.cssText='display:none;background:var(--ac);color:#fff;border-radius:12px;padding:10px 14px;margin:6px auto;max-width:420px;font-weight:600;font-size:14px;cursor:pointer';
 const area=E('div');area.style.cssText='position:relative;height:170px;display:flex;align-items:center;justify-content:center;user-select:none;-webkit-user-select:none;touch-action:manipulation';
 const ck=E('div','','🍪');ck.style.cssText='font-size:110px;line-height:1;cursor:pointer;transition:transform .08s;filter:drop-shadow(0 8px 14px rgba(0,0,0,.35));will-change:transform';area.append(ck);
 const pc=E('div','hint');
 const ups=E('div');ups.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:6px;max-width:420px;margin:8px auto';
 const shop=E('div');shop.style.cssText='max-width:420px;margin:8px auto 0;max-height:300px;overflow-y:auto;border-radius:12px;background:var(--bg);padding:6px;text-align:left';
 const rs=E('button','btn','🗑️ Reset');rs.style.cssText='margin-top:10px;background:#e74c3c;font-size:13px';
 st.append(sc,sub,msg,area,pc,ups,shop,rs,E('div','hint','Tik op het koekje · koop oma’s en fabrieken voor koekjes per seconde · je voortgang wordt bewaard'));
 const rows=B.map((b,i)=>{const r=E('button');r.style.cssText='display:flex;align-items:center;gap:10px;width:100%;border:0;border-radius:10px;padding:8px 10px;margin:3px 0;background:var(--card);color:var(--tx);cursor:pointer;text-align:left;font:inherit;transition:opacity .15s';
  r.innerHTML=`<span style="font-size:28px;width:38px;text-align:center">${b[0]}</span><span style="flex:1"><b>${b[1]}</b> <span class="n" style="color:var(--mu)"></span><br><small style="color:var(--mu)">+${fmtD(b[3])}/s per stuk</small></span><b class="k" style="white-space:nowrap"></b>`;
  r.onpointerdown=e=>{e.preventDefault();buy(i)};shop.append(r);return r});
 const ucards=U.map((u,i)=>{const d=E('button');d.style.cssText='border:0;border-radius:10px;padding:8px 6px;background:var(--bg);color:var(--tx);cursor:pointer;font:inherit;font-size:12px;line-height:1.25;transition:opacity .15s';d.title=u[3];
  d.innerHTML=`<span style="font-size:24px">${u[0]}</span><br><b>${u[1]}</b><br><span class="k" style="color:var(--mu)"></span>`;d.onpointerdown=e=>{e.preventDefault();buyU(i)};ups.append(d);return d});
 function float(txt,px,py,col){const f=E('div','',txt);f.style.cssText=`position:absolute;left:${px}px;top:${py}px;transform:translate(-50%,-50%);font-weight:800;font-size:22px;color:${col||'var(--tx)'};pointer-events:none;text-shadow:0 1px 3px rgba(0,0,0,.3)`;area.append(f);
  f.animate([{transform:'translate(-50%,-50%)',opacity:1},{transform:'translate(-50%,-130%)',opacity:0}],{duration:800,easing:'ease-out'}).onfinish=()=>f.remove()}
 function click(e){e.preventDefault();const g=perClick();S.c+=g;S.tot+=g;S.clicks++;ck.style.transform='scale(.88) rotate(-4deg)';setTimeout(()=>ck.style.transform='',90);
  const r=area.getBoundingClientRect();float('+'+fmtD(g),(e.clientX-r.left)||r.width/2,(e.clientY-r.top)||r.height/2);beep(900+R(200),.03,'sine',.02);draw()}
 ck.onpointerdown=click;
 function buy(i){const k=cost(i);if(S.c<k)return;S.c-=k;S.b[i]++;beep(660,.07,'triangle',.04);setTimeout(()=>beep(990,.08,'triangle',.04),70);draw(1)}
 function buyU(i){if(S.u[i]||S.c<U[i][2])return;S.c-=U[i][2];S.u[i]=1;beep(784,.1,'triangle',.05);setTimeout(()=>beep(1175,.14,'triangle',.05),100);draw(1)}
 let lastShop=0,armed=0,armT;
 function draw(force){const p=cps();sc.textContent='🍪 '+fmt(S.c)+' koekjes';sub.textContent=fmtD(p)+' per seconde · totaal gebakken: '+fmt(S.tot);pc.textContent='+'+fmtD(perClick())+' per klik';
  const now=performance.now();if(!force&&now-lastShop<150)return;lastShop=now;
  rows.forEach((r,i)=>{const k=cost(i);r.querySelector('.n').textContent=S.b[i]?'× '+S.b[i]:'';r.querySelector('.k').textContent=fmt(k)+' 🍪';r.style.opacity=S.c>=k?'1':'.45'});
  ucards.forEach((d,i)=>{d.querySelector('.k').textContent=S.u[i]?'✔ gekocht':fmt(U[i][2])+' 🍪';d.style.opacity=S.u[i]||S.c>=U[i][2]?'1':'.45';d.style.background=S.u[i]?'#2ecc7133':'var(--bg)'})}
 function showMsg(h){msg.innerHTML=h;msg.style.display='block';clearTimeout(msg._t);msg._t=setTimeout(()=>msg.style.display='none',9000)}
 msg.onclick=()=>msg.style.display='none';
 function arm(){if(armed){clearTimeout(armT);armed=0;S=fresh();save();rs.textContent='🗑️ Reset';showMsg('Alles gewist. Veel bakplezier!');draw(1);return}
  armed=1;rs.textContent='⚠️ Zeker? Tik nogmaals om te wissen';showMsg('⚠️ Alle voortgang wissen? Tik binnen 3 s nogmaals op Reset (of Opnieuw) om te bevestigen.');clearTimeout(armT);armT=setTimeout(()=>{armed=0;rs.textContent='🗑️ Reset';msg.style.display='none'},3000)}
 rs.onclick=arm;
 function init(){S=load();if(S){const away=Math.min(3600,Math.max(0,(Date.now()-(S.t||Date.now()))/1000)),p=cps(),gain=away*p;
   if(gain>0){S.c+=gain;S.tot+=gain}if(away>10&&gain>0){showMsg('👋 Welkom terug! Terwijl je '+(away>=60?Math.floor(away/60)+' min':Math.floor(away)+' s')+' weg was, bakten je helpers '+fmt(gain)+' koekjes.')}}
  else S=fresh();draw(1)}
 const stopLoop=loop(dt=>{const p=cps();if(p>0){S.c+=p*dt;S.tot+=p*dt}draw()});
 const saveT=setInterval(save,2000);
 st.ck={get S(){return S},cost,cps,perClick};
 init();cur.reset=arm;return()=>{stopLoop();clearInterval(saveT);clearTimeout(armT);clearTimeout(msg._t);save();ck.onpointerdown=null}}},
