{id:'maze3d',n:'Doolhof 3D',e:'🧱',c:'3D',g:'#283c86,#45a247',nw:1,run(st){
 const W=400,H=300,T=three(st,W,H,{fov:72,far:60}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 const sel=E('div','');sel.style.cssText='display:flex;gap:6px;justify-content:center;margin:4px 0 8px';const sbs=[];
 [8,12,16].forEach(n=>{const b=E('button','btn',n+'×'+n);b.onclick=()=>{if(size!==n){size=n;try{localStorage.setItem('sp_maze3d_size',n)}catch(e){}init()}};sel.append(b);sbs.push([n,b])});c.before(sel);
 const wr=E('div','wrap');c.replaceWith(wr);wr.append(c);
 const mm=E('canvas');mm.width=mm.height=168;mm.style.cssText='position:absolute;right:8px;top:8px;width:84px;height:84px;background:rgba(10,13,26,.6);border-radius:8px;pointer-events:none';wr.append(mm);const mx=mm.getContext('2d');
 st.append(E('div','hint','▲ ▼ = lopen · ◀ ▶ of slepen = draaien · vind de groene uitgang'));
 const BG=0x0a0d1a;S.background=new THREE.Color(BG);S.fog=new THREE.Fog(BG,1.5,13);
 T.r.toneMapping=THREE.ACESFilmicToneMapping;S.add(new THREE.HemisphereLight(0x9ab0e0,0x2a2a38,1.4));const torch=new THREE.PointLight(0xffd9a0,1.5,9,2);S.add(torch);const exl=new THREE.PointLight(0x4dff8a,1.2,6,2);S.add(exl);
 const bc=document.createElement('canvas');bc.width=bc.height=64;const bx=bc.getContext('2d');bx.fillStyle='#d9d4cc';bx.fillRect(0,0,64,64);for(let r=0;r<4;r++)for(let k=0;k<2;k++){bx.fillStyle=['#f2ece2','#e8e1d6','#ece6dc'][(r+k)%3];bx.fillRect(((k*32+(r%2)*16)%64)+1.5,r*16+1.5,29,13)}
 const btx=new THREE.CanvasTexture(bc);btx.colorSpace=THREE.SRGBColorSpace;btx.wrapS=btx.wrapT=THREE.RepeatWrapping;btx.anisotropy=T.r.capabilities.getMaxAnisotropy();btx.repeat.set(2,2);
 const WH=1.4,MAXL=33,wall=new THREE.InstancedMesh(new THREE.BoxGeometry(1,WH,1),new THREE.MeshStandardMaterial({color:0xffffff,map:btx,roughness:.9}),MAXL*MAXL);S.add(wall);
 const fc=document.createElement('canvas');fc.width=fc.height=64;const fx=fc.getContext('2d');fx.fillStyle='#262b3a';fx.fillRect(0,0,64,64);fx.strokeStyle='#343a4e';fx.lineWidth=3;fx.strokeRect(1.5,1.5,61,61);fx.fillStyle='#2d3344';fx.fillRect(14,14,36,36);
 const ft=new THREE.CanvasTexture(fc);ft.wrapS=ft.wrapT=THREE.RepeatWrapping;ft.colorSpace=THREE.SRGBColorSpace;ft.anisotropy=T.r.capabilities.getMaxAnisotropy();
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(1,1),new THREE.MeshStandardMaterial({map:ft,roughness:.95}));floor.rotation.x=-Math.PI/2;S.add(floor);
 const ceil=new THREE.Mesh(new THREE.PlaneGeometry(1,1),new THREE.MeshStandardMaterial({color:0x1e2232,roughness:1}));ceil.rotation.x=Math.PI/2;ceil.position.y=WH;S.add(ceil);
 const exitG=new THREE.Group(),gem=new THREE.Mesh(new THREE.OctahedronGeometry(.22),new THREE.MeshStandardMaterial({color:0x7dffb0,emissive:0x2bff7a,emissiveIntensity:1.6,roughness:.3}));gem.position.y=.75;
 const beam=new THREE.Mesh(new THREE.CylinderGeometry(.22,.3,WH,16,1,true),new THREE.MeshBasicMaterial({color:0x4dff8a,transparent:true,opacity:.18,side:THREE.DoubleSide,depthWrite:false}));beam.position.y=WH/2;
 const disc=new THREE.Mesh(new THREE.CircleGeometry(.38,20),new THREE.MeshBasicMaterial({color:0x4dff8a,transparent:true,opacity:.5}));disc.rotation.x=-Math.PI/2;disc.position.y=.012;exitG.add(gem,beam,disc);S.add(exitG);
 const bt=(n,s)=>{try{const k='sp_maze3d_'+n,b=+localStorage.getItem(k)||0;if(s>0&&(!b||s<b)){localStorage.setItem(k,s);return s}return b}catch(e){return s||0}};
 let size=8,L,grid,px,pz,ang,t,started,won,seen,wonAt,bob,vis,t0;try{size=[8,12,16].includes(+localStorage.getItem('sp_maze3d_size'))?+localStorage.getItem('sp_maze3d_size'):8}catch(e){}
 function gen(n){L=2*n+1;grid=Array.from({length:L},()=>new Uint8Array(L).fill(1));const stk=[[0,0]],V=new Set(['0,0']);grid[1][1]=0;
  while(stk.length){const [cx,cy]=stk[stk.length-1],nb=[[1,0],[-1,0],[0,1],[0,-1]].map(([dx,dy])=>[cx+dx,cy+dy]).filter(([x,y])=>x>=0&&y>=0&&x<n&&y<n&&!V.has(x+','+y));
   if(!nb.length){stk.pop();continue}const [nx,ny]=nb[R(nb.length)];V.add(nx+','+ny);grid[2*ny+1][2*nx+1]=0;grid[cy+ny+1][cx+nx+1]=0;stk.push([nx,ny])}}
 function build(){const m=new THREE.Matrix4(),col=new THREE.Color();let i=0;
  for(let z=0;z<L;z++)for(let x=0;x<L;x++)if(grid[z][x]){let open=0;for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++){const zz=z+dz,xx=x+dx;if(zz>=0&&xx>=0&&zz<L&&xx<L&&!grid[zz][xx])open=1}if(!open)continue;
   m.makeTranslation(x+.5,WH/2,z+.5);wall.setMatrixAt(i,m);col.setHSL(.58+Math.random()*.08,.4,.36+Math.random()*.12);wall.setColorAt(i,col);i++}
  wall.count=i;wall.instanceMatrix.needsUpdate=true;wall.instanceColor.needsUpdate=true;
  floor.scale.set(L,L,1);floor.position.set(L/2,0,L/2);ft.repeat.set(L,L);ceil.scale.set(L,L,1);ceil.position.set(L/2,WH,L/2);
  exitG.position.set(L-1.5,0,L-1.5);exl.position.set(L-1.5,.8,L-1.5)}
 function init(){gen(size);build();px=1.5;pz=1.5;ang=grid[1][2]===0?-Math.PI/2:Math.PI;t=0;t0=0;started=0;won=0;bob=0;seen=new Set;vis=new Set;sbs.forEach(([n,b])=>b.style.opacity=n===size?1:.5);overlay(st,c,'')}
 const hit=(x,z)=>{const r=.27;for(let bz=Math.floor(z)-1;bz<=Math.floor(z)+1;bz++)for(let bx=Math.floor(x)-1;bx<=Math.floor(x)+1;bx++){if(bz<0||bx<0||bz>=L||bx>=L||!grid[bz][bx])continue;
   const nx=Math.max(bx,Math.min(bx+1,x)),nz=Math.max(bz,Math.min(bz+1,z));if((nx-x)**2+(nz-z)**2<r*r)return 1}return 0};
 function win(){won=1;wonAt=performance.now();const s=Math.round(t*10)/10,b=bt(size,s);beep(660,.1,'triangle',.05);setTimeout(()=>beep(880,.12,'triangle',.05),120);setTimeout(()=>beep(1100,.2,'triangle',.05),260);
  overlay(st,c,`🎉 Uitgang gevonden!<br><span style="font-size:15px;font-weight:600">Tijd ${s.toFixed(1)} s · Beste ${size}×${size}: ${b.toFixed(1)} s<br>Tik of druk op een toets voor een nieuw doolhof</span>`).style.pointerEvents='none'}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight']],k=>{if(won&&performance.now()-wonAt>900)init()});
 let drag=0,lx=0,mv=0;c.onpointerdown=e=>{e.preventDefault();try{c.setPointerCapture(e.pointerId)}catch(x){}drag=1;lx=e.clientX;mv=0};
 c.onpointermove=e=>{if(!drag)return;const dx=(e.clientX-lx)*W/c.getBoundingClientRect().width;lx=e.clientX;mv+=Math.abs(dx);if(!won){ang-=dx*.007;started=1}};
 c.onpointerup=c.onpointercancel=e=>{if(!drag)return;drag=0;if(mv<8&&won&&performance.now()-wonAt>900)init()};
 const stopLoop=loop(dt=>{
  const fw=(inp.has('ArrowUp')||inp.has('w'))-(inp.has('ArrowDown')||inp.has('s')),tn=(inp.has('ArrowLeft')||inp.has('a'))-(inp.has('ArrowRight')||inp.has('d'));
  if(!won){if((fw||tn)&&!started)started=1;if(started){if(!t0)t0=performance.now();t=(performance.now()-t0)/1000}ang+=tn*2.3*dt;
   if(fw){const sp=fw*2.5*dt,nx=px-Math.sin(ang)*sp,nz=pz-Math.cos(ang)*sp;if(!hit(nx,pz))px=nx;if(!hit(px,nz))pz=nz;bob+=dt*9}
   const cx=Math.floor(px),cz=Math.floor(pz);for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++)seen.add((cx+dx)+','+(cz+dz));vis.add(cx+','+cz);
   if(cx===L-2&&cz===L-2)win()}
  cam.position.set(px,.62+Math.sin(bob)*.015,pz);cam.rotation.set(0,ang,0);torch.position.set(px,.9,pz);
  const now=performance.now()/1000;gem.rotation.y=now*1.5;gem.position.y=.75+Math.sin(now*2.5)*.08;exl.intensity=1.1+Math.sin(now*4)*.5;beam.material.opacity=.14+Math.sin(now*3)*.06;
  // minimap
  const cs=160/L;mx.clearRect(0,0,168,168);mx.save();mx.translate(4,4);
  for(let z=0;z<L;z++)for(let x=0;x<L;x++){if(!seen.has(x+','+z))continue;mx.fillStyle=grid[z][x]?'#5b6a9a':vis.has(x+','+z)?'#cfd6ee':'#8a93b8';mx.fillRect(x*cs,z*cs,cs+.5,cs+.5)}
  mx.fillStyle='#4dff8a';mx.beginPath();mx.arc((L-1.5)*cs,(L-1.5)*cs,Math.max(2,cs*.4),0,7);mx.fill();
  mx.fillStyle='#ffb703';mx.beginPath();mx.arc(px*cs,pz*cs,Math.max(2.5,cs*.35),0,7);mx.fill();mx.strokeStyle='#ffb703';mx.lineWidth=2;mx.beginPath();mx.moveTo(px*cs,pz*cs);mx.lineTo((px-Math.sin(ang)*1.2)*cs,(pz-Math.cos(ang)*1.2)*cs);mx.stroke();mx.restore();
  const b=bt(size,0);sc.textContent='Tijd: '+t.toFixed(1)+' s · Beste '+size+'×'+size+': '+(b?b.toFixed(1)+' s':'–')+(won?' · Gevonden!':'');
  T.r.render(S,cam)});
 init();cur.reset=init;cur.tp=()=>{px=L-2.5+(grid[L-2][L-3]===0?0:1);pz=L-2.5+(grid[L-2][L-3]===0?1:0);ang=grid[L-2][L-3]===0?-Math.PI/2:Math.PI;started=1};
 return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;sbs.forEach(([n,b])=>b.onclick=null);T.dispose()}}},
