{id:'connect4',n:'Vier op een Rij',e:'🔴',c:'Bord',g:'#ff416c,#ff4b2b',nw:1,run(st){
 // 7x6 Connect Four. Human = red (begins), computer = yellow.
 const sc=E('div','sc');st.append(sc);
 const top=E('div','bdr');top.style.cssText+='grid-template-columns:repeat(7,minmax(0,1fr));width:min(380px,100%);gap:6px;padding:0 8px;margin:6px auto 0';
 const bd=E('div','bdr');bd.style.cssText+='grid-template-columns:repeat(7,minmax(0,1fr));width:min(380px,100%);gap:6px;padding:8px;background:linear-gradient(160deg,#2f6fe4,#1b47b8);border-radius:14px;box-shadow:0 6px 16px rgba(20,50,140,.45);margin-top:2px';
 const hint=E('div','hint','Tik op een kolom · toetsen 1–7 of ◀ ▶ en spatie · vier op een rij wint');
 st.append(top,bd,hint);
 const RED='radial-gradient(circle at 35% 35%,#ff8a8a,#e8343f 55%,#a3121c)',YEL='radial-gradient(circle at 35% 35%,#fff3a0,#f5c518 55%,#b58a00)';
 const tops=[],cells=[],discs=[];
 for(let c=0;c<7;c++){const d=E('div');d.style.cssText='aspect-ratio:auto;height:26px;position:relative';const s=E('span');s.style.cssText='display:none;width:24px;height:24px;border-radius:50%;opacity:.6';d.append(s);tops.push(s);d.onpointerdown=e=>{e.preventDefault();human(c)};top.append(d)}
 for(let i=0;i<42;i++){const d=E('div');d.style.cssText='border-radius:50%;background:var(--bg);box-shadow:inset 0 2px 5px rgba(0,0,0,.35);position:relative';
  const s=E('span');s.style.cssText='display:none;position:absolute;inset:6%;border-radius:50%;box-shadow:0 2px 4px rgba(0,0,0,.45),inset 0 -3px 6px rgba(0,0,0,.25)';d.append(s);discs.push(s);
  d.onpointerdown=e=>{e.preventDefault();human(i%7)};cells.push(d);bd.append(d)}
 // ---------- rules ----------
 const WIN=[];for(let r=0;r<6;r++)for(let c=0;c<7;c++){if(c<4)WIN.push([r*7+c,r*7+c+1,r*7+c+2,r*7+c+3]);if(r<3)WIN.push([r*7+c,(r+1)*7+c,(r+2)*7+c,(r+3)*7+c]);if(r<3&&c<4)WIN.push([r*7+c,(r+1)*7+c+1,(r+2)*7+c+2,(r+3)*7+c+3]);if(r<3&&c>2)WIN.push([r*7+c,(r+1)*7+c-1,(r+2)*7+c-2,(r+3)*7+c-3])}
 function drop(b,c,p){for(let r=5;r>=0;r--){const i=r*7+c;if(!b[i]){b[i]=p;return i}}return-1}
 function winLine(b,i){const p=b[i],r=(i/7)|0,c=i%7,out=[];
  for(const[dr,dc]of[[0,1],[1,0],[1,1],[1,-1]]){const line=[i];for(const s of[1,-1]){let R=r+dr*s,C=c+dc*s;while(R>=0&&R<6&&C>=0&&C<7&&b[R*7+C]===p){line.push(R*7+C);R+=dr*s;C+=dc*s}}if(line.length>=4)out.push(...line)}
  return out.length?[...new Set(out)]:null}
 const wins=(b,i)=>i>=0&&!!winLine(b,i);
 // ---------- AI ----------
 const ORD=[3,2,4,1,5,0,6],CEN=[0,0,0,0,0,0,0];for(let r=0;r<6;r++)CEN[r*7+3]=1;
 function evalB(b,p){let e=0;for(const w of WIN){let m=0,o=0;for(const i of w){const v=b[i];if(v===p)m++;else if(v)o++}
   if(m&&!o)e+=m===3?60:m===2?8:1;else if(o&&!m)e-=o===3?70:o===2?9:1}
  for(let r=0;r<6;r++){const v=b[r*7+3];if(v===p)e+=5;else if(v)e-=5}return e}
 let nodes=0;
 function search(b,p,d,a,be,last){nodes++;if(last>=0&&wins(b,last))return-(100000+d);
  if(d<=0)return evalB(b,p);let any=0,best=-Infinity;
  for(const c of ORD){const i=drop(b,c,p);if(i<0)continue;any=1;const v=-search(b,-p,d-1,-be,-a,i);b[i]=0;if(v>best)best=v;if(v>a)a=v;if(a>=be)break}
  return any?best:0}
 let depth=6,lastMs=0;
 function root(b,p,D){let bc=-1,bv=-Infinity,a=-Infinity;const ord=R(2)?[3,2,4,1,5,0,6]:[3,4,2,5,1,6,0];// mirror at random for variety
  for(const c of ord){const i=drop(b,c,p);if(i<0)continue;const v=-search(b,-p,D-1,-Infinity,-a,i);b[i]=0;if(v>bv){bv=v;bc=c}if(v>a)a=v}
  return bc}
 function bestMove(b,p,fd){nodes=0;const w=b.slice();
  // fast paths: take an immediate win, otherwise block an immediate loss
  for(const c of ORD){const i=drop(w,c,p);if(i<0)continue;const ok=wins(w,i);w[i]=0;if(ok)return c}
  for(const c of ORD){const i=drop(w,c,-p);if(i<0)continue;const ok=wins(w,i);w[i]=0;if(ok)return c}
  const t0=performance.now();depth=fd||6;let m=root(w,p,depth);
  if(!fd)for(const D of[7,8]){if(performance.now()-t0>25)break;depth=D;m=root(w,p,D)}// still cheap: look further ahead
  return m}
 // ---------- state ----------
 let b,t,over,win,busy,cur_c,tm=0,n;
 function draw(){
  for(let i=0;i<42;i++){const v=b[i],s=discs[i];if(!v){s.style.display='none';s.dataset.v='';continue}
   s.style.display='block';s.style.background=v===1?RED:YEL;
   if(win){const w=win.includes(i);s.style.opacity=w?'1':'.45';s.style.boxShadow=w?'0 0 0 3px #fff,0 0 14px 4px rgba(255,255,255,.7)':'none'}else{s.style.opacity='1';s.style.boxShadow='0 2px 4px rgba(0,0,0,.45),inset 0 -3px 6px rgba(0,0,0,.25)'}}
  for(let c=0;c<7;c++){const s=tops[c];const show=!over&&!busy&&t===1&&c===cur_c&&b[c]===0;s.style.display=show?'block':'none';s.style.background=RED}
  sc.textContent=over?over:busy?'🤖 Computer denkt…':'🔴 Jij bent aan zet · zet '+(n+1)}
 function animate(i){const s=discs[i],r=(i/7)|0,h=cells[i].getBoundingClientRect().height||44;
  try{s.animate([{transform:'translateY(-'+((r+1)*(h+6))+'px)'},{transform:'none'}],{duration:120+r*55,easing:'cubic-bezier(.3,.6,.5,1.25)'})}catch(e){}}
 function place(c){const i=drop(b,c,t);if(i<0)return false;n++;draw();animate(i);beep(t===1?440:330,.06,'triangle',.04);
  const wl=winLine(b,i);if(wl){win=wl;over=t===1?'🎉 Jij wint!':'De computer wint 🤖';beep(t===1?880:160,.4,t===1?'triangle':'sawtooth',.05)}
  else if(n===42){over='Gelijkspel · het bord is vol';beep(330,.3,'sine',.04)}
  t=-t;return true}
 function human(c){if(over||busy||t!==1)return;cur_c=c;if(b[c]){draw();return}place(c);draw();if(!over){busy=1;draw();tm=setTimeout(aiMove,300)}}
 function aiMove(){tm=0;const t0=performance.now();const c=bestMove(b,-1);lastMs=performance.now()-t0;busy=0;if(c>=0)place(c);draw()}
 const inp=input(st,[],k=>{if(over||busy)return;
  if(k>='1'&&k<='7')human(+k-1);else if(k==='ArrowLeft'){cur_c=(cur_c+6)%7;draw()}else if(k==='ArrowRight'){cur_c=(cur_c+1)%7;draw()}else if(k===' '||k==='Enter'||k==='ArrowDown')human(cur_c)});
 function init(){clearTimeout(tm);tm=0;b=Array(42).fill(0);t=1;over='';win=null;busy=0;cur_c=3;n=0;draw()}
 window._c4={auto:1,board:()=>b.slice(),state:()=>({over,turn:t,busy,n}),
  drop(c){if(over||busy||b[c])return false;place(c);draw();if(this.auto&&!over&&t===-1){busy=1;draw();tm=setTimeout(aiMove,300)}return true},
  set(arr,side){clearTimeout(tm);b=arr.slice();t=side;over='';win=null;busy=0;n=b.filter(Boolean).length;draw()},
  ai(d){clearTimeout(tm);const t0=performance.now();const c=bestMove(b,t,d);const ms=performance.now()-t0;if(c>=0)place(c);draw();return{ms,nodes,c,depth}}};
 init();cur.reset=init;return()=>{clearTimeout(tm);tm=0;inp.stop();delete window._c4}}},
