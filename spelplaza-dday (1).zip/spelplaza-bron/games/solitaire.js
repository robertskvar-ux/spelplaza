{id:'solitaire',n:'Patience',e:'🂡',c:'Kaarten',g:'#0f9b0f,#2e8b57',nw:1,run(st){
 // Klondike patience: 7 kolommen, voorraad, afleg, 4 fundamenten. Tik om te kiezen, tik op het doel om te leggen.
 const SU=['♠','♥','♦','♣'],RN=['A','2','3','4','5','6','7','8','9','10','J','Q','K'],red=c=>c.s===1||c.s===2;
 const lb=(id,s)=>{try{const k='sp_'+id,b=+localStorage.getItem(k)||0;if(s<0&&(!b||s>b)){localStorage.setItem(k,s);return s}return b}catch(e){return 0}};// best() negeert negatieve scores: eigen "minder is beter"-opslag
 const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
 const sc=E('div','sc');
 const bar=E('div');bar.style.cssText='display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:4px 0 8px';
 const bUndo=E('button','btn','↩ Ongedaan'),bDraw=E('button','btn','🔁 Trek 1'),bFin=E('button','btn','✨ Afmaken');
 [bUndo,bDraw,bFin].forEach(b=>b.style.cssText='padding:7px 12px;font-size:13px');bFin.style.background='linear-gradient(135deg,#f5af19,#f12711)';bar.append(bUndo,bDraw,bFin);
 const board=E('div');board.style.cssText='position:relative;width:min(500px,100%);margin:0 auto;touch-action:manipulation;user-select:none;-webkit-user-select:none;background:radial-gradient(ellipse at 50% 20%,#2e9d57,#176b3a 80%);border-radius:14px;box-shadow:inset 0 0 30px rgba(0,0,0,.35)';
 const hint=E('div','hint','Tik op een kaart (of reeks) en dan op het doel · tik nog eens op een gekozen kaart om ze naar een fundament te sturen · tik op de voorraad om te trekken · spatie = trekken · u = ongedaan');
 st.append(sc,bar,board,hint);
 // ---------- vaste vakken en kaart-elementen ----------
 const slot=(p,txt)=>{const d=E('div','',txt);d.dataset.p=p;d.dataset.i=-1;d.style.cssText='position:absolute;border:2px dashed rgba(255,255,255,.45);border-radius:6px;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.55);font-weight:800;font-size:22px;cursor:pointer';board.append(d);return d};
 const sStock=slot('S','♻'),sWaste=slot('W',''),sF=[0,1,2,3].map(k=>slot('F'+k,'A')),sT=[0,1,2,3,4,5,6].map(k=>slot('T'+k,''));
 const el={};const cards=[];for(let s=0;s<4;s++)for(let r=1;r<=13;r++){const id=s*13+r,d=E('div');d.dataset.id=id;
  d.style.cssText='position:absolute;border-radius:5px;box-shadow:0 1px 3px rgba(0,0,0,.4);cursor:pointer;transition:left .18s ease,top .18s ease;overflow:hidden';
  const tl=E('span','',RN[r-1]+SU[s]),ct=E('span','',SU[s]);tl.style.cssText='position:absolute;top:2px;left:4px;font-weight:800;line-height:1';ct.style.cssText='position:absolute;right:4px;bottom:2px;line-height:1';d.append(tl,ct);d._tl=tl;d._ct=ct;el[id]=d;board.append(d);cards.push({id,r,s,up:0})}
 const ov=E('div','ov');ov.style.cssText+='display:none;overflow:hidden;z-index:500';ov.onpointerdown=e=>{e.preventDefault();init()};board.append(ov);
 // ---------- toestand ----------
 let S,hist,sel,moves,draw3=0,t0,secs,won,tm=0,auto=0,cw,ch,gap,offU,offD,y0;
 const top=a=>a[a.length-1];
 function layout(){const w=board.clientWidth||360;gap=w<420?4:6;cw=Math.floor((w-6*gap)/7);ch=Math.round(cw*1.42);offU=cw<60?18:26;offD=cw<60?8:12;y0=ch+14;
  const fs=Math.max(11,Math.round(cw*.27)),cs=Math.round(cw*.5);
  for(const c of cards){const d=el[c.id];d.style.width=cw+'px';d.style.height=ch+'px';d._tl.style.fontSize=fs+'px';d._ct.style.fontSize=cs+'px'}
  const X=k=>gap/2+k*(cw+gap);[sStock,sWaste,...sF,...sT].forEach((s,k)=>{const col=k<2?k:k<6?k+1:k-6;s.style.left=X(col)+'px';s.style.top=(k<6?6:y0)+'px';s.style.width=cw+'px';s.style.height=ch+'px'})}
 function put(c,x,y,z){const d=el[c.id];d.style.left=x+'px';d.style.top=y+'px';d.style.zIndex=z;
  if(c.up){d.style.background='#fff';d.style.border='1px solid #c9ccd6';d.style.color=red(c)?'#d32f2f':'#1b1d2a';d._tl.style.display=d._ct.style.display=''}
  else{d.style.background='repeating-linear-gradient(45deg,#3457b5 0 5px,#1e3c72 5px 10px)';d.style.border='3px solid #eef0f6';d._tl.style.display=d._ct.style.display='none'}}
 function draw(){const X=k=>gap/2+k*(cw+gap),inSel=new Set(selCards().map(c=>c.id));let hmax=y0+ch;
  S.stock.forEach((c,i)=>{put(c,X(0),6,i+1);el[c.id].dataset.p='S';el[c.id].dataset.i=i});
  const fan=draw3?Math.round(cw*.32):0,n=S.waste.length;
  S.waste.forEach((c,i)=>{const k=Math.max(0,i-(n-3));put(c,X(1)+(i>=n-3?k*fan:0),6,i+1);el[c.id].dataset.p='W';el[c.id].dataset.i=i});
  S.f.forEach((f,k)=>f.forEach((c,i)=>{put(c,X(3+k),6,i+1);el[c.id].dataset.p='F'+k;el[c.id].dataset.i=i}));
  S.t.forEach((col,k)=>{let y=y0;col.forEach((c,i)=>{put(c,X(k),y,i+1);el[c.id].dataset.p='T'+k;el[c.id].dataset.i=i;y+=c.up?offU:offD});hmax=Math.max(hmax,y-(col.length?(top(col).up?offU:offD):0)+ch)});
  for(const c of cards){const d=el[c.id];const s=inSel.has(c.id);d.style.boxShadow=s?'0 0 0 3px #ffd54a,0 4px 10px rgba(0,0,0,.4)':'0 1px 3px rgba(0,0,0,.4)';if(s)d.style.zIndex=+d.style.zIndex+100}
  board.style.height=(hmax+8)+'px';sStock.textContent=S.stock.length?'':S.waste.length?'♻':'';
  bFin.style.display=!won&&S.t.every(col=>col.every(c=>c.up))&&S.t.some(c=>c.length)?'':'none';bUndo.style.opacity=hist.length&&!won?'1':'.5';bDraw.textContent='🔁 Trek '+(draw3?3:1);
  const b=lb('solitaire',0);sc.textContent='Zetten: '+moves+' · Tijd: '+fmt(secs)+' · Beste tijd: '+(b?fmt(-b):'–')}
 // ---------- regels ----------
 const pile=p=>p==='S'?S.stock:p==='W'?S.waste:p[0]==='F'?S.f[+p[1]]:S.t[+p[1]];
 function selCards(){if(!sel)return[];const a=pile(sel.p);return a.slice(sel.i)}
 const canF=(c,k)=>{const f=S.f[k];return f.length?top(f).s===c.s&&top(f).r===c.r-1:c.r===1};
 const canT=(c,k)=>{const t=S.t[k];return t.length?top(t).up&&red(top(t))!==red(c)&&top(t).r===c.r+1:c.r===13};
 function snap(){hist.push(JSON.stringify(S));if(hist.length>400)hist.shift()}
 function act(f){snap();f();moves++;if(!t0)t0=Date.now();S.t.forEach(col=>{if(col.length&&!top(col).up)top(col).up=1});
  if(S.f.every(f=>f.length===13))win();else draw()}
 function moveTo(dst){const src=pile(sel.p),run=src.slice(sel.i);
  if(dst[0]==='F'){if(run.length!==1||!canF(run[0],+dst[1]))return false;act(()=>{src.pop();S.f[+dst[1]].push(run[0])});beep(660,.06,'triangle',.04);return true}
  if(dst[0]==='T'){if(!canT(run[0],+dst[1]))return false;act(()=>{src.splice(sel.i);S.t[+dst[1]].push(...run)});beep(480,.05,'triangle',.04);return true}
  return false}
 function toFound(){const src=pile(sel.p),run=src.slice(sel.i);if(run.length!==1)return false;const k=[0,1,2,3].find(k=>canF(run[0],k));if(k===undefined)return false;act(()=>{src.pop();S.f[k].push(run[0])});beep(720,.07,'triangle',.04);return true}
 function drawStock(){if(S.stock.length){act(()=>{for(let i=0;i<(draw3?3:1)&&S.stock.length;i++){const c=S.stock.pop();c.up=1;S.waste.push(c)}});beep(400,.04,'triangle',.03)}
  else if(S.waste.length){act(()=>{S.stock=S.waste.reverse();S.stock.forEach(c=>c.up=0);S.waste=[]});beep(300,.06,'sine',.03)}}
 function tap(p,i){if(won||auto)return;
  if(p==='S'){sel=null;drawStock();return}
  if(sel){if(sel.p===p&&sel.i===i){if(!toFound()){beep(220,.05,'square',.02)}sel=null;draw();return}
   if(p[0]==='T'||p[0]==='F'){const ok=moveTo(p);if(!ok){beep(200,.06,'square',.02);if(p[0]==='T'&&i>=0&&pile(p)[i].up){sel={p,i};draw();return}}sel=null;draw();return}
   if(p==='W'){sel=S.waste.length?{p:'W',i:S.waste.length-1}:null;draw();return}}
  if(p==='W'&&S.waste.length)sel={p:'W',i:S.waste.length-1};
  else if(p[0]==='F'&&pile(p).length)sel={p,i:pile(p).length-1};
  else if(p[0]==='T'&&i>=0&&pile(p)[i].up)sel={p,i};
  else sel=null;
  if(sel)beep(560,.03,'triangle',.02);draw()}
 function undo(){if(auto||!hist.length||won)return;S=JSON.parse(hist.pop());sel=null;moves++;beep(340,.05,'sine',.03);draw()}
 function finish(){if(auto||won)return;auto=1;sel=null;let guard=0;const step=()=>{guard++;
   for(let k=0;k<7;k++){const c=top(S.t[k]);if(c){const f=[0,1,2,3].find(f=>canF(c,f));if(f!==undefined){act(()=>{S.t[k].pop();S.f[f].push(c)});beep(600+f*60,.04,'triangle',.03);return}}}
   const w=top(S.waste);if(w){const f=[0,1,2,3].find(f=>canF(w,f));if(f!==undefined){act(()=>{S.waste.pop();S.f[f].push(w)});beep(600+f*60,.04,'triangle',.03);return}}
   if((S.stock.length||S.waste.length)&&guard<400)drawStock();else{clearInterval(tm);tm=0;auto=0;draw()}};
  tm=setInterval(()=>{if(won){clearInterval(tm);tm=0;auto=0;return}step()},110)}
 function win(){won=1;auto=0;clearInterval(tm);tm=0;sel=null;secs=t0?Math.floor((Date.now()-t0)/1000):0;const b=lb('solitaire',-Math.max(1,secs));draw();beep(880,.5,'triangle',.05);
  ov.innerHTML='🎉 Gewonnen!<br><span style="font-size:15px;font-weight:600">'+moves+' zetten · '+fmt(secs)+'<br>Beste tijd: '+fmt(-b)+'<br>Tik om opnieuw te spelen</span>';ov.style.display='flex';
  for(let i=0;i<28;i++){const p=E('span','',['🎉','✨','⭐','🃏'][R(4)]);p.style.cssText='position:absolute;top:-30px;left:'+R(100)+'%;font-size:'+(16+R(16))+'px;pointer-events:none';ov.append(p);
   try{p.animate([{transform:'translateY(0) rotate(0)',opacity:1},{transform:'translateY('+(board.clientHeight+60)+'px) rotate('+(R(2)?720:-720)+'deg)',opacity:.2}],{duration:1600+R(1400),delay:R(900),easing:'ease-in',fill:'forwards'})}catch(e){}}}
 board.onclick=e=>{const d=e.target.closest('[data-p]');if(!d)return;tap(d.dataset.p,+d.dataset.i)};
 bUndo.onclick=undo;bDraw.onclick=()=>{draw3=!draw3;draw()};bFin.onclick=finish;
 const inp=input(st,[],k=>{if(k===' '||k==='Enter')tap('S',-1);else if(k==='u'||k==='Backspace')undo();else if(k==='a'&&bFin.style.display!=='none')finish()});
 let tick=setInterval(()=>{if(t0&&!won){const s=Math.floor((Date.now()-t0)/1000);if(s!==secs){secs=s;sc.textContent='Zetten: '+moves+' · Tijd: '+fmt(secs)+' · Beste tijd: '+(lb('solitaire',0)?fmt(-lb('solitaire',0)):'–')}}},500);
 const onRs=()=>{layout();draw()};addEventListener('resize',onRs);
 function init(){clearInterval(tm);tm=0;auto=0;won=0;sel=null;moves=0;t0=0;secs=0;hist=[];ov.style.display='none';ov.innerHTML='';
  const deck=cards.map(c=>({...c,up:0}));for(let i=51;i>0;i--){const j=R(i+1);[deck[i],deck[j]]=[deck[j],deck[i]]}
  S={stock:[],waste:[],f:[[],[],[],[]],t:[[],[],[],[],[],[],[]]};for(let k=0;k<7;k++)for(let i=0;i<=k;i++){const c=deck.pop();c.up=i===k;S.t[k].push(c)}S.stock=deck;
  layout();for(const c of cards){const d=el[c.id];d.style.transition='none';d.style.left=(gap/2)+'px';d.style.top='6px'}void board.offsetWidth;for(const c of cards)el[c.id].style.transition='left .18s ease,top .18s ease';draw()}
 window._sol={state:()=>JSON.parse(JSON.stringify({S,sel,moves,won,hist:hist.length,draw3})),tap,undo,finish,set(s){S=JSON.parse(JSON.stringify(s));sel=null;draw()}};
 init();cur.reset=init;return()=>{clearInterval(tm);clearInterval(tick);tm=0;auto=0;inp.stop();removeEventListener('resize',onRs);delete window._sol}}},
