{id:'simon',n:'Simon Zegt',e:'🎵',c:'Geheugen',g:'#c471f5,#fa71cd',run(st){
 const W=340,C=W/2,c=mkCanvas(st,W,W),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Herhaal de reeks · tik op de kleuren of gebruik 1–4 / Q W A S · het tempo gaat omhoog!'));
 // 0 groen (linksboven) · 1 rood (rechtsboven) · 2 geel (linksonder) · 3 blauw (rechtsonder)
 const COL=[['#1fa35b','#5dff9e'],['#c0392b','#ff7a6b'],['#c9a400','#ffe45c'],['#2369c9','#6fb6ff']],FR=[415.3,310,252,209],A0=[Math.PI,Math.PI*1.5,Math.PI*.5,0];
 const KM={'1':0,'2':1,'3':2,'4':3,q:0,w:1,a:2,s:3,ArrowUp:0,ArrowRight:1,ArrowLeft:2,ArrowDown:3};
 let seq,pos,state,timer,showI,lt,round,t,overT,flash;
 function speed(){return Math.max(.24,.62-seq.length*.028)}
 function tone(i,d){beep(FR[i],d,'triangle',.06);beep(FR[i]*2,d*.7,'sine',.015)}
 function light(i,d){lt[i]=1;tone(i,d)}
 function init(){seq=[];pos=0;state=0;timer=0;showI=0;lt=[0,0,0,0];round=0;t=0;overT=0;flash=0;overlay(st,c,'')}
 function next(){seq.push(R(4));pos=0;state=1;showI=0;timer=.7}
 function press(i){if(state===0){next();return}if(state===3){if(overT>.6)init();return}if(state!==2)return;
  light(i,.22);if(seq[pos]===i){pos++;if(pos===seq.length){round=seq.length;best('simon',round);state=4;timer=.8;flash=.5}}
  else{state=3;overT=0;beep(90,.6,'sawtooth',.06);const o=overlay(st,c,`❌ Fout!<br><span style="font-size:15px;font-weight:600">Je haalde ${round} ${round===1?'ronde':'rondes'} · Beste ${best('simon',round)}<br>Tik of druk op een toets om opnieuw te spelen</span>`);if(o)o.style.pointerEvents='none'}}
 function hit(px,py){const dx=px-C,dy=py-C,d=Math.hypot(dx,dy);if(d<56){if(state===0||state===3)press(0);return -1}if(d>C-6)return -1;return dy<0?(dx<0?0:1):(dx<0?2:3)}
 c.onpointerdown=e=>{e.preventDefault();const r=c.getBoundingClientRect(),i=hit((e.clientX-r.left)*W/r.width,(e.clientY-r.top)*W/r.height);if(i>=0)press(i)};
 const inp=input(st,[],k=>{const i=KM[k];if(i!=null)press(i);else if(k===' '||k==='Enter'){if(state===0||state===3)press(0)}});
 const stopLoop=loop(dt=>{t+=dt;overT+=dt;for(let i=0;i<4;i++)lt[i]=Math.max(0,lt[i]-dt*3.2);flash=Math.max(0,flash-dt);
  if(state===1){timer-=dt;if(timer<=0){if(showI<seq.length){const sp=speed();light(seq[showI],sp*.75);showI++;timer=sp}else{state=2;pos=0}}}
  else if(state===4){timer-=dt;if(timer<=0)next()}
  x.fillStyle='#0e1020';x.fillRect(0,0,W,W);
  x.fillStyle='#1a1d3a';x.beginPath();x.arc(C,C,C-2,0,7);x.fill();
  for(let i=0;i<4;i++){const l=lt[i],a0=A0[i],a1=A0[i]+Math.PI/2;
   x.save();if(l>0){x.shadowColor=COL[i][1];x.shadowBlur=30*l}
   const g=x.createRadialGradient(C,C,60,C,C,C-10);g.addColorStop(0,l>.05?COL[i][1]:COL[i][0]);g.addColorStop(1,COL[i][0]);
   x.globalAlpha=.5+.5*Math.max(l,state===2?.35:.1);x.fillStyle=g;x.beginPath();x.arc(C,C,C-12,a0,a1);x.arc(C,C,64,a1,a0,true);x.closePath();x.fill();x.restore()}
  x.globalAlpha=1;x.strokeStyle='#1a1d3a';x.lineWidth=12;x.beginPath();x.moveTo(C,8);x.lineTo(C,W-8);x.moveTo(8,C);x.lineTo(W-8,C);x.stroke();x.fillStyle=flash>0?'#2b6a4a':'#121430';x.strokeStyle='#2c3060';x.lineWidth=4;x.beginPath();x.arc(C,C,56,0,7);x.fill();x.stroke();
  x.fillStyle='#fff';x.textAlign='center';x.textBaseline='middle';
  if(state===0){x.font='900 22px system-ui,sans-serif';x.fillText('START',C,C-6);x.font='600 11px system-ui,sans-serif';x.fillStyle='#9aa0c8';x.fillText('tik hier',C,C+14)}
  else{x.font='900 34px system-ui,sans-serif';x.fillText(seq.length,C,C-6);x.font='600 11px system-ui,sans-serif';x.fillStyle='#9aa0c8';x.fillText(state===1?'kijk…':state===2?'jouw beurt':state===4?'goed!':'ronde',C,C+20)}
  x.textBaseline='alphabetic';
  sc.textContent='Ronde: '+Math.max(round,seq.length)+' · Beste: '+best('simon',round)+(state===2?' · '+(seq.length-pos)+' te gaan':'');
 });
 st.t={get seq(){return seq},get state(){return state},press};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=null}}},
