{id:'kleurbal',n:'Ballensorteer',e:'🧪',c:'Puzzel',g:'#f857a6,#ff5858',nw:1,run(st){
 // Ball sort: tik een buis om de bovenste bal op te pakken, tik een andere buis om hem erop te leggen (leeg of zelfde kleur). Elk level is gecontroleerd oplosbaar.
 const W=360,H=480,CAP=4,BR=14,BS=31;
 const c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);c.style.cssText='display:block;margin:0 auto';
 const bar=E('div');bar.style.cssText='display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:8px';
 const bU=E('button','btn','↩ Terug'),bP=E('button','btn','➕ Buis'),bH=E('button','btn','💡 Hint'),bR=E('button','btn','🔄 Level');[bU,bP,bH,bR].forEach(b=>{b.style.cssText='padding:7px 11px;font-size:13px';bar.append(b)});
 st.append(bar,E('div','hint','Tik op een buis en dan op een andere: een bal mag op dezelfde kleur of in een lege buis · sorteer elke kleur in een eigen buis · ←→ + spatie, u = terug, h = hint'));
 const COL=['#ff4d6d','#3a8bff','#2ee59d','#ffd23f','#b56bff','#ff8c42','#ff7ad9','#2fe0e0','#9be15d','#a0704a','#f2f2f2','#5561ff'];
 let lvl,tubes,start,sel,mv,hist,extra,anim,won,kb,kbOn,parts,msg,msgT,shake,hintMv,hintT,stuck;const tms=[];
 const lsGet=()=>{try{return+localStorage.getItem('sp_kleurbal')||0}catch(e){return 0}};
 const top=t=>t[t.length-1],full=t=>t.length===CAP&&t.every(v=>v===t[0]);
 const legal=(a,b)=>a!==b&&tubes[a].length&&tubes[b].length<CAP&&(!tubes[b].length||top(tubes[b])===top(tubes[a]));
 // ---------- oplosser (DFS met geheugen) ----------
 function solve(s0,limit=60000){const seen=new Set,path=[];let n=0;const key=s=>s.map(t=>t.join('')).sort().join('|');
  const done=s=>s.every(t=>!t.length||full(t));
  function dfs(s){if(done(s))return 1;if(++n>limit)return 0;const k=key(s);if(seen.has(k))return 0;seen.add(k);
   for(let a=0;a<s.length;a++){const A=s[a];if(!A.length||full(A))continue;const uni=A.every(v=>v===A[0]);
    for(let b=0;b<s.length;b++){const B=s[b];if(a===b||B.length>=CAP)continue;if(B.length&&top(B)!==top(A))continue;if(!B.length&&uni)continue;
     B.push(A.pop());path.push([a,b]);if(dfs(s))return 1;path.pop();A.push(B.pop())}}return 0}
  const s=s0.map(t=>t.slice());return dfs(s)?path:null}
 function gen(L){const nc=Math.min(10,3+((L+1)>>1)),ne=2;for(let tr=0;tr<40;tr++){const balls=[];for(let k=0;k<nc;k++)for(let i=0;i<CAP;i++)balls.push(k);
   for(let i=balls.length-1;i>0;i--){const j=R(i+1);[balls[i],balls[j]]=[balls[j],balls[i]]}const t=[];for(let k=0;k<nc;k++)t.push(balls.slice(k*CAP,k*CAP+CAP));
   if(t.some(full))continue;for(let k=0;k<ne;k++)t.push([]);if(solve(t))return t}return null}
 function newLevel(L){lvl=L;start=gen(L)||gen(L);restartLevel()}
 function restartLevel(){tubes=start.map(t=>t.slice());sel=-1;mv=0;hist=[];extra=0;anim=null;won=0;kb=0;parts=[];msg='Sorteer de kleuren!';msgT=1.4;shake=null;hintMv=null;hintT=0;stuck=0;overlay(st,c,'')}
 function init(){newLevel(lsGet()+1)}
 // ---------- geometrie ----------
 function geo(i){const n=tubes.length,rows=n>6?2:1,per=Math.ceil(n/rows),row=i<per?0:1,inRow=row?n-per:per,k=row?i-per:i,tw=BR*2+8,th=CAP*BS+16;
  const gap=Math.min(22,(W-inRow*tw)/(inRow+1)),x0=(W-(inRow*tw+(inRow-1)*gap))/2,top_=rows===1?170:row?292:88;return{x:x0+k*(tw+gap),y:top_,w:tw,h:th}}
 const slot=(i,j)=>{const g=geo(i);return[g.x+g.w/2,g.y+g.h-8-BR-j*BS]};
 const lift=i=>{const g=geo(i);return[g.x+g.w/2,g.y-BR-10]};
 function tubeAt(px,py){for(let i=0;i<tubes.length;i++){const g=geo(i);if(px>g.x-8&&px<g.x+g.w+8&&py>g.y-50&&py<g.y+g.h+12)return i}return-1}
 // ---------- zetten ----------
 function pick(i){if(anim)land();if(won||i<0)return;hintMv=null;
  if(sel<0){if(tubes[i].length&&!full(tubes[i])){sel=i;beep(520,.03,'sine',.025)}else if(tubes[i].length){shake={i,t:.25};beep(180,.05,'square',.02)}return}
  if(sel===i){sel=-1;beep(400,.03,'sine',.02);return}
  if(legal(sel,i)){const a=sel,col=tubes[a].pop();hist.push([a,i]);mv++;sel=-1;anim={a,b:i,col,p:0};beep(620,.04,'triangle',.03)}
  else{shake={i,t:.25};beep(180,.06,'square',.025);if(tubes[i].length&&!full(tubes[i]))sel=i;else sel=-1}}
 function land(){const{b,col}=anim;tubes[b].push(col);anim=null;if(full(tubes[b])){const[sx,sy]=slot(b,CAP-1);for(let k=0;k<14;k++)parts.push({x:sx,y:sy,vx:(Math.random()-.5)*220,vy:-Math.random()*240,l:.6,c:COL[col]});beep(880,.08,'triangle',.035)}
  else beep(300,.03,'sine',.02);check()}
 function check(){if(tubes.every(t=>!t.length||full(t))){won=1;const b=best('kleurbal',lvl);try{localStorage.setItem('sp_kleurbal',Math.max(lvl,lsGet()))}catch(e){}
   [523,659,784,1046].forEach((f,k)=>tms.push(setTimeout(()=>beep(f,.12,'triangle',.04),k*110)));for(let k=0;k<60;k++)parts.push({x:W/2,y:200,vx:(Math.random()-.5)*420,vy:-Math.random()*420,l:1.2,c:COL[R(COL.length)]});
   const o=overlay(st,c,`🎉 Level ${lvl} opgelost!<br><span style="font-size:15px;font-weight:600">${mv} zetten · Beste: level ${b}<br>Tik of druk op spatie voor level ${lvl+1}</span>`);o.onpointerdown=e=>{e.preventDefault();newLevel(lvl+1)};return}
  let any=0;for(let a=0;a<tubes.length&&!any;a++)for(let b=0;b<tubes.length;b++)if(legal(a,b)){any=1;break}
  stuck=!any;if(stuck){msg=extra?'Vast! Maak een zet ongedaan':'Vast! Gebruik ↩ of ➕ Buis';msgT=2.5;beep(160,.25,'sawtooth',.035)}}
 function undo(){if(anim)land();if(won||!hist.length)return;const[a,b]=hist.pop();tubes[a].push(tubes[b].pop());mv++;sel=-1;stuck=0;beep(350,.04,'sine',.025)}
 function plus(){if(anim)land();if(won||extra)return;extra=1;tubes.push([]);sel=-1;stuck=0;msg='Extra buis!';msgT=.9;beep(700,.06,'triangle',.03)}
 function hint(){if(anim)land();if(won)return;const p=solve(tubes,40000);if(!p){msg=extra?'Geen oplossing — maak zetten ongedaan':'Probeer ➕ Buis of ↩';msgT=1.6;return}if(!p.length)return;hintMv=p[0];hintT=2.5;sel=-1;beep(600,.05,'sine',.03)}
 bU.onclick=undo;bP.onclick=plus;bH.onclick=hint;bR.onclick=()=>{if(!won)restartLevel()};
 c.onpointerdown=e=>{e.preventDefault();if(won){newLevel(lvl+1);return}const b=c.getBoundingClientRect();kbOn=0;pick(tubeAt((e.clientX-b.left)*W/b.width,(e.clientY-b.top)*H/b.height))};
 const inp=input(st,[],k=>{if(won){if(k===' '||k==='Enter')newLevel(lvl+1);return}const lk=k.toLowerCase();
  if(k==='ArrowLeft'||k==='ArrowRight'){kbOn=1;kb=(kb+(k==='ArrowLeft'?-1:1)+tubes.length)%tubes.length}
  else if(k==='ArrowUp'||k==='ArrowDown'){kbOn=1;const n=tubes.length;if(n>6){const per=Math.ceil(n/2);kb=kb<per?Math.min(n-1,kb+per):kb-per}}
  else if(k===' '||k==='Enter'){kbOn=1;pick(kb)}else if(lk==='u'||lk==='z')undo();else if(lk==='h')hint();else if(lk==='e'||lk==='+')plus();else if(lk==='r')restartLevel()});
 // ---------- tekenen ----------
 function ball(px,py,col,a=1){x.globalAlpha=a;const g=x.createRadialGradient(px-BR*.35,py-BR*.4,2,px,py,BR);g.addColorStop(0,'#fff');g.addColorStop(.25,COL[col]);g.addColorStop(1,'rgba(0,0,0,.45)');
  x.fillStyle=g;x.beginPath();x.arc(px,py,BR,0,7);x.fill();x.fillStyle='rgba(255,255,255,.5)';x.beginPath();x.ellipse(px-4,py-6,4,2.3,-.5,0,7);x.fill();x.globalAlpha=1}
 function draw(){const bg=x.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#1b1f45');bg.addColorStop(1,'#0e1020');x.fillStyle=bg;x.fillRect(0,0,W,H);
  const now=performance.now()/1000;
  for(let i=0;i<tubes.length;i++){const g=geo(i);let ox=0;if(shake&&shake.i===i)ox=Math.sin(shake.t*60)*4*shake.t/.25;const done=full(tubes[i]);
   const hl=hintT>0&&hintMv&&(hintMv[0]===i||hintMv[1]===i);
   x.save();x.translate(ox,0);x.fillStyle=done?'rgba(46,229,157,.14)':'rgba(255,255,255,.07)';x.strokeStyle=hl?`rgba(255,210,63,${.5+.5*Math.sin(now*10)})`:done?'rgba(46,229,157,.7)':(kbOn&&kb===i)?'#a99bff':'rgba(255,255,255,.4)';x.lineWidth=hl||(kbOn&&kb===i)?3:2;
   x.beginPath();x.moveTo(g.x,g.y);x.lineTo(g.x,g.y+g.h-g.w/2);x.arc(g.x+g.w/2,g.y+g.h-g.w/2,g.w/2,Math.PI,0,true);x.lineTo(g.x+g.w,g.y);x.fill();x.stroke();
   x.fillStyle='rgba(255,255,255,.12)';x.fillRect(g.x+5,g.y+6,3,g.h-28);
   x.strokeStyle='rgba(255,255,255,.55)';x.lineWidth=3;x.beginPath();x.moveTo(g.x-4,g.y);x.lineTo(g.x+g.w+4,g.y);x.stroke();
   tubes[i].forEach((col,j)=>{if(i===sel&&j===tubes[i].length-1){const[lx,ly]=lift(i);ball(lx,ly+Math.sin(now*6)*2,col)}else{const[sx,sy]=slot(i,j);ball(sx,sy,col)}});x.restore()}
  if(anim){const p=Math.min(1,anim.p),[ax,ay]=lift(anim.a),[bx,by]=lift(anim.b),[tx,ty]=slot(anim.b,tubes[anim.b].length);let px,py;
   if(p<.55){const q=p/.55,e=q<.5?2*q*q:1-Math.pow(-2*q+2,2)/2;px=ax+(bx-ax)*e;py=ay+(by-ay)*e-Math.sin(q*Math.PI)*26}else{const q=(p-.55)/.45;px=bx;py=by+(ty-by)*q*q}ball(px,py,anim.col)}
  for(const p of parts){x.globalAlpha=Math.max(0,Math.min(1,p.l*2));x.fillStyle=p.c;x.fillRect(p.x-2.5,p.y-2.5,5,5)}x.globalAlpha=1;
  x.fillStyle='rgba(255,255,255,.75)';x.font='bold 15px system-ui,sans-serif';x.textAlign='center';x.textBaseline='middle';
  x.fillText('Level '+lvl,W/2,26);x.font='12px system-ui,sans-serif';x.fillStyle='rgba(255,255,255,.5)';if(msgT>0){x.globalAlpha=Math.min(1,msgT*3);x.fillStyle='#ffd23f';x.font='bold 14px system-ui,sans-serif';x.fillText(msg,W/2,48);x.globalAlpha=1}else x.fillText(tubes.filter(full).length+' / '+start.filter(t=>t.length).length+' kleuren klaar',W/2,48);
  sc.textContent='Level '+lvl+' · Zetten: '+mv+' · Beste: '+(best('kleurbal',0)?'level '+best('kleurbal',0):'–');
  bU.style.opacity=hist.length?1:.5;bP.style.opacity=extra?.5:1;bP.disabled=!!extra}
 const stopLoop=loop(dt=>{if(msgT>0)msgT-=dt;if(hintT>0)hintT-=dt;if(shake&&(shake.t-=dt)<=0)shake=null;
  if(anim){anim.p+=dt/.3;if(anim.p>=1)land()}
  parts=parts.filter(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=650*dt;p.l-=dt;return p.l>0});draw()});
 window._kb={tubes:()=>tubes.map(t=>t.slice()),solve:()=>solve(tubes),geo,state:()=>({lvl,mv,won,stuck,sel,anim:!!anim,n:tubes.length})};
 init();cur.reset=()=>{if(won)newLevel(lvl+1);else restartLevel()};
 return()=>{stopLoop();tms.forEach(clearTimeout);inp.stop();c.onpointerdown=null;delete window._kb}}},
