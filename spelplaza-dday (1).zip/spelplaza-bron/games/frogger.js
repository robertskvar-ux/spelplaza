{id:'frogger',n:'Oversteek',e:'🐸',c:'Arcade',g:'#11998e,#38ef7d',nw:1,run(st){
 const C=28,W=13*C,H=420,Y0=28,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Pijltjes / vegen / knoppen = springen · tik = vooruit · breng 5 kikkers thuis'));
 const DIRS=[[1,0],[0,1],[-1,0],[0,-1]],KEY={ArrowRight:0,ArrowDown:1,ArrowLeft:2,ArrowUp:3,d:0,s:1,a:2,w:3,' ':3};
 const LANES=[{r:1,k:'log',l:3,v:60,n:3},{r:2,k:'tur',l:2,v:-55,n:4,d:1},{r:3,k:'log',l:4,v:80,n:2},{r:4,k:'log',l:2,v:-70,n:4},{r:5,k:'tur',l:3,v:50,n:3,d:0},
  {r:7,k:'truck',l:2,v:-75,n:2,c:'#d84f4f'},{r:8,k:'car',l:1,v:115,n:2,c:'#ffd23f'},{r:9,k:'car',l:1,v:-65,n:3,c:'#4fd8c8'},{r:10,k:'car',l:1,v:85,n:3,c:'#ff8c42'},{r:11,k:'car',l:1,v:-60,n:3,c:'#c77dff'}];
 const BAY=[0,3,6,9,12].map(i=>i*C+C/2),RY=r=>Y0+r*C;
 let fr,homes,score,lives,level,over,overT,tl,TMAX,deadT,deadK,levelT,maxR,t,ps,pmv;
 const spd=()=>1+(level-1)*.15;
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function objs(L){const len=L.l*C,P=W+len+40,sp=P/L.n,res=[];for(let i=0;i<L.n;i++){let px=(L.p+i*sp)%P;if(px<0)px+=P;res.push(px-len)}return res}
 function sub(L,i){if(!L.d)return 0;const ph=(t*.22+i*.37)%1;return ph>.7&&ph<.95?1:ph>.62&&ph<=.7?(ph-.62)/.08:0}
 function resetFrog(){fr={x:6*C+C/2,r:12,hop:0,hx:0,hr:0,fx:0,fr:12,d:3};tl=TMAX;maxR=12}
 function newLevel(){homes=[0,0,0,0,0];TMAX=Math.max(15,32-level*2);for(const L of LANES)L.p=R(500);resetFrog();levelT=level>1?1.5:0}
 function init(){score=0;lives=3;level=1;over=0;overT=0;deadT=0;t=0;newLevel();ov('')}
 function gameOver(){over=1;overT=0;best('frogger',score);ov(`💀 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('frogger',score)}<br>Tik of druk op een toets om opnieuw te spelen</span>`)}
 function die(k){if(deadT>0)return;deadT=1.1;deadK=k;lives--;fr.hop=0;beep(k==='car'?120:200,.3,'sawtooth',.05)}
 function jump(d){if(over){if(overT>.5)init();return}if(deadT>0||fr.hop>0||levelT>0)return;const nr=fr.r+DIRS[d][1];if(nr<0||nr>12)return;
  fr.hop=1;fr.hx=Math.max(C/2,Math.min(W-C/2,fr.x+DIRS[d][0]*C));fr.hr=nr;fr.fx=fr.x;fr.fr=fr.r;fr.d=d;beep(620,.04,'square',.02)}
 function land(){if(fr.r===0){const i=BAY.findIndex((b,j)=>Math.abs(fr.x-b)<24&&!homes[j]);if(i<0){die('bush');return}homes[i]=1;score+=50+Math.floor(tl)*2;beep(880,.12,'square',.04);
   if(homes.every(h=>h)){score+=1000;level++;beep(1320,.2,'square',.05);newLevel()}else resetFrog()}
  else if(fr.r<maxR){maxR=fr.r;score+=10}}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight']],k=>{if(KEY[k]!=null)jump(KEY[k]);else if(over&&overT>.5)init()});
 const pt=e=>{const r=c.getBoundingClientRect();return[(e.clientX-r.left)*W/r.width,(e.clientY-r.top)*H/r.height]};
 c.onpointerdown=e=>{e.preventDefault();ps=pt(e);pmv=0;try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointermove=e=>{if(!ps)return;const p=pt(e),dx=p[0]-ps[0],dy=p[1]-ps[1];if(Math.max(Math.abs(dx),Math.abs(dy))>22){jump(Math.abs(dx)>Math.abs(dy)?(dx>0?0:2):(dy>0?1:3));ps=p;pmv=1}};
 c.onpointerup=c.onpointercancel=e=>{if(ps&&!pmv&&e.type==='pointerup')jump(3);ps=null};
 const rr=(X,Y,w,h,r)=>{x.beginPath();x.moveTo(X+r,Y);x.arcTo(X+w,Y,X+w,Y+h,r);x.arcTo(X+w,Y+h,X,Y+h,r);x.arcTo(X,Y+h,X,Y,r);x.arcTo(X,Y,X+w,Y,r);x.closePath();x.fill()};
 function drawFrog(X,Y,s,d,col){x.save();x.translate(X,Y);x.rotate([Math.PI/2,Math.PI,-Math.PI/2,0][d]);x.scale(s,s);x.fillStyle=col||'#5ad85a';
  x.fillRect(-12,-7,4,9);x.fillRect(8,-7,4,9);x.fillRect(-13,3,5,8);x.fillRect(8,3,5,8);x.beginPath();x.ellipse(0,0,8,10,0,0,7);x.fill();
  x.fillStyle='#fff';x.beginPath();x.arc(-4,-8,3,0,7);x.arc(4,-8,3,0,7);x.fill();x.fillStyle='#111';x.beginPath();x.arc(-4,-9,1.4,0,7);x.arc(4,-9,1.4,0,7);x.fill();x.restore()}
 const stopLoop=loop(dt=>{
  t+=dt;if(over)overT+=dt;
  if(!over){
   if(levelT>0)levelT-=dt;
   else if(deadT>0){deadT-=dt;if(deadT<=0){if(lives<=0)gameOver();else resetFrog()}}
   else{
    for(const L of LANES)L.p+=L.v*spd()*dt;
    tl-=dt;if(tl<=0){tl=0;die('time')}
    if(fr.hop>0){fr.hop-=dt/.12;if(fr.hop<=0){fr.hop=0;fr.x=fr.hx;fr.r=fr.hr;land()}}
    else if(fr.r>=7&&fr.r<=11){for(const L of LANES)if(L.r===fr.r)for(const px of objs(L))if(fr.x+8>px+3&&fr.x-8<px+L.l*C-3)die('car')}
    else if(fr.r>=1&&fr.r<=5){let ride=null;for(const L of LANES)if(L.r===fr.r)objs(L).forEach((px,i)=>{if(fr.x>px-2&&fr.x<px+L.l*C+2&&sub(L,i)<1)ride=L});
     if(ride)fr.x+=ride.v*spd()*dt;else die('water');if(fr.x<4||fr.x>W-4)die('water')}
   }}
  // tekenen
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);
  x.fillStyle='#2e8b3f';x.fillRect(0,RY(0),W,C);x.fillRect(0,RY(12),W,C);x.fillStyle='#1b3c8c';x.fillRect(0,RY(1),W,5*C);x.fillStyle='#3a2a6e';x.fillRect(0,RY(6),W,C);x.fillStyle='#1c1c2c';x.fillRect(0,RY(7),W,5*C);
  x.strokeStyle='#2c4fb0';x.lineWidth=1;x.beginPath();for(let r=1;r<=5;r++)for(let i=0;i<5;i++){const wx=((i*80+t*(r%2?18:-14))%(W+40)+W+40)%(W+40)-20;x.moveTo(wx,RY(r)+8+(i%3)*6);x.lineTo(wx+12,RY(r)+8+(i%3)*6)}x.stroke();
  x.strokeStyle='#55556a';x.setLineDash([10,10]);x.beginPath();for(let r=8;r<=11;r++){x.moveTo(0,RY(r)+.5);x.lineTo(W,RY(r)+.5)}x.stroke();x.setLineDash([]);
  x.fillStyle='#6a5a9e';for(let i=0;i<13;i++)x.fillRect(i*C+10,RY(6)+12,6,4);
  for(let i=0;i<5;i++){x.fillStyle='#0e1020';x.fillRect(BAY[i]-16,RY(0)+2,32,C-2);if(homes[i])drawFrog(BAY[i],RY(0)+C/2+1,.8,3,'#9ff58a')}
  for(const L of LANES){const y=RY(L.r)+C/2,len=L.l*C;objs(L).forEach((px,i)=>{
   if(L.k==='log'){x.fillStyle='#7a4c22';rr(px,y-10,len,20,8);x.fillStyle='#9a6a3a';x.fillRect(px+8,y-7,len-16,3);x.fillRect(px+12,y+3,len-24,2);x.fillStyle='#5b3816';x.beginPath();x.ellipse(px+len-3,y,4,9,0,0,7);x.fill()}
   else if(L.k==='tur'){const s=sub(L,i);x.globalAlpha=1-s*.85;for(let k=0;k<L.l;k++){const tx=px+k*C+C/2;x.fillStyle='#2fbf71';x.beginPath();x.arc(tx,y,10,0,7);x.fill();x.fillStyle='#1e8a50';x.beginPath();x.arc(tx,y,6,0,7);x.fill();x.fillStyle='#2fbf71';x.beginPath();x.arc(tx+(L.v>0?11:-11),y,4,0,7);x.fill()}x.globalAlpha=1}
   else{const f=L.v>0;x.fillStyle=L.c;rr(px+2,y-10,len-4,20,5);x.fillStyle='#10131f';
    if(L.k==='truck'){x.fillRect(f?px+len-20:px+4,y-8,16,16);x.fillStyle=L.c;x.fillRect(f?px+len-18:px+6,y-6,5,12)}else{x.fillRect(px+(f?6:10),y-7,len-16,14);x.fillStyle=L.c;x.fillRect(px+(f?8:12),y-5,len-20,10)}
    x.fillStyle='#fff6a8';x.fillRect(f?px+len-5:px+2,y-8,3,4);x.fillRect(f?px+len-5:px+2,y+4,3,4);x.fillStyle='#ff4a4a';x.fillRect(f?px+2:px+len-5,y-8,3,4);x.fillRect(f?px+2:px+len-5,y+4,3,4)}})}
  // kikker
  if(deadT<=0||deadK==='bush'||deadK==='time'){const k=1-fr.hop,fx=fr.hop?fr.fx+(fr.hx-fr.fx)*k:fr.x,fy=RY(fr.hop?fr.fr+(fr.hr-fr.fr)*k:fr.r)+C/2;
   if(deadT<=0||Math.floor(t*10)%2)drawFrog(fx,fy,1+Math.sin(k*Math.PI)*.3,fr.d)}
  else{const fx=fr.x,fy=RY(fr.r)+C/2,k=1-deadT/1.1;
   if(deadK==='car'){x.fillStyle='#ff5c7a';x.globalAlpha=1-k*.6;x.beginPath();for(let i=0;i<12;i++){const a=i/12*Math.PI*2,r=i%2?13:7;x[i?'lineTo':'moveTo'](fx+Math.cos(a)*r,fy+Math.sin(a)*r)}x.closePath();x.fill();x.globalAlpha=1}
   else{x.strokeStyle='#9fd0ff';x.lineWidth=2;for(let i=0;i<3;i++){const r=4+k*22-i*6;if(r>0){x.globalAlpha=1-k;x.beginPath();x.arc(fx,fy,r,0,7);x.stroke()}}x.globalAlpha=1}}
  if(deadT>0&&!over){x.fillStyle='#fff';x.font='bold 22px system-ui,sans-serif';x.textAlign='center';x.fillText({car:'Plat!',water:'Plons!',time:'Tijd op!',bush:'Mis!'}[deadK],W/2,RY(6)+C/2+8)}
  if(levelT>0&&!over){x.fillStyle='#fff';x.font='bold 24px system-ui,sans-serif';x.textAlign='center';x.fillText('Level '+level,W/2,RY(6)+C/2+9)}
  // HUD
  x.fillStyle='#8a90b8';x.font='bold 12px system-ui,sans-serif';x.textAlign='left';x.fillText('TIJD',8,19);x.fillStyle='#262c4a';x.fillRect(44,8,150,12);const fT=Math.max(0,tl/TMAX);x.fillStyle=fT<.25?'#ff5c7a':fT<.5?'#ffd23f':'#38ef7d';x.fillRect(44,8,150*fT,12);
  x.textAlign='right';x.fillStyle='#8a90b8';x.fillText('LEVEL '+level,W-8,19);
  for(let i=0;i<Math.max(0,lives);i++)drawFrog(16+i*26,H-14,.6,3);
  sc.textContent='Score: '+score+' · Beste: '+best('frogger',score)+' · Level '+level+(over?' · Game over':'');
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
