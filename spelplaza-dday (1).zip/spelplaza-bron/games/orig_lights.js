{id:'lights',n:'Licht Uit',e:'💡',c:'Puzzel',g:'#f12711,#f5af19',run(st){
 const N=5,W=340,P=10,T=(W-P*(N+1))/N,c=mkCanvas(st,W,W),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 const bar=E('div');bar.style.cssText='display:flex;gap:6px;justify-content:center;align-items:center;margin:2px 0 8px;flex-wrap:wrap';sc.after(bar);
 const pv=E('button','btn','◀'),lb=E('div','sc'),nx=E('button','btn','▶'),hb=E('button','btn','💡 Hint');[pv,nx,hb].forEach(b=>b.style.cssText='padding:6px 12px;font-size:13px;border-radius:99px');lb.style.cssText='min-width:86px;margin:0';bar.append(pv,lb,nx,hb);
 st.append(E('div','hint','Tik op een lamp: die en zijn buren schakelen om · doe alle lampen uit · pijltjes + spatie'));
 let lvl=1;try{lvl=Math.max(1,+localStorage.getItem('sp_lights_cur')||1)}catch(e){}
 let a,lit,sol,mv,par,done,cu,rip,hint,used,overT,t;
 const nb=i=>{const r=[i],cx=i%N,cy=i/N|0;if(cx>0)r.push(i-1);if(cx<N-1)r.push(i+1);if(cy>0)r.push(i-N);if(cy<N-1)r.push(i+N);return r};
 function tg(arr,i){for(const j of nb(i))arr[j]^=1}
 function init(){overlay(st,c,'');try{localStorage.setItem('sp_lights_cur',lvl)}catch(e){}
  const k=Math.min(N*N-3,2+lvl);do{a=Array(N*N).fill(0);sol=Array(N*N).fill(0);const pick=[...Array(N*N).keys()].sort(()=>Math.random()-.5).slice(0,k);for(const i of pick){tg(a,i);sol[i]=1}}while(a.every(v=>!v));
  par=sol.filter(Boolean).length;lit=a.map(v=>v);mv=0;done=0;cu=-1;rip=[];hint=-1;used=0;overT=0;upd()}
 function upd(){const b=best('lights',0);lb.textContent='Level '+lvl;nx.disabled=lvl>b;nx.style.opacity=nx.disabled?.4:1;pv.disabled=lvl<=1;pv.style.opacity=pv.disabled?.4:1;
  sc.textContent=`Zetten: ${mv} · Par: ${par} · Beste: ${b?'level '+b:'–'} · ${a.filter(Boolean).length} aan`}
 pv.onclick=()=>{if(lvl>1){lvl--;init()}};nx.onclick=()=>{if(lvl<=best('lights',0)){lvl++;init()}};
 hb.onclick=()=>{if(done)return;const i=sol.findIndex(Boolean);if(i>=0){hint=i;used=1;beep(990,.06,'sine',.03)}};
 function press(i){if(done){if(overT>.5){lvl++;init()}return}tg(a,i);sol[i]^=1;mv++;if(hint===i||(hint>=0&&!sol[hint]))hint=-1;rip.push({i,t:0});
  beep(a[i]?700:440,.05,'triangle',.035);
  if(a.every(v=>!v)){done=1;overT=0;const stars=mv<=par?3:mv<=par+3?2:1;best('lights',lvl);
   [523,659,784,1047].forEach((f,k)=>setTimeout(()=>beep(f,.12,'triangle',.05),150+k*100));
   const o=overlay(st,c,`🌙 Level ${lvl} klaar!<br><span style="font-size:28px">${'⭐'.repeat(stars)}${'☆'.repeat(3-stars)}</span><span style="font-size:15px;font-weight:600">${mv} zetten · par ${par}${used?' · met hint':''}<br>Tik voor level ${lvl+1}</span>`);if(o)o.style.pointerEvents='none'}
  upd()}
 c.onpointerdown=e=>{e.preventDefault();const r=c.getBoundingClientRect(),X=(e.clientX-r.left)*W/r.width,Y=(e.clientY-r.top)*W/r.height;cu=-1;
  if(done){press(0);return}const ix=Math.floor((X-P/2)/(T+P)),iy=Math.floor((Y-P/2)/(T+P));if(ix>=0&&iy>=0&&ix<N&&iy<N)press(iy*N+ix)};
 const inp=input(st,[],k=>{if(done){if(k===' '||k==='Enter')press(0);return}if(cu<0){if(k.startsWith('Arrow')||k===' '){cu=12;return}return}
  if(k==='ArrowLeft'&&cu%N)cu--;else if(k==='ArrowRight'&&cu%N<N-1)cu++;else if(k==='ArrowUp'&&cu>=N)cu-=N;else if(k==='ArrowDown'&&cu<N*N-N)cu+=N;else if(k===' '||k==='Enter')press(cu)});
 t=0;
 const stopLoop=loop(dt=>{t+=dt;if(done)overT+=dt;for(let i=0;i<N*N;i++)lit[i]+=(a[i]-lit[i])*Math.min(1,dt*14);for(const r of rip)r.t+=dt*3;rip=rip.filter(r=>r.t<1);
  x.fillStyle='#0e1020';x.fillRect(0,0,W,W);
  for(let i=0;i<N*N;i++){const px=P+(i%N)*(T+P),py=P+(i/N|0)*(T+P),l=lit[i],cx=px+T/2,cy=py+T/2;
   x.fillStyle=`rgb(${30+l*14},${34+l*10},${70-l*30})`;x.beginPath();x.roundRect?x.roundRect(px,py,T,T,14):x.rect(px,py,T,T);x.fill();
   if(l>.02){const g=x.createRadialGradient(cx,cy,2,cx,cy,T*.7);g.addColorStop(0,`rgba(255,230,120,${.9*l})`);g.addColorStop(.5,`rgba(255,180,60,${.45*l})`);g.addColorStop(1,'rgba(255,160,40,0)');x.fillStyle=g;x.fillRect(px-10,py-10,T+20,T+20)}
   x.fillStyle=l>.5?'#fff6c8':'#3a3f72';x.beginPath();x.arc(cx,cy-4,T*.2,0,7);x.fill();x.fillStyle=l>.5?'#d9b44a':'#2c3060';x.fillRect(cx-T*.09,cy+T*.13,T*.18,T*.12);
   if(i===hint){x.strokeStyle=`rgba(120,220,255,${.6+.4*Math.sin(t*8)})`;x.lineWidth=4;x.strokeRect(px+3,py+3,T-6,T-6)}
   if(i===cu){x.strokeStyle='#fff';x.lineWidth=3;x.strokeRect(px+1.5,py+1.5,T-3,T-3)}}
  for(const r of rip){const px=P+(r.i%N)*(T+P)+T/2,py=P+(r.i/N|0)*(T+P)+T/2;x.strokeStyle=`rgba(255,255,255,${.5*(1-r.t)})`;x.lineWidth=3;x.beginPath();x.arc(px,py,T*.4+r.t*T*.9,0,7);x.stroke()}
 });
 st.t={get a(){return a},get sol(){return sol},get done(){return done},press,get lvl(){return lvl}};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=null}}},
