{id:'doodle',n:'Spring Omhoog',e:'🦘',c:'Arcade',g:'#f5af19,#f12711',nw:1,run(st){
 const W=320,H=480,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','◀ ▶ / knoppen = sturen · of houd je vinger links/rechts van het midden'));
 const G=1500,JV=-650,PW=56,PH=12;
 let p,plats,cam,score,over,overT,t,ptr,topY,parts,face,lastK;
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function addPlat(){const h=Math.max(0,score),gap=40+Math.min(60,h/15)+Math.random()*Math.min(20,4+h/60);
  const y=topY-gap,r=Math.random(),pl={x:R(W-PW),y,k:0,sp:0};
  if(r<Math.min(.3,.04+h/2500)){pl.k=1;pl.vx=(40+Math.random()*70)*(R(2)?1:-1)}else if(Math.random()<.09)pl.sp=1;
  plats.push(pl);if(lastK!==2&&Math.random()<Math.min(.28,h/2000)){plats.push({x:R(W-PW),y:y+gap*(.35+Math.random()*.35),k:2,sp:0});lastK=2}else lastK=pl.k;topY=y}
 function init(){p={x:W/2,y:H-80,vx:0,vy:JV,sq:0};cam=0;score=0;over=0;overT=0;t=0;plats=[{x:W/2-PW/2,y:H-40,k:0,sp:0}];parts=[];topY=H-40;face=1;lastK=0;ptr=null;while(topY>-H)addPlat();ov('')}
 function gameOver(){over=1;overT=0;best('doodle',score);beep(140,.4,'sawtooth',.05);ov(`😵 Gevallen!<br><span style="font-size:15px;font-weight:600">Hoogte ${score} m · Beste ${best('doodle',score)} m<br>Tik of druk op een toets om opnieuw te spelen</span>`)}
 const inp=input(st,[['◀','ArrowLeft'],['▶','ArrowRight']],k=>{if(over&&overT>.5)init()});
 const px=e=>{const r=c.getBoundingClientRect();return(e.clientX-r.left)*W/r.width};
 c.onpointerdown=e=>{e.preventDefault();if(over){if(overT>.5)init();return}ptr=px(e);try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointermove=e=>{if(ptr!=null)ptr=px(e)};c.onpointerup=c.onpointercancel=()=>{ptr=null};
 const rr=(X,Y,w,h,r)=>{x.beginPath();x.moveTo(X+r,Y);x.arcTo(X+w,Y,X+w,Y+h,r);x.arcTo(X+w,Y+h,X,Y+h,r);x.arcTo(X,Y+h,X,Y,r);x.arcTo(X,Y,X+w,Y,r);x.closePath();x.fill()};
 const stopLoop=loop(dt=>{
  t+=dt;if(over)overT+=dt;
  if(!over){
   let ax=0;if(inp.has('ArrowLeft')||inp.has('a'))ax=-1;if(inp.has('ArrowRight')||inp.has('d'))ax=1;
   if(ptr!=null){const d=ptr-W/2;ax=Math.sign(d)*Math.min(1,Math.abs(d)/50)}
   p.vx+=(ax*310-p.vx)*Math.min(1,dt*9);p.x+=p.vx*dt;if(p.x<-14)p.x+=W+28;else if(p.x>W+14)p.x-=W+28;if(Math.abs(p.vx)>20)face=Math.sign(p.vx);
   const y0=p.y+16;p.vy+=G*dt;p.y+=p.vy*dt;const y1=p.y+16;p.sq=Math.max(0,p.sq-dt*4);
   for(const pl of plats){if(pl.k===1){pl.x+=pl.vx*dt;if(pl.x<0||pl.x>W-PW){pl.x=Math.max(0,Math.min(W-PW,pl.x));pl.vx=-pl.vx}}if(pl.fall)pl.y+=pl.fall*dt,pl.fall+=900*dt}
   if(p.vy>0)for(const pl of plats){if(pl.fall)continue;if(y0<=pl.y&&y1>=pl.y&&p.x+11>pl.x&&p.x-11<pl.x+PW){p.y=pl.y-16;p.sq=1;
     if(pl.sp&&Math.abs(p.x-pl.x-PW/2)<18){p.vy=JV*1.5;beep(900,.12,'square',.04);for(let i=0;i<8;i++)parts.push({x:p.x,y:pl.y,vx:(Math.random()-.5)*160,vy:-Math.random()*120,l:.5})}
     else{p.vy=JV;beep(pl.k===2?240:520,.05,pl.k===2?'sawtooth':'sine',.03)}
     if(pl.k===2)pl.fall=60;break}}
   if(p.y<cam+H*.42)cam=p.y-H*.42;score=Math.max(score,Math.floor((H-80-p.y)/10));
   while(topY>cam-80)addPlat();plats=plats.filter(pl=>pl.y<cam+H+40);
   if(p.y>cam+H+30)gameOver()}
  for(const q of parts){q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=600*dt;q.l-=dt}parts=parts.filter(q=>q.l>0);
  // tekenen
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);x.strokeStyle='#1a1f3d';x.lineWidth=1;x.beginPath();const off=((-cam)%24+24)%24;for(let gy=off-24;gy<H+24;gy+=24){x.moveTo(0,gy+.5);x.lineTo(W,gy+.5)}for(let gx=0;gx<W;gx+=24){x.moveTo(gx+.5,0);x.lineTo(gx+.5,H)}x.stroke();
  x.save();x.translate(0,-cam);
  for(const pl of plats){x.fillStyle=pl.k===1?'#4fb3ff':pl.k===2?'#b5653a':'#5ad85a';rr(pl.x,pl.y,PW,PH,6);x.fillStyle='rgba(255,255,255,.25)';x.fillRect(pl.x+6,pl.y+2,PW-12,2);
   if(pl.k===2){x.strokeStyle='#5a2d12';x.lineWidth=1.5;x.beginPath();x.moveTo(pl.x+22,pl.y);x.lineTo(pl.x+27,pl.y+5);x.lineTo(pl.x+24,pl.y+8);x.lineTo(pl.x+30,pl.y+PH);x.stroke()}
   if(pl.sp){x.fillStyle='#c9ccd6';x.fillRect(pl.x+PW/2-7,pl.y-9,14,3);x.strokeStyle='#9a9eae';x.lineWidth=1.5;x.beginPath();for(let i=0;i<4;i++){x.moveTo(pl.x+PW/2-6,pl.y-6+i*1.5);x.lineTo(pl.x+PW/2+6,pl.y-5+i*1.5)}x.stroke()}}
  for(const q of parts){x.globalAlpha=q.l*2;x.fillStyle='#fff';x.fillRect(q.x-1.5,q.y-1.5,3,3)}x.globalAlpha=1;
  // figuurtje
  const sx=1+p.sq*.18,sy=1-p.sq*.18;x.save();x.translate(p.x,p.y+16);x.scale(sx*(face<0?-1:1),sy);x.translate(0,-16);
  x.fillStyle='#ffd23f';x.fillRect(-9,10,6,8);x.fillRect(3,10,6,8);x.beginPath();x.ellipse(0,-2,13,15,0,0,7);x.fill();x.fillStyle='#f5a623';x.beginPath();x.ellipse(6,0,8,5,0,0,7);x.fill();
  x.fillStyle='#fff';x.beginPath();x.arc(3,-8,4.5,0,7);x.arc(10,-6,3.5,0,7);x.fill();x.fillStyle='#222';x.beginPath();x.arc(4.5,-8,2,0,7);x.arc(11,-6,1.6,0,7);x.fill();
  x.fillStyle='#e8631f';x.fillRect(11,1,5,3);x.fillStyle='#ffd23f';x.beginPath();x.moveTo(-6,-14);x.lineTo(-2,-26);x.lineTo(3,-14);x.fill();x.restore();
  x.restore();
  x.fillStyle='rgba(14,16,32,.6)';x.fillRect(0,0,W,26);x.fillStyle='#fff';x.font='bold 14px system-ui,sans-serif';x.textAlign='left';x.fillText(score+' m',10,18);x.textAlign='right';x.fillStyle='#8a90b8';x.fillText('Beste '+best('doodle',score)+' m',W-10,18);
  sc.textContent='Hoogte: '+score+' m · Beste: '+best('doodle',score)+' m'+(over?' · Gevallen':'');
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
