{id:'tetris',n:'Blokkenval',e:'🧱',c:'Arcade',g:'#2193b0,#6dd5ed',run(st){
 const S=20,BW=10,BH=22,VIS=20,OX=8,OY=8,W=320,H=416,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 const SH={I:[[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]],J:[[1,0,0],[1,1,1],[0,0,0]],L:[[0,0,1],[1,1,1],[0,0,0]],O:[[1,1],[1,1]],S:[[0,1,1],[1,1,0],[0,0,0]],T:[[0,1,0],[1,1,1],[0,0,0]],Z:[[1,1,0],[0,1,1],[0,0,0]]};
 const CO={I:'#22d3ee',J:'#3b82f6',L:'#f59e0b',O:'#facc15',S:'#22c55e',T:'#a855f7',Z:'#ef4444'};
 const K0={'01':[[0,0],[-1,0],[-1,1],[0,-2],[-1,-2]],'10':[[0,0],[1,0],[1,-1],[0,2],[1,2]],'12':[[0,0],[1,0],[1,-1],[0,2],[1,2]],'21':[[0,0],[-1,0],[-1,1],[0,-2],[-1,-2]],
  '23':[[0,0],[1,0],[1,1],[0,-2],[1,-2]],'32':[[0,0],[-1,0],[-1,-1],[0,2],[-1,2]],'30':[[0,0],[-1,0],[-1,-1],[0,2],[-1,2]],'03':[[0,0],[1,0],[1,1],[0,-2],[1,-2]]};
 const KI={'01':[[0,0],[-2,0],[1,0],[-2,-1],[1,2]],'10':[[0,0],[2,0],[-1,0],[2,1],[-1,-2]],'12':[[0,0],[-1,0],[2,0],[-1,2],[2,-1]],'21':[[0,0],[1,0],[-2,0],[1,-2],[-2,1]],
  '23':[[0,0],[2,0],[-1,0],[2,1],[-1,-2]],'32':[[0,0],[-2,0],[1,0],[-2,-1],[1,2]],'30':[[0,0],[1,0],[-2,0],[1,-2],[-2,1]],'03':[[0,0],[-1,0],[2,0],[-1,2],[2,-1]]};
 const rotM=m=>m[0].map((_,i)=>m.map(r=>r[i]).reverse());
 st.append(E('div','hint','← → schuiven · ↑/X draai · Z draai terug · ↓ zacht · spatie = vallen · C = vasthouden · P = pauze<br>Op het scherm: tik = draai, sleep = schuiven, veeg omlaag = vallen'));
 let B,bag,nextQ,p,hold,canHold,score,lines,lvl,over,overT,gT,lockT,resets,clr,das,dasK,paused,parts,flashT;
 function fillBag(){const k=Object.keys(SH);for(let i=k.length-1;i>0;i--){const j=R(i+1);[k[i],k[j]]=[k[j],k[i]]}bag.push(...k)}
 function take(){if(bag.length<7)fillBag();return bag.shift()}
 function newP(t){const m=SH[t].map(r=>[...r]);return{t,m,r:0,x:t==='O'?4:3,y:t==='I'?0:1}}
 const hit=(m,X,Y)=>m.some((r,j)=>r.some((v,i)=>v&&(X+i<0||X+i>=BW||Y+j>=BH||(Y+j>=0&&B[Y+j][X+i]))));
 function spawn(t){p=newP(t||take());gT=0;lockT=0;resets=0;if(hit(p.m,p.x,p.y))end()}
 function end(){over=1;overT=0;best('tetris',score);beep(110,.6,'sawtooth',.05);
  const o=overlay(st,c,`🧱 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Level ${lvl} · ${lines} lijnen<br>Beste ${best('tetris',score)}<br>Tik of druk op spatie om opnieuw te spelen</span>`);if(o)o.style.pointerEvents='none'}
 function init(){B=Array.from({length:BH},()=>Array(BW).fill(0));bag=[];fillBag();hold=null;canHold=1;score=0;lines=0;lvl=1;over=0;overT=0;clr=null;das=0;dasK=null;paused=0;parts=[];flashT=0;spawn();overlay(st,c,'')}
 function grav(){return Math.pow(Math.max(.05,.8-(lvl-1)*.007),lvl-1)}
 function touchReset(){if(hit(p.m,p.x,p.y+1)&&resets<15){lockT=0;resets++}}
 function move(dx){if(!hit(p.m,p.x+dx,p.y)){p.x+=dx;touchReset();beep(300,.02,'triangle',.012);return 1}return 0}
 function rotate(dir){if(p.t==='O')return;const nr=(p.r+(dir>0?1:3))%4;let m=p.m;m=dir>0?rotM(m):rotM(rotM(rotM(m)));const tb=(p.t==='I'?KI:K0)[''+p.r+nr];
  for(const[kx,ky]of tb){if(!hit(m,p.x+kx,p.y-ky)){p.m=m;p.x+=kx;p.y-=ky;p.r=nr;touchReset();beep(520,.03,'triangle',.02);return}}}
 function soft(){if(!hit(p.m,p.x,p.y+1)){p.y++;score+=1;gT=0;return 1}return 0}
 function hard(){let n=0;while(!hit(p.m,p.x,p.y+1)){p.y++;n++}score+=n*2;flashT=.12;beep(160,.07,'square',.03);lock()}
 function doHold(){if(!canHold)return;const t=p.t;if(hold)spawn(hold);else spawn();hold=t;canHold=0;beep(440,.05,'sine',.03)}
 function lock(){p.m.forEach((r,j)=>r.forEach((v,i)=>{if(v&&p.y+j>=0)B[p.y+j][p.x+i]=p.t}));canHold=1;
  if(p.m.every((r,j)=>r.every(v=>!v||p.y+j<BH-VIS))){end();return}
  const full=[];B.forEach((r,j)=>{if(r.every(Boolean))full.push(j)});
  if(full.length){clr={rows:full,t:0};const n=full.length;score+=[0,100,300,500,800][n]*lvl;
   [0,1,2,3].slice(0,n).forEach(k=>setTimeout(()=>beep(523*Math.pow(1.26,k),.1,'triangle',.045),k*60));
   for(const j of full)for(let i=0;i<BW;i++)for(let k=0;k<2;k++)parts.push({x:OX+i*S+10,y:OY+(j-2)*S+10,vx:(Math.random()-.5)*200,vy:-Math.random()*160,l:.6,c:CO[B[j][i]]})}
  else{beep(200,.03,'triangle',.02);spawn()}}
 function finishClear(){const n=clr.rows.length;B=B.filter((r,j)=>!clr.rows.includes(j));while(B.length<BH)B.unshift(Array(BW).fill(0));
  const ol=lvl;lines+=n;lvl=1+Math.floor(lines/10);if(lvl>ol)setTimeout(()=>{beep(660,.12,'square',.04);beep(990,.18,'triangle',.04)},200);clr=null;spawn()}
 function press(k){if(over){if(overT>.6&&(k===' '||k==='Enter'))init();return}const kk=k.length===1?k.toLowerCase():k;
  if(kk==='p'||k==='Escape'){paused^=1;overlay(st,c,paused?'⏸ Pauze<br><span style="font-size:15px;font-weight:600">Druk P om verder te spelen</span>':'');const o=st.querySelector('.ov');if(o)o.style.pointerEvents='none';return}
  if(paused||clr)return;
  if(k==='ArrowLeft'||k==='ArrowRight'){const d=k==='ArrowLeft'?-1:1;move(d);dasK=k;das=0}
  else if(k==='ArrowUp'||kk==='x')rotate(1);else if(kk==='z'||k==='Control')rotate(-1);
  else if(k==='ArrowDown')soft();else if(k===' ')hard();else if(kk==='c'||k==='Shift'||kk==='h')doHold()}
 const inp=input(st,[['◀','ArrowLeft'],['⟲','z'],['⟳','ArrowUp'],['▶','ArrowRight'],['⬇','ArrowDown'],['⏬',' '],['⇄','H']],press);
 if(inp.pad){// compacte pad in 2 rijen direct onder het bord: draaien/vasthouden/vallen boven, schuiven/zacht onder
  const pd=inp.pad;pd.style.cssText+=';display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;width:min(320px,100%);margin:8px auto 0';
  const POS={'◀':'2/1','⬇':'2/2/auto/span 2','▶':'2/4','⟲':'1/1','⟳':'1/2','⇄':'1/3','⏬':'1/4'},TT={'◀':'Links','▶':'Rechts','⟲':'Draai terug','⟳':'Draai','⬇':'Zacht omlaag','⏬':'Laten vallen','⇄':'Vasthouden'};
  pd.querySelectorAll('.btn').forEach(b=>{const k=b.textContent.trim();b.style.cssText+=';min-width:0;width:auto;min-height:44px;height:44px;padding:0;font-size:20px;margin:0';if(POS[k])b.style.gridArea=POS[k];if(TT[k])b.title=TT[k]});
  (c.parentElement&&c.parentElement.classList.contains('wrap')?c.parentElement:c).after(pd)}
 let ps=null;
 c.onpointerdown=e=>{e.preventDefault();if(over){if(overT>.6)init();return}ps={x:e.clientX,y:e.clientY,t:performance.now(),mx:0,moved:0};try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointermove=e=>{if(!ps||over||paused||clr)return;const r=c.getBoundingClientRect(),cell=S*r.width/W,dx=e.clientX-ps.x-ps.mx*cell;
  if(Math.abs(dx)>cell*.9){const d=Math.sign(dx);if(move(d)){ps.mx+=d}else ps.mx+=d;ps.moved=1}
  if(e.clientY-ps.y>cell*1.2&&Math.abs(e.clientX-ps.x)<cell*1.5&&!ps.sd){ps.moved=1}};
 c.onpointerup=e=>{if(!ps)return;const dy=e.clientY-ps.y,dt=performance.now()-ps.t,dx=e.clientX-ps.x;const s=ps;ps=null;if(over||paused||clr)return;
  if(dy>60&&Math.abs(dy)>Math.abs(dx)*1.5){hard();return}if(!s.moved&&dt<350&&Math.hypot(dx,dy)<14)rotate(1)};
 function blk(px,py,col,a){x.globalAlpha=a==null?1:a;x.fillStyle=col;x.fillRect(px+1,py+1,S-2,S-2);x.fillStyle='rgba(255,255,255,.35)';x.fillRect(px+1,py+1,S-2,3);x.fillRect(px+1,py+1,3,S-2);x.fillStyle='rgba(0,0,0,.25)';x.fillRect(px+1,py+S-4,S-2,3);x.fillRect(px+S-4,py+1,3,S-2);x.globalAlpha=1}
 function mini(t,cx,cy,dim){if(!t)return;const m=SH[t],s=14,h=m.filter(r=>r.some(Boolean)),w=m[0].length,used=[...Array(w).keys()].filter(i=>m.some(r=>r[i]));
  const ox=cx-used.length*s/2-used[0]*s,oy=cy-h.length*s/2;x.globalAlpha=dim?.35:1;
  h.forEach((r,j)=>r.forEach((v,i)=>{if(v){x.fillStyle=CO[t];x.fillRect(ox+i*s+1,oy+j*s+1,s-2,s-2);x.fillStyle='rgba(255,255,255,.3)';x.fillRect(ox+i*s+1,oy+j*s+1,s-2,2)}}));x.globalAlpha=1}
 const stopLoop=loop(dt=>{if(over)overT+=dt;flashT=Math.max(0,flashT-dt);
  if(!over&&!paused){
   if(clr){clr.t+=dt;if(clr.t>.28)finishClear()}
   else{if(dasK&&inp.has(dasK)){das+=dt;while(das>.22){das-=.05;move(dasK==='ArrowLeft'?-1:1)}}else dasK=null;
    const g=inp.has('ArrowDown')?Math.min(.04,grav()):grav();gT+=dt;
    if(hit(p.m,p.x,p.y+1)){lockT+=dt;if(lockT>.5)lock()}
    else while(gT>=g){gT-=g;if(!hit(p.m,p.x,p.y+1)){p.y++;if(inp.has('ArrowDown'))score++}else break}}}
  for(const q of parts){q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=500*dt;q.l-=dt}parts=parts.filter(q=>q.l>0);
  // draw
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);x.fillStyle='#14183a';x.fillRect(OX,OY,BW*S,VIS*S);
  x.strokeStyle='#1d2250';x.lineWidth=1;x.beginPath();for(let i=1;i<BW;i++){x.moveTo(OX+i*S+.5,OY);x.lineTo(OX+i*S+.5,OY+VIS*S)}for(let j=1;j<VIS;j++){x.moveTo(OX,OY+j*S+.5);x.lineTo(OX+BW*S,OY+j*S+.5)}x.stroke();
  for(let j=2;j<BH;j++)for(let i=0;i<BW;i++){const v=B[j][i];if(v){const fl=clr&&clr.rows.includes(j);blk(OX+i*S,OY+(j-2)*S,fl?(Math.floor(clr.t*24)%2?'#fff':CO[v]):CO[v])}}
  if(clr)for(const j of clr.rows){x.fillStyle=`rgba(255,255,255,${.5*(1-clr.t/.28)})`;x.fillRect(OX,OY+(j-2)*S,BW*S,S)}
  if(!over&&!clr){let gy=p.y;while(!hit(p.m,p.x,gy+1))gy++;
   p.m.forEach((r,j)=>r.forEach((v,i)=>{if(v&&gy+j>=2){x.strokeStyle=CO[p.t];x.globalAlpha=.55;x.lineWidth=2;x.strokeRect(OX+(p.x+i)*S+2,OY+(gy+j-2)*S+2,S-4,S-4);x.globalAlpha=.12;x.fillStyle=CO[p.t];x.fillRect(OX+(p.x+i)*S+2,OY+(gy+j-2)*S+2,S-4,S-4);x.globalAlpha=1}}));
   const la=hit(p.m,p.x,p.y+1)?.65+.35*Math.cos(lockT*20):1;p.m.forEach((r,j)=>r.forEach((v,i)=>{if(v&&p.y+j>=2)blk(OX+(p.x+i)*S,OY+(p.y+j-2)*S,CO[p.t],la)}))}
  if(flashT>0){x.fillStyle=`rgba(255,255,255,${flashT})`;x.fillRect(OX,OY,BW*S,VIS*S)}
  x.strokeStyle='#3a3f72';x.lineWidth=2;x.strokeRect(OX-1,OY-1,BW*S+2,VIS*S+2);
  for(const q of parts){x.globalAlpha=Math.max(0,q.l*1.6);x.fillStyle=q.c;x.fillRect(q.x-2,q.y-2,4,4)}x.globalAlpha=1;
  // side panel
  const SX=OX+BW*S+12,PW=W-SX-8;x.textAlign='center';
  const box=(y,h,l)=>{x.fillStyle='#14183a';x.fillRect(SX,y,PW,h);x.strokeStyle='#2c3060';x.lineWidth=1;x.strokeRect(SX+.5,y+.5,PW-1,h-1);x.fillStyle='#8a90b8';x.font='800 11px system-ui,sans-serif';x.fillText(l,SX+PW/2,y+15)};
  box(OY,66,'VASTHOUDEN');mini(hold,SX+PW/2,OY+42,!canHold);
  box(OY+76,150,'VOLGENDE');const nq=bag.slice(0,3);nq.forEach((t,i)=>mini(t,SX+PW/2,OY+76+44+i*40));
  box(OY+236,164,'');x.fillStyle='#8a90b8';x.font='800 11px system-ui,sans-serif';
  [['SCORE',score],['LEVEL',lvl],['LIJNEN',lines],['BESTE',best('tetris',score)]].forEach(([l,v],i)=>{const y=OY+236+20+i*38;x.fillStyle='#8a90b8';x.font='800 10px system-ui,sans-serif';x.fillText(l,SX+PW/2,y);x.fillStyle='#fff';x.font='800 '+(String(v).length>5?13:16)+'px system-ui,sans-serif';x.fillText(v,SX+PW/2,y+18)});
  sc.textContent='Score: '+score+' · Beste: '+best('tetris',score)+' · Level '+lvl+' · Lijnen '+lines+(over?' · Game over':'');
 });
 st.t={get B(){return B},get p(){return p},get lines(){return lines},get lvl(){return lvl},get over(){return over},press};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=null}}},
