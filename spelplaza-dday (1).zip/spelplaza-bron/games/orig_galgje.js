{id:'galgje',n:'Galgje',e:'🪢',c:'Woorden',g:'#614385,#516395',run(st){
 const CAT={'🐾 Dieren':'OLIFANT,KANGOEROE,GIRAF,PINGUIN,KROKODIL,EEKHOORN,VLINDER,SCHILDPAD,DOLFIJN,NIJLPAARD,EGEL,PAPEGAAI,KONIJN,ZEEHOND,HAMSTER,KAMEEL,STRUISVOGEL,OCTOPUS,NEUSHOORN,SCHNAUZER',
  '🍕 Eten':'CHOCOLADE,SPAGHETTI,PANNENKOEK,STROOPWAFEL,FRIETJES,BOTERHAM,AARDBEI,WATERMELOEN,KOEKJE,CROISSANT,HAGELSLAG,BANAAN,LASAGNE,SPRUITJES,TOMATENSOEP,WAFEL,MAYONAISE,STOOFVLEES,PRALINE,SPECULOOS',
  '🌍 Landen':'BELGIE,NEDERLAND,FRANKRIJK,ITALIE,SPANJE,DUITSLAND,ZWEDEN,NOORWEGEN,PORTUGAL,GRIEKENLAND,JAPAN,AUSTRALIE,BRAZILIE,CANADA,MEXICO,EGYPTE,MAROKKO,IJSLAND,OOSTENRIJK,ZWITSERLAND',
  '👩‍🔧 Beroepen':'DIERENARTS,BAKKER,BRANDWEERMAN,ASTRONAUT,PILOOT,LERAAR,KAPPER,TANDARTS,POLITIEAGENT,LOODGIETER,VERPLEGER,JOURNALIST,ARCHITECT,PROGRAMMEUR,SCHILDER,MUZIKANT,ELEKTRICIEN,APOTHEKER,CHIRURG,BOSWACHTER',
  '🏰 Dingen':'COMPUTER,FIETS,KASTEEL,VLIEGTUIG,REGENBOOG,GITAAR,VULKAAN,BIBLIOTHEEK,WINDMOLEN,TREINSTATION,ZONNEBLOEM,PARAPLU,TELEFOON,KOELKAST,TRAMPOLINE,VUURTOREN,ACHTBAAN,SCHOMMEL,TELESCOOP,LUCHTBALLON'};
 const CN=Object.keys(CAT),MAXF=8;let ci=-1;try{ci=+(localStorage.getItem('sp_galgje_cat')??-1)}catch(e){}if(ci>=CN.length)ci=-1;
 const W=300,H=200,sc=E('div','sc'),opt=E('div'),c=E('canvas'),wd=E('div'),msg=E('div','sc'),kb=E('div');c.width=W;c.height=H;
 opt.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 8px;flex-wrap:wrap';
 wd.style.cssText='display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin:12px auto 6px;max-width:400px;min-height:46px';
 msg.style.cssText='min-height:24px;font-size:16px';kb.style.cssText='display:flex;flex-direction:column;gap:6px;align-items:center;margin-top:6px;user-select:none;-webkit-user-select:none';
 const x=c.getContext('2d');st.append(sc,opt,c,wd,msg,kb,E('div','hint','Tik letters of typ op je toetsenbord · 8 fouten en je hangt!'));
 let w,cat,g,f,end,streak,anim,t,kbtn={},boxes=[];
 function drawOpt(){opt.innerHTML='';[[-1,'🎲 Alles'],...CN.map((n,i)=>[i,n])].forEach(([i,l])=>{const q=E('button','btn',l);q.style.cssText='padding:6px 10px;font-size:12px;border-radius:99px;'+(i===ci?'':'background:var(--bg);color:var(--tx)');q.onclick=()=>{ci=i;try{localStorage.setItem('sp_galgje_cat',i)}catch(e){}streak=0;round()};opt.append(q)})}
 ['AZERTYUIOP','QSDFGHJKLM','WXCVBN'].forEach(row=>{const r=E('div');r.style.cssText='display:flex;gap:4px;justify-content:center';
  [...row].forEach(l=>{const b=E('button','btn',l);b.style.cssText='width:clamp(28px,8.4vw,36px);height:42px;padding:0;font-size:17px;border-radius:8px;transition:background .2s,opacity .2s,transform .1s';b.onpointerdown=e=>{e.preventDefault();guess(l)};kbtn[l]=b;r.append(b)});kb.append(r)});
 function upd(){sc.textContent=`Reeks: ${streak} · Beste: ${best('galgje',streak)} · Fouten: ${f}/${MAXF} · ${cat}`}
 function round(){const ks=ci<0?CN[R(CN.length)]:CN[ci],ws=CAT[ks].split(',');let nw;do nw=ws[R(ws.length)];while(nw===w&&ws.length>1);w=nw;cat=ks;g=new Set;f=0;end=0;anim=[];msg.textContent='';
  wd.innerHTML='';boxes=[...w].map(()=>{const d=E('div');d.style.cssText='width:clamp(22px,7vw,32px);height:42px;border-bottom:3px solid var(--mu);display:flex;align-items:flex-end;justify-content:center;font-size:clamp(20px,6vw,28px);font-weight:800;color:var(--tx);transition:transform .25s';wd.append(d);return d});
  Object.values(kbtn).forEach(b=>{b.disabled=false;b.style.background='';b.style.opacity=1});drawOpt();upd()}
 function init(){streak=0;round()}
 function guess(l){if(end){return}if(g.has(l)||!kbtn[l])return;g.add(l);const b=kbtn[l];b.disabled=true;
  if(w.includes(l)){b.style.background='#2fb36b';beep(660,.06,'triangle',.035);[...w].forEach((ch,i)=>{if(ch===l){boxes[i].textContent=ch;boxes[i].style.transform='translateY(-6px)';setTimeout(()=>boxes[i]&&(boxes[i].style.transform=''),180)}});
   if([...w].every(ch=>g.has(ch))){end=1;streak++;best('galgje',streak);msg.innerHTML='🎉 Goed geraden! <span style="font-weight:600">Tik op een letter of spatie voor een nieuw woord</span>';[523,659,784,1047].forEach((q,i)=>setTimeout(()=>beep(q,.12,'triangle',.05),i*100))}}
  else{b.style.background='#ff5e5b';b.style.opacity=.55;f++;anim.push({k:f,t:0});beep(180,.12,'sawtooth',.035);
   if(f>=MAXF){end=1;streak=0;msg.innerHTML='💀 Helaas! Het woord was <b>'+w+'</b><br><span style="font-weight:600;font-size:14px">Tik op een letter of spatie voor een nieuw woord</span>';[...w].forEach((ch,i)=>{if(!g.has(ch)){boxes[i].textContent=ch;boxes[i].style.color='#ff5e5b'}});setTimeout(()=>beep(110,.5,'sawtooth',.04),150)}}
  upd()}
 kb.addEventListener('pointerdown',()=>{if(end)setTimeout(()=>{if(end)round()},0)},true);
 const inp=input(st,[],k=>{if(end&&(k===' '||k==='Enter')){round();return}const l=k.toUpperCase();if(/^[A-Z]$/.test(l))guess(l)});
 t=0;
 const parts=[[[20,186,150,186]],[[50,186,50,18]],[[50,18,170,18],[50,50,82,18]],[[170,18,170,44]],'head',[[170,84,170,134]],[[170,96,146,120],[170,96,194,120]],[[170,134,150,168],[170,134,190,168]]];
 const stopLoop=loop(dt=>{t+=dt;for(const a of anim)a.t=Math.min(1,a.t+dt*3);
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);x.fillStyle='#16193a';x.fillRect(0,186,W,14);
  x.lineCap='round';x.strokeStyle='#1c2150';x.lineWidth=3;for(const pt of parts){x.beginPath();if(pt==='head')x.arc(170,64,20,0,7);else for(const[x0,y0,x1,y1]of pt){x.moveTo(x0,y0);x.lineTo(x1,y1)}x.stroke()}
  for(let k=1;k<=f;k++){const a=anim.find(q=>q.k===k),e=a?a.t:1,pt=parts[k-1],col=k<=4?'#c8a26a':f>=MAXF?'#ff5e5b':'#f1f3ff';x.strokeStyle=col;x.lineWidth=k<=4?6:4;
   const sw=f>=MAXF&&k>4?Math.sin(t*2)*3:0;
   if(pt==='head'){x.beginPath();x.arc(170+sw,64,20,-Math.PI/2,-Math.PI/2+e*Math.PI*2);x.stroke();if(e>=1&&f>=MAXF){x.lineWidth=2;for(const s of[-1,1]){x.beginPath();x.moveTo(170+sw+s*7-3,58);x.lineTo(170+sw+s*7+3,64);x.moveTo(170+sw+s*7+3,58);x.lineTo(170+sw+s*7-3,64);x.stroke()}}}
   else for(const[x0,y0,x1,y1]of pt){const o=k>4?sw:0;x.beginPath();x.moveTo(x0+o,y0);x.lineTo(x0+o+(x1-x0)*e,y0+(y1-y0)*e);x.stroke()}}
  if(end&&f<MAXF){x.font='40px system-ui';x.textAlign='center';x.fillText('🎉',230+Math.sin(t*4)*6,110)}
  x.fillStyle='#4a5090';x.font='700 11px system-ui,sans-serif';x.textAlign='right';x.fillText(w.length+' letters',W-8,180);
 });
 st.t={get w(){return w},get end(){return end},get f(){return f},guess};
 init();cur.reset=init;return()=>{stopLoop();inp.stop()}}},
