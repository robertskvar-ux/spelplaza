{id:'memory',n:'Memory',e:'🃏',c:'Puzzel',g:'#4facfe,#00f2fe',run(st){
 const SZ=[{l:'Klein',c:4,r:3},{l:'Middel',c:4,r:4},{l:'Groot',c:6,r:5}];
 const EM='🐶🐱🦊🐼🐸🦁🐵🐙🦄🐢🐝🦋🐧🦉🐳🦀🍓🍉🌻🚀'.match(/\p{Extended_Pictographic}/gu);
 let si=1;try{si=+(localStorage.getItem('sp_memory_size')??1)}catch(e){}if(!SZ[si])si=1;
 const sc=E('div','sc'),opt=E('div');opt.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 10px;flex-wrap:wrap';
 const b=E('div');const wr=E('div','wrap');wr.style.cssText='display:block;margin:0 auto';wr.append(b);b.style.cssText='display:grid;gap:8px;width:100%;user-select:none;-webkit-user-select:none;touch-action:manipulation';
 const css=E('style','',`.mm-c{perspective:600px;aspect-ratio:4/5;cursor:pointer}.mm-i{position:relative;width:100%;height:100%;transition:transform .38s cubic-bezier(.3,1.4,.5,1);transform-style:preserve-3d}
.mm-c.o .mm-i{transform:rotateY(180deg)}.mm-f{position:absolute;inset:0;border-radius:12px;display:flex;align-items:center;justify-content:center;backface-visibility:hidden;-webkit-backface-visibility:hidden}
.mm-b{background:linear-gradient(135deg,var(--ac),#ff6fb5);box-shadow:0 3px 8px rgba(0,0,0,.18)}.mm-b:after{content:'';width:42%;aspect-ratio:1;border-radius:50%;border:3px solid rgba(255,255,255,.45)}
.mm-e{transform:rotateY(180deg);background:var(--card);border:2px solid var(--ln);box-shadow:0 3px 8px rgba(0,0,0,.12)}
.mm-c.m .mm-e{border-color:#38d996;background:color-mix(in srgb,#38d996 16%,var(--card));animation:mmp .4s}.mm-c.x .mm-i{animation:mms .35s}
@keyframes mmp{50%{transform:scale(1.12)}}@keyframes mms{0%,100%{transform:rotateY(180deg) translateX(0)}30%{transform:rotateY(180deg) translateX(5px)}70%{transform:rotateY(180deg) translateX(-5px)}}`);
 st.append(css,sc,opt,wr,E('div','hint','Draai twee kaarten om · vind alle paren zo snel mogelijk'));
 let cards,open,moves,pairs,lock,t0,tm,done,to=[];
 const fmt=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
 const bk=()=>'sp_memory_t'+si;
 function getBest(){try{return+localStorage.getItem(bk())||0}catch(e){return 0}}
 function setBest(s){const o=getBest();if(!o||s<o){try{localStorage.setItem(bk(),s)}catch(e){}return 1}return 0}
 function upd(){const el=t0?((done||performance.now())-t0)/1000:0,bb=getBest();sc.textContent='Zetten: '+moves+' · Tijd: '+fmt(el)+(bb?' · Beste: '+fmt(bb):'')+' · '+pairs+'/'+cards.length/2+' paren'}
 function drawOpt(){opt.innerHTML='';SZ.forEach((z,i)=>{const q=E('button','btn',z.l+' '+z.c+'×'+z.r);q.style.cssText='padding:6px 12px;font-size:12px;border-radius:99px;'+(i===si?'':'background:var(--bg);color:var(--tx)');q.onclick=()=>{si=i;try{localStorage.setItem('sp_memory_size',i)}catch(e){}init()};opt.append(q)})}
 function init(){to.forEach(clearTimeout);to=[];overlay(st,b,'');const z=SZ[si],n=z.c*z.r/2,pool=[...EM].sort(()=>Math.random()-.5).slice(0,n);
  const d=[...pool,...pool].sort(()=>Math.random()-.5);b.innerHTML='';b.style.gridTemplateColumns=`repeat(${z.c},1fr)`;wr.style.width=z.c>4?'min(400px,100%)':'min(360px,100%)';
  const fs=z.c>4?'clamp(20px,7vw,32px)':'clamp(28px,10vw,44px)';open=[];moves=0;pairs=0;lock=0;t0=0;done=0;
  cards=d.map((v,i)=>{const el=E('div','mm-c',`<div class="mm-i"><div class="mm-f mm-b"></div><div class="mm-f mm-e" style="font-size:${fs}">${v}</div></div>`);
   const cd={v,el,o:0,m:0};el.onclick=()=>flip(cd);b.append(el);return cd});drawOpt();upd()}
 function flip(cd){if(lock||cd.o||done)return;if(!t0)t0=performance.now();cd.o=1;cd.el.classList.add('o');open.push(cd);beep(520+open.length*120,.05,'triangle',.03);
  if(open.length<2)return;moves++;const[a,q]=open;open=[];
  if(a.v===q.v){a.m=q.m=1;pairs++;to.push(setTimeout(()=>{a.el.classList.add('m');q.el.classList.add('m');beep(880,.08,'triangle',.04);to.push(setTimeout(()=>beep(1175,.12,'triangle',.04),90))},300));
   if(pairs===cards.length/2){done=performance.now();const s=(done-t0)/1000,rec=setBest(s);upd();
    to.push(setTimeout(()=>{[523,659,784,1047].forEach((f,i)=>to.push(setTimeout(()=>beep(f,.14,'triangle',.05),i*110)));
     const o=overlay(st,b,`🎉 Alle paren gevonden!<br><span style="font-size:15px;font-weight:600">${moves} zetten · ${fmt(s)}${rec?' · Nieuw record!':' · Beste '+fmt(getBest())}<br>Tik om opnieuw te spelen</span>`);o.style.cursor='pointer';o.onclick=init},650))}}
  else{lock=1;to.push(setTimeout(()=>{a.el.classList.add('x');q.el.classList.add('x');beep(180,.1,'sine',.03)},380));
   to.push(setTimeout(()=>{[a,q].forEach(k=>{k.o=0;k.el.classList.remove('o','x')});lock=0},900))}
  upd()}
 const inp=input(st,[],k=>{if(done&&(k===' '||k==='Enter'))init()});
 const tick=setInterval(()=>{if(t0&&!done)upd()},250);
 init();cur.reset=init;return()=>{clearInterval(tick);to.forEach(clearTimeout);inp.stop()}}},
