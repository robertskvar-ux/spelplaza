{id:'match3',n:'Juwelen',e:'💎',c:'Puzzel',g:'#ff0844,#ffb199',nw:1,run(st){
 // Match-3 on an 8x8 canvas board: swap by tap-tap / swipe / keyboard; cascades, combo multiplier, levels with move limit.
 const N=8,S=45,W=N*S,H=N*S,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 const bar=E('div');bar.style.cssText='display:flex;gap:8px;justify-content:center;margin-top:8px';
 const hb=E('button','btn','💡 Hint');bar.append(hb);st.append(bar,E('div','hint','Tik op twee buursteentjes of veeg om te wisselen · 3 op een rij verdwijnt · pijltjes + spatie'));
 const COL=['#ff3b5c','#3d8bff','#2ee59d','#ffd93d','#b76bff','#ff9f1c'],MOVES=20;
 let g,phase,sel,swp,clr,score,moves,level,target,combo,parts,hintMv,hintT,over,cur_r,cur_c,kb,msg,msgT,idle,drag=null,ovEl=null;
 const rr=(x0,y0,w,h,r)=>{x.moveTo(x0+r,y0);x.arcTo(x0+w,y0,x0+w,y0+h,r);x.arcTo(x0+w,y0+h,x0,y0+h,r);x.arcTo(x0,y0+h,x0,y0,r);x.arcTo(x0,y0,x0+w,y0,r);x.closePath()};let tm=0;
 const rnd=()=>R(6),ease=p=>p<.5?2*p*p:1-Math.pow(-2*p+2,2)/2,tgt=l=>1000+(l-1)*1500;
 // ---------- board logic ----------
 function newBoard(){do{g=[];for(let r=0;r<N;r++){g.push([]);for(let c2=0;c2<N;c2++){let t;do t=rnd();while((c2>1&&g[r][c2-1].t===t&&g[r][c2-2].t===t)||(r>1&&g[r-1][c2].t===t&&g[r-2][c2].t===t));g[r].push({t,dy:0,vy:0})}}}while(!findMoves().length)}
 function matches(){const m=new Set,runs=[];
  for(let r=0;r<N;r++){let c2=0;while(c2<N){const t=g[r][c2]?g[r][c2].t:-1;let e=c2+1;while(e<N&&g[r][e]&&g[r][e].t===t)e++;if(t>=0&&e-c2>=3){runs.push(e-c2);for(let k=c2;k<e;k++)m.add(r*N+k)}c2=e}}
  for(let c2=0;c2<N;c2++){let r=0;while(r<N){const t=g[r][c2]?g[r][c2].t:-1;let e=r+1;while(e<N&&g[e][c2]&&g[e][c2].t===t)e++;if(t>=0&&e-r>=3){runs.push(e-r);for(let k=r;k<e;k++)m.add(k*N+c2)}r=e}}
  return{m,runs}}
 function lineAt(r,c2){const t=g[r][c2].t;let n=1;for(let k=c2-1;k>=0&&g[r][k].t===t;k--)n++;for(let k=c2+1;k<N&&g[r][k].t===t;k++)n++;if(n>=3)return 1;n=1;for(let k=r-1;k>=0&&g[k][c2].t===t;k--)n++;for(let k=r+1;k<N&&g[k][c2].t===t;k++)n++;return n>=3}
 function findMoves(){const out=[];for(let r=0;r<N;r++)for(let c2=0;c2<N;c2++)for(const[dr,dc]of[[0,1],[1,0]]){const r2=r+dr,c3=c2+dc;if(r2>=N||c3>=N)continue;
   [g[r][c2],g[r2][c3]]=[g[r2][c3],g[r][c2]];if(lineAt(r,c2)||lineAt(r2,c3))out.push({a:{r,c:c2},b:{r:r2,c:c3}});[g[r][c2],g[r2][c3]]=[g[r2][c3],g[r][c2]]}return out}
 function trySwap(a,b){if(phase!=='idle'||over)return false;if(Math.abs(a.r-b.r)+Math.abs(a.c-b.c)!==1)return false;phase='swap';swp={a,b,p:0,back:0};hintT=0;idle=0;beep(420,.04,'sine',.03);return true}
 function startClear(){const{m,runs}=matches();clr={m,p:0};let add=0;for(const l of runs)add+=l*10*combo+(l===4?40:l>=5?120:0);score+=add;
  for(const i of m){const r=(i/N)|0,c2=i%N;for(let k=0;k<6;k++)parts.push({x:c2*S+S/2,y:r*S+S/2,vx:(Math.random()-.5)*260,vy:(Math.random()-.8)*260,l:.35+Math.random()*.3,col:COL[g[r][c2].t]})}
  beep(520+combo*90,.08,'triangle',.04);if(combo>1){msg='Combo x'+combo+'  +'+add;msgT=.9}phase='clear'}
 function startFall(){for(let c2=0;c2<N;c2++){let w=N-1;for(let r=N-1;r>=0;r--){const gm=g[r][c2];if(!gm)continue;if(w!==r){g[w][c2]=gm;gm.dy=(r-w);g[r][c2]=null}gm.vy=0;w--}
   for(let r=w;r>=0;r--)g[r][c2]={t:rnd(),dy:-(w+1),vy:0}}phase='fall'}
 function settle(){phase='idle';combo=0;
  if(score>=target){const bonus=moves*30;score+=bonus;level++;target=tgt(level);moves=MOVES;msg='Level '+level+'!  +'+bonus+' bonus';msgT=1.6;beep(660,.12,'triangle',.05);tm=setTimeout(()=>beep(990,.2,'triangle',.05),130)}
  if(!findMoves().length){newBoard();msg='Geen zetten meer - nieuwe stenen!';msgT=1.8;beep(300,.15,'sine',.04)}
  if(moves<=0&&score<target)gameOver()}
 function gameOver(){over=1;best('match3',score);beep(160,.4,'sawtooth',.05);ovEl=overlay(st,c,`Geen zetten meer<br><span style="font-size:15px;font-weight:600">Level ${level} · Score ${score} · Beste ${best('match3',score)}<br>Tik of druk op spatie om opnieuw te spelen</span>`);ovEl.onpointerdown=e=>{e.preventDefault();init()}}
 function showHint(){if(phase!=='idle'||over)return;const mv=findMoves();if(!mv.length)return;hintMv=mv[R(mv.length)];hintT=2.5}
 function init(){newBoard();phase='idle';sel=null;swp=null;clr=null;score=0;moves=MOVES;level=1;target=tgt(1);combo=0;parts=[];hintMv=null;hintT=0;over=0;cur_r=cur_c=3;kb=0;msg='';msgT=0;idle=0;drag=null;ovEl=null;overlay(st,c,'')}
 // ---------- input ----------
 function cellAt(e){const b=c.getBoundingClientRect(),px=(e.clientX-b.left)*W/b.width,py=(e.clientY-b.top)*H/b.height;return{r:Math.floor(py/S),c:Math.floor(px/S),px,py}}
 c.onpointerdown=e=>{e.preventDefault();if(over){init();return}if(phase!=='idle')return;const p=cellAt(e);if(p.r<0||p.r>=N||p.c<0||p.c>=N)return;kb=0;idle=0;try{c.setPointerCapture(e.pointerId)}catch(_){}
  if(sel&&sel.r===p.r&&sel.c===p.c){sel=null;drag=null;return}
  if(sel&&Math.abs(sel.r-p.r)+Math.abs(sel.c-p.c)===1){trySwap(sel,{r:p.r,c:p.c});sel=null;drag=null;return}
  sel={r:p.r,c:p.c};drag={r:p.r,c:p.c,px:p.px,py:p.py};beep(500,.03,'sine',.02)};
 c.onpointermove=e=>{if(!drag||phase!=='idle')return;const p=cellAt(e),dx=p.px-drag.px,dy=p.py-drag.py;if(Math.max(Math.abs(dx),Math.abs(dy))<S*.4)return;
  const d=Math.abs(dx)>Math.abs(dy)?[0,Math.sign(dx)]:[Math.sign(dy),0],b={r:drag.r+d[0],c:drag.c+d[1]};if(b.r>=0&&b.r<N&&b.c>=0&&b.c<N){trySwap({r:drag.r,c:drag.c},b);sel=null}drag=null};
 c.onpointerup=c.onpointercancel=()=>{drag=null};
 hb.onclick=showHint;
 const inp=input(st,[],k=>{if(over){if(k===' '||k==='Enter')init();return}if(k==='h'||k==='H'){showHint();return}
  const d={ArrowUp:[-1,0],ArrowDown:[1,0],ArrowLeft:[0,-1],ArrowRight:[0,1]}[k];
  if(d){kb=1;if(sel&&phase==='idle'){const b={r:sel.r+d[0],c:sel.c+d[1]};if(b.r>=0&&b.r<N&&b.c>=0&&b.c<N){trySwap(sel,b)}sel=null}else{cur_r=(cur_r+d[0]+N)%N;cur_c=(cur_c+d[1]+N)%N}}
  else if(k===' '||k==='Enter'){kb=1;if(phase!=='idle')return;sel=sel&&sel.r===cur_r&&sel.c===cur_c?null:{r:cur_r,c:cur_c}}});
 // ---------- drawing ----------
 function gem(t,px,py,r,a){x.save();x.globalAlpha=a;x.translate(px,py);const col=COL[t];
  const gr=x.createRadialGradient(-r*.35,-r*.35,r*.1,0,0,r*1.1);gr.addColorStop(0,'#fff');gr.addColorStop(.25,col);gr.addColorStop(1,'rgba(0,0,0,.4)');x.fillStyle=gr;x.strokeStyle='rgba(255,255,255,.35)';x.lineWidth=1.5;x.beginPath();
  if(t===0)x.arc(0,0,r,0,7);
  else if(t===1){const q=r*.86;rr(-q,-q,2*q,2*q,r*.3)}
  else if(t===2){x.moveTo(0,-r*1.05);x.lineTo(r*.8,0);x.lineTo(0,r*1.05);x.lineTo(-r*.8,0);x.closePath()}
  else if(t===3){x.moveTo(0,-r);x.lineTo(r*.95,r*.7);x.lineTo(-r*.95,r*.7);x.closePath()}
  else if(t===4){for(let k=0;k<6;k++){const an=Math.PI/3*k-Math.PI/6;x.lineTo(Math.cos(an)*r,Math.sin(an)*r)}x.closePath()}
  else{for(let k=0;k<10;k++){const an=Math.PI/5*k-Math.PI/2,rr=k%2?r*.48:r*1.05;x.lineTo(Math.cos(an)*rr,Math.sin(an)*rr)}x.closePath()}
  x.fill();x.stroke();x.fillStyle='rgba(255,255,255,.35)';x.beginPath();x.ellipse(-r*.3,-r*.4,r*.28,r*.16,-.6,0,7);x.fill();x.restore()}
 function pos(r,c2){const gm=g[r][c2];let px=c2*S+S/2,py=(r+(gm?gm.dy:0))*S+S/2;
  if(phase==='swap'&&swp){const e=ease(Math.min(1,swp.p)),{a,b}=swp;if(r===a.r&&c2===a.c){px+=(b.c-a.c)*S*e;py+=(b.r-a.r)*S*e}else if(r===b.r&&c2===b.c){px+=(a.c-b.c)*S*e;py+=(a.r-b.r)*S*e}}return[px,py]}
 function draw(){x.fillStyle='#0e1020';x.fillRect(0,0,W,H);x.fillStyle='rgba(255,255,255,.035)';for(let r=0;r<N;r++)for(let c2=0;c2<N;c2++)if((r+c2)%2)x.fillRect(c2*S,r*S,S,S);
  if(sel&&!over){x.fillStyle='rgba(255,255,255,.14)';x.fillRect(sel.c*S,sel.r*S,S,S)}
  if(kb&&!over){x.strokeStyle='rgba(255,255,255,.55)';x.lineWidth=2;x.strokeRect(cur_c*S+2,cur_r*S+2,S-4,S-4)}
  if(hintT>0&&hintMv){const pu=.5+.5*Math.sin(performance.now()/120);x.strokeStyle=`rgba(255,255,255,${.35+.5*pu})`;x.lineWidth=3;for(const q of[hintMv.a,hintMv.b]){x.beginPath();rr(q.c*S+3,q.r*S+3,S-6,S-6,8);x.stroke()}}
  for(let r=0;r<N;r++)for(let c2=0;c2<N;c2++){const gm=g[r][c2];if(!gm)continue;const[px,py]=pos(r,c2);let sz=1,a=1;
   if(phase==='clear'&&clr&&clr.m.has(r*N+c2)){sz=1-ease(Math.min(1,clr.p));a=sz}
   if(sel&&sel.r===r&&sel.c===c2)sz*=1.12;gem(gm.t,px,py,17*sz,a)}
  for(const p of parts){x.globalAlpha=Math.min(1,p.l*3);x.fillStyle=p.col;x.fillRect(p.x-2,p.y-2,4,4)}x.globalAlpha=1;
  if(msgT>0){const a=Math.min(1,msgT*3);x.fillStyle=`rgba(14,16,32,${.8*a})`;x.fillRect(0,H/2-26,W,52);x.fillStyle=`rgba(255,255,255,${a})`;x.font='bold 22px system-ui,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(msg,W/2,H/2)}
  sc.textContent='Level '+level+' · '+score+' / '+target+' · Zetten: '+moves+' · Beste: '+best('match3',score)}
 const stopLoop=loop(dt=>{
  if(msgT>0)msgT-=dt;if(hintT>0)hintT-=dt;
  parts=parts.filter(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=700*dt;p.l-=dt;return p.l>0});
  if(!over&&phase==='idle'){idle+=dt;if(idle>9){showHint();idle=0}}
  if(phase==='swap'){swp.p+=dt/.18;if(swp.p>=1){const{a,b}=swp;[g[a.r][a.c],g[b.r][b.c]]=[g[b.r][b.c],g[a.r][a.c]];
    if(swp.back){phase='idle';swp=null}else if(matches().m.size){moves--;combo=1;startClear()}else{swp={a,b,p:0,back:1};beep(200,.08,'square',.03)}}}
  else if(phase==='clear'){clr.p+=dt/.22;if(clr.p>=1){for(const i of clr.m)g[(i/N)|0][i%N]=null;startFall()}}
  else if(phase==='fall'){let done=1;for(let r=0;r<N;r++)for(let c2=0;c2<N;c2++){const gm=g[r][c2];if(gm.dy<0){gm.vy+=60*dt;gm.dy+=gm.vy*dt;if(gm.dy>=0){gm.dy=0;gm.vy=0}else done=0}}
   if(done){if(matches().m.size){combo++;startClear()}else settle()}}
  draw()});
 window._m3={grid:()=>g.map(r=>r.map(q=>q.t)),swap:(r1,c1,r2,c2)=>trySwap({r:r1,c:c1},{r:r2,c:c2}),moves:findMoves,state:()=>({score,moves,level,target,phase,over,combo}),set(s){score=s},setMoves(m){moves=m}};
 init();cur.reset=init;return()=>{stopLoop();clearTimeout(tm);inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;delete window._m3}}},
