{id:'piano',n:'Piano Tegels',e:'🎹',c:'Arcade',g:'#232526,#414345',nw:1,run(st){
 const W=320,H=480,CW=80,TH=120,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Tik op de zwarte tegels (onderaan) · toetsen D F J K of 1–4'));
 // Vader Jacob (Frère Jacques) als frequenties
 const C=261.63,D=293.66,Ee=329.63,F=349.23,Gg=392,A=440,G3=196;
 const MEL=[C,D,Ee,C,C,D,Ee,C,Ee,F,Gg,Ee,F,Gg,Gg,A,Gg,F,Ee,C,Gg,A,Gg,F,Ee,C,C,G3,C,C,G3,C];
 let tiles,score,over,started,t,t0,v,note,bad,overT,flashT;
 function addTile(){const last=tiles[tiles.length-1];let col=R(4);if(last&&tiles.length>1&&last.col===col&&tiles[tiles.length-2].col===col)col=(col+1+R(3))%4;tiles.push({col,y:last?last.y-TH:H-TH,hit:0,ht:0})}
 function init(){tiles=[];score=0;over=0;started=0;t=0;t0=0;v=220;note=0;bad=null;flashT=0;clearTimeout(overT);overlay(st,c,'');for(let i=0;i<6;i++)addTile()}
 function fail(tile,col){if(over)return;over=1;bad=tile||{col,y:H-TH,miss:1};best('piano',score);beep(110,.35,'sawtooth',.06);
  overT=setTimeout(()=>{if(over)overlay(st,c,'💀 Game over<br><span style="font-size:15px;font-weight:600">Score '+score+' · Beste '+best('piano',score)+'<br>Tik of druk op spatie om opnieuw te spelen</span>')},650)}
 function press(col,py){if(over)return;const n=tiles.find(q=>!q.hit);if(!n)return;
  if(n.col===col&&n.y+TH>0){n.hit=1;n.ht=t;score++;if(!started){started=1;t0=t}v=Math.min(950,220+score*5);beep(MEL[note%MEL.length],.16,'triangle',.07);note++}
  else{const hitTile=tiles.find(q=>q.col===col&&!q.hit&&py>=q.y&&py<q.y+TH);fail(hitTile||null,col);if(!hitTile){const base=tiles[0]?tiles[0].y:0,yy=py==null?H-TH:base+Math.floor((py-base)/TH)*TH;bad={col,y:Math.max(-TH/2,Math.min(H-TH/2,yy)),miss:1}}}}
 c.onpointerdown=e=>{e.preventDefault();if(over){init();return}const r=c.getBoundingClientRect();const px=(e.clientX-r.left)*W/r.width,py=(e.clientY-r.top)*H/r.height;press(Math.max(0,Math.min(3,Math.floor(px/CW))),py)};
 const KM={d:0,f:1,j:2,k:3,'1':0,'2':1,'3':2,'4':3};
 const inp=input(st,[],k=>{const kk=(k||'').toLowerCase();if(over){if(k===' '||k==='Enter')init();return}if(kk in KM)press(KM[kk],null)});
 const onDown=e=>{if(over&&e.target.closest&&e.target.closest('.ov'))init()};st.addEventListener('pointerdown',onDown);
 const stopLoop=loop(dt=>{t+=dt;
  if(started&&!over){for(const q of tiles)q.y+=v*dt;const n=tiles.find(q=>!q.hit);if(n&&n.y>H){n.y=H-TH;fail(n,n.col)}
   tiles=tiles.filter(q=>q.y<H+TH);while(tiles.length<7)addTile()}
  // draw
  x.fillStyle='#f3f3f8';x.fillRect(0,0,W,H);
  x.fillStyle='#e9e9f1';x.fillRect(0,H-TH,W,TH);
  x.strokeStyle='#cfd0dc';x.lineWidth=1;for(let i=1;i<4;i++){x.beginPath();x.moveTo(i*CW+.5,0);x.lineTo(i*CW+.5,H);x.stroke()}
  for(const q of tiles){const px=q.col*CW,py=q.y;if(py>H||py+TH<0)continue;
   if(q.hit){const a=Math.min(1,(t-q.ht)/.25);x.fillStyle=`rgb(${Math.round(160+40*a)},${Math.round(140+60*a)},255)`;x.fillRect(px+2,py+2,CW-4,TH-4);
    if(a<1){x.fillStyle=`rgba(255,255,255,${(1-a)*.8})`;x.fillRect(px+2,py+2,CW-4,TH-4)}}
   else{x.fillStyle='#15161f';x.fillRect(px+2,py+2,CW-4,TH-4);x.fillStyle='#2b2d3d';x.fillRect(px+2,py+2,CW-4,6)}
   x.strokeStyle='#cfd0dc';x.strokeRect(px+.5,py+.5,CW-1,TH-1)}
  if(bad){const bl=Math.floor(t*8)%2;x.fillStyle=bl?'#ff3b3b':'#c81e1e';x.fillRect(bad.col*CW+2,bad.y+2,CW-4,TH-4);x.fillStyle='#fff';x.font='bold 34px system-ui,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText('✕',bad.col*CW+CW/2,bad.y+TH/2)}
  const pill=(w,h,py)=>{x.fillStyle='rgba(255,255,255,.82)';x.beginPath();x.roundRect(W/2-w/2,py,w,h,h/2);x.fill()};
  x.textAlign='center';x.textBaseline='middle';pill(90,50,8);x.font='bold 36px system-ui,sans-serif';x.fillStyle='#15161f';x.fillText(score,W/2,34);
  if(!started&&!over){pill(300,36,H/2-30);x.font='bold 16px system-ui,sans-serif';x.fillStyle='#6c5ce7';x.fillText('Tik op de zwarte tegel om te starten',W/2,H/2-12)}
  const el=started?Math.max(.5,t-t0):0,tps=started?(score/el).toFixed(1).replace('.',','):'0,0';
  sc.textContent='Score: '+score+' · Beste: '+best('piano',score)+' · '+tps+' tegels/s'+(over?' · 💀':'')});
 st.pn={get next(){const n=tiles.find(q=>!q.hit);return n?n.col:-1},get nextY(){const n=tiles.find(q=>!q.hit);return n?n.y:-1},get score(){return score},get over(){return over},get started(){return started},get v(){return v}};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();clearTimeout(overT);st.removeEventListener('pointerdown',onDown);c.onpointerdown=null}}},
