{id:'dino',n:'Dino Ren',e:'🦖',c:'Arcade',g:'#232526,#414345',nw:1,run(st){
 const W=400,H=220,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Spatie / ⬆ / tik = springen · ⬇ = bukken'));
 let y,vy,duck,obs,sp,dist,score,over,t,clouds,legT,started=0,deadAt=0;
 const GY=180;
 function init(){y=0;vy=0;duck=0;obs=[];sp=220;dist=0;score=0;over=0;t=0;legT=0;clouds=[{x:80,y:40},{x:260,y:70},{x:380,y:30}];started=0;ov(`🦖 Dino Ren<br><span style="font-size:15px;font-weight:600">Tik of druk op spatie om te starten</span>`)}
 function ov(h){const o=overlay(st,c,h);if(o)o.onpointerdown=e=>{e.preventDefault();jump()}}
 function begin(){init();started=1;overlay(st,c,'');beep(660,.05,'square',.03)}
 function jump(){if(over){if(performance.now()-deadAt>400)begin();return}if(!started){begin();return}if(y===0){vy=-520;beep(520,.06,'square',.03)}}
 const inp=input(st,[['⬆ Spring',' '],['⬇ Buk','ArrowDown']],k=>{if(k===' '||k==='ArrowUp')jump()});
 c.onpointerdown=e=>{e.preventDefault();jump()};
 function spawn(){const r=Math.random();if(r<.7){const n=1+R(3);obs.push({x:W+20,w:n*16,h:28+R(16),k:'c'})}else obs.push({x:W+20,w:40,h:22,k:'b',fy:R(2)?GY-60:GY-28})}
 function dead(){over=1;deadAt=performance.now();best('dino',score);beep(140,.3,'sawtooth',.05);ov(`💀 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('dino',score)}<br>Tik of druk op spatie om opnieuw te spelen</span>`)}
 const stopLoop=loop(dt=>{
  if(started&&!over){t+=dt;duck=inp.has('ArrowDown')&&y===0;if(inp.has(' ')||inp.has('ArrowUp'))jump();
   vy+=1500*dt;y+=vy*dt;if(y>0){y=0;vy=0}
   sp=Math.min(560,220+dist/40);dist+=sp*dt;score=Math.floor(dist/20);
   if(!obs.length||obs[obs.length-1].x<W-180-R(220))spawn();
   obs.forEach(o=>o.x-=sp*dt);obs=obs.filter(o=>o.x>-80);
   clouds.forEach(cl=>{cl.x-=sp*dt*.2;if(cl.x<-60)cl.x=W+60});
   const ph=duck?22:44,pw=duck?52:34,px=50,py=GY+y-ph;
   for(const o of obs){const oy=o.k==='b'?o.fy:GY-o.h,oh=o.k==='b'?18:o.h;if(px+pw-6>o.x&&px+6<o.x+o.w&&py+ph-4>oy&&py+4<oy+oh){dead();break}}
   legT+=dt*14}
  // draw
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);
  x.fillStyle='#1c2140';clouds.forEach(cl=>{x.beginPath();x.arc(cl.x,cl.y,14,0,7);x.arc(cl.x+16,cl.y-6,16,0,7);x.arc(cl.x+32,cl.y,13,0,7);x.fill()});
  x.strokeStyle='#5a5f80';x.lineWidth=2;x.beginPath();x.moveTo(0,GY+.5);x.lineTo(W,GY+.5);x.stroke();
  x.fillStyle='#3a3f60';for(let i=0;i<8;i++){const gx=((i*61-dist)%W+W)%W;x.fillRect(gx,GY+6+(i%3)*4,8,2)}
  obs.forEach(o=>{if(o.k==='b'){x.fillStyle='#c9b458';const f=Math.floor(t*6)%2;x.fillRect(o.x+12,o.fy+4,16,10);x.fillRect(o.x,o.fy+(f?0:8),12,6);x.fillRect(o.x+28,o.fy+(f?0:8),12,6);x.fillStyle='#0e1020';x.fillRect(o.x+22,o.fy+6,3,3)}
   else{x.fillStyle='#38ef7d';const n=o.w/16;for(let i=0;i<n;i++){const bx=o.x+i*16;x.fillRect(bx+5,GY-o.h,6,o.h);x.fillRect(bx,GY-o.h+8,4,10);x.fillRect(bx+12,GY-o.h+12,4,10);x.fillRect(bx,GY-o.h+16,6,3);x.fillRect(bx+10,GY-o.h+20,6,3)}}});
  // dino
  const ph=duck?22:44,pw=duck?52:34,px=50,py=GY+y-ph;x.fillStyle='#b6ffd0';
  if(duck){x.fillRect(px,py+4,40,14);x.fillRect(px+36,py,16,12);x.fillStyle='#0e1020';x.fillRect(px+46,py+3,3,3);x.fillStyle='#b6ffd0';x.fillRect(px+6,py+18,6,4);x.fillRect(px+22,py+18,6,4)}
  else{x.fillRect(px,py+14,22,18);x.fillRect(px+14,py,20,16);x.fillRect(px-8,py+18,10,6);x.fillStyle='#0e1020';x.fillRect(px+26,py+4,3,3);x.fillStyle='#b6ffd0';const l=y===0&&!over?Math.floor(legT)%2:0;x.fillRect(px+3,py+32,6,l?8:12);x.fillRect(px+13,py+32,6,l?12:8)}
  sc.textContent='Score: '+score+' · Beste: '+best('dino',score)+(over?' · Game over':'');
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=null}}},
