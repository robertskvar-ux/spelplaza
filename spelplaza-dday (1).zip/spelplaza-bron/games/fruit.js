{id:'fruit',n:'Fruit Snijden',e:'🍉',c:'Arcade',g:'#f12711,#f5af19',nw:1,run(st){
 const W=360,H=480,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Veeg snel over het fruit · 💣 niet raken · 3 gemist = game over'));
 const FR=[['🍉','#ff4d6d'],['🍎','#e63946'],['🍊','#ff9f1c'],['🍌','#ffd166'],['🍓','#ef476f'],['🥝','#8ac926'],['🍍','#ffca3a']],G=820,RAD=27;
 let fr,halves,parts,texts,trail,score,miss,over,t,spawnT,down,last,swipeN,lastSlice,flash,shake,sliced,deadT;
 function init(){fr=[];halves=[];parts=[];texts=[];trail=[];score=0;miss=0;over=0;t=0;spawnT=.6;down=0;last=null;swipeN=0;lastSlice=0;flash=0;shake=0;sliced=0;clearTimeout(deadT);overlay(st,c,'')}
 function spawn(){const n=1+R(Math.min(4,1+Math.floor(t/18)));for(let i=0;i<n;i++){const bomb=Math.random()<Math.min(.22,.06+t*.004)&&score>0;const px=40+R(W-80),k=R(FR.length);
  fr.push({x:px,y:H+30+R(40),vx:(W/2-px)*.5+(Math.random()-.5)*140,vy:-(640+Math.random()*170),rot:Math.random()*6.3,vr:(Math.random()-.5)*5,em:bomb?'💣':FR[k][0],col:bomb?'#555':FR[k][1],bomb})}}
 function dead(msg){over=1;down=0;trail=[];best('fruit',score);beep(90,.4,'sawtooth',.06);deadT=setTimeout(()=>{if(over)overlay(st,c,msg+'<br><span style="font-size:15px;font-weight:600">Score '+score+' · Beste '+best('fruit',score)+'<br>Tik of druk op spatie om opnieuw te spelen</span>')},500)}
 function ftext(px,py,txt,col,big){texts.push({x:px,y:py,txt,col,t:0,big})}
 function slice(f,ang){f.dead=1;sliced++;const nx=-Math.sin(ang),ny=Math.cos(ang);
  if(f.bomb){flash=1;shake=.5;for(let i=0;i<40;i++){const a=Math.random()*6.3,s=120+Math.random()*320;parts.push({x:f.x,y:f.y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,col:i%2?'#ffb703':'#fb5607',t:0,r:3+R(5)})}dead('💥 Boem! Dat was een bom');return}
  for(const s of[-1,1])halves.push({x:f.x,y:f.y,vx:f.vx+nx*s*90,vy:f.vy*.5-40+ny*s*90,rot:f.rot,vr:f.vr+s*3,em:f.em,ang:ang-f.rot,side:s,t:0});
  for(let i=0;i<12;i++){const a=Math.random()*6.3,s=40+Math.random()*180;parts.push({x:f.x,y:f.y,vx:Math.cos(a)*s+f.vx*.3,vy:Math.sin(a)*s+f.vy*.3,col:f.col,t:0,r:2+R(4)})}
  score+=10;swipeN++;lastSlice=t;ftext(f.x,f.y-20,'+10','#fff');beep(700+R(400),.05,'triangle',.035)}
 function endSwipe(){if(swipeN>=3){const b=swipeN*10;score+=b;ftext(W/2,H*.4,'COMBO ×'+swipeN+'  +'+b,'#ffd166',1);[0,1,2].forEach(i=>setTimeout(()=>beep(600+i*200,.08,'triangle',.05),i*70))}swipeN=0}
 function pt(e){const r=c.getBoundingClientRect();return{x:(e.clientX-r.left)*W/r.width,y:(e.clientY-r.top)*H/r.height,tm:performance.now()}}
 function move(e){const p=pt(e);if(last){const dx=p.x-last.x,dy=p.y-last.y,d=Math.hypot(dx,dy),dt=Math.max(1,p.tm-last.tm);if(d<2)return;trail.push({x:p.x,y:p.y,t:t});
   if(!over&&d/dt*1000>220){const ang=Math.atan2(dy,dx);for(const f of fr){if(f.dead)continue;const fx=f.x-last.x,fy=f.y-last.y,u=Math.max(0,Math.min(1,(fx*dx+fy*dy)/(d*d)));if(Math.hypot(fx-u*dx,fy-u*dy)<RAD+6)slice(f,ang)}}}
  else trail.push({x:p.x,y:p.y,t:t});last=p}
 c.onpointerdown=e=>{e.preventDefault();try{c.setPointerCapture(e.pointerId)}catch(z){}if(over){init();return}down=1;last=null;trail=[];move(e)};
 c.onpointermove=e=>{if(down||(e.pointerType==='mouse'&&!over))move(e)};
 c.onpointerup=c.onpointercancel=e=>{down=0;last=null;endSwipe()};
 const inp=input(st,[],k=>{if(over&&(k===' '||k==='Enter'))init()});
 const onDown=e=>{if(over&&e.target.closest&&e.target.closest('.ov'))init()};st.addEventListener('pointerdown',onDown);
 function drawEmoji(em,px,py,rot,size){x.save();x.translate(px,py);x.rotate(rot);x.font=size+'px serif';x.textAlign='center';x.textBaseline='middle';x.fillText(em,0,size*.06);x.restore()}
 const stopLoop=loop(dt=>{
  if(!over){t+=dt;spawnT-=dt;if(spawnT<=0){spawn();spawnT=Math.max(.55,1.35-t*.012)+Math.random()*.3}}
  if(swipeN&&t-lastSlice>.3)endSwipe();
  for(const f of fr){f.vy+=G*dt;f.x+=f.vx*dt;f.y+=f.vy*dt;f.rot+=f.vr*dt;if(f.x<RAD){f.x=RAD;f.vx=Math.abs(f.vx)}if(f.x>W-RAD){f.x=W-RAD;f.vx=-Math.abs(f.vx)}
   if(!f.dead&&f.vy>0&&f.y>H+50){f.dead=1;if(!f.bomb&&!over){miss++;beep(200,.12,'square',.03);ftext(f.x,H-30,'❌ gemist','#ff6b6b');if(miss>=3)dead('💀 Te veel fruit gemist')}}}
  fr=fr.filter(f=>!f.dead);
  for(const h of halves){h.vy+=G*dt;h.x+=h.vx*dt;h.y+=h.vy*dt;h.rot+=h.vr*dt;h.t+=dt}halves=halves.filter(h=>h.y<H+80);
  for(const p of parts){p.vy+=G*.6*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.t+=dt}parts=parts.filter(p=>p.t<.9&&p.y<H+20);
  for(const q of texts)q.t+=dt;texts=texts.filter(q=>q.t<(q.big?1.4:.8));trail=trail.filter(p=>t-p.t<.16);
  if(flash>0)flash-=dt*3;if(shake>0)shake-=dt;
  // draw
  x.save();if(shake>0)x.translate((Math.random()-.5)*shake*16,(Math.random()-.5)*shake*16);
  const bg=x.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#1a1140');bg.addColorStop(1,'#0e1020');x.fillStyle=bg;x.fillRect(-10,-10,W+20,H+20);
  x.fillStyle='#ffffff08';for(let i=0;i<6;i++){x.beginPath();x.arc(60+i*55,90+(i%3)*120,28+i*4,0,7);x.fill()}
  for(const p of parts){x.globalAlpha=Math.max(0,1-p.t/.9);x.fillStyle=p.col;x.beginPath();x.arc(p.x,p.y,p.r,0,7);x.fill()}x.globalAlpha=1;
  for(const h of halves){x.save();x.translate(h.x,h.y);x.rotate(h.rot);x.beginPath();const a0=h.ang+(h.side>0?0:Math.PI);x.arc(0,0,RAD+14,a0,a0+Math.PI);x.closePath();x.clip();x.font='54px serif';x.textAlign='center';x.textBaseline='middle';x.fillText(h.em,0,3);x.restore()}
  for(const f of fr){if(f.bomb){x.fillStyle='#ffb703';x.beginPath();x.arc(f.x+Math.cos(f.rot)*18,f.y+Math.sin(f.rot)*18-16,3+R(3),0,7);x.fill()}drawEmoji(f.em,f.x,f.y,f.rot,54)}
  if(trail.length>1){x.lineCap='round';x.lineJoin='round';for(let i=1;i<trail.length;i++){const a=i/trail.length;x.strokeStyle=`rgba(120,230,255,${a*.6})`;x.lineWidth=14*a;x.shadowColor='#7df9ff';x.shadowBlur=12;x.beginPath();x.moveTo(trail[i-1].x,trail[i-1].y);x.lineTo(trail[i].x,trail[i].y);x.stroke()}
   x.shadowBlur=0;for(let i=1;i<trail.length;i++){const a=i/trail.length;x.strokeStyle=`rgba(255,255,255,${a})`;x.lineWidth=5*a;x.beginPath();x.moveTo(trail[i-1].x,trail[i-1].y);x.lineTo(trail[i].x,trail[i].y);x.stroke()}}
  for(const q of texts){const life=q.big?1.4:.8;x.globalAlpha=Math.max(0,1-q.t/life);x.fillStyle=q.col;x.font=(q.big?'bold 30px':'bold 20px')+' system-ui,sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(q.txt,q.x,q.y-q.t*40);}x.globalAlpha=1;
  x.textAlign='left';x.textBaseline='top';x.fillStyle='#fff';x.font='bold 26px system-ui,sans-serif';x.fillText('🍉 '+score,12,10);
  x.textAlign='right';x.font='20px serif';for(let i=0;i<3;i++){x.globalAlpha=i<miss?1:.3;x.fillText('❌',W-12-i*26,13)}x.globalAlpha=1;
  if(flash>0){x.fillStyle=`rgba(255,255,255,${Math.min(1,flash)})`;x.fillRect(-10,-10,W+20,H+20)}
  x.restore();
  sc.textContent='Score: '+score+' · Beste: '+best('fruit',score)+' · Gemist '+miss+'/3'+(over?' · 💀':'');
 });
 st.fr={get fr(){return fr},get score(){return score},get over(){return over},get miss(){return miss},get sliced(){return sliced}};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();clearTimeout(deadT);st.removeEventListener('pointerdown',onDown);c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
