{id:'platform3d',n:'3D-platformer',e:'🍄',c:'3D',g:'#56ab2f,#a8e063',nw:1,run(st){
 const W=360,H=440,T=three(st,W,H,{fov:55,far:160}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','◀▲▼▶ / WASD lopen · spatie / ⤒ springen · spring op vijanden · pak 10 ⭐ en haal de vlag'));
 const hemi=new THREE.HemisphereLight(0xffffff,0x5a6b4a,1.1),sun=new THREE.DirectionalLight(0xfff4e0,3);sun.position.set(-5,12,6);S.add(hemi,sun,new THREE.AmbientLight(0xffffff,.6));
 S.fog=new THREE.Fog(0x8fd3ff,40,110);S.background=new THREE.Color(0x8fd3ff);
 const std=(cl,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:cl,roughness:.8},o)),BOX=new THREE.BoxGeometry(1,1,1),SPH=new THREE.SphereGeometry(1,18,12);
 const mesh=(g,m,sx,sy,sz,x=0,y=0,z=0)=>{const o=new THREE.Mesh(g,m);o.scale.set(sx,sy,sz);o.position.set(x,y,z);return o};
 // levels: P=[x,ytop,z,w,d,move?[axis,amp,speed]], stars=[platform,dx,dz], en=[platform,axis(0=x,2=z),range]
 const LV=[
  {sky:0x8fd3ff,top:0x6cc24a,dirt:0x8d5a3b,cp:6,fl:12,
   P:[[0,0,0,6,6],[0,0,-7,3,4],[0,1,-12,3,3],[3.5,2,-16,3,3],[0,2,-21.5,5,4],[0,2,-27,3,3,[0,2.5,1]],[0,2,-33,6,5],[-4,3,-38,3,3],[-4,4,-42.5,3,3],[0,4,-46.5,3,3,[1,1.5,1.2]],[4,5,-50.5,3,3],[4,5,-56.5,4,6],[0,5,-64,6,5]],
   st:[[1,0,0],[2,0,0],[3,0,0],[4,-1.5,0],[4,1.5,0],[5,0,0],[7,0,0],[9,0,0],[10,0,0],[11,0,-2]],en:[[4,0,1.8],[11,2,2]]},
  {sky:0xffb38a,top:0xf2c14e,dirt:0xa0522d,cp:8,fl:13,
   P:[[0,0,0,5,5],[0,0,-6,2,4],[0,.5,-11,4,3,[0,3,1.2]],[0,1,-16,3,3],[-3.5,2,-19,3,3],[-7,3,-22,3,3],[-7,3,-28,4,6],[-2,3,-32,4,3,[0,2,1.4]],[3,3,-36,5,5],[3,4,-42,3,3,[1,1.2,1.5]],[3,5,-47,3,3],[-1,6,-50,3,3],[-5,6,-54,3,3,[2,2,1.3]],[-5,6,-61,5,5]],
   st:[[1,0,0],[2,0,0],[3,0,0],[4,0,0],[5,0,0],[6,0,-2],[8,1.5,1.5],[9,0,0],[11,0,0],[12,0,0]],en:[[6,2,2],[8,0,1.8],[13,0,1.8]]},
  {sky:0x1c2b55,top:0xbfe9ff,dirt:0x5b6b8c,cp:7,fl:14,
   P:[[0,0,0,5,5],[0,0,-6,1.4,5],[0,0,-12,4,4],[3.5,1,-16,2.5,2.5,[1,1,1.6]],[0,2,-20,2.5,2.5],[-3.5,3,-23.5,2.5,2.5],[-3.5,3,-29,2.5,4,[0,2.5,1.6]],[0,3,-35,5,5],[0,3,-41,1.4,5],[0,4,-46,3,3,[0,3,1.8]],[0,5,-51,3,3,[2,1.5,1.5]],[4,6,-55,3,3],[0,7,-58.5,2.5,2.5,[1,1.2,1.4]],[-4,7,-62,3,3],[-4,7,-68.5,6,6]],
   st:[[1,0,-1.5],[1,0,1.5],[3,0,0],[4,0,0],[5,0,0],[6,0,0],[8,0,0],[9,0,0],[11,0,0],[13,0,0]],en:[[2,0,1.6],[7,2,1.8],[14,0,2.2],[14,2,2.2]]}];
 // decor: clouds
 const cloudM=std(0xffffff,{roughness:1}),clouds=new THREE.Group();for(let i=0;i<14;i++){const g=new THREE.Group();for(let k=0;k<4;k++)g.add(mesh(SPH,cloudM,1.6+Math.random(),1.1,1.4,k*1.6-2.4,Math.random()*.5,Math.random()));g.position.set((Math.random()<.5?-1:1)*(14+Math.random()*16),-6+Math.random()*16,10-i*6.5);clouds.add(g)}S.add(clouds);
 // player (chunky, from primitives) – faces +z
 const pl=new THREE.Group(),skin=std(0xffd3a8),red=std(0xe63946,{roughness:.5}),blue=std(0x2a6fdb,{roughness:.6}),dark=std(0x3b2a20),black=std(0x111111,{roughness:.3});
 const body=mesh(BOX,blue,.7,.6,.5,0,.5,0),head=mesh(SPH,skin,.32,.32,.32,0,1.08,0),cap=mesh(new THREE.SphereGeometry(.34,16,8,0,Math.PI*2,0,Math.PI/2),red,1,1,1,0,1.12,0),brim=mesh(BOX,red,.46,.06,.3,0,1.14,.26);
 const eyeL=mesh(SPH,black,.05,.07,.05,-.11,1.08,.29),eyeR=mesh(SPH,black,.05,.07,.05,.11,1.08,.29),footL=mesh(BOX,dark,.22,.18,.34,-.17,.09,0),footR=mesh(BOX,dark,.22,.18,.34,.17,.09,0);
 const armL=mesh(BOX,red,.16,.42,.16,-.45,.6,0),armR=mesh(BOX,red,.16,.42,.16,.45,.6,0);pl.add(body,head,cap,brim,eyeL,eyeR,footL,footR,armL,armR);S.add(pl);
 const shadow=new THREE.Mesh(new THREE.CircleGeometry(.42,18),new THREE.MeshBasicMaterial({color:0,transparent:true,opacity:.3,depthWrite:false}));shadow.rotation.x=-Math.PI/2;S.add(shadow);
 // star geometry
 const shp=new THREE.Shape();for(let i=0;i<10;i++){const a=Math.PI/2+i*Math.PI/5,r=i%2?.18:.42;i?shp.lineTo(Math.cos(a)*r,Math.sin(a)*r):shp.moveTo(Math.cos(a)*r,Math.sin(a)*r)}
 const starG=new THREE.ExtrudeGeometry(shp,{depth:.14,bevelEnabled:true,bevelSize:.04,bevelThickness:.04,bevelSegments:1});starG.center();const starM=std(0xffd60a,{emissive:0x8a6500,roughness:.3,metalness:.4});
 const enM=std(0x9b2fd6,{roughness:.45}),poleM=std(0xdddddd,{metalness:.5,roughness:.3}),cpOff=std(0xd62828),cpOn=std(0x2dc653,{emissive:0x0d5a20}),flagM=std(0xffd60a,{emissive:0x6a4a00}),white=std(0xffffff);
 const MATS=[cloudM,skin,red,blue,dark,black,starM,enM,poleM,cpOff,cpOn,flagM,white],lvlG=new THREE.Group();S.add(lvlG);
 let L,boxes,stars,ens,cpPole,cpFlag,goal,px,py,pz,vx,vy,vz,ground,coyote,buf,lives,score,level,got,cpOnF,inv,msgT,msgFn,over,t,face,walk,camP=new THREE.Vector3(),look=new THREE.Vector3();
 const HW=.34,PH=1.35;
 function load(n){level=n;L=LV[n];lvlG.clear();boxes=[];stars=[];ens=[];got=0;cpOnF=0;
  S.background.setHex(L.sky);S.fog.color.setHex(L.sky);hemi.intensity=n===2?.8:1.1;const topM=L.tm||(L.tm=std(L.top)),dirtM=L.dm||(L.dm=std(L.dirt,{roughness:1}));
  L.P.forEach(p=>{const [x,y,z,w,d,m]=p,g=new THREE.Group();g.add(mesh(BOX,dirtM,w,1.5,d,0,-.9,0),mesh(BOX,topM,w+.08,.3,d+.08,0,-.15,0));g.position.set(x,y,z);lvlG.add(g);
   boxes.push({x,y,z,w,d,m,g,ox:x,oy:y,oz:z,dx:0,dy:0,dz:0,x0:0,x1:0,y0:0,y1:0,z0:0,z1:0})});
  L.st.forEach(([i,dx,dz])=>{const b=boxes[i],o=new THREE.Mesh(starG,starM);o.position.set(b.ox+dx,b.oy+1,b.oz+dz);lvlG.add(o);stars.push(o)});
  L.en.forEach(([i,ax,r],k)=>{const b=boxes[i],o=new THREE.Group();o.add(mesh(SPH,enM,.42,.34,.42,0,.34,0),mesh(SPH,white,.1,.12,.06,-.14,.45,.36),mesh(SPH,white,.1,.12,.06,.14,.45,.36),mesh(SPH,black,.05,.06,.04,-.14,.45,.41),mesh(SPH,black,.05,.06,.04,.14,.45,.41),mesh(BOX,dark,.5,.08,.1,0,.62,.3));
   o.userData={b,ax,r,ph:k*1.7,alive:1,sq:0};lvlG.add(o);ens.push(o)});
  const cb=boxes[L.cp];cpPole=mesh(BOX,poleM,.1,1.8,.1,cb.ox+cb.w/2-.5,cb.oy+.9,cb.oz+cb.d/2-.5);cpFlag=mesh(BOX,cpOff,.6,.4,.05,cpPole.position.x+.32,cb.oy+1.55,cpPole.position.z);lvlG.add(cpPole,cpFlag);
  const fb=boxes[L.fl];goal=new THREE.Group();goal.add(mesh(BOX,poleM,.14,3.2,.14,0,1.6,0),mesh(BOX,flagM,1.1,.7,.06,.6,2.8,0),mesh(SPH,flagM,.16,.16,.16,0,3.3,0));goal.position.set(fb.ox,fb.oy,fb.oz-1);lvlG.add(goal);
  spawn()}
 function spawn(){const b=boxes[cpOnF?L.cp:0];px=b.ox;py=b.oy+.2;pz=b.oz;vx=vy=vz=0;ground=null;coyote=0;buf=0;inv=1;face=Math.PI;camP.set(px,py+5,pz+8);look.set(px,py+1,pz-3)}
 function init(){lives=3;score=0;over=0;t=0;walk=0;msgT=0;msgFn=null;load(0);overlay(st,c,'')}
 function msg(h,s,f){if(!s)overAt=performance.now();msgT=s;msgFn=f;const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function hurt(fell){lives--;beep(fell?160:220,.25,'sawtooth',.05);if(lives<=0){over=1;const b=best('platform3d',score);msg(`💀 Game over<br><span style="font-size:15px;font-weight:600">Level ${level+1} · Score ${score} · Beste: ${b}<br>Tik of druk op een toets om opnieuw te spelen</span>`,0);return}
  msg(fell?'💧 Gevallen!':'💥 Au!',.9,()=>{overlay(st,c,'');spawn()})}
 function finish(){beep(660,.12,'triangle',.05);setTimeout(()=>beep(990,.2,'triangle',.05),130);score+=500+got*50;lives=Math.min(5,lives+1);
  if(level===2){over=2;const b=best('platform3d',score);msg(`🏆 Alle 3 levels gehaald!<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste: ${b}<br>Tik of druk op een toets om opnieuw te spelen</span>`,0);return}
  msg(`🚩 Level ${level+1} gehaald!<br><span style="font-size:15px;font-weight:600">⭐ ${got}/10 · Score ${score} · +1 ❤️</span>`,1.8,()=>{overlay(st,c,'');load(level+1)})}
 const again=()=>{if(over&&msgT<=0)init()};
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight'],['⤒',' ']],k=>{if(over){if(performance.now()-overAt>700)again();return}if(k===' '||k==='Space')buf=.14});
 let overAt=0;const P=inp.pad;if(P){P.style.cssText='display:grid;grid-template-columns:repeat(3,58px) 1fr 92px;grid-template-rows:repeat(2,50px);gap:6px;max-width:340px;margin:10px auto 0';
  const pos=[[1,2],[2,1],[2,2],[3,2],[5,1]];[...P.children].forEach((b,i)=>{b.style.gridColumn=pos[i][0];b.style.gridRow=i===4?'1 / span 2':pos[i][1];b.style.minWidth='0';b.style.padding='0';if(i===4)b.style.fontSize='30px'})}
 c.onpointerdown=e=>{e.preventDefault();if(over){if(performance.now()-overAt>700)again()}else buf=.14};
 const hold=k=>inp.has(k),ovl=(b)=>px+HW>b.x0&&px-HW<b.x1&&pz+HW>b.z0&&pz-HW<b.z1&&py+PH>b.y0&&py<b.y1;
 function mv(ax,d){if(ax===0)px+=d;else if(ax===1)py+=d;else pz+=d;
  for(const b of boxes){if(!ovl(b))continue;
   if(ax===0){px=(d?d>0:px<(b.x0+b.x1)/2)?b.x0-HW-1e-3:b.x1+HW+1e-3;vx=0}
   else if(ax===2){pz=(d?d>0:pz<(b.z0+b.z1)/2)?b.z0-HW-1e-3:b.z1+HW+1e-3;vz=0}
   else if(d<=0){py=b.y1;vy=0;ground=b}else{py=b.y0-PH-1e-3;vy=0}}}
 const stopLoop=loop(dt=>{t+=dt;
  if(msgT>0){msgT-=dt;if(msgT<=0)msgT=0;if(msgT<=0&&msgFn){const f=msgFn;msgFn=null;f()}}
  // platforms
  for(const b of boxes){let x=b.ox,y=b.oy,z=b.oz;if(b.m){const v=Math.sin(t*b.m[2])*b.m[1];if(b.m[0]===0)x+=v;else if(b.m[0]===1)y+=v;else z+=v}
   b.dx=x-b.x;b.dy=y-b.y;b.dz=z-b.z;b.x=x;b.y=y;b.z=z;b.x0=x-b.w/2;b.x1=x+b.w/2;b.z0=z-b.d/2;b.z1=z+b.d/2;b.y1=y;b.y0=y-1.6;b.g.position.set(x,y,z)}
  const busy=over||msgT>0;
  if(!busy){inv=Math.max(0,inv-dt);
   let ix=(hold('ArrowRight')||hold('d')?1:0)-(hold('ArrowLeft')||hold('a')?1:0),iz=(hold('ArrowDown')||hold('s')?1:0)-(hold('ArrowUp')||hold('w')?1:0);const l=Math.hypot(ix,iz);if(l>1){ix/=l;iz/=l}
   const acc=ground?40:22;vx+=(ix*6.2-vx)*Math.min(1,acc*dt/6);vz+=(iz*6.2-vz)*Math.min(1,acc*dt/6);
   if(ground){px+=ground.dx;pz+=ground.dz;py+=ground.dy;coyote=.11}else coyote-=dt;
   buf-=dt;if(buf>0&&coyote>0){vy=11.2;buf=0;coyote=0;ground=null;beep(520,.06,'triangle',.035)}
   if(vy>0&&!hold(' '))vy-=40*dt;vy=Math.max(-20,vy-30*dt);
   ground=null;for(let s=0;s<2;s++){mv(0,vx*dt/2);mv(2,vz*dt/2);mv(1,vy*dt/2-(s?0:.002))}
   if(ground&&py<ground.y1+.01)py=ground.y1;
   if(l>.1){const tf=Math.atan2(vx,vz);let d=tf-face;d=Math.atan2(Math.sin(d),Math.cos(d));face+=d*Math.min(1,dt*14)}
   walk+=Math.hypot(vx,vz)*dt*2.2;
   // stars
   for(const s of stars)if(s.visible&&Math.hypot(s.position.x-px,s.position.y-(py+.7),s.position.z-pz)<.9){s.visible=false;got++;score+=100;beep(880+got*40,.07,'sine',.05)}
   // checkpoint
   if(!cpOnF&&ground===boxes[L.cp]){cpOnF=1;cpFlag.material=cpOn;beep(700,.1,'triangle',.04);setTimeout(()=>beep(1050,.12,'triangle',.04),90)}
   // enemies
   for(const e of ens){const u=e.userData;if(!u.alive)continue;const v=Math.sin(t*1.3+u.ph)*u.r;e.position.set(u.b.x+(u.ax===0?v:0),u.b.y,u.b.z+(u.ax===2?v:0));e.rotation.y=u.ax===0?(Math.cos(t*1.3+u.ph)>0?Math.PI/2:-Math.PI/2):(Math.cos(t*1.3+u.ph)>0?0:Math.PI);
    const hx=Math.abs(e.position.x-px),hz=Math.abs(e.position.z-pz),ey=e.position.y;
    if(hx<.85&&hz<.85&&py<ey+.8&&py+PH>ey){
     if(vy<=.5&&py>ey+.2){u.alive=0;u.sq=1;vy=9;score+=50;beep(330,.08,'square',.04);setTimeout(()=>beep(500,.08,'square',.04),70)}
     else if(inv<=0&&hx<.62&&hz<.62&&py<ey+.55){inv=1.5;hurt(0)}}}
   if(Math.hypot(goal.position.x-px,goal.position.z-pz)<1&&Math.abs(goal.position.y-py)<1.5)finish();
   if(py<-12)hurt(1)}
  for(const e of ens){const u=e.userData;if(!u.alive&&u.sq>0){u.sq-=dt*3;e.scale.set(1+(1-u.sq)*.5,Math.max(.05,u.sq*.4),1+(1-u.sq)*.5);if(u.sq<=0)e.visible=false}}
  for(const s of stars)s.rotation.y+=dt*2.5;goal.children[1].rotation.y=Math.sin(t*3)*.2;
  // character pose
  const sw=ground?Math.sin(walk*3):0,air=!ground&&!busy;footL.position.z=sw*.2;footR.position.z=-sw*.2;armL.rotation.x=air?-2.4:sw*.8;armR.rotation.x=air?-2.4:-sw*.8;body.position.y=.5+Math.abs(sw)*.04;
  pl.position.set(px,py,pz);pl.rotation.y=face;pl.visible=!(inv>0&&!busy&&Math.floor(t*14)%2);
  let gy=-99;for(const b of boxes)if(px>b.x0&&px<b.x1&&pz>b.z0&&pz<b.z1&&b.y1<=py+.05&&b.y1>gy)gy=b.y1;shadow.visible=gy>-99;shadow.position.set(px,gy+.02,pz);const ss=Math.max(.35,1-(py-gy)*.15);shadow.scale.set(ss,ss,1);
  const k=1-Math.exp(-4*dt);camP.lerp(look.set(px,Math.max(py,-4)+5,pz+8),k);cam.position.copy(camP);cam.lookAt(camP.x,camP.y-4.2,camP.z-11);
  clouds.position.z=pz*.3;
  sc.textContent=`Lvl ${level+1}/3 · ⭐ ${got}/10 · ${'❤️'.repeat(Math.max(0,Math.min(lives,5)))||'💔'} · ${score} pt · Beste: ${best('platform3d',0)}`;
  T.r.render(S,cam)});
 init();cur.reset=init;
 return()=>{stopLoop();inp.stop();c.onpointerdown=null;T.dispose();lvlG.clear();MATS.forEach(m=>m.dispose());LV.forEach(l=>{l.tm&&l.tm.dispose();l.dm&&l.dm.dispose();l.tm=l.dm=null});[BOX,SPH,starG].forEach(g=>g.dispose())}}},
