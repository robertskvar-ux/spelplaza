{id:'quiz',n:'Weet je het?',e:'❓',c:'Woorden',g:'#4568dc,#b06ab3',nw:1,run(st){
 const CAT={A:'Aardrijkskunde',D:'Dieren & natuur',W:'Wetenschap',G:'Geschiedenis',T:'Taal & cultuur',S:'Sport'};
 // [categorie, vraag, 'JUIST|fout|fout|fout'] — het eerste antwoord is altijd het juiste (wordt bij het tonen geschud)
 const Q=[
  ['A','Wat is de hoofdstad van Australië?','Canberra|Sydney|Melbourne|Perth'],
  ['A','Wat is de langste rivier van Afrika?','De Nijl|De Congo|De Niger|De Zambezi'],
  ['A','Welk land is het grootste ter wereld in oppervlakte?','Rusland|Canada|China|Verenigde Staten'],
  ['A','Wat is de hoofdstad van Canada?','Ottawa|Toronto|Vancouver|Montreal'],
  ['A','Wat is de hoogste berg ter wereld?','Mount Everest|K2|Kilimanjaro|Mont Blanc'],
  ['A','Welke oceaan is de grootste?','Grote (Stille) Oceaan|Atlantische Oceaan|Indische Oceaan|Noordelijke IJszee'],
  ['A','Wat is de hoofdstad van Brazilië?','Brasília|Rio de Janeiro|São Paulo|Salvador'],
  ['A','Wat is het kleinste land ter wereld?','Vaticaanstad|Monaco|San Marino|Liechtenstein'],
  ['A','Welke rivier stroomt door Parijs?','De Seine|De Loire|De Rhône|De Theems'],
  ['A','Hoeveel provincies heeft België?','10|9|11|12'],
  ['D','Hoeveel poten heeft een spin?','8|6|10|4'],
  ['D','Wat is het grootste dier dat ooit op aarde heeft geleefd?','Blauwe vinvis|Afrikaanse olifant|Tyrannosaurus rex|Witte haai'],
  ['D','Welk dier is het snelste landdier?','Jachtluipaard|Leeuw|Paard|Antilope'],
  ['D','Hoeveel harten heeft een octopus?','3|1|2|4'],
  ['D','Welke vogel kan niet vliegen?','Pinguïn|Duif|Zwaluw|Ooievaar'],
  ['D','Wat is het grootste landdier?','Afrikaanse olifant|Neushoorn|Nijlpaard|Giraf'],
  ['D','Hoeveel poten heeft een insect?','6|8|4|10'],
  ['D','Wat eet een reuzenpanda vooral?','Bamboe|Vis|Vlees|Fruit'],
  ['D','Welk van deze dieren is een zoogdier?','Dolfijn|Haai|Krokodil|Kikker'],
  ['D','Wat is de grootste levende vogel?','Struisvogel|Adelaar|Albatros|Condor'],
  ['W','Wat is het chemisch symbool voor goud?','Au|Ag|Go|Gd'],
  ['W','Welke planeet staat het dichtst bij de zon?','Mercurius|Venus|Aarde|Mars'],
  ['W','Hoeveel planeten telt ons zonnestelsel?','8|9|7|10'],
  ['W','Wat is de chemische formule van water?','H₂O|CO₂|O₂|NaCl'],
  ['W','Welke planeet wordt de rode planeet genoemd?','Mars|Jupiter|Venus|Saturnus'],
  ['W','Wat is het grootste orgaan van het menselijk lichaam?','De huid|De lever|De longen|De hersenen'],
  ['W','Bij hoeveel graden Celsius kookt water op zeeniveau?','100|90|110|80'],
  ['W','Wat is het chemisch symbool voor ijzer?','Fe|Ir|Ij|Fr'],
  ['W','Welke planeet is de grootste van ons zonnestelsel?','Jupiter|Saturnus|Neptunus|Aarde'],
  ['W','Welk element heeft atoomnummer 1?','Waterstof|Helium|Zuurstof|Koolstof'],
  ['G','In welk jaar begon de Eerste Wereldoorlog?','1914|1918|1939|1912'],
  ['G','In welk jaar eindigde de Tweede Wereldoorlog?','1945|1944|1946|1939'],
  ['G','Wie zette als eerste mens voet op de maan?','Neil Armstrong|Buzz Aldrin|Joeri Gagarin|Michael Collins'],
  ['G','In welk jaar viel de Berlijnse Muur?','1989|1991|1985|1979'],
  ['G','In welk jaar bereikte Columbus Amerika?','1492|1500|1452|1512'],
  ['G','In welk jaar werd België onafhankelijk?','1830|1815|1848|1900'],
  ['G','Welke beschaving bouwde de piramiden van Gizeh?','De Egyptenaren|De Romeinen|De Grieken|De Maya’s'],
  ['G','Wie was de eerste president van de Verenigde Staten?','George Washington|Abraham Lincoln|Thomas Jefferson|John Adams'],
  ['G','In welk jaar zonk de Titanic?','1912|1905|1920|1898'],
  ['G','Welke Romeinse stad werd in 79 n.Chr. bedolven door de Vesuvius?','Pompeï|Rome|Athene|Carthago'],
  ['T','Wie schreef ‘Romeo en Julia’?','William Shakespeare|Charles Dickens|Jane Austen|Oscar Wilde'],
  ['T','Wie schilderde de Mona Lisa?','Leonardo da Vinci|Michelangelo|Rembrandt|Pablo Picasso'],
  ['T','Wie schreef het dagboek ‘Het Achterhuis’?','Anne Frank|Annie M.G. Schmidt|Hella Haasse|Harry Mulisch'],
  ['T','Welke componist schreef de Negende Symfonie met ‘Ode aan de vreugde’?','Ludwig van Beethoven|Wolfgang Amadeus Mozart|Johann Sebastian Bach|Frédéric Chopin'],
  ['T','Wie schreef de Harry Potter-boeken?','J.K. Rowling|J.R.R. Tolkien|Roald Dahl|Stephen King'],
  ['T','Wie schilderde ‘De Nachtwacht’?','Rembrandt van Rijn|Vincent van Gogh|Johannes Vermeer|Frans Hals'],
  ['T','Wie schreef ‘In de ban van de ring’?','J.R.R. Tolkien|C.S. Lewis|George R.R. Martin|Terry Pratchett'],
  ['T','Welke taal is de officiële taal van Brazilië?','Portugees|Spaans|Braziliaans|Italiaans'],
  ['T','Wie schilderde ‘De Sterrennacht’?','Vincent van Gogh|Claude Monet|Salvador Dalí|Rembrandt van Rijn'],
  ['T','Welke Belgische striptekenaar bedacht de Smurfen?','Peyo|Hergé|Willy Vandersteen|Marc Sleen'],
  ['S','Hoeveel spelers staan er per ploeg op het veld bij voetbal?','11|10|12|9'],
  ['S','Om de hoeveel jaar worden de Olympische Zomerspelen gehouden?','4|2|3|5'],
  ['S','Hoeveel ringen heeft het olympische logo?','5|4|6|7'],
  ['S','Welke sport wordt op Wimbledon gespeeld?','Tennis|Golf|Cricket|Hockey'],
  ['S','Hoe lang is een marathon ongeveer?','42 km|21 km|50 km|30 km'],
  ['S','Welke kleur heeft de leiderstrui in de Ronde van Frankrijk?','Geel|Groen|Wit|Rood'],
  ['S','Hoeveel spelers staan er per ploeg op het veld bij basketbal?','5|6|7|4'],
  ['S','In welk land werden in 1896 de eerste moderne Olympische Spelen gehouden?','Griekenland|Frankrijk|Italië|Engeland'],
  ['S','Hoeveel holes heeft een standaard golfbaan?','18|9|12|20'],
  ['S','Bij welke sport speel je met een shuttle?','Badminton|Tennis|Squash|Tafeltennis']];
 const TL=15,PER=10;
 const sc=E('div','sc'),chips=E('div');chips.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:4px 0 10px';
 const card=E('div');card.style.cssText='background:var(--bg);border-radius:14px;padding:14px;max-width:460px;margin:0 auto;text-align:left';
 const cat=E('div');cat.style.cssText='font-size:12px;font-weight:700;color:var(--ac);text-transform:uppercase;letter-spacing:.5px';
 const qt=E('div');qt.style.cssText='font-size:19px;font-weight:700;margin:6px 0 10px;min-height:52px;line-height:1.3';
 const barW=E('div');barW.style.cssText='height:8px;border-radius:99px;background:var(--card);overflow:hidden;margin-bottom:12px';
 const bar=E('div');bar.style.cssText='height:100%;width:100%;border-radius:99px;background:#38d9a9';barW.append(bar);
 const ans=E('div');ans.style.cssText='display:grid;gap:8px';
 const fb=E('div');fb.style.cssText='min-height:24px;margin-top:10px;font-weight:700;font-size:15px';
 card.append(cat,qt,barW,ans,fb);
 st.append(sc,chips,card,E('div','hint','Tik op een antwoord of druk op 1–4 · Enter = volgende'));
 let filt='Alles',round,qi,score,streak,nOk,ok,timeLeft,running,nextT,summary,q,order,btns;
 const nl=n=>String(n).replace('.',',');
 const mult=()=>streak>=5?2:streak>=3?1.5:1;
 function drawChips(){chips.innerHTML='';['Alles',...Object.keys(CAT)].forEach(k=>{const lab=k==='Alles'?'Alles':CAT[k];const b=E('button','btn',lab);b.style.cssText='padding:6px 10px;font-size:12px;border-radius:99px;'+(k===filt?'':'background:var(--bg);color:var(--tx)');b.onclick=()=>{filt=k;init()};chips.append(b)})}
 function status(){sc.textContent=summary?'Ronde klaar · Score '+score+' · Beste '+best('quiz',0):'Vraag '+Math.min(qi+1,PER)+'/'+PER+' · Score '+score+' · Beste '+best('quiz',0)+(streak>=3?' · 🔥 '+streak+' ×'+nl(mult()):'')}
 function show(){q=round[qi];order=[0,1,2,3].sort(()=>Math.random()-.5);btns=[];ok=null;running=1;timeLeft=TL;cat.textContent=CAT[q[0]];qt.textContent=q[1];fb.textContent='';ans.innerHTML='';
  const o=q[2].split('|');order.forEach((oi,k)=>{const b=E('button','btn',(k+1)+'. '+o[oi]);b.style.cssText='width:100%;text-align:left;padding:12px 14px;font-size:16px;background:var(--card);color:var(--tx);border:2px solid transparent;transition:background .15s';b.onpointerdown=e=>{e.preventDefault();answer(k)};btns.push(b);ans.append(b)});status()}
 function answer(k){if(!running||summary)return;running=0;ok=k>=0&&order[k]===0;const o=q[2].split('|');
  btns.forEach((b,i)=>{b.style.pointerEvents='none';if(order[i]===0){b.style.background='#2ecc71';b.style.color='#fff'}else if(i===k){b.style.background='#e74c3c';b.style.color='#fff'}else b.style.opacity='.55'});
  if(ok){streak++;nOk++;const pts=Math.round((100+Math.round(timeLeft*10))*mult());score+=pts;fb.style.color='#2ecc71';fb.textContent='✅ Juist! +'+pts+(mult()>1?' (×'+nl(mult())+')':'');beep(660,.08,'triangle',.05);setTimeout(()=>beep(880,.1,'triangle',.05),90)}
  else{streak=0;fb.style.color='#e74c3c';fb.textContent=(k<0?'⏰ Tijd om! ':'❌ Fout. ')+'Het juiste antwoord: '+o[0];beep(160,.2,'sawtooth',.04)}
  status();nextT=setTimeout(next,1800)}
 function next(){clearTimeout(nextT);if(summary)return;qi++;if(qi>=PER)finish();else show()}
 function finish(){summary=1;running=0;const b=best('quiz',score),n=round.length;cat.textContent='Ronde klaar';qt.innerHTML='🏁 Je score: <b style="color:var(--ac)">'+score+'</b> punten'+(score>=b&&score>0?' · 🏆 Nieuw record!':'')+'<br><span style="font-size:15px;font-weight:600;color:var(--mu)">'+nOk+' van de '+n+' juist · Beste: '+b+'</span>';barW.style.display='none';ans.innerHTML='';fb.textContent='';
  const again=E('button','btn','🔄 Nog een ronde');again.style.cssText='width:100%;padding:12px;font-size:16px';again.onclick=init;ans.append(again);status();[0,1,2].forEach(i=>setTimeout(()=>beep(523*Math.pow(1.26,i),.12,'triangle',.05),i*120))}
 const inp=input(st,[],k=>{if(k>='1'&&k<='4'&&running)answer(+k-1);else if((k==='Enter'||k===' ')&&!running&&!summary)next()});
 const stopLoop=loop(dt=>{if(!running||summary)return;timeLeft=Math.max(0,timeLeft-dt);const f=timeLeft/TL;bar.style.width=f*100+'%';bar.style.background=`hsl(${Math.round(f*120)},70%,50%)`;if(timeLeft<=0)answer(-1)});
 function init(){clearTimeout(nextT);const pool=Q.filter(x=>filt==='Alles'||x[0]===filt).slice().sort(()=>Math.random()-.5);round=pool.slice(0,PER);qi=0;score=0;streak=0;nOk=0;summary=0;drawChips();barW.style.display='';bar.style.width='100%';show()}
 st.qz={get q(){return q},get order(){return order},get score(){return score},get running(){return running},get summary(){return summary},answer,next};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();clearTimeout(nextT)}}},
