{id:'chess',n:'Schaken',e:'♟️',c:'Bord',g:'#434343,#000000',nw:1,run(st){
 // ---------- UI skeleton ----------
 const sc=E('div','sc');st.append(sc);
 const capTop=E('div','hint'),capBot=E('div','hint');capTop.style.minHeight=capBot.style.minHeight='20px';capTop.style.fontSize=capBot.style.fontSize='18px';capTop.style.margin='4px 0';capBot.style.margin='4px 0';
 const bd=E('div','bdr');bd.style.gridTemplateColumns='repeat(8,1fr)';bd.style.width='min(380px,100%)';bd.style.gap='0';bd.style.borderRadius='8px';bd.style.overflow='hidden';bd.style.boxShadow='0 4px 14px rgba(0,0,0,.35)';bd.style.fontSize='min(36px,9vw)';
 const hint=E('div','hint','Tik op een stuk en dan op een doelvak · jij speelt wit');
 st.append(capTop,bd,capBot,hint);
 const GL={k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'},FILES='abcdefgh';
 const sq=[];for(let i=0;i<64;i++){const d=E('div');d.style.position='relative';d.style.lineHeight='1';const pc=E('span');pc.style.fontFamily="'Segoe UI Symbol','Apple Symbols','Noto Sans Symbols2','DejaVu Sans',sans-serif";pc.style.pointerEvents='none';d.append(pc);
  const r=i>>3,c=i&7,light=(r+c)%2===0;
  const lbl=(txt,pos)=>{const lb=E('span','',txt);lb.style.cssText='position:absolute;font-size:10px;font-weight:800;pointer-events:none;color:'+(light?'#6e4a2a':'#2b1a0c')+pos;d.append(lb)};
  if(c===0)lbl(8-r,';top:1px;left:2px');if(r===7)lbl(FILES[c],';bottom:1px;right:2px');
  d.onpointerdown=e=>{e.preventDefault();tap(i)};sq.push(d);bd.append(d)}
 // ---------- engine ----------
 const PV={p:100,n:320,b:330,r:500,q:900,k:0};
 const PST={
  p:[0,0,0,0,0,0,0,0,50,50,50,50,50,50,50,50,10,10,20,30,30,20,10,10,5,5,10,25,25,10,5,5,0,0,0,20,20,0,0,0,5,-5,-10,0,0,-10,-5,5,5,10,10,-20,-20,10,10,5,0,0,0,0,0,0,0,0],
  n:[-50,-40,-30,-30,-30,-30,-40,-50,-40,-20,0,0,0,0,-20,-40,-30,0,10,15,15,10,0,-30,-30,5,15,20,20,15,5,-30,-30,0,15,20,20,15,0,-30,-30,5,10,15,15,10,5,-30,-40,-20,0,5,5,0,-20,-40,-50,-40,-30,-30,-30,-30,-40,-50],
  b:[-20,-10,-10,-10,-10,-10,-10,-20,-10,0,0,0,0,0,0,-10,-10,0,5,10,10,5,0,-10,-10,5,5,10,10,5,5,-10,-10,0,10,10,10,10,0,-10,-10,10,10,10,10,10,10,-10,-10,5,0,0,0,0,5,-10,-20,-10,-10,-10,-10,-10,-10,-20],
  r:[0,0,0,0,0,0,0,0,5,10,10,10,10,10,10,5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,0,0,0,5,5,0,0,0],
  q:[-20,-10,-10,-5,-5,-10,-10,-20,-10,0,0,0,0,0,0,-10,-10,0,5,5,5,5,0,-10,-5,0,5,5,5,5,0,-5,0,0,5,5,5,5,0,-5,-10,5,5,5,5,5,0,-10,-10,0,5,0,0,0,0,-10,-20,-10,-10,-5,-5,-10,-10,-20],
  k:[-30,-40,-40,-50,-50,-40,-40,-30,-30,-40,-40,-50,-50,-40,-40,-30,-30,-40,-40,-50,-50,-40,-40,-30,-30,-40,-40,-50,-50,-40,-40,-30,-20,-30,-30,-40,-40,-30,-30,-20,-10,-20,-20,-20,-20,-20,-20,-10,20,20,0,0,0,0,20,20,20,30,10,0,0,10,30,20],
  ke:[-50,-40,-30,-20,-20,-30,-40,-50,-30,-20,-10,0,0,-10,-20,-30,-30,-10,20,30,30,20,-10,-30,-30,-10,30,40,40,30,-10,-30,-30,-10,30,40,40,30,-10,-30,-30,-10,20,30,30,20,-10,-30,-30,-30,0,0,0,0,-30,-30,-50,-30,-30,-30,-30,-30,-30,-50]};
 const KN=[[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]],KG=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]],BD=[[-1,-1],[-1,1],[1,-1],[1,1]],RD=[[-1,0],[1,0],[0,-1],[0,1]];
 const isB=p=>p>='a',inb=(r,c)=>r>=0&&r<8&&c>=0&&c<8;
 function start(){const b=Array(64).fill('');'rnbqkbnr'.split('').forEach((p,i)=>{b[i]=p;b[8+i]='p';b[48+i]='P';b[56+i]=p.toUpperCase()});return{b,t:'w',cr:'KQkq',ep:-1,hm:0,fm:1}}
 function attacked(b,i,byW){const r=i>>3,c=i&7,pr=byW?r+1:r-1,pp=byW?'P':'p';
  if(pr>=0&&pr<8){if(c>0&&b[pr*8+c-1]===pp)return 1;if(c<7&&b[pr*8+c+1]===pp)return 1}
  const kn=byW?'N':'n',kg=byW?'K':'k',bi=byW?'B':'b',ro=byW?'R':'r',qu=byW?'Q':'q';
  for(const[dr,dc]of KN){const R=r+dr,C=c+dc;if(inb(R,C)&&b[R*8+C]===kn)return 1}
  for(const[dr,dc]of KG){const R=r+dr,C=c+dc;if(inb(R,C)&&b[R*8+C]===kg)return 1}
  for(const[dr,dc]of BD){let R=r+dr,C=c+dc;while(inb(R,C)){const q=b[R*8+C];if(q){if(q===bi||q===qu)return 1;break}R+=dr;C+=dc}}
  for(const[dr,dc]of RD){let R=r+dr,C=c+dc;while(inb(R,C)){const q=b[R*8+C];if(q){if(q===ro||q===qu)return 1;break}R+=dr;C+=dc}}
  return 0}
 const kingSq=(b,t)=>b.indexOf(t==='w'?'K':'k');
 const inCheck=s=>attacked(s.b,kingSq(s.b,s.t),s.t!=='w');
 // pseudo-legal moves; co=1 -> captures/promotions only
 function gen(s,co){const b=s.b,w=s.t==='w',m=[],mine=q=>q&&isB(q)!==w,enemy=q=>q&&isB(q)===w;
  for(let i=0;i<64;i++){const p=b[i];if(!mine(p))continue;const r=i>>3,c=i&7,P=p.toLowerCase();
   if(P==='p'){const d=w?-8:8,sr=w?6:1,pr=w?0:7,t=i+d;
    if(!b[t]){if((t>>3)===pr)m.push({f:i,t,p:'q'});else if(!co){m.push({f:i,t});if(r===sr&&!b[t+d])m.push({f:i,t:t+d})}}
    for(const dc of[-1,1]){const C=c+dc;if(C<0||C>7)continue;const tt=t+dc;if(enemy(b[tt]))m.push({f:i,t:tt,p:(tt>>3)===pr?'q':0});else if(tt===s.ep)m.push({f:i,t:tt,e:1})}}
   else if(P==='n'||P==='k'){for(const[dr,dc]of(P==='n'?KN:KG)){const R=r+dr,C=c+dc;if(!inb(R,C))continue;const t=R*8+C;if(mine(b[t])||(co&&!b[t]))continue;m.push({f:i,t})}
    if(P==='k'&&!co){const cr=s.cr;
     if(w&&i===60){if(cr.includes('K')&&!b[61]&&!b[62]&&!attacked(b,60,0)&&!attacked(b,61,0)&&!attacked(b,62,0))m.push({f:60,t:62,c:1});if(cr.includes('Q')&&!b[59]&&!b[58]&&!b[57]&&!attacked(b,60,0)&&!attacked(b,59,0)&&!attacked(b,58,0))m.push({f:60,t:58,c:1})}
     if(!w&&i===4){if(cr.includes('k')&&!b[5]&&!b[6]&&!attacked(b,4,1)&&!attacked(b,5,1)&&!attacked(b,6,1))m.push({f:4,t:6,c:1});if(cr.includes('q')&&!b[3]&&!b[2]&&!b[1]&&!attacked(b,4,1)&&!attacked(b,3,1)&&!attacked(b,2,1))m.push({f:4,t:2,c:1})}}}
   else{const ds=P==='b'?BD:P==='r'?RD:KG;for(const[dr,dc]of ds){let R=r+dr,C=c+dc;while(inb(R,C)){const t=R*8+C,q=b[t];if(q){if(enemy(q))m.push({f:i,t});break}if(!co)m.push({f:i,t});R+=dr;C+=dc}}}}
  return m}
 function make(s,m){const b=s.b.slice(),p=b[m.f],w=s.t==='w',cap=b[m.t];let cr=s.cr,ep=-1,hm=s.hm+1;
  b[m.t]=m.p?(w?'Q':'q'):p;b[m.f]='';
  if(p==='P'||p==='p'){hm=0;if(m.e)b[m.t+(w?8:-8)]='';if(Math.abs(m.t-m.f)===16)ep=(m.f+m.t)/2}
  if(cap)hm=0;
  if(m.c){if(m.t===62){b[61]='R';b[63]=''}else if(m.t===58){b[59]='R';b[56]=''}else if(m.t===6){b[5]='r';b[7]=''}else{b[3]='r';b[0]=''}}
  if(p==='K')cr=cr.replace(/[KQ]/g,'');else if(p==='k')cr=cr.replace(/[kq]/g,'');
  if(cr){for(const i of[m.f,m.t]){if(i===63)cr=cr.replace('K','');else if(i===56)cr=cr.replace('Q','');else if(i===7)cr=cr.replace('k','');else if(i===0)cr=cr.replace('q','')}}
  return{b,t:w?'b':'w',cr,ep,hm,fm:s.fm+(w?0:1)}}
 const legalAfter=(s,ns)=>!attacked(ns.b,kingSq(ns.b,s.t),ns.t==='w');
 function legal(s){return gen(s).filter(m=>legalAfter(s,make(s,m)))}
 function evalS(s){let e=0,q=0;const b=s.b;for(let i=0;i<64;i++){const p=b[i];if(p==='Q'||p==='q')q++}
  for(let i=0;i<64;i++){const p=b[i];if(!p)continue;if(isB(p)){const P=p==='k'&&!q?'ke':p;e-=PV[p]+PST[P][i^56]}else{const P=p.toLowerCase();e+=PV[P]+PST[P==='k'&&!q?'ke':P][i]}}
  return s.t==='w'?e:-e}
 const MATE=100000;let nodes=0;
 const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=R(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
 function order(ms,b){for(const m of ms){const q=b[m.t];m.s=(q?PV[q.toLowerCase()]*10-PV[b[m.f].toLowerCase()]:0)+(m.p?800:0)+(m.e?90:0)+(m.c?30:0)}ms.sort((a,b)=>b.s-a.s)}
 function quiesce(s,a,be,q){nodes++;const sp=evalS(s);if(sp>=be||q>=3)return sp;let best=sp;if(sp>a)a=sp;
  const ms=gen(s,1);order(ms,s.b);
  for(const m of ms){const ns=make(s,m);if(!legalAfter(s,ns))continue;const v=-quiesce(ns,-be,-a,q+1);if(v>best){best=v;if(v>a){a=v;if(a>=be)break}}}
  return best}
 let deadline=Infinity,aborted=0;
 function search(s,d,a,be,ply){nodes++;if((nodes&2047)===0&&performance.now()>deadline)aborted=1;if(aborted||s.hm>=100)return 0;
  const chk=inCheck(s);if(chk&&ply<8)d++;
  if(d<=0)return quiesce(s,a,be,0);
  const ms=gen(s);order(ms,s.b);let best=-Infinity,n=0;
  for(const m of ms){const ns=make(s,m);if(!legalAfter(s,ns))continue;n++;
   const v=-search(ns,d-1,-be,-a,ply+1);if(v>best){best=v;if(v>a){a=v;if(a>=be)break}}}
  if(!n)return chk?-MATE+ply:0;
  return best}
 function root(s,D){const ms=shuffle(gen(s));order(ms,s.b);let bm=null,bv=-Infinity,a=-Infinity;// shuffle = variety among equal moves
  for(const m of ms){const ns=make(s,m);if(!legalAfter(s,ns))continue;const v=-search(ns,D-1,-Infinity,-a,1);
   if(v>bv){bv=v;bm=m}if(v>a)a=v}
  return bm}
 let depth=3;
 function bestMove(s,fd){nodes=0;aborted=0;deadline=Infinity;const t0=performance.now();let m=root(s,fd||3);depth=fd||3;
  if(!fd&&performance.now()-t0<40){deadline=t0+350;const m4=root(s,4);if(m4&&!aborted){m=m4;depth=4}deadline=Infinity;aborted=0}// look one ply deeper when there is time (hard limit 350 ms)
  return m}
 // ---------- game state ----------
 let s,sel,tg,last,over,chk,capW,capB,busy,tm=0,rep,lastMs=0;
 const key=s=>s.b.map(p=>p||'.').join('')+s.t+s.cr+s.ep;
 function insufficient(b){let minors=[0,0];for(const p of b){if(!p)continue;const P=p.toLowerCase();if(P==='p'||P==='r'||P==='q')return 0;if(P==='n'||P==='b')minors[isB(p)?1:0]++}return minors[0]<=1&&minors[1]<=1}
 function status(){chk=inCheck(s);over='';const ms=legal(s);
  if(!ms.length)over=chk?(s.t==='w'?'Schaakmat · de computer wint 🤖':'Schaakmat · jij wint! 🎉'):'Pat · gelijkspel';
  else if(s.hm>=100)over='Gelijkspel · 50 zetten zonder slag of pionzet';
  else if(insufficient(s.b))over='Gelijkspel · te weinig materiaal';
  else if((rep.get(key(s))||0)>=3)over='Gelijkspel · driemaal dezelfde stelling';
  if(over)beep(over.includes('jij wint')?880:over.includes('computer')?160:330,.35,over.includes('jij wint')?'triangle':'sawtooth',.05);
  else if(chk)beep(990,.1,'square',.04);
  return ms}
 function apply(m){const cap=s.b[m.t]||(m.e?(s.t==='w'?'p':'P'):'');if(cap)(isB(cap)?capB:capW).push(cap);
  s=make(s,m);last=m;sel=-1;tg=new Set;const k=key(s);rep.set(k,(rep.get(k)||0)+1);beep(cap?300:520,.05,'square',.03)}
 function mat(list){return list.reduce((a,p)=>a+PV[p.toLowerCase()],0)}
 function draw(){
  for(let i=0;i<64;i++){const d=sq[i],p=s.b[i],light=((i>>3)+(i&7))%2===0;let bg=light?'#f0d9b5':'#b58863';
   if(last&&(i===last.f||i===last.t))bg=light?'#cdd26a':'#aaa23a';if(i===sel)bg=light?'#f6f669':'#baca2b';d.style.backgroundColor=bg;
   let img='none';if(chk&&p===(s.t==='w'?'K':'k'))img='radial-gradient(circle,#ff2d2d 0 16%,rgba(255,40,40,.6) 42%,transparent 70%)';
   else if(tg.has(i))img=p?'radial-gradient(circle,transparent 0 56%,rgba(0,0,0,.3) 58%)':'radial-gradient(circle,rgba(0,0,0,.3) 0 21%,transparent 23%)';
   d.style.backgroundImage=img;const pc=d.firstChild;pc.textContent=p?GL[p.toLowerCase()]:'';
   if(p){const w=!isB(p);pc.style.color=w?'#fff':'#1a1a20';pc.style.webkitTextStroke=w?'1px #222':'0.5px #000';pc.style.textShadow=w?'0 2px 3px rgba(0,0,0,.55)':'0 0 3px rgba(255,255,255,.35)'}}
  const dw=mat(capB)-mat(capW);
  capTop.innerHTML='🤖 Computer (zwart) · geslagen: <span style="color:var(--tx)">'+(capW.map(p=>GL[p.toLowerCase()]).join('')||'–')+'</span>'+(dw<0?' <b>+'+(-dw/100)+'</b>':'');
  capBot.innerHTML='🙂 Jij (wit) · geslagen: <span style="color:var(--tx)">'+(capB.map(p=>GL[p.toLowerCase()]).join('')||'–')+'</span>'+(dw>0?' <b>+'+(dw/100)+'</b>':'');
  sc.textContent=(over?over:busy?'🤖 Computer denkt…':'Jij bent aan zet (wit)'+(chk?' · Schaak!':''))+' · Zet '+s.fm}
 function tap(i){if(over||busy||s.t!=='w')return;const p=s.b[i];
  if(sel>=0&&tg.has(i)){const m=legal(s).find(m=>m.f===sel&&m.t===i);if(m){play(m);return}}
  if(p&&!isB(p)){sel=i;tg=new Set(legal(s).filter(m=>m.f===i).map(m=>m.t))}else{sel=-1;tg=new Set}draw()}
 function play(m){apply(m);status();draw();if(!over&&s.t==='b'){busy=1;draw();tm=setTimeout(aiMove,300)}}
 function aiMove(fd){tm=0;const t0=performance.now();const m=bestMove(s,fd);lastMs=performance.now()-t0;busy=0;if(!m)return;apply(m);status();draw()}
 function init(){clearTimeout(tm);tm=0;s=start();sel=-1;tg=new Set;last=null;over='';chk=0;capW=[];capB=[];busy=0;rep=new Map;rep.set(key(s),1);draw()}
 const alg=a=>(7-(a.charCodeAt(1)-49))*8+(a.charCodeAt(0)-97);
 window._chess={auto:1,
  move(f,t){const m=legal(s).find(m=>m.f===alg(f)&&m.t===alg(t));if(!m||over||busy)return false;apply(m);status();draw();if(this.auto&&!over&&s.t==='b'){busy=1;draw();tm=setTimeout(aiMove,300)}return true},
  ai(d){clearTimeout(tm);busy=1;aiMove(d);return{ms:lastMs,nodes,depth}},
  fen(){let f='';for(let r=0;r<8;r++){let e=0;for(let c=0;c<8;c++){const p=s.b[r*8+c];if(p){if(e){f+=e;e=0}f+=p}else e++}if(e)f+=e;if(r<7)f+='/'}return f+' '+s.t+' '+(s.cr||'-')+' '+(s.ep>=0?FILES[s.ep&7]+(8-(s.ep>>3)):'-')+' '+s.hm+' '+s.fm},
  load(fen){const[pl,t,cr,ep,hm,fm]=fen.split(' ');const b=Array(64).fill('');let i=0;for(const ch of pl){if(ch==='/')continue;if(ch>='1'&&ch<='8')i+=+ch;else b[i++]=ch}
   clearTimeout(tm);s={b,t,cr:cr==='-'?'':cr,ep:ep==='-'?-1:alg(ep),hm:+hm||0,fm:+fm||1};sel=-1;tg=new Set;last=null;busy=0;rep=new Map;rep.set(key(s),1);status();draw()},
  score(f,t,d){const m=legal(s).find(m=>m.f===alg(f)&&m.t===alg(t));return m?-search(make(s,m),(d||3)-1,-Infinity,Infinity,1):null},
  legal:()=>legal(s).map(m=>FILES[m.f&7]+(8-(m.f>>3))+FILES[m.t&7]+(8-(m.t>>3))),state:()=>({over,chk,turn:s.t,busy}),tap};
 init();cur.reset=init;return()=>{clearTimeout(tm);tm=0;delete window._chess}}},
