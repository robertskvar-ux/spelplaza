{id:'pong',n:'Pong',e:'🏸',c:'Arcade',g:'#373b44,#4286f4',run(st){
 const W=400,H=300,PH=56,PWD=10,BR=6,WIN=7,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 const opt=E('div');opt.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 8px;flex-wrap:wrap';sc.after(opt);
 st.append(E('div','hint','Sleep op het veld of ▲ ▼ / W S = peddel · eerste tot 7 wint · raak met de rand voor een scherpe hoek'));
 const LV=[['Makkelijk',170,0,60],['Normaal',250,0,44],['Moeilijk',340,0,36]];
 let lv=1;try{lv=+(localStorage.getItem('sp_pong_lv')??1)}catch(e){}if(!LV[lv])lv=1;
 let py,ay,b,a,s,state,stT,serveDir,trail,ty,aiErr,aiT,hits,parts,flash;
 function drawOpt(){opt.innerHTML='';LV.forEach(([l],i)=>{const q=E('button','btn',l);q.style.cssText='padding:6px 12px;font-size:12px;border-radius:99px;'+(i===lv?'':'background:var(--bg);color:var(--tx)');q.onclick=()=>{lv=i;try{localStorage.setItem('sp_pong_lv',i)}catch(e){}init()};opt.append(q)})}
 function serve(d){b={x:W/2,y:H/2,vx:0,vy:0};serveDir=d;state=0;stT=0;trail=[];hits=0}
 function init(){py=ay=H/2;a=s=0;ty=null;aiErr=0;aiT=0;parts=[];flash=0;drawOpt();serve(R(2)?1:-1);ov('')}
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function go(){const sp=230+lv*20,an=(Math.random()-.5)*.9;b.vx=Math.cos(an)*sp*serveDir;b.vy=Math.sin(an)*sp;state=1;beep(500,.05,'square',.03)}
 function point(me){if(me)a++;else s++;flash=.3;beep(me?880:200,.18,me?'triangle':'sawtooth',.045);
  for(let i=0;i<20;i++){const an=Math.random()*7,v=50+Math.random()*150;parts.push({x:b.x,y:b.y,vx:Math.cos(an)*v,vy:Math.sin(an)*v,l:.6,c:me?'#38ef7d':'#ff5c7a'})}
  if(a>=WIN||s>=WIN){state=2;stT=0;const won=a>s;if(won)best('pong',a-s);
   if(won)[523,659,784,1047].forEach((f,i)=>setTimeout(()=>beep(f,.14,'triangle',.05),i*110));
   ov((won?'🏆 Gewonnen!':'🤖 Verloren')+`<br><span style="font-size:15px;font-weight:600">${a} – ${s} op ${LV[lv][0].toLowerCase()}${won?'':''}<br>Beste winst: +${best('pong',0)}<br>Tik of druk op spatie om opnieuw te spelen</span>`)}
  else serve(me?1:-1)}
 const inp=input(st,[['▲','ArrowUp'],['▼','ArrowDown']],k=>{if(state===2){if(stT>.6&&(k===' '||k==='Enter'))init()}else if(state===0&&(k===' '||k==='Enter'))go()});
 const pos=e=>{const r=c.getBoundingClientRect();return(e.clientY-r.top)*H/r.height};let drag=0;
 c.onpointerdown=e=>{e.preventDefault();if(state===2){if(stT>.6)init();return}drag=1;ty=pos(e);try{c.setPointerCapture(e.pointerId)}catch(_){}if(state===0&&stT>.3)go()};
 c.onpointermove=e=>{if(drag||e.pointerType==='mouse')ty=pos(e)};c.onpointerup=c.onpointercancel=()=>{drag=0};
 function paddleHit(px,pyy,dir){if(Math.abs(b.y-pyy)>PH/2+BR)return 0;const off=(b.y-pyy)/(PH/2),sp=Math.min(620,Math.hypot(b.vx,b.vy)*1.05+6),an=off*1.0;
  b.vx=Math.cos(an)*sp*dir;b.vy=Math.sin(an)*sp;b.x=px+dir*(PWD/2+BR+1);hits++;beep(dir>0?440:330,.04,'square',.03);
  for(let i=0;i<6;i++)parts.push({x:b.x,y:b.y,vx:dir*(40+Math.random()*80),vy:(Math.random()-.5)*120,l:.3,c:'#fff'});return 1}
 const stopLoop=loop(dt=>{stT+=dt;flash=Math.max(0,flash-dt);
  if(inp.has('ArrowUp')||inp.has('w')){py-=360*dt;ty=null}if(inp.has('ArrowDown')||inp.has('s')){py+=360*dt;ty=null}
  if(ty!=null){const d=ty-py;py+=Math.sign(d)*Math.min(Math.abs(d),1100*dt)}py=Math.max(PH/2,Math.min(H-PH/2,py));
  if(state===0&&stT>1.1)go();
  // AI
  const[,asp,,err]=LV[lv];const hd=b.vx>0?1:-1;if(hd>0&&aiT<=0)aiErr=(Math.random()-.5)*2*err;aiT=hd;
  let tgt=H/2;if(b.vx>0){let px=b.x,pyb=b.y,vx=b.vx,vy=b.vy;const tt=(W-24-px)/vx;let yy=pyb+vy*tt;const span=H-2*BR;yy-=BR;yy=((yy%(2*span))+2*span)%(2*span);if(yy>span)yy=2*span-yy;tgt=yy+BR+aiErr;if(lv===0)tgt=b.y+aiErr}
  const ad=tgt-ay;ay+=Math.sign(ad)*Math.min(Math.abs(ad),asp*dt);ay=Math.max(PH/2,Math.min(H-PH/2,ay));
  if(state===1){const n=Math.ceil(Math.hypot(b.vx,b.vy)*dt/4);for(let k=0;k<n;k++){const sd=dt/n;b.x+=b.vx*sd;b.y+=b.vy*sd;
    if(b.y<BR){b.y=BR;b.vy=Math.abs(b.vy);beep(260,.02,'triangle',.015)}if(b.y>H-BR){b.y=H-BR;b.vy=-Math.abs(b.vy);beep(260,.02,'triangle',.015)}
    if(b.vx<0&&b.x-BR<=24+PWD/2&&b.x-BR>=24-PWD){if(paddleHit(24,py,1))continue}
    if(b.vx>0&&b.x+BR>=W-24-PWD/2&&b.x+BR<=W-24+PWD){if(paddleHit(W-24,ay,-1))continue}
    if(b.x<-BR){point(0);break}if(b.x>W+BR){point(1);break}}
   trail.push({x:b.x,y:b.y});if(trail.length>12)trail.shift()}
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.l-=dt}parts=parts.filter(p=>p.l>0);
  // draw
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);if(flash>0){x.fillStyle=`rgba(255,255,255,${flash*.15})`;x.fillRect(0,0,W,H)}
  x.fillStyle='#262b55';for(let y=8;y<H;y+=22)x.fillRect(W/2-2,y,4,12);
  x.strokeStyle='#262b55';x.lineWidth=2;x.beginPath();x.arc(W/2,H/2,40,0,7);x.stroke();
  x.textAlign='center';x.font='900 56px system-ui,sans-serif';x.fillStyle='#2f3570';x.fillText(a,W/2-70,70);x.fillText(s,W/2+70,70);
  x.font='700 10px system-ui,sans-serif';x.fillStyle='#4a5090';x.fillText('JIJ',W/2-70,86);x.fillText('COMPUTER',W/2+70,86);
  const pd=(px,pyy,col)=>{x.fillStyle=col;x.shadowColor=col;x.shadowBlur=14;x.beginPath();x.roundRect?x.roundRect(px-PWD/2,pyy-PH/2,PWD,PH,5):x.rect(px-PWD/2,pyy-PH/2,PWD,PH);x.fill();x.shadowBlur=0};
  pd(24,py,'#38ef7d');pd(W-24,ay,'#ff5c7a');
  trail.forEach((q,i)=>{x.globalAlpha=i/trail.length*.35;x.fillStyle='#ffd86b';x.beginPath();x.arc(q.x,q.y,BR*(i/trail.length),0,7);x.fill()});x.globalAlpha=1;
  if(state!==2){x.fillStyle='#fff';x.shadowColor='#ffd86b';x.shadowBlur=12;x.beginPath();x.arc(b.x,b.y,BR,0,7);x.fill();x.shadowBlur=0}
  for(const p of parts){x.globalAlpha=Math.max(0,p.l*2);x.fillStyle=p.c;x.fillRect(p.x-2,p.y-2,3,3)}x.globalAlpha=1;
  if(state===0){x.fillStyle='#cfd3f5';x.font='700 13px system-ui,sans-serif';x.fillText(a+s===0?'Klaar? Tik om op te slaan':'Opslag…',W/2,H/2+64)}
  sc.textContent=`Jij ${a} – ${s} Computer · Beste winst: +${best('pong',0)}`+(state===2?(a>s?' · 🎉 Gewonnen!':' · Verloren'):'');
 });
 st.t={get b(){return b},get state(){return state},get a(){return a},get s(){return s},setY:v=>{ty=v}};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
