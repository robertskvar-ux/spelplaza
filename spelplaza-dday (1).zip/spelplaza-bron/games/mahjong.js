{id:'mahjong',n:'Mahjong',e:'🀄',c:'Puzzel',g:'#11998e,#e8c872',nw:1,run(st){
 // Mahjong-solitaire, schildpad-opstelling (144 stenen, 5 lagen). Altijd oplosbaar: paren worden omgekeerd geplaatst.
 const K=['🍎','🍊','🍋','🍇','🍓','🍒','🍑','🍍','🥝','🥥','🍉','🍌','🐶','🐱','🐭','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐸','🐵','⭐','🌙','☀️','⚡','❄️','🔥','🌈','🌸','🍀','🍄','💎','🎈'];
 // posities in halve-steen eenheden {x,y,z}
 const P=[],add=(x,y,z)=>P.push({x,y,z});
 [[1,12],[3,10],[2,11],[1,12],[1,12],[2,11],[3,10],[1,12]].forEach(([a,b],r)=>{for(let i=a;i<=b;i++)add(2*i,2*r,0)});add(0,7,0);add(26,7,0);add(28,7,0);
 for(let r=1;r<=6;r++)for(let i=4;i<=9;i++)add(2*i,2*r,1);for(let r=2;r<=5;r++)for(let i=5;i<=8;i++)add(2*i,2*r,2);for(let r=3;r<=4;r++)for(let i=6;i<=7;i++)add(2*i,2*r,3);add(13,7,4);
 const N=P.length,ov=(a,b)=>Math.abs(a.x-b.x)<2&&Math.abs(a.y-b.y)<2;
 const above=P.map(t=>P.map((q,j)=>j).filter(j=>P[j].z===t.z+1&&ov(P[j],t))),below=P.map(t=>P.map((q,j)=>j).filter(j=>P[j].z===t.z-1&&ov(P[j],t)));
 const lft=P.map(t=>P.map((q,j)=>j).filter(j=>P[j].z===t.z&&P[j].x===t.x-2&&Math.abs(P[j].y-t.y)<2)),rgt=P.map(t=>P.map((q,j)=>j).filter(j=>P[j].z===t.z&&P[j].x===t.x+2&&Math.abs(P[j].y-t.y)<2));
 const band=P.map(t=>P.map((q,j)=>j).filter(j=>P[j].z===t.z&&Math.abs(P[j].y-t.y)<2));
 const isFree=(i,has)=>!above[i].some(has)&&(!lft[i].some(has)||!rgt[i].some(has));
 // ---------- generator: bouw van leeg naar vol; elk geplaatst paar moet op dat moment vrij zijn ----------
 function gen(set){const ids=[...set];for(let att=0;att<300;att++){const pl=new Set,pairs=[],has=j=>pl.has(j);let fail=0;
   const valid=c=>{if(pl.has(c)||!set.has(c))return 0;if(below[c].some(j=>set.has(j)&&!pl.has(j)))return 0;pl.add(c);let ok=isFree(c,has);
    if(ok)for(const s of band[c]){if(!set.has(s)||pl.has(s))continue;const t=P[s];let L=0,Rr=0;for(const q of band[s]){if(!pl.has(q)||q===s)continue;if(P[q].x<t.x)L=1;else if(P[q].x>t.x)Rr=1}if(L&&Rr){ok=0;break}}
    pl.delete(c);return ok};
   while(pl.size<ids.length&&!fail){const cand=ids.filter(valid).sort(()=>Math.random()-.5);let done=0;
    for(const a of cand.slice(0,8)){pl.add(a);const cb=ids.filter(b=>b!==a&&valid(b)).sort(()=>Math.random()-.5);
     for(const b of cb){pl.add(b);if(isFree(a,has)){pairs.push([a,b]);done=1;break}pl.delete(b)}if(done)break;pl.delete(a)}
    if(!done)fail=1}
   if(!fail)return pairs}return null}
 // ---------- DOM ----------
 const sc=E('div','sc'),bar=E('div');bar.style.cssText='display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:4px 0 8px';
 const bH=E('button','btn','💡 Hint'),bS=E('button','btn','🔀 Schud'),bU=E('button','btn','↩ Terug');[bH,bS,bU].forEach(b=>{b.style.cssText='padding:7px 12px;font-size:13px';bar.append(b)});
 const board=E('div');board.style.cssText='position:relative;margin:0 auto;user-select:none;-webkit-user-select:none;touch-action:manipulation;border-radius:14px;background:radial-gradient(ellipse at 50% 30%,#2a7a5a,#134634 85%);box-shadow:inset 0 0 26px rgba(0,0,0,.4)';
 const css=E('style','','.mj{position:absolute;border-radius:5px;display:flex;align-items:center;justify-content:center;cursor:pointer;background:linear-gradient(145deg,#fffdf4,#efe4c4);transition:opacity .2s,transform .2s;line-height:1}.mj.lo{filter:brightness(.8) saturate(.75)}.mj.sel{background:linear-gradient(145deg,#fff6a8,#ffd84d)}.mj.hi{animation:mjp .6s ease-in-out infinite alternate}.mj.kb{outline:3px solid #6c5ce7;outline-offset:1px}.mj.no{animation:mjs .25s}.mj.gone{opacity:0;transform:scale(.6);pointer-events:none}@keyframes mjp{to{background:linear-gradient(145deg,#c8ffd8,#6be39a)}}@keyframes mjs{25%{transform:translateX(-3px)}75%{transform:translateX(3px)}}');
 const msgEl=E('div','ov');msgEl.style.cssText+='display:none;z-index:9999;font-size:20px';board.append(msgEl);
 st.append(css,sc,bar,board,E('div','hint','Tik op twee gelijke vrije stenen (niets erop, links óf rechts vrij) · h = hint · s = schudden · u = terug · ←→ + spatie'));
 const el=P.map((p,i)=>{const d=E('div','mj');d.onpointerdown=e=>{e.preventDefault();tap(i)};board.append(d);return d});
 const tms=[];let kind,alive,sel,hist,shuf,score,t0,secs,over,kb,tm=0,hintT=0,pairsLeft;
 const has=j=>alive[j];
 function layout(){const cs=getComputedStyle(st),aw=Math.max(240,Math.min(st.clientWidth-parseFloat(cs.paddingLeft)-parseFloat(cs.paddingRight),700)),tw=Math.floor((aw-12)/15.25),th=Math.round(tw*1.32),dp=Math.max(3,Math.round(tw*.2));
  board.style.width=(tw*15+dp+12)+'px';board.style.height=(th*8+dp+14)+'px';
  P.forEach((p,i)=>{const d=el[i];d.style.width=(tw-1)+'px';d.style.height=(th-1)+'px';d.style.left=(5+p.x*tw/2-p.z*dp)+'px';d.style.top=(7+p.y*th/2-p.z*dp)+'px';
   d.style.fontSize=Math.round(tw*.74)+'px';d.style.zIndex=p.z*1000+p.x*20+p.y;d.style.boxShadow=`${dp*.5}px ${dp*.5}px 0 #d8c99c,${dp}px ${dp}px 0 #a8935e,${dp+1+p.z}px ${dp+2+p.z}px ${dp+3+p.z*3}px rgba(0,0,0,${.4+p.z*.07})`,d.style.border='1px solid rgba(120,100,50,.35)'})}
 function deal(set,kinds){const pr=gen(set);if(!pr)return 0;kinds.sort(()=>Math.random()-.5);pr.forEach(([a,b],i)=>{kind[a]=kind[b]=kinds[i]});return 1}
 function init(){kind=Array(N).fill(0);alive=Array(N).fill(1);const ks=[];for(let k=0;k<36;k++)ks.push(k,k);deal(new Set(P.map((_,i)=>i)),ks);
  sel=-1;hist=[];shuf=3;score=0;t0=performance.now();secs=0;over=0;kb=-1;pairsLeft=72;msgEl.style.display='none';layout();render()}
 function render(){P.forEach((p,i)=>{const d=el[i];d.textContent=K[kind[i]];d.className='mj'+(alive[i]?'':' gone')+(alive[i]&&!isFree(i,has)?' lo':'')+(i===sel?' sel':'')+(i===kb?' kb':'')});
  bS.textContent='🔀 Schud ('+shuf+')';bS.disabled=!shuf;bS.style.opacity=shuf?1:.5;bU.style.opacity=hist.length?1:.5;stat()}
 const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
 function stat(){sc.textContent='Paren: '+(72-pairsLeft)+'/72 · ⏱ '+fmt(secs)+' · Score '+score+' · Beste: '+best('mahjong',score)}
 const freeList=()=>P.map((_,i)=>i).filter(i=>alive[i]&&isFree(i,has));
 function moves(){const f=freeList(),out=[];for(let a=0;a<f.length;a++)for(let b=a+1;b<f.length;b++)if(kind[f[a]]===kind[f[b]])out.push([f[a],f[b]]);return out}
 function tap(i){if(over||!alive[i])return;clearHint();
  if(!isFree(i,has)){el[i].classList.remove('no');void el[i].offsetWidth;el[i].classList.add('no');beep(160,.06,'square',.03);return}
  if(sel===i){sel=-1;render();return}
  if(sel>=0&&kind[sel]===kind[i]){alive[sel]=alive[i]=0;hist.push([sel,i]);pairsLeft--;score+=10;beep(660,.06,'triangle',.04);tm=setTimeout(()=>beep(990,.08,'triangle',.035),70);sel=-1;render();after();return}
  sel=i;beep(480,.03,'sine',.025);render()}
 function after(){if(!pairsLeft){over=1;const bonus=Math.max(0,900-secs)*2+shuf*100;score+=bonus;stat();const b=best('mahjong',score);
   show(`🎉 Opgelost!<span style="font-size:15px;font-weight:600">Tijd ${fmt(secs)} · Score ${score} (+${bonus} bonus) · Beste ${b}<br>Tik om opnieuw te spelen</span>`,1);[523,659,784,1046].forEach((f,k)=>tms.push(setTimeout(()=>beep(f,.14,'triangle',.04),k*120)));return}
  if(!moves().length){if(shuf)show(`Geen zetten meer!<span style="font-size:15px;font-weight:600">Tik om te schudden (${shuf} over)</span>`,2);
   else{over=1;const b=best('mahjong',score);show(`Vastgelopen 😕<span style="font-size:15px;font-weight:600">${72-pairsLeft} paren · Score ${score} · Beste ${b}<br>Tik om opnieuw te spelen</span>`,1);beep(150,.35,'sawtooth',.04)}}}
 function show(h,mode){msgEl.innerHTML=h;msgEl.style.display='flex';msgEl.onpointerdown=e=>{e.preventDefault();msgEl.style.display='none';if(mode===1)init();else shuffle()}}
 function shuffle(){if(over||!shuf)return;const set=new Set(P.map((_,i)=>i).filter(i=>alive[i])),ks=[],cnt={};for(const i of set)cnt[kind[i]]=(cnt[kind[i]]||0)+1;
  for(const k in cnt)for(let n=0;n<cnt[k]/2;n++)ks.push(+k);if(!deal(set,ks))return;shuf--;sel=-1;hist=[];msgEl.style.display='none';beep(330,.1,'sine',.04);render();after()}
 function undo(){if(over||!hist.length)return;const[a,b]=hist.pop();alive[a]=alive[b]=1;pairsLeft++;score=Math.max(0,score-10);sel=-1;beep(300,.05,'sine',.03);render()}
 function clearHint(){if(hintT){clearTimeout(hintT);hintT=0;el.forEach(d=>d.classList.remove('hi'))}}
 function hint(){if(over)return;clearHint();const m=moves();if(!m.length){after();return}const[a,b]=m[R(m.length)];el[a].classList.add('hi');el[b].classList.add('hi');score=Math.max(0,score-5);stat();hintT=setTimeout(clearHint,2200)}
 bH.onclick=hint;bS.onclick=shuffle;bU.onclick=undo;
 const inp=input(st,[],k=>{if(over){if(k===' '||k==='Enter')init();return}const lk=k.toLowerCase();if(lk==='h')hint();else if(lk==='s')shuffle();else if(lk==='u'||lk==='z')undo();
  else if(k.startsWith('Arrow')){const f=freeList();if(!f.length)return;const hz=k==='ArrowLeft'||k==='ArrowRight';f.sort(hz?(a,b)=>P[a].x-P[b].x||P[a].y-P[b].y:(a,b)=>P[a].y-P[b].y||P[a].x-P[b].x);
   let j=f.indexOf(kb);j=j<0?0:(j+(k==='ArrowLeft'||k==='ArrowUp'?-1:1)+f.length)%f.length;kb=f[j];render()}
  else if((k===' '||k==='Enter')&&kb>=0&&alive[kb]){tap(kb);if(!alive[kb])kb=-1;render()}});
 const iv=setInterval(()=>{if(!over){secs=Math.floor((performance.now()-t0)/1000);stat()}},500);
 const onR=()=>layout();addEventListener('resize',onR);
 window._mj={P,gen,isFree,kind:()=>kind.slice(),alive:()=>alive.slice(),free:i=>isFree(i,has),moves,tap,el};
 init();cur.reset=init;
 return()=>{clearInterval(iv);clearTimeout(tm);tms.forEach(clearTimeout);clearHint();removeEventListener('resize',onR);inp.stop();delete window._mj}}},
