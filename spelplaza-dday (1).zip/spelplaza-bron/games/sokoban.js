{id:'sokoban',n:'Sokoban',e:'📦',c:'Puzzel',g:'#f7971e,#ffd200',nw:1,run(st){
 // 12 built-in levels (# wall, . target, $ box, * box on target, @ player). All verified solvable with a BFS solver.
 const LEVELS=[
 {n:'Eerste duw',m:`
######
#    #
# $. #
# @  #
######`},
 {n:'Twee kisten',m:`
#######
#  .  #
# $$  #
# .@  #
#     #
#######`},
 {n:'Hoekje',m:`
#######
#     #
# #$# #
# $ . #
# #.# #
#  @  #
#######`},
 {n:'De gang',m:`
########
#      #
# $ #. #
# $ @. #
#   #  #
########`},
 {n:'Rondje',m:`
########
#.     #
# $ ## #
#  @## #
# $  $ #
#.    .#
########`},
 {n:'Sleutelgat',m:`
########
#  @   #
# $$ $ #
#      #
# #.#  #
# . .  #
#      #
########`},
 {n:'Twee kamers',m:`
##########
#    #   #
# $$   . #
# $  # . #
#  @ # . #
#    #   #
##########`},
 {n:'Opslag',m:`
#########
#   #   #
# $ # $ #
# ..#.. #
# $   $ #
#   @   #
#########`},
 {n:'Draai',m:`
#########
#   #   #
# $ $ $ #
#  ...  #
#   *   #
#   #   #
#   @   #
#########`},
 {n:'Doolhof',m:`
###########
#    #    #
# $  # $  #
# ##.#.## #
#   $     #
#.# ### # #
#    @    #
###########`},
 {n:'Magazijn',m:`
##########
#   ##   #
# $    $ #
#  $##$  #
##  ..  ##
 #  ..  #
 #  @   #
 ########`},
 {n:'Grote finale',m:`
###########
#    #    #
# $$ #  . #
#    # .  #
##   $  ###
#.   # $  #
#  ##  @  #
#.        #
###########`},
 ];
 const NL=LEVELS.length,KEY='sp_soko';
 let save={lvl:0,done:{}};try{save=Object.assign(save,JSON.parse(localStorage.getItem(KEY)||'{}'))}catch(e){}
 const store=()=>{try{localStorage.setItem(KEY,JSON.stringify(save))}catch(e){}};
 // ---------- DOM ----------
 const sc=E('div','sc'),lr=E('div');lr.style.cssText='display:flex;gap:8px;justify-content:center;align-items:center;margin:2px 0 8px';
 const pb=E('button','btn','◀'),nb=E('button','btn','▶'),ll=E('span');ll.style.cssText='font-weight:700;min-width:150px';lr.append(pb,ll,nb);
 const c=mkCanvas(st,360,300),x=c.getContext('2d');st.append(sc,lr,c);
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight']],press);
 const br=E('div');br.style.cssText='display:flex;gap:8px;justify-content:center;margin-top:8px';
 const ub=E('button','btn','↩ Ongedaan'),rb=E('button','btn','🔁 Level opnieuw');br.append(ub,rb);
 st.append(br,E('div','hint','Duw alle kisten 📦 op de doelen · pijltjes / WASD / veeg / tik · Z = ongedaan · R = opnieuw'));
 // ---------- state ----------
 let lvl,Rn,Cn,wall,tg,inside,box,pr,pc,moves,pushes,hist,done,T,aoff,abox,ovEl=null,tm=0;
 function load(i){lvl=(i+NL)%NL;save.lvl=lvl;store();const rows=LEVELS[lvl].m.split('\n').filter(r=>r.length);Rn=rows.length;Cn=Math.max(...rows.map(r=>r.length));
  wall=[];tg=[];box=[];for(let r=0;r<Rn;r++){wall.push([]);tg.push([]);box.push([]);for(let cc=0;cc<Cn;cc++){const ch=rows[r][cc]||' ';wall[r][cc]=ch==='#';tg[r][cc]=ch==='.'||ch==='*'||ch==='+';box[r][cc]=ch==='$'||ch==='*';if(ch==='@'||ch==='+'){pr=r;pc=cc}}}
  inside=wall.map(r=>r.map(()=>false));const q=[[pr,pc]];inside[pr][pc]=true;while(q.length){const[r,cc]=q.pop();for(const[dr,dc]of[[1,0],[-1,0],[0,1],[0,-1]]){const nr=r+dr,nc=cc+dc;if(nr<0||nr>=Rn||nc<0||nc>=Cn||wall[nr][nc]||inside[nr][nc])continue;inside[nr][nc]=true;q.push([nr,nc])}}
  T=Math.min(44,Math.floor(360/Cn),Math.floor(380/Rn));c.width=Cn*T;c.height=Rn*T;c.style.width=c.width+'px';
  moves=0;pushes=0;hist=[];done=0;aoff=null;abox=null;if(ovEl){overlay(st,c,'');ovEl=null}draw()}
 const solved=()=>box.every((row,r)=>row.every((b,cc)=>!b||tg[r][cc]));
 function move(dr,dc){if(done)return;const nr=pr+dr,nc=pc+dc;if(wall[nr][nc])return;let pushed=null;
  if(box[nr][nc]){const br2=nr+dr,bc2=nc+dc;if(wall[br2][bc2]||box[br2][bc2]){beep(150,.05,'square',.02);return}box[nr][nc]=false;box[br2][bc2]=true;pushed=[br2,bc2];pushes++;beep(300,.05,'triangle',.03)}
  hist.push({pr,pc,pushed});pr=nr;pc=nc;moves++;aoff={dr:-dr,dc:-dc,t:1};abox=pushed;
  if(pushed&&solved()){done=1;const b=save.done[lvl];if(!b||moves<b)save.done[lvl]=moves;store();beep(660,.12,'triangle',.05);tm=setTimeout(()=>beep(990,.25,'triangle',.05),140);
   const last=lvl===NL-1;ovEl=overlay(st,c,`🎉 Level ${lvl+1} opgelost!<br><span style="font-size:15px;font-weight:600">Zetten ${moves} · Duwen ${pushes} · Beste ${save.done[lvl]}<br>${last?'Dat was het laatste level - alles opgelost! 🏆<br>Tik om opnieuw te beginnen':'Tik voor het volgende level'}</span>`);
   ovEl.onpointerdown=e=>{e.preventDefault();load(lvl+1)}}
  draw()}
 function undo(){if(done||!hist.length)return;const h=hist.pop();if(h.pushed){const[r,cc]=h.pushed;box[r][cc]=false;box[pr][pc]=true;pushes--}pr=h.pr;pc=h.pc;moves--;aoff=null;abox=null;beep(240,.04,'sine',.02);draw()}
 function press(k){if(done){if(k===' '||k==='Enter')load(lvl+1);return}const d={ArrowUp:[-1,0],ArrowDown:[1,0],ArrowLeft:[0,-1],ArrowRight:[0,1],w:[-1,0],s:[1,0],a:[0,-1],d:[0,1]}[k.length===1?k.toLowerCase():k];
  if(d)move(d[0],d[1]);else if(k==='z'||k==='Z'||k==='Backspace')undo();else if(k==='r'||k==='R')load(lvl);else if(k==='n'||k==='N')load(lvl+1);else if(k==='p'||k==='P')load(lvl-1)}
 pb.onclick=()=>load(lvl-1);nb.onclick=()=>load(lvl+1);ub.onclick=undo;rb.onclick=()=>load(lvl);
 let pd=null;c.onpointerdown=e=>{e.preventDefault();pd={x:e.clientX,y:e.clientY};try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointerup=e=>{if(!pd)return;const dx=e.clientX-pd.x,dy=e.clientY-pd.y;pd=null;if(done)return;
  if(Math.max(Math.abs(dx),Math.abs(dy))>=24){if(Math.abs(dx)>Math.abs(dy))move(0,Math.sign(dx));else move(Math.sign(dy),0);return}
  const b=c.getBoundingClientRect(),cc=Math.floor((e.clientX-b.left)*c.width/b.width/T),r=Math.floor((e.clientY-b.top)*c.height/b.height/T),ddr=r-pr,ddc=cc-pc;if(!ddr&&!ddc)return;
  if(Math.abs(ddc)>Math.abs(ddr))move(0,Math.sign(ddc));else move(Math.sign(ddr),0)};
 c.onpointercancel=()=>{pd=null};
 // ---------- drawing ----------
 function tile(r,cc,kind){const X=cc*T,Y=r*T;
  if(kind==='wall'){x.fillStyle='#3e3454';x.fillRect(X,Y,T,T);x.fillStyle='#6a5a8c';const h=T/2;x.fillRect(X+1,Y+1,T/2-2,h-2);x.fillRect(X+T/2+1,Y+1,T/2-2,h-2);x.fillRect(X+1,Y+h+1,T/4-2,h-2);x.fillRect(X+T/4+1,Y+h+1,T/2-2,h-2);x.fillRect(X+3*T/4+1,Y+h+1,T/4-2,h-2);x.fillStyle='rgba(255,255,255,.07)';x.fillRect(X,Y,T,2)}
  else{x.fillStyle=(r+cc)%2?'#1b1e36':'#191c32';x.fillRect(X,Y,T,T);if(tg[r][cc]){x.strokeStyle='rgba(255,184,74,.9)';x.lineWidth=2;x.beginPath();x.arc(X+T/2,Y+T/2,T*.22,0,7);x.stroke();x.fillStyle='rgba(255,184,74,.25)';x.fill()}}}
 function crate(px,py,on){const p=T*.1,s=T-2*p;const g=x.createLinearGradient(px,py,px,py+T);g.addColorStop(0,on?'#8fdc6a':'#d9a056');g.addColorStop(1,on?'#3f8a2c':'#8a5a22');x.fillStyle=g;x.fillRect(px+p,py+p,s,s);
  x.strokeStyle=on?'#2c5e1e':'#5a3a12';x.lineWidth=Math.max(2,T*.07);x.strokeRect(px+p,py+p,s,s);x.beginPath();x.moveTo(px+p,py+p);x.lineTo(px+p+s,py+p+s);x.moveTo(px+p+s,py+p);x.lineTo(px+p,py+p+s);x.stroke();
  x.fillStyle='rgba(255,255,255,.18)';x.fillRect(px+p+2,py+p+2,s-4,T*.12)}
 function guy(px,py){const cx=px+T/2,cy=py+T/2,r=T*.3;x.fillStyle='#ff6f91';x.beginPath();x.arc(cx,cy+T*.12,r*.95,0,7);x.fill();x.fillStyle='#ffd9b3';x.beginPath();x.arc(cx,cy-T*.08,r*.8,0,7);x.fill();
  x.fillStyle='#2a4a8a';x.beginPath();x.arc(cx,cy-T*.1,r*.8,Math.PI,2*Math.PI);x.fill();x.fillStyle='#222';x.beginPath();x.arc(cx-r*.3,cy-T*.04,T*.045,0,7);x.arc(cx+r*.3,cy-T*.04,T*.045,0,7);x.fill()}
 function draw(){x.fillStyle='#0e1020';x.fillRect(0,0,c.width,c.height);const t=aoff?aoff.t:0;
  for(let r=0;r<Rn;r++)for(let cc=0;cc<Cn;cc++){if(wall[r][cc])tile(r,cc,'wall');else if(inside[r][cc])tile(r,cc,'floor')}
  for(let r=0;r<Rn;r++)for(let cc=0;cc<Cn;cc++)if(box[r][cc]){const mv=abox&&abox[0]===r&&abox[1]===cc;crate((cc+(mv?aoff.dc*t:0))*T,(r+(mv?aoff.dr*t:0))*T,tg[r][cc])}
  guy((pc+(aoff?aoff.dc*t:0))*T,(pr+(aoff?aoff.dr*t:0))*T);
  const b=save.done[lvl];sc.textContent='Zetten: '+moves+' · Duwen: '+pushes+(b?' · Beste: '+b:'')+(done?' · 🎉 Opgelost!':'');
  const nd=Object.keys(save.done).length;ll.textContent='Level '+(lvl+1)+'/'+NL+' · '+LEVELS[lvl].n+(save.done[lvl]?' ✓':'');nb.title=pb.title=nd+' opgelost'}
 const stopLoop=loop(dt=>{if(aoff&&aoff.t>0){aoff.t=Math.max(0,aoff.t-dt/.09);draw();if(!aoff.t){aoff=null;abox=null}}});
 window._soko={level:load,move:k=>press(k),state:()=>({lvl,moves,pushes,done,pr,pc}),boxes:()=>box.map(r=>r.map(Number).join('')).join('/'),levels:NL};
 load(save.lvl||0);cur.reset=()=>load(lvl);return()=>{stopLoop();clearTimeout(tm);inp.stop();c.onpointerdown=c.onpointerup=c.onpointercancel=null;delete window._soko}}},
