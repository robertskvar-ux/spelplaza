{id:'2048',n:'2048',e:'🔢',c:'Puzzel',g:'#f093fb,#f5576c',run(st){
 const W=360,P=10,T=(W-P*5)/4,c=mkCanvas(st,W,W),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 const bar=E('div');bar.style.cssText='display:flex;gap:8px;justify-content:center;margin:10px 0 4px';
 const ub=E('button','btn','↶ Zet terug (1×)');ub.style.cssText='padding:7px 14px;font-size:13px';bar.append(ub);st.append(bar);
 st.append(E('div','hint','Pijltjes / WASD / vegen · gelijke tegels smelten samen · haal 2048!'));
 const D='#3c3a32',DD='#1e1b16',COL={2:['#eee4da',D],4:['#ede0c8',D],8:['#f2b179',D],16:['#f59563',D],32:['#f67c5f',DD],64:['#f65e3b',DD],128:['#edcf72',D],256:['#edcc61',D],512:['#edc850',D],1024:['#edc53f',D],2048:['#edc22e',D]};// cijfers donker: contrast ≥ 4.5:1 op elke tegel
 let g,score,undo,undoLeft,anim,at,pops,over,won,keep,overT,maxT,addSc;
 const px=i=>P+i*(T+P);
 function empty(){const e=[];for(let r=0;r<4;r++)for(let k=0;k<4;k++)if(!g[r][k])e.push([r,k]);return e}
 function add(){const e=empty();if(!e.length)return;const[r,k]=e[R(e.length)];g[r][k]=Math.random()<.9?2:4;pops.push({r,k,t:0,n:1})}
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function init(){g=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]];score=0;undo=null;undoLeft=1;anim=null;pops=[];over=0;won=0;keep=0;overT=0;maxT=0;addSc=[];add();add();ov('');upd()}
 function canMove(){if(empty().length)return 1;for(let r=0;r<4;r++)for(let k=0;k<4;k++){if(k<3&&g[r][k]===g[r][k+1])return 1;if(r<3&&g[r][k]===g[r+1][k])return 1}return 0}
 function upd(){maxT=Math.max(maxT,...g.flat());sc.textContent='Score: '+score+' · Beste: '+best('2048',score)+' · Beste tegel: '+best('2048_tegel',maxT);
  ub.disabled=!undo||!undoLeft||over;ub.style.opacity=ub.disabled?.45:1;ub.textContent=undoLeft?'↶ Zet terug (1×)':'↶ Al gebruikt'}
 function move(dir){if(anim)finish();if(over||(won&&!keep))return;
  const D={ArrowLeft:[0,-1],a:[0,-1],ArrowRight:[0,1],d:[0,1],ArrowUp:[-1,0],w:[-1,0],ArrowDown:[1,0],s:[1,0]}[dir];if(!D)return;
  const old=g.map(r=>[...r]),ng=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]],mv=[],mg=[];let gain=0,moved=0;
  for(let l=0;l<4;l++){const cells=[];for(let i=0;i<4;i++){const j=D[0]+D[1]>0?3-i:i;cells.push(D[0]?[j,l]:[l,j])}
   let k=0,lastM=-1;for(const[r,cc]of cells){const v=old[r][cc];if(!v)continue;
    if(k>0&&ng[cells[k-1][0]][cells[k-1][1]]===v&&lastM!==k-1){const[tr,tc]=cells[k-1];ng[tr][tc]=v*2;gain+=v*2;lastM=k-1;mv.push({v,fr:r,fc:cc,tr,tc});mg.push([tr,tc]);moved=1}
    else{const[tr,tc]=cells[k];ng[tr][tc]=v;mv.push({v,fr:r,fc:cc,tr,tc});if(tr!==r||tc!==cc)moved=1;k++}}}
  if(!moved){beep(120,.04,'triangle',.015);return}
  undo={g:old,score};g=ng;score+=gain;anim={mv,mg,t:0};
  if(gain){addSc.push({v:gain,t:0});const top=Math.max(...mg.map(([r,k])=>g[r][k]));beep(260+Math.log2(top)*45,.09,'triangle',.045)}else beep(200,.03,'sine',.02)}
 function finish(){if(!anim)return;anim.mg.forEach(([r,k])=>pops.push({r,k,t:0,n:0}));anim=null;add();upd();
  if(!won&&g.flat().includes(2048)){won=1;beep(784,.3,'triangle',.05);ov('🏆 2048 gehaald!<br><span style="font-size:15px;font-weight:600">Score '+score+'<br>Tik of druk op een toets om door te spelen</span>')}
  else if(!canMove()){over=1;overT=0;best('2048',score);beep(140,.4,'sawtooth',.04);upd();ov('😵 Geen zetten meer<br><span style="font-size:15px;font-weight:600">Score '+score+' · Beste '+best('2048',score)+'<br>Tik of druk op een toets om opnieuw te spelen</span>')}}
 ub.onclick=()=>{if(!undo||!undoLeft||over||anim)return;g=undo.g;score=undo.score;undo=null;undoLeft=0;pops=[];beep(500,.06,'sine',.03);upd()};
 function anyKey(k){if(over){if(overT>.4)init();return 1}if(won&&!keep){keep=1;ov('');return 1}return 0}
 const inp=input(st,[],k=>{if(anyKey(k))return;move(k)});
 let sx,sy;c.onpointerdown=e=>{e.preventDefault();if(anyKey(''))return;sx=e.clientX;sy=e.clientY};
 c.onpointerup=e=>{if(sx==null)return;const dx=e.clientX-sx,dy=e.clientY-sy;sx=null;if(Math.max(Math.abs(dx),Math.abs(dy))<24)return;move(Math.abs(dx)>Math.abs(dy)?(dx>0?'ArrowRight':'ArrowLeft'):(dy>0?'ArrowDown':'ArrowUp'))};
 function rr(X,Y,w,h,r){x.beginPath();x.roundRect?x.roundRect(X,Y,w,h,r):x.rect(X,Y,w,h);x.fill()}
 function tile(v,X,Y,s){const[bg,fg]=COL[v]||['#3c3a32','#fff'],w=T*s,o=(T-w)/2;x.fillStyle=bg;
  if(v>=128){x.shadowColor=bg;x.shadowBlur=12}rr(X+o,Y+o,w,w,8);x.shadowBlur=0;
  x.fillStyle=fg;const d=String(v).length;x.font=`800 ${(d<3?36:d<4?30:d<5?24:19)*s}px system-ui,sans-serif`;x.textAlign='center';x.textBaseline='middle';x.fillText(v,X+T/2,Y+T/2+2)}
 const stopLoop=loop(dt=>{if(over)overT+=dt;
  if(anim){anim.t+=dt/.11;if(anim.t>=1)finish()}
  for(const p of pops)p.t+=dt/.16;pops=pops.filter(p=>p.t<1);for(const a of addSc)a.t+=dt;addSc=addSc.filter(a=>a.t<.8);
  x.fillStyle='#0e1020';x.fillRect(0,0,W,W);x.fillStyle='#1d2142';rr(0,0,W,W,12);
  x.fillStyle='#2a2f58';for(let r=0;r<4;r++)for(let k=0;k<4;k++)rr(px(k),px(r),T,T,8);
  if(anim){const e=1-Math.pow(1-Math.min(1,anim.t),3);for(const m of anim.mv)tile(m.v,px(m.fc+(m.tc-m.fc)*e),px(m.fr+(m.tr-m.fr)*e),1)}
  else for(let r=0;r<4;r++)for(let k=0;k<4;k++){const v=g[r][k];if(!v)continue;const p=pops.find(p=>p.r===r&&p.k===k);
   let s=1;if(p)s=p.n?Math.min(1,.2+p.t*.8):1+Math.sin(p.t*Math.PI)*.14;tile(v,px(k),px(r),s)}
  for(const a of addSc){x.globalAlpha=1-a.t/.8;x.fillStyle='#ffd86b';x.font='800 20px system-ui,sans-serif';x.textAlign='center';x.fillText('+'+a.v,W/2,W/2-a.t*60);x.globalAlpha=1}
 });
 st.t={get g(){return g},get score(){return score},move};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointerup=null}}},
