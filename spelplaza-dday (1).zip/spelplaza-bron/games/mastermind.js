{id:'mastermind',n:'Kleurcode',e:'🎯',c:'Puzzel',g:'#c33764,#1d2671',nw:1,run(st){
 // Mastermind: 4 colours out of 6, 10 attempts. Black peg = right colour & place, white peg = right colour, wrong place.
 const COL=['#e63946','#1d6fe0','#2bb673','#ffd166','#9b5de5','#ff8c42'],SYM=['▲','■','●','★','◆','✚'],NAMES=['rood','blauw','groen','geel','paars','oranje'],ROWS=10,NS=4;
 const bestLow=(id,s)=>{let b=best(id,-s);if(b>=0){try{localStorage.setItem('sp_'+id,-s)}catch(e){}b=-s}return-b};
 const sc=E('div','sc'),top=E('div');top.style.cssText='display:flex;gap:8px;justify-content:center;margin:2px 0 6px';
 const repb=E('button','btn');repb.style.cssText='font-size:13px;padding:6px 10px';top.append(repb);
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(300px,100%);margin:4px auto';
 const bd=E('div');bd.style.cssText='background:linear-gradient(160deg,#5a4a3a,#3b2f24);border-radius:14px;padding:8px 10px;box-shadow:0 6px 16px rgba(0,0,0,.35)';
 const pal=E('div');pal.style.cssText='display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin:10px auto 0;width:min(340px,100%)';
 const hint=E('div','hint','Tik op kleuren om de rij te vullen (tik op een vakje om het te wijzigen) · ✔ controleert · toetsen 1–6, Backspace, Enter · ⚫ = goede kleur op de juiste plek · ⚪ = goede kleur, verkeerde plek');
 wrap.append(bd);st.append(sc,top,wrap,pal,hint);
 const peg=(sz)=>{const d=E('div');d.style.cssText=`width:${sz}px;height:${sz}px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:${sz*.5}px;font-weight:800;line-height:1;background:rgba(0,0,0,.35);box-shadow:inset 0 2px 4px rgba(0,0,0,.6);color:#fff;user-select:none;-webkit-user-select:none`;return d};
 const paint=(d,c,sel)=>{if(c==null){d.style.background='rgba(0,0,0,.35)';d.style.boxShadow='inset 0 2px 4px rgba(0,0,0,.6)';d.textContent='';d.style.color='#fff'}
  else{d.style.background=`radial-gradient(circle at 35% 30%,#fff8,${COL[c]} 45%,${COL[c]})`;d.style.boxShadow='0 2px 4px rgba(0,0,0,.5),inset 0 -2px 4px rgba(0,0,0,.25)';d.textContent=SYM[c];d.style.color=c===3?'#4a3a00':'#fff';d.style.textShadow=c===3?'none':'0 1px 2px rgba(0,0,0,.6)'}
  d.style.outline=sel?'3px solid #fff':'none';d.style.outlineOffset='1px'};
 // secret row
 const secRow=E('div');secRow.style.cssText='display:grid;grid-template-columns:repeat(4,30px) 44px;gap:8px;justify-content:center;align-items:center;padding:2px 0 6px;border-bottom:2px solid rgba(255,255,255,.15);margin-bottom:6px';
 const secP=[];for(let i=0;i<NS;i++){const d=peg(28);d.textContent='?';d.style.fontSize='16px';secP.push(d);secRow.append(d)}const lk=E('span','','🔒');lk.style.cssText='font-size:18px';secRow.append(lk);bd.append(secRow);
 // guess rows
 const rows=[];for(let r=0;r<ROWS;r++){const row=E('div');row.style.cssText='display:grid;grid-template-columns:repeat(4,30px) 44px;gap:8px;justify-content:center;align-items:center;padding:2px 4px;border-radius:8px;margin:1px 0';
  const pegs=[];for(let i=0;i<NS;i++){const d=peg(28);d.onpointerdown=e=>{e.preventDefault();tapSlot(r,i)};pegs.push(d);row.append(d)}
  const fb=E('div');fb.style.cssText='display:grid;grid-template-columns:1fr 1fr;gap:3px;width:26px;margin:0 auto';const fp=[];for(let i=0;i<NS;i++){const p=E('i');p.style.cssText='display:block;width:10px;height:10px;border-radius:50%;background:rgba(0,0,0,.3);box-shadow:inset 0 1px 2px rgba(0,0,0,.5)';fp.push(p);fb.append(p)}
  row.append(fb);rows.push({row,pegs,fp});bd.append(row)}
 // palette
 const palb=COL.map((c,i)=>{const d=peg(40);paint(d,i);d.style.cursor='pointer';d.title=NAMES[i];d.onpointerdown=e=>{e.preventDefault();pick(i)};pal.append(d);return d});
 const delb=E('button','btn','⌫');delb.style.cssText='min-width:48px;font-size:18px;padding:6px 10px';delb.onpointerdown=e=>{e.preventDefault();del()};
 const okb=E('button','btn','✔ Controleer');okb.style.cssText='font-size:15px;padding:8px 14px';okb.onpointerdown=e=>{e.preventDefault();check()};const pal2=E('div');pal2.style.cssText='display:flex;gap:8px;justify-content:center;margin-top:8px';pal2.append(delb,okb);pal.after(pal2);
 // ---------- state ----------
 let secret,guess,at,sel,over,rep=1,ov=null;
 try{rep=localStorage.getItem('sp_mm_rep')==='0'?0:1}catch(e){}
 function newSecret(){secret=[];while(secret.length<NS){const c=R(6);if(!rep&&secret.includes(c))continue;secret.push(c)}}
 function init(){newSecret();guess=[];for(let r=0;r<ROWS;r++)guess.push([null,null,null,null]);at=0;sel=0;over=0;if(ov){ov.remove();ov=null}draw()}
 function score(g){let b=0,w=0;const cs=Array(6).fill(0),cg=Array(6).fill(0);for(let i=0;i<NS;i++){if(g[i]===secret[i])b++;else{cs[secret[i]]++;cg[g[i]]++}}for(let c=0;c<6;c++)w+=Math.min(cs[c],cg[c]);return{b,w}}
 function tapSlot(r,i){if(over||r!==at)return;sel=i;draw()}
 function pick(c){if(over)return;const g=guess[at];let i=sel;if(i==null||i>=NS||g[i]!=null){i=g.indexOf(null);if(i<0)i=sel!=null&&sel<NS?sel:NS-1}g[i]=c;beep(440+c*60,.05,'sine',.03);
  const nx=g.indexOf(null);sel=nx<0?null:nx;draw()}
 function del(){if(over)return;const g=guess[at];let i=NS-1;while(i>=0&&g[i]==null)i--;if(i<0)return;g[i]=null;sel=i;beep(220,.04,'sine',.02);draw()}
 function check(){if(over)return;const g=guess[at];if(g.includes(null)){beep(160,.08,'square',.03);rows[at].row.animate([{transform:'translateX(0)'},{transform:'translateX(-6px)'},{transform:'translateX(6px)'},{transform:'translateX(0)'}],{duration:220});return}
  const s=score(g);rows[at].s=s;
  if(s.b===NS){over=1;const n=at+1,b=bestLow('mastermind',n);beep(660,.12,'triangle',.05);setTimeout(()=>beep(990,.25,'triangle',.05),140);
   showOv(`🎉 Gekraakt!<br><span style="font-size:15px;font-weight:600">in ${n} ${n===1?'poging':'pogingen'} · beste ${b}<br>Tik voor een nieuwe code</span>`)}
  else{at++;sel=0;beep(s.b?520:300,.06,'triangle',.03);if(at>=ROWS){over=2;beep(150,.4,'sawtooth',.05);showOv(`❌ Helaas!<br><span style="font-size:15px;font-weight:600">De code was ${secret.map(c=>SYM[c]+' '+NAMES[c]).join(', ')}<br>Tik om opnieuw te spelen</span>`)}}
  draw()}
 let tm=0;function showOv(h){ov=E('div','ov',h);ov.style.background='rgba(14,16,32,.82)';ov.onpointerdown=e=>{e.preventDefault();init()};tm=setTimeout(()=>wrap.append(ov),600)}
 function draw(){for(let i=0;i<NS;i++){if(over){paint(secP[i],secret[i])}else{paint(secP[i],null);secP[i].textContent='?'}}
  for(let r=0;r<ROWS;r++){const{row,pegs,fp,s}=rows[r];const act=r===at&&!over;row.style.background=act?'rgba(255,255,255,.12)':'';row.style.outline=act?'2px solid rgba(255,255,255,.35)':'none';row.style.opacity=r>at?'.55':'1';
   for(let i=0;i<NS;i++)paint(pegs[i],guess[r][i],act&&sel===i);
   const fbv=r<at||(over&&r===at)?s:null;for(let i=0;i<NS;i++){const p=fp[i];if(!fbv){p.style.background='rgba(0,0,0,.3)';p.style.boxShadow='inset 0 1px 2px rgba(0,0,0,.5)';continue}
    if(i<fbv.b){p.style.background='#111';p.style.boxShadow='0 0 0 1.5px #fff,0 1px 2px rgba(0,0,0,.6)'}else if(i<fbv.b+fbv.w){p.style.background='#fff';p.style.boxShadow='0 1px 2px rgba(0,0,0,.6)'}else{p.style.background='rgba(0,0,0,.3)';p.style.boxShadow='inset 0 1px 2px rgba(0,0,0,.5)'}}}
  repb.textContent='🔁 Herhalingen: '+(rep?'aan':'uit');okb.style.opacity=over||guess[at]?.includes(null)?'.5':'1';
  const b=best('mastermind',-999);sc.textContent=(over===1?'🎉 Gekraakt in '+(at+1):over===2?'❌ Verloren':'Poging '+(at+1)+' van '+ROWS)+(b<0?' · Beste: '+(-b):'')}
 repb.onclick=()=>{rep=rep?0:1;try{localStorage.setItem('sp_mm_rep',rep)}catch(e){}init()};
 const inp=input(st,[],k=>{if(over){if(k==='Enter'||k===' ')init();return}if(k>='1'&&k<='6')pick(+k-1);else if(k==='Backspace'||k==='Delete')del();else if(k==='Enter'||k===' ')check();
  else if(k==='ArrowLeft'||k==='ArrowRight'){sel=((sel==null?0:sel)+(k==='ArrowLeft'?NS-1:1))%NS;draw()}});
 window._mm={secret:()=>secret.slice(),guess:(g)=>{guess[at]=g.slice();draw()},check,pick,del,state:()=>({at,over,rep,sel,row:guess[Math.min(at,ROWS-1)].slice()}),score};
 init();cur.reset=init;return()=>{clearTimeout(tm);inp.stop();delete window._mm}}},
