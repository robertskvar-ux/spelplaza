{id:'dots',n:'Kamertje Verhuren',e:'✏️',c:'Bord',g:'#7f00ff,#e100ff',nw:1,run(st){
 // Kamertje verhuren (dots & boxes) tegen de computer. Tik tussen twee stippen om een lijn te trekken; een hokje dicht = nog een beurt.
 const NS='http://www.w3.org/2000/svg',SV=(t,a)=>{const e=document.createElementNS(NS,t);for(const k in a)e.setAttribute(k,a[k]);return e};
 const PC='#8f3dff',CC='#ff9100',PT='rgba(143,61,255,.22)',CT='rgba(255,145,0,.22)';
 const sc=E('div','sc');
 const sizes=E('div');sizes.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 8px';
 const sbtn=[4,5,6].map(k=>{const b=E('button','btn',k+'×'+k);b.style.cssText='padding:6px 12px;font-size:13px';b.onclick=()=>{n=k;build();init()};sizes.append(b);return b});
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(380px,100%);margin:0 auto';
 const svg=SV('svg',{});svg.style.cssText='width:100%;height:auto;display:block;background:var(--bg);border-radius:14px;touch-action:manipulation;user-select:none;-webkit-user-select:none';
 const ov=E('div','ov');ov.style.display='none';ov.onpointerdown=e=>{e.preventDefault();init()};wrap.append(svg,ov);
 const hint=E('div','hint','Tik tussen twee stippen om een lijn te trekken · wie een hokje sluit, krijgt het en mag nog eens · de meeste hokjes winnen');
 st.append(sc,sizes,wrap,hint);
 // ---------- bord ----------
 let n=5,NE,NB,H,lines=[],hits=[],boxes=[],letters=[],halo,E_,B_,turn,over,busy,lastE=-1,tm=0;
 const hIdx=(r,c)=>r*(n-1)+c,vIdx=(r,c)=>H+r*n+c,bIdx=(r,c)=>r*(n-1)+c;
 const boxEdges=b=>{const r=(b/(n-1))|0,c=b%(n-1);return[hIdx(r,c),hIdx(r+1,c),vIdx(r,c),vIdx(r,c+1)]};
 function edgeBoxes(e){const out=[];if(e<H){const r=(e/(n-1))|0,c=e%(n-1);if(r>0)out.push(bIdx(r-1,c));if(r<n-1)out.push(bIdx(r,c))}else{const k=e-H,r=(k/n)|0,c=k%n;if(c>0)out.push(bIdx(r,c-1));if(c<n-1)out.push(bIdx(r,c))}return out}
 const sides=(E,b)=>boxEdges(b).reduce((s,e)=>s+(E[e]?1:0),0);
 function build(){H=n*(n-1);NE=2*H;NB=(n-1)*(n-1);const W=(n-1)*100+100;svg.setAttribute('viewBox','0 0 '+W+' '+W);svg.innerHTML='';lines=[];hits=[];boxes=[];letters=[];
  const P=(r,c)=>[50+c*100,50+r*100];
  for(let b=0;b<NB;b++){const r=(b/(n-1))|0,c=b%(n-1),[x,y]=P(r,c);const rc=SV('rect',{x:x+7,y:y+7,width:86,height:86,rx:10,fill:'transparent'});const t=SV('text',{x:x+50,y:y+66,'text-anchor':'middle','font-size':'46','font-weight':'800','font-family':'system-ui,Arial,sans-serif'});svg.append(rc,t);boxes.push(rc);letters.push(t)}
  halo=SV('line',{stroke:'rgba(255,213,74,.55)','stroke-width':'24','stroke-linecap':'round',visibility:'hidden'});svg.append(halo);
  for(let e=0;e<NE;e++){let x1,y1,x2,y2;if(e<H){const r=(e/(n-1))|0,c=e%(n-1);[x1,y1]=P(r,c);[x2,y2]=P(r,c+1)}else{const k=e-H,r=(k/n)|0,c=k%n;[x1,y1]=P(r,c);[x2,y2]=P(r+1,c)}
   const l=SV('line',{x1,y1,x2,y2,'stroke-width':'10','stroke-linecap':'round','pointer-events':'none'});lines.push(l);svg.append(l)}
  for(let e=0;e<NE;e++){const l=lines[e],x1=+l.getAttribute('x1'),y1=+l.getAttribute('y1'),hz=e<H;
   const h=SV('rect',hz?{x:x1+10,y:y1-24,width:80,height:48}:{x:x1-24,y:y1+10,width:48,height:80});h.setAttribute('fill','transparent');h.style.cursor='pointer';
   h.onpointerenter=()=>{if(!E_[e]&&turn===1&&!over&&!busy){l.setAttribute('stroke',PC);l.setAttribute('stroke-opacity','.45')}};h.onpointerleave=()=>{if(!E_[e])paintEdge(e)};
   h.onpointerdown=ev=>{ev.preventDefault();human(e)};hits.push(h);svg.append(h)}
  for(let r=0;r<n;r++)for(let c=0;c<n;c++){const[x,y]=P(r,c);svg.append(SV('circle',{cx:x,cy:y,r:9,fill:'var(--tx)','pointer-events':'none'}))}
  sbtn.forEach((b,i)=>b.style.opacity=[4,5,6][i]===n?'1':'.5')}
 function paintEdge(e){const l=lines[e],o=E_[e];l.setAttribute('stroke',o===1?PC:o===2?CC:'var(--mu)');l.setAttribute('stroke-opacity',o?'1':'.22');l.setAttribute('stroke-width',o?(e===lastE?'13':'10'):'8');l.setAttribute('stroke-dasharray',o?'':'1 16')}
 function draw(){for(let e=0;e<NE;e++)paintEdge(e);
  for(let b=0;b<NB;b++){const o=B_[b];boxes[b].setAttribute('fill',o===1?PT:o===2?CT:'transparent');letters[b].textContent=o===1?'J':o===2?'C':'';letters[b].setAttribute('fill',o===1?PC:CC)}
  if(lastE>=0){const l=lines[lastE];['x1','y1','x2','y2'].forEach(k=>halo.setAttribute(k,l.getAttribute(k)));halo.setAttribute('visibility','visible')}else halo.setAttribute('visibility','hidden');
  const pj=B_.filter(v=>v===1).length,pc=B_.filter(v=>v===2).length;
  sc.innerHTML='<span style="color:'+PC+'">✏️ Jij '+pj+'</span> – <span style="color:'+CC+'">'+pc+' Computer 🤖</span> · '+(over?over:busy?'Computer denkt…':turn===1?'Jij bent aan zet':'')}
 // ---------- regels ----------
 function play(e,p){if(E_[e])return 0;E_[e]=p;lastE=e;let got=0;for(const b of edgeBoxes(e))if(!B_[b]&&sides(E_,b)===4){B_[b]=p;got++}
  if(got)beep(p===1?760:520,.1,'triangle',.05);else beep(p===1?440:360,.04,'square',.03);
  if(B_.every(Boolean)){const pj=B_.filter(v=>v===1).length,pc=NB-pj;over=pj>pc?'🎉 Jij wint '+pj+'–'+pc+'!':pc>pj?'De computer wint '+pc+'–'+pj+' 🤖':'Gelijkspel '+pj+'–'+pc;busy=0;
   ov.innerHTML=over+'<br><span style="font-size:15px;font-weight:600">Tik om opnieuw te spelen</span>';ov.style.display='flex';beep(pj>pc?880:pj<pc?160:330,.4,pj>pc?'triangle':'sawtooth',.05)}
  return got}
 // ---------- computer ----------
 function chainAfter(E,e){const T=E.slice();T[e]=2;let cnt=0,found=1;while(found){found=0;for(let b=0;b<NB;b++)if(sides(T,b)===3){for(const x of boxEdges(b))T[x]=T[x]||2;cnt++;found=1}}return cnt}
 function aiPick(){const free=[];for(let e=0;e<NE;e++)if(!E_[e])free.push(e);
  const take=free.filter(e=>edgeBoxes(e).some(b=>sides(E_,b)===3));if(take.length)return take.sort((a,b)=>edgeBoxes(b).filter(x=>sides(E_,x)===3).length-edgeBoxes(a).filter(x=>sides(E_,x)===3).length)[0];
  const safe=free.filter(e=>edgeBoxes(e).every(b=>sides(E_,b)!==2));if(safe.length)return safe[R(safe.length)];
  let bestE=free[0],bestN=1e9;for(const e of free.sort(()=>Math.random()-.5)){const k=chainAfter(E_,e);if(k<bestN){bestN=k;bestE=e}}return bestE}
 function human(e){if(over||busy||turn!==1||E_[e])return;const got=play(e,1);if(over){draw();return}if(!got){turn=2;busy=1;tm=setTimeout(aiMove,300)}draw()}
 function aiMove(){tm=0;const e=aiPick();const got=play(e,2);if(over){draw();return}if(got){draw();tm=setTimeout(aiMove,300);return}turn=1;busy=0;draw()}
 function init(){clearTimeout(tm);tm=0;E_=new Uint8Array(NE);B_=new Uint8Array(NB);turn=1;over='';busy=0;lastE=-1;ov.style.display='none';draw()}
 window._dots={state:()=>({n,turn,over,busy,E:[...E_],B:[...B_],lastE}),play:e=>human(e),set(E,B){clearTimeout(tm);E_=Uint8Array.from(E);B_=Uint8Array.from(B);turn=1;over='';busy=0;draw()},ai(){clearTimeout(tm);const e=aiPick();play(e,2);draw();return e},edgeBoxes,boxEdges,sides:b=>sides(E_,b)};
 build();init();cur.reset=init;return()=>{clearTimeout(tm);tm=0;delete window._dots}}},
