{id:'yahtzee',n:'Yahtzee',e:'🎲',c:'Bord',g:'#f12711,#f5af19',nw:1,run(st){
 // Yahtzee voor één speler: 13 beurten, max 3 worpen per beurt, tik op een dobbelsteen om hem vast te houden.
 const PIPS=[[],[4],[2,6],[2,4,6],[0,2,6,8],[0,2,4,6,8],[0,2,3,5,6,8]];
 const CATS=[['Enen',1],['Tweeën',2],['Drieën',3],['Vieren',4],['Vijven',5],['Zessen',6],['3 gelijk','3k'],['4 gelijk','4k'],['Full house','fh'],['Kleine straat','ss'],['Grote straat','ls'],['Yahtzee','y'],['Kans','ch']];
 const sc=E('div','sc');
 const diceRow=E('div');diceRow.style.cssText='display:flex;gap:10px;justify-content:center;margin:8px 0 10px';
 const dice=[],faces=[];for(let i=0;i<5;i++){const d=E('div');d.style.cssText='width:58px;height:58px;border-radius:12px;background:#fff;border:2px solid #ddd;box-shadow:0 3px 8px rgba(0,0,0,.3);display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(3,1fr);padding:8px;gap:2px;cursor:pointer;transition:transform .2s,box-shadow .2s;position:relative;user-select:none;-webkit-user-select:none;touch-action:manipulation';
  const pips=[];for(let k=0;k<9;k++){const p=E('span');p.style.cssText='border-radius:50%;background:#1b1d2a;visibility:hidden';d.append(p);pips.push(p)}
  const tag=E('span','','vast');tag.style.cssText='position:absolute;left:0;right:0;bottom:-20px;font-size:11px;font-weight:800;color:#f5af19;display:none';d.append(tag);d._tag=tag;
  d.onpointerdown=e=>{e.preventDefault();hold(i)};diceRow.append(d);dice.push(d);faces.push(pips)}
 const bRoll=E('button','btn','🎲 Gooi');bRoll.style.cssText='font-size:17px;padding:11px 22px;margin:14px 0 10px;background:linear-gradient(135deg,#f12711,#f5af19)';bRoll.onclick=()=>roll();
 const sheet=E('div');sheet.style.cssText='display:grid;grid-template-columns:1fr 1fr;gap:8px;width:min(560px,100%);margin:0 auto;text-align:left';
 const colU=E('div'),colL=E('div');[colU,colL].forEach(c=>c.style.cssText='background:var(--bg);border-radius:12px;padding:6px;display:flex;flex-direction:column;gap:2px');
 sheet.append(colU,colL);
 const rows={};function mkRow(key,label,parent,isCat){const r=E('div');r.style.cssText='display:flex;justify-content:space-between;align-items:center;padding:6px 8px;border-radius:8px;font-size:14px;min-height:32px;cursor:'+(isCat?'pointer':'default');
  const l=E('span','',label),v=E('span');v.style.cssText='font-weight:800;min-width:34px;text-align:right';r.append(l,v);r._v=v;r._l=l;if(isCat)r.onpointerdown=e=>{e.preventDefault();score(key)};parent.append(r);rows[key]=r;return r}
 CATS.slice(0,6).forEach(([n,k])=>mkRow(k,n,colU,1));mkRow('bonus','Bonus (63+)',colU,0);mkRow('utot','Boven totaal',colU,0);
 CATS.slice(6).forEach(([n,k])=>mkRow(k,n,colL,1));mkRow('ybonus','Yahtzee-bonus',colL,0);mkRow('ltot','Onder totaal',colL,0);
 ['bonus','utot','ybonus','ltot'].forEach(k=>{rows[k].style.borderTop='1px solid var(--mu)';rows[k].style.marginTop='2px';rows[k]._l.style.color='var(--mu)'});
 const wrap=E('div');wrap.style.cssText='position:relative';wrap.append(sheet);
 const ov=E('div','ov');ov.style.display='none';ov.onpointerdown=e=>{e.preventDefault();init()};wrap.append(ov);
 const hint=E('div','hint','Tik op een dobbelsteen om hem vast te houden · tik op een rij om te scoren · spatie = gooien · 1–5 = vasthouden');
 st.append(sc,diceRow,bRoll,wrap,hint);
 // ---------- regels ----------
 function calc(k,d){const cnt=[0,0,0,0,0,0,0];d.forEach(v=>cnt[v]++);const sum=d.reduce((a,b)=>a+b,0),mx=Math.max(...cnt);
  const yz=mx===5,joker=yz&&S.y===50;// jokerregel: tweede yahtzee telt als full house / straat
  if(typeof k==='number')return cnt[k]*k;
  if(k==='3k')return mx>=3?sum:0;if(k==='4k')return mx>=4?sum:0;if(k==='ch')return sum;if(k==='y')return yz?50:0;
  if(k==='fh')return(mx===3&&cnt.includes(2))||joker?25:0;
  const has=a=>a.every(v=>cnt[v]);
  if(k==='ss')return has([1,2,3,4])||has([2,3,4,5])||has([3,4,5,6])||joker?30:0;
  if(k==='ls')return has([1,2,3,4,5])||has([2,3,4,5,6])||joker?40:0;return 0}
 // ---------- toestand ----------
 let S,d,held,rolls,turn,rolling,tm=0,anim=0,over;
 const upper=()=>[1,2,3,4,5,6].reduce((a,k)=>a+(S[k]||0),0),bonus=()=>upper()>=63?35:0,lower=()=>['3k','4k','fh','ss','ls','y','ch'].reduce((a,k)=>a+(S[k]||0),0)+S.yb;
 const total=()=>upper()+bonus()+lower();
 function showDie(i,v){faces[i].forEach((p,k)=>p.style.visibility=PIPS[v].includes(k)?'visible':'hidden')}
 function draw(){for(let i=0;i<5;i++){showDie(i,d[i]);const h=held[i];dice[i].style.transform=h?'translateY(8px)':'none';dice[i].style.boxShadow=h?'0 0 0 3px #f5af19,0 3px 8px rgba(0,0,0,.3)':'0 3px 8px rgba(0,0,0,.3)';dice[i].style.opacity=rolls===3?'.75':'1';dice[i]._tag.style.display=h?'block':'none'}
  for(const[n,k]of CATS){const r=rows[k],done=S[k]!=null;r._v.textContent=done?S[k]:rolls>0?calc(k,d):'';r._v.style.color=done?'var(--tx)':'var(--mu)';r._v.style.opacity=done?'1':'.75';r.style.background=done?'transparent':rolls>0?'var(--card)':'transparent';r._l.style.fontWeight=done?'400':'600';r._l.style.opacity=done?'.6':'1'}
  rows.bonus._v.textContent=bonus()||(upper()>=63?'35':upper()+'/63');rows.utot._v.textContent=upper()+bonus();rows.ybonus._v.textContent=S.yb||'';rows.ltot._v.textContent=lower();
  bRoll.textContent=over?'🎲 Nieuw spel':rolls===3?'Kies een rij':'🎲 Gooi ('+(3-rolls)+' over)';bRoll.disabled=rolling;bRoll.style.opacity=rolling||(rolls===3&&!over)?'.5':'1';
  sc.textContent=(over?'Klaar! ':'Beurt '+Math.min(turn,13)+'/13 · ')+'Totaal: '+total()+' · Beste: '+best('yahtzee',over?total():0)}
 function roll(){if(over){init();return}if(rolling||rolls>=3)return;rolling=1;let n=0;beep(300,.05,'triangle',.03);
  tm=setInterval(()=>{n++;for(let i=0;i<5;i++)if(!held[i]){showDie(i,1+R(6));dice[i].style.transform='rotate('+(R(2)?-1:1)*(6+R(14))+'deg) scale(1.06)'}
   if(n>=7){clearInterval(tm);tm=0;for(let i=0;i<5;i++)if(!held[i])d[i]=1+R(6);rolling=0;rolls++;
    const cnt=[0,0,0,0,0,0,0];d.forEach(v=>cnt[v]++);if(Math.max(...cnt)===5)beep(880,.4,'triangle',.05);else beep(520,.06,'triangle',.03);draw()}},70);draw()}
 function hold(i){if(rolling||rolls===0||rolls===3||over)return;held[i]=!held[i];beep(held[i]?620:420,.04,'square',.03);draw()}
 function score(k){if(rolling||rolls===0||over||S[k]!=null)return;const v=calc(k,d);const cnt=[0,0,0,0,0,0,0];d.forEach(x=>cnt[x]++);
  if(Math.max(...cnt)===5&&S.y===50){S.yb+=100;beep(990,.3,'triangle',.05)}
  S[k]=v;beep(v?700:260,.08,v?'triangle':'sawtooth',.04);turn++;rolls=0;held=[0,0,0,0,0];
  if(CATS.every(([n,k])=>S[k]!=null)){over=1;const t=total(),b=best('yahtzee',t);draw();
   ov.innerHTML='🏁 Klaar!<br><span style="font-size:15px;font-weight:600">Totaal: '+t+' · Beste: '+b+(t>=b&&t>0?' 🏆':'')+'<br>Tik om opnieuw te spelen</span>';ov.style.display='flex';beep(880,.5,'triangle',.05);return}
  draw()}
 const inp=input(st,[],k=>{if(k===' '||k==='Enter')roll();else if(k>='1'&&k<='5')hold(+k-1)});
 function init(){clearInterval(tm);tm=0;S={yb:0};d=[1,2,3,4,5];held=[0,0,0,0,0];rolls=0;turn=1;rolling=0;over=0;ov.style.display='none';draw()}
 window._yz={state:()=>({S:{...S},d:d.slice(),held:held.slice(),rolls,turn,over,rolling}),roll,hold,score,setDice(a){d=a.slice();rolls=Math.max(rolls,1);draw()}};
 init();cur.reset=init;return()=>{clearInterval(tm);tm=0;inp.stop();delete window._yz}}},
