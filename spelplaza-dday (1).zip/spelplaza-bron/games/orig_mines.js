{id:'mines',n:'Mijnenveger',e:'💣',c:'Puzzel',g:'#434343,#6c5ce7',run(st){
 const SZ=[{l:'Klein',w:9,m:10},{l:'Middel',w:12,m:24},{l:'Groot',w:16,m:40}],NC=['','#3d8bff','#2fb36b','#ff5e5b','#8a5cff','#c0392b','#16a3b5','#555','#999'];
 let si=0;try{si=+(localStorage.getItem('sp_mines_size')??0)}catch(e){}if(!SZ[si])si=0;
 const sc=E('div','sc'),opt=E('div'),wr=E('div','wrap'),b=E('div'),bar=E('div');
 opt.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 8px;flex-wrap:wrap';
 wr.style.cssText='display:block;margin:0 auto;width:min(400px,100%)';b.style.cssText='display:grid;gap:2px;padding:6px;border-radius:12px;background:var(--bg);user-select:none;-webkit-user-select:none;touch-action:manipulation';wr.append(b);
 bar.style.cssText='display:flex;gap:8px;justify-content:center;align-items:center;margin:10px 0 2px';
 const fb=E('button','btn','⛏️ Graven');fb.style.cssText='padding:8px 14px;font-size:14px;min-width:120px';bar.append(fb);
 const css=E('style','',`.mn{aspect-ratio:1;border-radius:4px;display:flex;align-items:center;justify-content:center;font-weight:800;cursor:pointer;background:linear-gradient(160deg,color-mix(in srgb,var(--ac) 78%,#fff),var(--ac));color:#fff;transition:background .15s,transform .15s;line-height:1}
.mn.o{background:var(--card);box-shadow:inset 0 0 0 1px var(--ln);cursor:default}.mn.k{background:#ff5e5b!important}.mn.cu{outline:3px solid #ffd86b;outline-offset:-2px}.mn.p{transform:scale(.88)}`);
 st.append(css,sc,opt,wr,bar,E('div','hint','Tik = graven · lang drukken / rechtsklik / 🚩-knop = vlag · tik op een cijfer = rondom openen · pijltjes + spatie, F = vlag'));
 let W,M,cells,over,started,opened,flags,t0,tEnd,flagMode=0,cu=-1,lp,lpFired;
 const to=[],later=(f,ms)=>to.push(setTimeout(f,ms));
 const fmt=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
 const bk=()=>'sp_mines_t'+si,getBest=()=>{try{return+localStorage.getItem(bk())||0}catch(e){return 0}};
 function upd(){const el=t0?((tEnd||performance.now())-t0)/1000:0,bb=getBest();sc.textContent=`💣 ${M-flags} · ⏱ ${fmt(el)}`+(bb?' · Beste: '+fmt(bb):'')}
 function drawOpt(){opt.innerHTML='';SZ.forEach((z,i)=>{const q=E('button','btn',`${z.l} ${z.w}×${z.w}`);q.style.cssText='padding:6px 12px;font-size:12px;border-radius:99px;'+(i===si?'':'background:var(--bg);color:var(--tx)');q.onclick=()=>{si=i;try{localStorage.setItem('sp_mines_size',i)}catch(e){}init()};opt.append(q)})}
 fb.onclick=()=>{flagMode^=1;fb.textContent=flagMode?'🚩 Vlaggen':'⛏️ Graven';fb.style.background=flagMode?'#ff9f43':''};
 function nb(i){const r=[],cx=i%W,cy=i/W|0;for(let dy=-1;dy<2;dy++)for(let dx=-1;dx<2;dx++){const X=cx+dx,Y=cy+dy;if((dx||dy)&&X>=0&&X<W&&Y>=0&&Y<W)r.push(Y*W+X)}return r}
 function init(){to.forEach(clearTimeout);to.length=0;overlay(st,b,'');const z=SZ[si];W=z.w;M=z.m;over=0;started=0;opened=0;flags=0;t0=0;tEnd=0;cu=-1;b.innerHTML='';b.style.gridTemplateColumns=`repeat(${W},1fr)`;
  const fs=W>12?'clamp(11px,3.2vw,15px)':W>9?'clamp(13px,4vw,18px)':'clamp(16px,5vw,22px)';
  cells=[];for(let i=0;i<W*W;i++){const el=E('div','mn');el.style.fontSize=fs;const cl={m:0,o:0,f:0,n:0,el};cells.push(cl);
   el.onpointerdown=e=>{if(e.button===2)return;lpFired=0;clearTimeout(lp);el.classList.add('p');lp=setTimeout(()=>{lpFired=1;el.classList.remove('p');flag(i);try{navigator.vibrate&&navigator.vibrate(25)}catch(_){}},420)};
   el.onpointerup=e=>{clearTimeout(lp);el.classList.remove('p');if(e.button===2||lpFired)return;cu=-1;act(i)};el.onpointerleave=el.onpointercancel=()=>{clearTimeout(lp);el.classList.remove('p')};
   el.oncontextmenu=e=>{e.preventDefault();clearTimeout(lp);if(!lpFired)flag(i);lpFired=0};b.append(el)}
  drawOpt();upd()}
 function plant(safe){const ex=new Set([safe,...nb(safe)]);let k=0;while(k<M){const i=R(W*W);if(!cells[i].m&&!ex.has(i)){cells[i].m=1;k++}}cells.forEach((c,i)=>c.n=nb(i).filter(j=>cells[j].m).length)}
 function act(i){if(over)return;const c=cells[i];if(c.o){chord(i);return}if(flagMode)flag(i);else dig(i)}
 function flag(i){const c=cells[i];if(over||c.o)return;c.f^=1;flags+=c.f?1:-1;c.el.textContent=c.f?'🚩':'';beep(c.f?700:500,.04,'triangle',.03);upd()}
 function reveal(i){const q=[i];let n=0;while(q.length){const j=q.pop(),c=cells[j];if(c.o||c.f)continue;c.o=1;opened++;n++;c.el.classList.add('o');c.el.textContent=c.n||'';c.el.style.color=NC[c.n];
   if(!c.n)nb(j).forEach(k=>{if(!cells[k].o)q.push(k)})}return n}
 function dig(i){const c=cells[i];if(c.f||c.o)return;if(!started){started=1;plant(i);t0=performance.now()}
  if(c.m){lose(i);return}const n=reveal(i);beep(n>1?330:440,n>1?.1:.04,'triangle',.03);check()}
 function chord(i){const c=cells[i];if(!c.n)return;const ns=nb(i),f=ns.filter(j=>cells[j].f).length;if(f!==c.n){ns.forEach(j=>{if(!cells[j].o&&!cells[j].f){cells[j].el.classList.add('p');later(()=>cells[j].el.classList.remove('p'),130)}});return}
  let boom=-1,n=0;ns.forEach(j=>{const q=cells[j];if(q.o||q.f)return;if(q.m)boom=j;else n+=reveal(j)});if(boom>=0){lose(boom);return}if(n)beep(360,.06,'triangle',.03);check()}
 function check(){if(opened===W*W-M){over=1;tEnd=performance.now();const s=(tEnd-t0)/1000,o=getBest(),rec=!o||s<o;if(rec)try{localStorage.setItem(bk(),s)}catch(e){}
   cells.forEach(c=>{if(c.m&&!c.f){c.f=1;c.el.textContent='🚩'}});flags=M;upd();[523,659,784,1047].forEach((f,k)=>later(()=>beep(f,.13,'triangle',.05),k*100));
   later(()=>{if(!over)return;const v=overlay(st,b,`🎉 Veld geveegd!<br><span style="font-size:15px;font-weight:600">Tijd ${fmt(s)}${rec?' · Nieuw record!':' · Beste '+fmt(getBest())}<br>Tik om opnieuw te spelen</span>`);v.onclick=init;v.style.cursor='pointer'},500)}else upd()}
 function lose(i){over=1;tEnd=performance.now();cells[i].el.classList.add('o','k');cells[i].el.textContent='💥';beep(90,.5,'sawtooth',.06);
  const ms=cells.map((c,j)=>j).filter(j=>cells[j].m&&j!==i);ms.forEach((j,k)=>later(()=>{const c=cells[j];if(!c.f){c.el.classList.add('o');c.el.textContent='💣'}},40+k*25));
  cells.forEach(c=>{if(c.f&&!c.m){c.el.textContent='❌';c.el.classList.add('o')}});upd();
  later(()=>{if(!over)return;const v=overlay(st,b,'💥 Boem!<br><span style="font-size:15px;font-weight:600">Tik om opnieuw te spelen</span>');v.onclick=init;v.style.cursor='pointer'},Math.min(1400,500+ms.length*25))}
 function setCu(n){if(cu>=0)cells[cu].el.classList.remove('cu');cu=n;cells[cu].el.classList.add('cu')}
 const inp=input(st,[],k=>{if(over){if(k===' '||k==='Enter')init();return}const kk=k.toLowerCase();if(cu<0&&(k.startsWith('Arrow')||k===' '||kk==='f')){setCu((W*W/2|0)-(W%2?0:W/2));return}
  if(k==='ArrowLeft'&&cu%W)setCu(cu-1);else if(k==='ArrowRight'&&cu%W<W-1)setCu(cu+1);else if(k==='ArrowUp'&&cu>=W)setCu(cu-W);else if(k==='ArrowDown'&&cu<W*W-W)setCu(cu+W);
  else if(k===' '||k==='Enter'){const c=cells[cu];if(c.o)chord(cu);else dig(cu)}else if(kk==='f')flag(cu)});
 const tick=setInterval(()=>{if(t0&&!over)upd()},500);
 st.t={get cells(){return cells},get over(){return over},act,flag,get W(){return W}};
 init();cur.reset=init;return()=>{clearInterval(tick);clearTimeout(lp);to.forEach(clearTimeout);inp.stop()}}},
