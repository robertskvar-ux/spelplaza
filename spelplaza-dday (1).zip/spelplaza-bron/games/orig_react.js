{id:'react',n:'Reactietest',e:'⚡',c:'Geheugen',g:'#fc4a1a,#f7b733',run(st){
 const TRY=5,sc=E('div','sc'),b=E('div'),dots=E('div'),res=E('div');
 b.style.cssText='height:min(52vh,300px);border-radius:18px;display:flex;flex-direction:column;gap:8px;align-items:center;justify-content:center;font-size:26px;font-weight:800;color:#fff;cursor:pointer;user-select:none;-webkit-user-select:none;touch-action:manipulation;transition:background .12s;padding:16px;text-align:center;box-shadow:0 6px 18px rgba(0,0,0,.18)';
 dots.style.cssText='display:flex;gap:8px;justify-content:center;margin:12px 0 4px';res.style.cssText='max-width:380px;margin:8px auto 0;text-align:left';
 st.append(sc,b,dots,res,E('div','hint','Tik (of spatie) zodra het vlak groen wordt · 5 pogingen · je gemiddelde telt'));
 let s,times,t0,wait,to,big,sub,early;
 const K='sp_react_avg',getBest=()=>{try{return+localStorage.getItem(K)||0}catch(e){return 0}};
 const rate=ms=>ms<200?'⚡ Bliksemsnel!':ms<250?'🚀 Supersnel':ms<300?'👍 Goed':ms<380?'🙂 Gemiddeld':'😴 Slaperig';
 function set(bg,h,sb){b.style.background=bg;b.innerHTML=`<div>${h}</div>`+(sb?`<div style="font-size:15px;font-weight:600;opacity:.9">${sb}</div>`:'')}
 function upd(){const bb=getBest();sc.textContent=`Poging ${Math.min(times.length+(s===3?0:1),TRY)}/${TRY}`+(times.length?` · Gemiddeld: ${Math.round(times.reduce((p,q)=>p+q,0)/times.length)} ms`:'')+(bb?` · Beste: ${bb} ms`:'');
  dots.innerHTML='';for(let i=0;i<TRY;i++){const d=E('div','',times[i]?times[i]+'':'');d.style.cssText=`min-width:52px;height:30px;border-radius:99px;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;padding:0 8px;${times[i]!=null?'background:var(--ac);color:#fff':'background:var(--bg);color:var(--mu);border:1px solid var(--ln)'}`;if(i===times.length&&s!==3)d.style.outline='2px solid var(--ac)';dots.append(d)}}
 function init(){clearTimeout(to);s=0;times=[];early=0;res.innerHTML='';set('linear-gradient(135deg,#3d8bff,#5b4cf5)','Tik om te beginnen','Wacht tot het groen wordt en tik dan zo snel mogelijk');upd()}
 function arm(){s=1;set('linear-gradient(135deg,#ff5e5b,#d63031)','Wacht…','nog niet tikken!');to=setTimeout(()=>{s=2;t0=performance.now();set('linear-gradient(135deg,#2fd17a,#13a85a)','TIK!','');beep(880,.05,'square',.03)},1200+Math.random()*2800)}
 function finish(){s=3;const avg=Math.round(times.reduce((p,q)=>p+q,0)/TRY),bb=getBest(),rec=!bb||avg<bb;if(rec)try{localStorage.setItem(K,avg)}catch(e){}
  set('linear-gradient(135deg,#5b4cf5,#b259ff)',`${avg} ms gemiddeld`,`${rate(avg)}${rec?' · Nieuw record! 🏆':''}<br>Tik om opnieuw te spelen`);
  [523,659,784].forEach((f,i)=>setTimeout(()=>beep(f,.12,'triangle',.05),i*110));const mx=Math.max(...times);
  res.innerHTML=times.map((v,i)=>`<div style="display:flex;align-items:center;gap:8px;margin:4px 0;font-size:13px"><span style="width:62px;color:var(--mu)">Poging ${i+1}</span><div style="flex:1;height:12px;border-radius:99px;background:var(--bg)"><div style="width:${v/mx*100}%;height:100%;border-radius:99px;background:${v===Math.min(...times)?'#2fd17a':'var(--ac)'}"></div></div><b style="width:56px;text-align:right">${v} ms</b></div>`).join('')+`<div style="font-size:13px;color:var(--mu);margin-top:6px">Snelste: ${Math.min(...times)} ms · traagste: ${mx} ms${early?` · ${early}× te vroeg`:''}</div>`;upd()}
 function tap(){if(s===0||s===4){arm();upd();return}
  if(s===1){clearTimeout(to);early++;s=4;beep(150,.2,'sawtooth',.04);set('linear-gradient(135deg,#f39c12,#e67e22)','Te vroeg! 😅','Tik om deze poging opnieuw te doen');return}
  if(s===2){const ms=Math.round(performance.now()-t0);times.push(ms);beep(660,.06,'triangle',.04);
   if(times.length>=TRY){finish();return}s=4;set('linear-gradient(135deg,#3d8bff,#5b4cf5)',ms+' ms',rate(ms)+'<br>Tik voor poging '+(times.length+1));upd();return}
  if(s===3)init()}
 b.onpointerdown=e=>{e.preventDefault();tap()};
 const inp=input(st,[],k=>{if(k===' '||k==='Enter')tap()});
 st.t={get s(){return s},get times(){return times},tap};
 init();cur.reset=init;return()=>{clearTimeout(to);inp.stop()}}},
