{id:'stack3d',n:'Stapel 3D',e:'🏗️',c:'3D',g:'#ee0979,#ff6a00',nw:1,run(st){
 const W=360,H=520,T=three(st,W,H),S=T.s,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','Tik / spatie = blok neerzetten · precies erop = perfect, 3× perfect = blok groeit'));
 const asp=W/H;let D=5.5;const cam=new THREE.OrthographicCamera(-D*asp,D*asp,D,-D,-20,120);
 const setD=d=>{D=d;cam.left=-D*asp;cam.right=D*asp;cam.top=D;cam.bottom=-D;cam.updateProjectionMatrix()};setD(D);
 // pastel gradient background
 const bc=document.createElement('canvas');bc.width=2;bc.height=256;const bx=bc.getContext('2d'),bt=new THREE.CanvasTexture(bc);bt.colorSpace=THREE.SRGBColorSpace;S.background=bt;
 let bgH=-1;const paintBg=h=>{if(h===bgH)return;bgH=h;const g=bx.createLinearGradient(0,0,0,256);g.addColorStop(0,`hsl(${h},70%,90%)`);g.addColorStop(1,`hsl(${(h+50)%360},65%,76%)`);bx.fillStyle=g;bx.fillRect(0,0,2,256);bt.needsUpdate=true};
 const sun=new THREE.DirectionalLight(0xffffff,2.4);sun.position.set(6,12,3);S.add(sun,new THREE.HemisphereLight(0xffffff,0x8a7a90,1));
 const box=new THREE.BoxGeometry(1,1,1),BH=.6,SZ=3,A=4.3;
 const mkM=()=>new THREE.MeshStandardMaterial({color:0xffffff,roughness:.85,metalness:0});
 const pool=[],falls=[];for(let i=0;i<6;i++){const m=new THREE.Mesh(box,mkM());m.visible=false;S.add(m);falls.push(m)}
 const getBlock=i=>{while(pool.length<=i){const m=new THREE.Mesh(box,mkM());S.add(m);pool.push(m)}return pool[i]};
 const ring=new THREE.Mesh(new THREE.RingGeometry(.5,.56,32),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:0,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.visible=false;S.add(ring);
 const col=(h,l)=>new THREE.Color().setHSL(h/360,.6,l);
 let level,top,mov,axis,dir,sp,perf,hue,over,deadAt,focusY,camF,zoomT,ringT,t,bestS;
 function place(m,x,y,z,sx,sz,h,l){m.visible=true;m.position.set(x,y,z);m.scale.set(sx,BH,sz);m.material.color.copy(col(h,l))}
 function init(){level=0;perf=0;over=0;t=0;ringT=0;zoomT=0;hue=R(360);bestS=best('stack3d',0);
  pool.forEach(m=>m.visible=false);falls.forEach(m=>m.visible=false);ring.visible=false;
  const b=getBlock(0);place(b,0,-2+BH/2,0,SZ,SZ,hue,.5);b.scale.y=4;b.position.y=-2;
  top={x:0,z:0,sx:SZ,sz:SZ,y:0};focusY=0;camF=0;setD(5.5);spawn();overlay(st,c,'')}
 function spawn(){axis=level%2?'z':'x';dir=1;sp=Math.min(8,3.4+level*.11);hue=(hue+9)%360;mov=getBlock(level+1);
  const y=top.y+BH/2;place(mov,top.x,y,top.z,top.sx,top.sz,hue,.56+Math.sin(level*.9)*.06);mov.position[axis]=top[axis]-A;paintBg(Math.floor(hue/40)*40)}
 function drop(){if(over){if(performance.now()-deadAt>1000)init();return}
  const s=axis==='x'?top.sx:top.sz,m=mov.position[axis],d=m-top[axis],ad=Math.abs(d);
  if(ad>=s-.02){over=1;deadAt=performance.now();fall(mov,mov.position.x,mov.position.y,mov.position.z,mov.scale.x,mov.scale.z,d>0?1:-1);mov.visible=false;best('stack3d',level);
   beep(150,.3,'sawtooth',.06);zoomT=0;overlay(st,c,`🏗️ Gemist!<br><span style="font-size:15px;font-weight:600">${level} blokken · Beste ${best('stack3d',level)}<br>Tik of druk op spatie om opnieuw te spelen</span>`).style.pointerEvents='none';return}
  if(ad<.1){mov.position[axis]=top[axis];perf++;beep(520+Math.min(8,perf)*70,.09,'sine',.05);ringT=1;ring.position.set(mov.position.x,mov.position.y+BH/2+.01,mov.position.z);ring.scale.set(1,1,1);ring.visible=true;
   if(perf>=3){top.sx=Math.min(SZ,top.sx+.18);top.sz=Math.min(SZ,top.sz+.18);mov.scale.x=top.sx;mov.scale.z=top.sz;setTimeout(()=>beep(1040,.1,'triangle',.04),90)}}
  else{perf=0;beep(260,.05,'square',.03);const ns=s-ad,nc=top[axis]+d/2,cc=top[axis]+Math.sign(d)*(s/2+ad/2);
   mov.position[axis]=nc;if(axis==='x')mov.scale.x=ns;else mov.scale.z=ns;
   const fx=axis==='x'?cc:mov.position.x,fz=axis==='z'?cc:mov.position.z,fsx=axis==='x'?ad:mov.scale.x,fsz=axis==='z'?ad:mov.scale.z;fall(mov,fx,mov.position.y,fz,fsx,fsz,Math.sign(d))}
  top={x:mov.position.x,z:mov.position.z,sx:mov.scale.x,sz:mov.scale.z,y:mov.position.y+BH/2};level++;focusY=top.y;spawn()}
 function fall(src,x,y,z,sx,sz,sg){const f=falls.find(f=>!f.visible)||falls[0];f.visible=true;f.position.set(x,y,z);f.scale.set(sx,BH,sz);f.rotation.set(0,0,0);f.material.color.copy(src.material.color);f.userData={vy:0,ax:axis,sg,t:0}}
 const inp=input(st,[['⬇ Plaats',' ']],k=>{if(k===' '||k==='ArrowDown'||k==='Enter'||over)drop()});
 c.onpointerdown=e=>{e.preventDefault();drop()};
 const stopLoop=loop(dt=>{t+=dt;
  if(!over){mov.position[axis]+=dir*sp*dt;const off=mov.position[axis]-top[axis];if(off>A){mov.position[axis]=top[axis]+A;dir=-1}else if(off<-A){mov.position[axis]=top[axis]-A;dir=1}}
  else{zoomT=Math.min(1,zoomT+dt);const h=top.y+2;setD(5.5+Math.max(0,h*.5-1.2)*zoomT);focusY=top.y-Math.max(0,h-6)*.4*zoomT}
  for(const f of falls)if(f.visible){const u=f.userData;u.t+=dt;u.vy-=22*dt;f.position.y+=u.vy*dt;f.rotation[u.ax==='x'?'z':'x']+=(u.ax==='x'?-u.sg:u.sg)*dt*2.5;if(u.t>2.5)f.visible=false}
  if(ringT>0){ringT=Math.max(0,ringT-dt*2.2);const k=1+(1-ringT)*2.2;ring.scale.set(k,k,1);ring.material.opacity=ringT*.9;if(!ringT)ring.visible=false}
  camF+=(focusY-camF)*Math.min(1,dt*4);cam.position.set(20,camF+22,20);cam.lookAt(0,camF,0);
  sc.textContent=over?'Blokken: '+level+' · Beste: '+Math.max(bestS,level)+' · Gemist':'Blokken: '+level+' · Beste: '+Math.max(bestS,level)+(perf>=2?' · Perfect ×'+perf:'');
  T.r.render(S,cam)});
 init();cur.reset=init;cur.dbg=()=>({off:+(mov.position[axis]-top[axis]).toFixed(3),level,perf,over});
 return()=>{stopLoop();inp.stop();c.onpointerdown=null;T.dispose()}}},
