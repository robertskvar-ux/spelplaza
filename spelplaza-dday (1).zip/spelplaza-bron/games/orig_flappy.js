{id:'flappy',n:'Flappy Vogel',e:'🐤',c:'Arcade',g:'#f7971e,#ffd200',run(st){
 const W=320,H=480,GY=420,BX=86,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Tik / spatie / ▲ = fladderen · medailles bij 10, 20, 30 en 50'));
 const sky=x.createLinearGradient(0,0,0,GY);sky.addColorStop(0,'#1b1f4b');sky.addColorStop(.55,'#5b3f8c');sky.addColorStop(1,'#ff9a76');
 const stars=[];for(let i=0;i<30;i++)stars.push({x:R(W),y:R(200),s:Math.random()<.3?2:1});
 const city=[];{let cx=0;while(cx<W*2){const w=22+R(30);city.push({x:cx,w,h:40+R(70)});cx+=w+2}}
 let ob0,y,vy,pipes,score,state,stT,dist,t,flapT,parts,sp,newBest;
 const MED=[[50,'Platina','#e5f4ff','#9fd3ff'],[30,'Goud','#ffd700','#c99a00'],[20,'Zilver','#e0e0e0','#9a9a9a'],[10,'Brons','#e39b5a','#a15d24']];
 function init(){y=220;vy=0;pipes=[];score=0;state=0;stT=0;dist=0;flapT=0;parts=[];sp=140;newBest=0;ob0=best('flappy',0);overlay(st,c,'')}
 function flap(){if(state===2){if(stT>.6)init();return}if(state===0)state=1;vy=-420;flapT=.25;beep(720,.05,'triangle',.03)}
 const inp=input(st,[],k=>{if(k===' '||k==='ArrowUp'||k==='w'||k==='Enter')flap()});
 c.onpointerdown=e=>{e.preventDefault();flap()};
 function die(){if(state===2)return;state=2;stT=0;beep(160,.35,'sawtooth',.05);newBest=score>ob0;best('flappy',score);
  for(let i=0;i<18;i++){const a=Math.random()*7,s=40+Math.random()*120;parts.push({x:BX,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:.6,c:i%2?'#ffd23f':'#fff'})}}
 function medal(){return MED.find(m=>score>=m[0])}
 function showOver(){const m=medal();const md=m?`<div style="width:64px;height:64px;border-radius:50%;margin:4px auto;background:radial-gradient(circle at 35% 30%,#fff8,${m[2]} 40%,${m[3]});box-shadow:0 0 18px ${m[2]};display:flex;align-items:center;justify-content:center;font-size:30px">🏅</div><div style="font-size:14px">${m[1]}</div>`:'<div style="font-size:14px;font-weight:600;opacity:.8">Nog geen medaille · 10 = brons</div>';
  const o=overlay(st,c,`💥 Game over${md}<span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('flappy',score)}${newBest?' · Nieuw record!':''}<br>Tik of druk op spatie om opnieuw te spelen</span>`);if(o)o.style.pointerEvents='none'}
 function bird(bx,by,ang){x.save();x.translate(bx,by);x.rotate(ang);
  x.fillStyle='#ffd23f';x.beginPath();x.ellipse(0,0,15,12,0,0,7);x.fill();x.fillStyle='#fff3b0';x.beginPath();x.ellipse(-2,4,9,6,0,0,7);x.fill();
  const wf=state===2?0:Math.sin(t*(flapT>0?40:14));x.fillStyle='#f4a51c';x.beginPath();x.ellipse(-5,1+wf*4,8,5,-.3+wf*.4,0,7);x.fill();
  x.fillStyle='#fff';x.beginPath();x.arc(7,-4,5,0,7);x.fill();x.fillStyle='#1b1f3a';x.beginPath();x.arc(8.5,-4,2.4,0,7);x.fill();
  x.fillStyle='#ff6b3d';x.beginPath();x.moveTo(11,0);x.lineTo(21,3);x.lineTo(11,7);x.closePath();x.fill();x.restore()}
 function pipe(px,top,bot){const g=x.createLinearGradient(px,0,px+52,0);g.addColorStop(0,'#2e9e46');g.addColorStop(.35,'#7be27a');g.addColorStop(1,'#1e6e33');x.fillStyle=g;
  x.fillRect(px,0,52,top-22);x.fillRect(px,bot+22,52,GY-bot-22);x.fillRect(px-4,top-24,60,24);x.fillRect(px-4,bot,60,24);
  x.strokeStyle='#0e3d1c';x.lineWidth=2;x.strokeRect(px-4,top-24,60,24);x.strokeRect(px-4,bot,60,24);x.beginPath();x.moveTo(px,0);x.lineTo(px,top-24);x.moveTo(px+52,0);x.lineTo(px+52,top-24);x.moveTo(px,bot+24);x.lineTo(px,GY);x.moveTo(px+52,bot+24);x.lineTo(px+52,GY);x.stroke()}
 t=0;
 const stopLoop=loop(dt=>{t+=dt;stT+=dt;flapT-=dt;
  if(state===1){vy=Math.min(620,vy+1500*dt);y+=vy*dt;sp=Math.min(200,140+score*2);dist+=sp*dt;
   if(!pipes.length||pipes[pipes.length-1].x<W-185){const gap=Math.max(112,150-score*1.5),top=60+R(GY-120-gap);pipes.push({x:W+30,top,bot:top+gap,s:0})}
   for(const p of pipes){p.x-=sp*dt;if(!p.s&&p.x+52<BX){p.s=1;score++;beep(980,.06,'square',.03);if(MED.some(m=>m[0]===score))setTimeout(()=>beep(1320,.12,'triangle',.04),80)}
    if(BX+12>p.x-4&&BX-12<p.x+56&&(y-10<p.top||y+10>p.bot))die()}
   pipes=pipes.filter(p=>p.x>-70);if(y>GY-12){y=GY-12;die()}if(y<-30){y=-30;vy=0}}
  else if(state===0){y=220+Math.sin(t*3)*8;dist+=60*dt}
  else{if(y<GY-12){vy=Math.min(700,vy+1800*dt);y=Math.min(GY-12,y+vy*dt)}if(stT>.5&&!st.querySelector('.ov'))showOver()}
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=300*dt;p.l-=dt}parts=parts.filter(p=>p.l>0);
  // draw
  x.fillStyle=sky;x.fillRect(0,0,W,GY);x.fillStyle='#ffffff88';for(const s of stars)x.fillRect(s.x,s.y,s.s,s.s);
  x.fillStyle='#ffe2a8';x.beginPath();x.arc(250,90,26,0,7);x.fill();
  x.fillStyle='#3a2a63';for(const b of city){const bx=((b.x-dist*.25)%(W*2)+W*2)%(W*2)-40;x.fillRect(bx,GY-b.h,b.w,b.h)}
  x.fillStyle='#ffd86b55';for(const b of city){const bx=((b.x-dist*.25)%(W*2)+W*2)%(W*2)-40;for(let wy=GY-b.h+8;wy<GY-8;wy+=12)for(let wx=bx+4;wx<bx+b.w-6;wx+=9)if((wx*7+wy*3|0)%5===0)x.fillRect(wx,wy,4,5)}
  for(const p of pipes)pipe(p.x,p.top,p.bot);
  x.fillStyle='#d8b26e';x.fillRect(0,GY,W,H-GY);x.fillStyle='#6fcf5a';x.fillRect(0,GY,W,10);x.fillStyle='#4aa83c';for(let i=-1;i<W/20+1;i++){const gx=i*20-(dist%20);x.beginPath();x.moveTo(gx,GY+10);x.lineTo(gx+10,GY+10);x.lineTo(gx+4,GY+16);x.lineTo(gx-6,GY+16);x.fill()}
  x.fillStyle='#c39a55';for(let i=0;i<10;i++)x.fillRect(((i*47-dist)%W+W)%W,GY+30+(i%3)*10,10,3);
  bird(BX,y,state===0?0:Math.max(-.5,Math.min(1.3,vy/520)));
  for(const p of parts){x.globalAlpha=Math.max(0,p.l*1.6);x.fillStyle=p.c;x.fillRect(p.x-2,p.y-2,4,4)}x.globalAlpha=1;
  x.textAlign='center';x.lineJoin='round';if(state===1||state===2){x.font='900 44px system-ui,sans-serif';x.lineWidth=6;x.strokeStyle='#1b1f3a';x.strokeText(score,W/2,70);x.fillStyle='#fff';x.fillText(score,W/2,70)}
  if(state===0){x.font='900 30px system-ui,sans-serif';x.lineWidth=6;x.strokeStyle='#1b1f3a';x.strokeText('Flappy Vogel',W/2,130);x.fillStyle='#ffd23f';x.fillText('Flappy Vogel',W/2,130);
   x.font='bold 16px system-ui,sans-serif';x.lineWidth=4;x.strokeText('Tik om te starten',W/2,300);x.fillStyle='#fff';x.fillText('Tik om te starten',W/2,300)}
  sc.textContent='Score: '+score+' · Beste: '+best('flappy',score)+(state===2?' · Game over':'');
 });
 st.t={get y(){return y},get vy(){return vy},get pipes(){return pipes},flap};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=null}}},
