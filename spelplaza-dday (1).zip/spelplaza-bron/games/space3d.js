{id:'space3d',n:'Ruimtevlucht',e:'🛸',c:'3D',g:'#000428,#004e92',nw:1,run(st){
 const W=360,H=480,T=three(st,W,H,{fov:60,far:400}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','◀ ▲ ▼ ▶ of sleep · spatie / 🔥 / vasthouden = schieten · ontwijk de asteroïden'));
 const BG=new THREE.Color(0x03031c),FL=new THREE.Color(0xff3b3b);S.background=BG.clone();S.fog=new THREE.Fog(0x03031c,55,135);
 const sun=new THREE.DirectionalLight(0xffffff,2.8);sun.position.set(6,10,8);S.add(sun,new THREE.HemisphereLight(0x8899ff,0x201030,.9));
 const std=o=>new THREE.MeshStandardMaterial(o),V3=THREE.Vector3;
 // ship: cone nose + wings + fin + engine glow
 const ship=new THREE.Group(),nose=new THREE.Mesh(new THREE.ConeGeometry(.42,2.1,10),std({color:0xd8ecff,roughness:.35,metalness:.3}));nose.rotation.x=-Math.PI/2;nose.position.z=-.1;
 const eng=new THREE.Mesh(new THREE.CylinderGeometry(.3,.22,.4,10),std({color:0x2a2f45,roughness:.6,metalness:.5}));eng.rotation.x=Math.PI/2;eng.position.z=1.1;const cock=new THREE.Mesh(new THREE.SphereGeometry(.2,10,8),std({color:0x1c2a4a,roughness:.1,metalness:.6}));cock.position.set(0,.25,-.1);
 const wing=new THREE.Mesh(new THREE.BoxGeometry(2.4,.08,.8),std({color:0x3d7bff,roughness:.5,metalness:.3}));wing.position.set(0,-.05,.35);
 const fin=new THREE.Mesh(new THREE.BoxGeometry(.08,.5,.6),std({color:0x3d7bff}));fin.position.set(0,.35,.5);
 const glow=new THREE.Mesh(new THREE.SphereGeometry(.15,10,8),new THREE.MeshBasicMaterial({color:0x7fe0ff}));glow.position.set(0,0,1.3);ship.add(nose,eng,cock,wing,fin,glow);S.add(ship);
 const planet=new THREE.Mesh(new THREE.SphereGeometry(22,32,24),std({color:0x3b6fd6,roughness:.8,fog:false}));planet.position.set(-32,16,-160);S.add(planet);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(32,2.2,6,48),std({color:0x9fb4e8,roughness:.9,fog:false}));ring.rotation.x=1.25;ring.position.copy(planet.position);S.add(ring);
 // rocky asteroid geometries (consistent per-vertex displacement so faces stay sealed)
 const rockGs=[0,1,2].map(()=>{const g=new THREE.IcosahedronGeometry(1,1),p=g.attributes.position,f={},v=new V3;for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i);const k=v.x.toFixed(2)+v.y.toFixed(2)+v.z.toFixed(2);f[k]=f[k]||.72+Math.random()*.5;v.multiplyScalar(f[k]);p.setXYZ(i,v.x,v.y,v.z)}g.computeVertexNormals();return g});
 const rockMs=[0x8f7a66,0x6f6b7c,0x9b5f4a].map(cl=>std({color:cl,roughness:.95,flatShading:true}));
 const rocks=[];for(let i=0;i<26;i++){const m=new THREE.Mesh(rockGs[i%3],rockMs[R(3)]);m.visible=false;m.userData={on:0};S.add(m);rocks.push(m)}
 function spawnRock(m){const s=.5+Math.random()*1.2,u=m.userData;u.s=s;u.on=1;u.v=.8+Math.random()*.4;u.rx=(Math.random()-.5)*2;u.ry=(Math.random()-.5)*2;m.scale.setScalar(s);m.position.set((Math.random()-.5)*11,(Math.random()-.5)*6.5,-115-Math.random()*50);m.rotation.set(Math.random()*6,Math.random()*6,0);m.visible=true}
 const bolts=[],boltG=new THREE.BoxGeometry(.15,.15,2.2),boltM=new THREE.MeshBasicMaterial({color:0x9dfff0});for(let i=0;i<16;i++){const m=new THREE.Mesh(boltG,boltM);m.visible=false;S.add(m);bolts.push(m)}
 // particles (one Points object, pooled)
 const NPART=180,pg=new THREE.BufferGeometry(),pp=new Float32Array(NPART*3).fill(999),pv=new Float32Array(NPART*3),pl=new Float32Array(NPART);pg.setAttribute('position',new THREE.BufferAttribute(pp,3));
 const parts=new THREE.Points(pg,new THREE.PointsMaterial({color:0xffb347,size:.4,transparent:true,opacity:.95}));parts.frustumCulled=false;S.add(parts);let pi=0;
 function burst(x,y,z,n,sp){for(let k=0;k<n;k++){const i=pi;pi=(pi+1)%NPART;pp[i*3]=x;pp[i*3+1]=y;pp[i*3+2]=z;const a=Math.random()*6.283,b=(Math.random()-.5)*3.14,r=sp*(.3+Math.random());pv[i*3]=Math.cos(a)*Math.cos(b)*r;pv[i*3+1]=Math.sin(b)*r;pv[i*3+2]=Math.sin(a)*Math.cos(b)*r;pl[i]=.5+Math.random()*.5}}
 // star field
 const NST=400,sg=new THREE.BufferGeometry(),spos=new Float32Array(NST*3);for(let i=0;i<NST;i++){spos[i*3]=(Math.random()-.5)*90;spos[i*3+1]=(Math.random()-.5)*70;spos[i*3+2]=-150+Math.random()*160}sg.setAttribute('position',new THREE.BufferAttribute(spos,3));
 const stars=new THREE.Points(sg,new THREE.PointsMaterial({color:0xffffff,size:1.7,sizeAttenuation:false,fog:false,transparent:true,opacity:.85}));stars.frustumCulled=false;S.add(stars);
 let sx,sy,tx,ty,shields,score,over,t,cool,inv,hitF,shake,ptr,side,last;
 function ov(html){const o=overlay(st,c,html);if(o)o.onpointerdown=e=>{e.preventDefault();init()}}
 function init(){sx=sy=tx=ty=0;shields=3;score=0;over=0;t=0;cool=0;inv=0;hitF=0;shake=0;ptr=0;side=1;rocks.forEach(m=>{m.userData.on=0;m.visible=false});bolts.forEach(m=>m.visible=false);pl.fill(0);pp.fill(999);ship.visible=true;overlay(st,c,'')}
 function fire(){const b=bolts.find(m=>!m.visible);if(!b)return;side=-side;b.visible=true;b.position.set(sx+side*.95,sy-.05,-.6);beep(900,.05,'square',.03)}
 function kill(m,pts){burst(m.position.x,m.position.y,m.position.z,16,9);score+=pts;spawnRock(m);beep(pts>10?160:260,.12,'sawtooth',.045)}
 function hit(m){burst(m.position.x,m.position.y,m.position.z,20,10);spawnRock(m);shields--;inv=2;hitF=1;shake=1;beep(110,.35,'sawtooth',.06);
  if(shields<=0){over=1;ship.visible=true;best('space3d',score);ov(`💥 Schip vernietigd<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('space3d',score)}<br>Tik of druk op spatie om opnieuw te spelen</span>`)}}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight'],['🔥',' ']],k=>{if(over)init()});
 c.onpointerdown=e=>{e.preventDefault();if(over){init();return}try{c.setPointerCapture(e.pointerId)}catch(x){}ptr=1;last=[e.clientX,e.clientY]};
 c.onpointermove=e=>{if(!ptr)return;const r=c.getBoundingClientRect();tx+=(e.clientX-last[0])/r.width*12;ty-=(e.clientY-last[1])/r.height*8;last=[e.clientX,e.clientY]};
 c.onpointerup=c.onpointercancel=()=>{ptr=0};
 const camP=new V3,look=new V3;
 const stopLoop=loop(dt=>{t+=dt;
  if(!over){
   const spd=Math.min(50,17+t*.45),want=Math.min(26,5+Math.floor(t/6));
   tx=Math.max(-4,Math.min(4,tx+((inp.has('ArrowRight')?1:0)-(inp.has('ArrowLeft')?1:0))*9*dt));ty=Math.max(-2.5,Math.min(2.5,ty+((inp.has('ArrowUp')?1:0)-(inp.has('ArrowDown')?1:0))*7*dt));
   const k=Math.min(1,10*dt);sx+=(tx-sx)*k;sy+=(ty-sy)*k;ship.position.set(sx,sy,0);ship.rotation.z=-(tx-sx)*.5;ship.rotation.x=(ty-sy)*.35;
   cool-=dt;if((inp.has(' ')||ptr)&&cool<=0){cool=.16;fire()}
   inv-=dt;ship.visible=inv<=0||Math.floor(t*14)%2===0;glow.scale.setScalar(1+Math.sin(t*25)*.25);
   let n=0;rocks.forEach(m=>{if(m.userData.on)n++});for(const m of rocks){if(n>=want)break;if(!m.userData.on){spawnRock(m);n++}}
   for(const m of rocks){const u=m.userData;if(!u.on)continue;m.position.z+=spd*u.v*dt;m.rotation.x+=u.rx*dt;m.rotation.y+=u.ry*dt;
    if(m.position.z>8){spawnRock(m);continue}
    if(inv<=0&&m.position.distanceTo(ship.position)<u.s*.9+.55){hit(m);if(over)break}}
   for(const b of bolts){if(!b.visible)continue;b.position.z-=75*dt;if(b.position.z<-130){b.visible=false;continue}
    for(const m of rocks){if(m.userData.on&&b.position.distanceTo(m.position)<m.userData.s*.95+.45){b.visible=false;kill(m,m.userData.s>1.1?30:10);break}}}
   for(let i=0;i<NPART;i++){if(pl[i]<=0)continue;pl[i]-=dt;pp[i*3]+=pv[i*3]*dt;pp[i*3+1]+=pv[i*3+1]*dt;pp[i*3+2]+=(pv[i*3+2]+spd*.6)*dt;if(pl[i]<=0)pp[i*3+2]=999}
   pg.attributes.position.needsUpdate=true;
   for(let i=2;i<NST*3;i+=3){spos[i]+=spd*.5*dt;if(spos[i]>10)spos[i]-=160}sg.attributes.position.needsUpdate=true;
  }
  hitF=Math.max(0,hitF-dt*2.5);shake=Math.max(0,shake-dt*2);S.background.copy(BG).lerp(FL,hitF*.6);
  camP.set(sx*.55+(Math.random()-.5)*shake*.5,sy*.5+4.2+(Math.random()-.5)*shake*.5,8);cam.position.copy(camP);cam.lookAt(look.set(sx*.55,sy*.5-.5,-12));
  T.r.render(S,cam);
  sc.textContent=`Score: ${score} · ${'🛡️'.repeat(Math.max(0,shields))||'💥'} · Beste: ${best('space3d',score)}`;
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;T.dispose()}}},
