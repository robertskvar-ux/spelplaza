{id:'tunnel3d',n:'Tunnelvlucht',e:'🌀',c:'3D',g:'#240b36,#c31432',nw:1,run(st){
 const W=360,H=480,T=three(st,W,H,{fov:72,far:140}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','◀ ▶ of sleep = draaien in de tunnel · vlieg door de opening · ontwijk balken · pak 💎'));
 const BG=0x05040f;S.background=new THREE.Color(BG);S.fog=new THREE.Fog(BG,38,118);
 const sun=new THREE.DirectionalLight(0xffffff,3);sun.position.set(2,6,5);S.add(sun,new THREE.AmbientLight(0xffffff,.6));
 const TR=4,LEN=120,SEG=40,RAD=32,PR=TR-.8,TAU=Math.PI*2,FAR=-LEN+16,AD=(a,b)=>{let d=(a-b)%TAU;if(d>Math.PI)d-=TAU;if(d<-Math.PI)d+=TAU;return d};
 const world=new THREE.Group();S.add(world);
 // neon grid tube (vertices bent every frame for the curved-tunnel look)
 const tc=document.createElement('canvas');tc.width=tc.height=64;const tx=tc.getContext('2d');tx.fillStyle='#0a0820';tx.fillRect(0,0,64,64);tx.fillStyle='#ffffff';tx.fillRect(0,0,64,3);tx.fillRect(0,0,2,64);tx.globalAlpha=.18;tx.fillRect(0,31,64,2);
 const tt=new THREE.CanvasTexture(tc);tt.wrapS=tt.wrapT=THREE.RepeatWrapping;tt.repeat.set(16,LEN/5);tt.anisotropy=T.r.capabilities.getMaxAnisotropy();
 const tg=new THREE.CylinderGeometry(TR,TR,LEN,RAD,SEG,true);tg.rotateX(Math.PI/2);tg.translate(0,0,-LEN/2+8);
 const tp=tg.attributes.position,base=Float32Array.from(tp.array);
 const tubeM=new THREE.MeshBasicMaterial({map:tt,side:THREE.BackSide,color:0xff3cac});const tube=new THREE.Mesh(tg,tubeM);tube.frustumCulled=false;world.add(tube);
 let kx=0,ky=0;const bx=z=>z<0?kx*z*z:0,by=z=>z<0?ky*z*z:0;
 // pools
 const add=(o,arr)=>{o.visible=false;world.add(o);arr.push(o);return o};
 const GAPS=[1.9,1.45,1.1],rings=[],bars=[],gems=[],halos=[];
 const ringMs=[0xff2e88,0xffb703,0x00f5d4].map(cl=>new THREE.MeshBasicMaterial({color:cl,transparent:true,opacity:.62,side:THREE.DoubleSide,depthWrite:false}));
 const edgeM=new THREE.LineBasicMaterial({color:0xffffff});
 GAPS.forEach((gp,gi)=>{const g=new THREE.RingGeometry(TR-1.75,TR-.02,28,1,gp/2,TAU-gp),eg=new THREE.EdgesGeometry(g);for(let i=0;i<4;i++){const o=new THREE.Group();o.add(new THREE.Mesh(g,ringMs[gi]),new THREE.LineSegments(eg,edgeM));o.userData={k:0,gi,gap:gp};add(o,rings)}});
 const barG=new THREE.BoxGeometry(2*TR,.55,.55),barM=new THREE.MeshStandardMaterial({color:0x3df2ff,emissive:0x0a8fb0,roughness:.3}),hubM=new THREE.MeshStandardMaterial({color:0xffffff,emissive:0x444466});
 const hubG=new THREE.SphereGeometry(.55,14,10);
 for(let i=0;i<6;i++){const o=new THREE.Group(),a=new THREE.Mesh(barG,barM),b=new THREE.Mesh(barG,barM);b.rotation.z=Math.PI/2;o.add(a,b,new THREE.Mesh(hubG,hubM));o.userData={k:1,b};add(o,bars)}
 const gemG=new THREE.OctahedronGeometry(.32),gemM=new THREE.MeshStandardMaterial({color:0xfff07a,emissive:0xb08800,roughness:.2,metalness:.3});
 for(let i=0;i<24;i++){const o=new THREE.Mesh(gemG,gemM);o.scale.y=1.5;o.userData={k:2};add(o,gems)}
 const haloG=new THREE.TorusGeometry(TR-.04,.05,6,40),haloM=new THREE.MeshBasicMaterial({color:0xb9a8ff,transparent:true,opacity:.45});
 for(let i=0;i<8;i++){const o=new THREE.Mesh(haloG,haloM);world.add(o);halos.push(o)}
 // ship
 const ship=new THREE.Group(),std=o=>new THREE.MeshStandardMaterial(o);
 const nose=new THREE.Mesh(new THREE.ConeGeometry(.26,1.2,8),std({color:0xf2f4ff,roughness:.3,metalness:.4}));nose.rotation.x=-Math.PI/2;
 const wing=new THREE.Mesh(new THREE.BoxGeometry(1.15,.06,.42),std({color:0x7b2ff7,emissive:0x2a0866,roughness:.4}));wing.position.set(0,0,.3);
 const fin=new THREE.Mesh(new THREE.BoxGeometry(.06,.3,.4),std({color:0x7b2ff7}));fin.position.set(0,.18,.38);
 const flame=new THREE.Mesh(new THREE.ConeGeometry(.16,.7,8),new THREE.MeshBasicMaterial({color:0x48e5ff,transparent:true,opacity:.85}));flame.rotation.x=Math.PI/2;flame.position.z=.9;
 ship.add(nose,wing,fin,flame);ship.position.set(0,-PR,0);S.add(ship);
 // crash particles
 const NP=90,pg=new THREE.BufferGeometry(),pp=new Float32Array(NP*3).fill(999),pv=new Float32Array(NP*3);pg.setAttribute('position',new THREE.BufferAttribute(pp,3));
 const dc=document.createElement('canvas');dc.width=dc.height=32;const dx=dc.getContext('2d'),dg=dx.createRadialGradient(16,16,0,16,16,16);dg.addColorStop(0,'#fff');dg.addColorStop(.4,'rgba(255,255,255,.8)');dg.addColorStop(1,'rgba(255,255,255,0)');dx.fillStyle=dg;dx.fillRect(0,0,32,32);
 const parts=new THREE.Points(pg,new THREE.PointsMaterial({map:new THREE.CanvasTexture(dc),color:0xffc04d,size:.45,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));parts.frustumCulled=false;S.add(parts);
 function burst(){for(let i=0;i<NP;i++){pp[i*3]=0;pp[i*3+1]=-PR;pp[i*3+2]=0;const a=Math.random()*TAU,b=(Math.random()-.5)*Math.PI,r=3+Math.random()*7;pv[i*3]=Math.cos(a)*Math.cos(b)*r;pv[i*3+1]=Math.sin(b)*r+2;pv[i*3+2]=Math.sin(a)*Math.cos(b)*r-4}parts.material.opacity=1}
 let pa,pvel,sp,dist,gemN,score,over,deadAt,spawnD,lastA,t,shake,drag=null,partT;
 function init(){pa=0;pvel=0;sp=16;dist=0;gemN=0;score=0;over=0;spawnD=40;lastA=0;t=0;shake=0;partT=0;drag=null;
  [...rings,...bars,...gems].forEach(o=>o.visible=false);halos.forEach((h,i)=>h.position.z=6-i*15);ship.visible=true;pp.fill(999);pg.attributes.position.needsUpdate=true;overlay(st,c,'')}
 const take=a=>a.find(o=>!o.visible);
 function place(o,z){o.visible=true;o.position.z=z;o.userData.pz=z;return o}
 function gemLine(a0,a1,z,n){for(let i=0;i<n;i++){const g=take(gems);if(!g)return;const a=a0+(a1-a0)*i/Math.max(1,n-1);place(g,z+i*2.4);g.userData.a=a;g.userData.on=1}}
 function spawn(){const lvl=Math.min(2,Math.floor(dist/700)),reach=Math.min(2.6,3.2*(spacing()/sp)*.75),r=Math.random();
  const na=lastA+(Math.random()*2-1)*reach;
  if(dist<120||r<.55){const gi=Math.min(2,R(lvl+1)+(dist>1500?1:0)),o=take(rings.filter(x=>x.userData.gi===gi));if(!o)return;place(o,FAR);o.rotation.z=na;o.userData.a=na;
   if(Math.random()<.6)gemLine(lastA,na,FAR+6,4);lastA=na}
  else{const o=take(bars);if(!o)return;place(o,FAR);const u=o.userData;u.cross=dist>900&&Math.random()<.4;u.b.visible=u.cross;u.w=(Math.random()<.5?-1:1)*(.7+Math.random()*(.5+lvl*.4));u.a=Math.random()*TAU;o.rotation.z=u.a;
   if(Math.random()<.5)gemLine(lastA,lastA,FAR+5,3)}}
 const spacing=()=>Math.max(15,32-dist/90);
 function die(){over=1;deadAt=performance.now();shake=1;ship.visible=false;burst();partT=1.4;score+=Math.floor(dist);const b=best('tunnel3d',score);sc.textContent=`Score: ${score} · ${Math.floor(dist)} m · 💎 ${gemN} · Beste: ${b} · Gecrasht`;beep(150,.3,'sawtooth',.06);setTimeout(()=>beep(80,.35,'sawtooth',.05),110);
  overlay(st,c,`💥 Gecrasht!<br><span style="font-size:15px;font-weight:600">${Math.floor(dist)} m · 💎 ${gemN} · Score ${score}<br>Beste: ${b}<br>Tik of druk op een toets om opnieuw te vliegen</span>`).style.pointerEvents='none'}
 const again=()=>{if(over&&performance.now()-deadAt>800)init()};
 const inp=input(st,[['◀','ArrowLeft'],['▶','ArrowRight']],k=>again());
 c.onpointerdown=e=>{e.preventDefault();if(over){again();return}try{c.setPointerCapture(e.pointerId)}catch(x){}drag=e.clientX};
 c.onpointermove=e=>{if(drag==null||over)return;const r=c.getBoundingClientRect(),dx=(e.clientX-drag)*W/r.width;drag=e.clientX;pa+=dx*.016};
 c.onpointerup=c.onpointercancel=()=>{drag=null};
 const stopLoop=loop(dt=>{t+=dt;
  if(!over){sp=Math.min(50,16+dist/45);dist+=sp*dt;
   const dir=(inp.has('ArrowRight')||inp.has('d')?1:0)-(inp.has('ArrowLeft')||inp.has('a')?1:0);pvel+=(dir*3.2-pvel)*Math.min(1,dt*10);pa+=pvel*dt;
   spawnD-=sp*dt;if(spawnD<=0){spawn();spawnD=spacing()}}
  const dz=over?sp*dt*Math.max(0,1-(performance.now()-deadAt)/500):sp*dt;
  kx=.0032*Math.sin(t*.23)+.0012*Math.sin(t*.57);ky=.0024*Math.sin(t*.19+1.3);
  world.rotation.z=-Math.PI/2-pa;tt.offset.y-=dz/5;
  const hue=(dist/1400+.88)%1;tubeM.color.setHSL(hue,.9,.5);
  for(let i=0;i<tp.count;i++){const z=base[i*3+2];tp.array[i*3]=base[i*3]+bx(z);tp.array[i*3+1]=base[i*3+1]+by(z)}tp.needsUpdate=true;
  for(const h of halos){h.position.z+=dz;if(h.position.z>8)h.position.z-=8*15;h.position.x=bx(h.position.z);h.position.y=by(h.position.z)}
  for(const o of rings)if(o.visible){const u=o.userData,z0=o.position.z;o.position.z+=dz;const z=o.position.z;o.position.x=bx(z);o.position.y=by(z);
   if(!over&&z0<0&&z>=0){if(Math.abs(AD(pa,u.a))>u.gap/2-.13)die();else{score+=5;beep(660,.04,'sine',.03)}}if(z>8)o.visible=false}
  for(const o of bars)if(o.visible){const u=o.userData,z0=o.position.z;o.position.z+=dz;const z=o.position.z;o.position.x=bx(z);o.position.y=by(z);if(!over)u.a+=u.w*dt;o.rotation.z=u.a;o.rotation.y=0;
   if(!over&&z0<-.3&&z>=-.3){const n=u.cross?4:2;let hit=0;for(let k=0;k<n;k++)if(Math.abs(AD(pa,u.a+k*TAU/n))<.27)hit=1;if(hit)die();else score+=5}if(z>8)o.visible=false}
  for(const o of gems)if(o.visible){const u=o.userData;o.position.z+=dz;const z=o.position.z;o.position.x=bx(z)+Math.cos(u.a)*PR;o.position.y=by(z)+Math.sin(u.a)*PR;o.rotation.y+=dt*4;
   if(!over&&Math.abs(z)<.9&&Math.abs(AD(pa,u.a))<.32){o.visible=false;gemN++;score+=20;beep(990+gemN%5*90,.06,'triangle',.05)}if(z>8)o.visible=false}
  if(partT>0){partT-=dt;for(let i=0;i<NP;i++){pv[i*3+1]-=6*dt;pp[i*3]+=pv[i*3]*dt;pp[i*3+1]+=pv[i*3+1]*dt;pp[i*3+2]+=pv[i*3+2]*dt}pg.attributes.position.needsUpdate=true;parts.material.opacity=Math.max(0,partT/1.4)}
  ship.rotation.z=-pvel*.18;ship.position.y=-PR+Math.sin(t*6)*.04;flame.scale.set(1,.8+Math.random()*.5,1);
  if(shake>0)shake=Math.max(0,shake-dt*1.8);const sh=shake*shake*.6;
  cam.position.set((Math.random()-.5)*sh,-PR+2.05+(Math.random()-.5)*sh,4.2);cam.lookAt(0,-PR+.55,-10);
  if(!over){const m=Math.floor(dist);sc.textContent=`Score: ${m+score} · ${m} m · 💎 ${gemN} · Beste: ${best('tunnel3d',0)}`}
  T.r.render(S,cam)});
 init();cur.reset=init;
 return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;T.dispose()}}},
