{id:'asteroids',n:'Asteroïden',e:'☄️',c:'Arcade',g:'#0f0c29,#302b63',nw:1,run(st){
 const W=380,H=380,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','◀ ▶ draaien · ▲ gas · spatie / 🔥 schieten · slepen = draaien, tik = schieten'));
 const RAD=[0,12,22,38],PTS=[0,100,50,20],stars=[];for(let i=0;i<60;i++)stars.push({x:R(W),y:R(H),s:Math.random()<.25?2:1,b:.3+Math.random()*.7});
 let ship,ast,bul,parts,score,lives,level,over,overT,respT,inv,shootT,levelT,thr,t,drag,dsx,dmv;
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function mkAst(sz,px,py,vx,vy){const n=9+R(4),v=[];for(let i=0;i<n;i++)v.push(.72+Math.random()*.4);return{x:px,y:py,vx,vy,sz,r:RAD[sz],v,a:Math.random()*7,va:(Math.random()-.5)*2}}
 function spawnAst(n){for(let i=0;i<n;i++){let px,py;do{px=Math.random()*W;py=Math.random()*H}while(Math.hypot(px-W/2,py-H/2)<130);const a=Math.random()*7,s=(28+Math.random()*36)*(1+level*.12);ast.push(mkAst(3,px,py,Math.cos(a)*s,Math.sin(a)*s))}}
 function newShip(){ship={x:W/2,y:H/2,vx:0,vy:0,a:-Math.PI/2,r:11};inv=2.5;respT=0}
 function init(){score=0;lives=3;level=1;over=0;overT=0;ast=[];bul=[];parts=[];t=0;shootT=0;levelT=0;drag=0;newShip();spawnAst(4);ov('')}
 function boom(bx,by,col,n,ln){for(let i=0;i<n;i++){const a=Math.random()*7,s=30+Math.random()*110;parts.push({x:bx,y:by,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:.5+Math.random()*.6,c:col,ln:ln?6+R(10):0,an:a,va:(Math.random()-.5)*6})}}
 function shoot(){if(over||!ship||respT>0||bul.length>=4||shootT>0)return;const ca=Math.cos(ship.a),sa=Math.sin(ship.a);bul.push({x:ship.x+ca*14,y:ship.y+sa*14,vx:ship.vx+ca*430,vy:ship.vy+sa*430,l:1.1,r:2});shootT=.22;beep(1000,.05,'square',.025)}
 function split(i){const a=ast[i];ast.splice(i,1);score+=PTS[a.sz];boom(a.x,a.y,'#cfd8ff',6+a.sz*4);beep(80+a.sz*45,.12,'sawtooth',.04);
  if(a.sz>1)for(let k=0;k<2;k++){const an=Math.random()*7,s=(45+Math.random()*50)*(1+level*.1);ast.push(mkAst(a.sz-1,a.x,a.y,a.vx*.4+Math.cos(an)*s,a.vy*.4+Math.sin(an)*s))}}
 function die(){lives--;boom(ship.x,ship.y,'#7ef0ff',14);boom(ship.x,ship.y,'#7ef0ff',6,1);ship=null;respT=1.8;beep(130,.45,'sawtooth',.06)}
 function gameOver(){over=1;overT=0;best('asteroids',score);ov(`💥 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('asteroids',score)}<br>Tik of druk op spatie om opnieuw te spelen</span>`)}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['🔥',' '],['▶','ArrowRight']],k=>{if(over){if(overT>.5)init();return}if(k===' ')shoot()});
 const px=e=>{const r=c.getBoundingClientRect();return(e.clientX-r.left)*W/r.width};
 c.onpointerdown=e=>{e.preventDefault();if(over){if(overT>.5)init();return}drag=1;dsx=px(e);dmv=0;try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointermove=e=>{if(!drag||!ship)return;const nx=px(e),dx=nx-dsx;dsx=nx;dmv+=Math.abs(dx);ship.a+=dx*.014};
 c.onpointerup=e=>{if(drag&&dmv<6)shoot();drag=0};c.onpointercancel=()=>{drag=0};
 const wrap=o=>{if(o.x<-o.r)o.x+=W+2*o.r;else if(o.x>W+o.r)o.x-=W+2*o.r;if(o.y<-o.r)o.y+=H+2*o.r;else if(o.y>H+o.r)o.y-=H+2*o.r};
 const stopLoop=loop(dt=>{
  t+=dt;if(over)overT+=dt;thr=0;
  if(!over){
   shootT-=dt;
   if(respT>0){respT-=dt;if(respT<=0){if(lives<=0)gameOver();else if(ast.some(a=>Math.hypot(a.x-W/2,a.y-H/2)<a.r+75))respT=.25;else newShip()}}
   else if(ship){
    if(inp.has('ArrowLeft')||inp.has('a'))ship.a-=4*dt;if(inp.has('ArrowRight')||inp.has('d'))ship.a+=4*dt;
    if(inp.has('ArrowUp')||inp.has('w')){thr=1;ship.vx+=Math.cos(ship.a)*290*dt;ship.vy+=Math.sin(ship.a)*290*dt}
    const dmp=Math.pow(.4,dt);ship.vx*=dmp;ship.vy*=dmp;const sp=Math.hypot(ship.vx,ship.vy);if(sp>330){ship.vx*=330/sp;ship.vy*=330/sp}
    ship.x+=ship.vx*dt;ship.y+=ship.vy*dt;wrap(ship);inv-=dt;if(inp.has(' '))shoot()}
   for(const a of ast){a.x+=a.vx*dt;a.y+=a.vy*dt;a.a+=a.va*dt;wrap(a)}
   for(const b of bul){b.x+=b.vx*dt;b.y+=b.vy*dt;b.l-=dt;wrap(b)}bul=bul.filter(b=>b.l>0);
   for(const b of bul){for(let i=0;i<ast.length;i++){const a=ast[i];if(Math.hypot(a.x-b.x,a.y-b.y)<a.r*.92){split(i);b.l=0;break}}}bul=bul.filter(b=>b.l>0);
   if(ship&&inv<=0)for(const a of ast)if(Math.hypot(a.x-ship.x,a.y-ship.y)<a.r*.85+8){die();break}
   if(!ast.length){if(levelT<=0){levelT=2.2;beep(660,.15,'square',.04)}else{levelT-=dt;if(levelT<=0){level++;spawnAst(3+level)}}}
  }
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.an+=p.va*dt;p.l-=dt}parts=parts.filter(p=>p.l>0);
  // tekenen
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);for(const s of stars){x.globalAlpha=s.b*(.6+.4*Math.sin(t*2+s.x));x.fillStyle='#9aa3d8';x.fillRect(s.x,s.y,s.s,s.s)}x.globalAlpha=1;
  x.lineWidth=2;x.lineJoin='round';
  for(const a of ast){x.beginPath();for(let i=0;i<a.v.length;i++){const an=a.a+i/a.v.length*Math.PI*2,rr=a.r*a.v[i];x[i?'lineTo':'moveTo'](a.x+Math.cos(an)*rr,a.y+Math.sin(an)*rr)}x.closePath();x.fillStyle='#181c3c';x.fill();x.strokeStyle=a.sz===3?'#cfd8ff':a.sz===2?'#b4bdf0':'#9aa3d8';x.stroke()}
  if(ship&&(inv<=0||Math.floor(t*8)%2)){x.save();x.translate(ship.x,ship.y);x.rotate(ship.a);x.strokeStyle='#7ef0ff';x.fillStyle='#10304a';x.beginPath();x.moveTo(15,0);x.lineTo(-11,9);x.lineTo(-7,0);x.lineTo(-11,-9);x.closePath();x.fill();x.stroke();
   if(thr&&Math.floor(t*25)%3){x.strokeStyle='#ffb347';x.beginPath();x.moveTo(-9,5);x.lineTo(-18-R(8),0);x.lineTo(-9,-5);x.stroke()}x.restore()}
  x.fillStyle='#fff';for(const b of bul){x.beginPath();x.arc(b.x,b.y,2,0,7);x.fill()}
  for(const p of parts){x.globalAlpha=Math.min(1,p.l);if(p.ln){x.strokeStyle=p.c;x.beginPath();x.moveTo(p.x-Math.cos(p.an)*p.ln,p.y-Math.sin(p.an)*p.ln);x.lineTo(p.x+Math.cos(p.an)*p.ln,p.y+Math.sin(p.an)*p.ln);x.stroke()}else{x.fillStyle=p.c;x.fillRect(p.x-1.5,p.y-1.5,3,3)}}x.globalAlpha=1;
  x.strokeStyle='#7ef0ff';x.lineWidth=1.5;for(let i=0;i<Math.max(0,lives);i++){x.beginPath();x.moveTo(14+i*18,8);x.lineTo(20+i*18,22);x.lineTo(14+i*18,18);x.lineTo(8+i*18,22);x.closePath();x.stroke()}
  x.fillStyle='#8a90b8';x.font='bold 12px system-ui,sans-serif';x.textAlign='right';x.fillText('LEVEL '+level,W-10,18);
  if(levelT>0&&!over){x.fillStyle='#fff';x.font='bold 24px system-ui,sans-serif';x.textAlign='center';x.fillText('Level '+(level+1),W/2,H/2-40)}
  sc.textContent='Score: '+score+' · Beste: '+best('asteroids',score)+' · Level '+level+(over?' · Game over':'');
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
