{id:'race3d',n:'Race 3D',e:'🏎️',c:'3D',g:'#000000,#e74c3c',nw:1,run(st){
 const W=360,H=480,T=three(st,W,H,{fov:62,far:300}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','◀ ▶ of houd links/rechts op het scherm · haal in zonder te botsen · rakelings passeren = bonus'));
 const BG=0x0d0f1f;S.background=new THREE.Color(BG);S.fog=new THREE.Fog(BG,40,180);
 const sun=new THREE.DirectionalLight(0xfff0dd,2.6);sun.position.set(-6,12,8);S.add(sun,new THREE.HemisphereLight(0x5566aa,0x101018,1));
 const std=o=>new THREE.MeshStandardMaterial(o),box=(w,h,d)=>new THREE.BoxGeometry(w,h,d),M=new THREE.Matrix4();
 // static world: grass, asphalt, solid edge lines, distant stars
 const ground=new THREE.Mesh(new THREE.PlaneGeometry(400,500),std({color:0x16301e,roughness:1}));ground.rotation.x=-Math.PI/2;ground.position.set(0,-.02,-150);S.add(ground);
 const road=new THREE.Mesh(new THREE.PlaneGeometry(10.8,500),std({color:0x2a2b36,roughness:.95}));road.rotation.x=-Math.PI/2;road.position.set(0,0,-150);S.add(road);
 const lineM=std({color:0xf1c40f,emissive:0x5a4400});[-5.1,5.1].forEach(x=>{const m=new THREE.Mesh(box(.16,.02,500),lineM);m.position.set(x,.01,-150);S.add(m)});
 const sg=new THREE.BufferGeometry(),sp_=new Float32Array(750);for(let i=0;i<250;i++){sp_[i*3]=(Math.random()-.5)*500;sp_[i*3+1]=15+Math.random()*150;sp_[i*3+2]=-280+Math.random()*100}sg.setAttribute('position',new THREE.BufferAttribute(sp_,3));
 const stars=new THREE.Points(sg,new THREE.PointsMaterial({color:0xffffff,size:2,sizeAttenuation:false,fog:false}));stars.frustumCulled=false;S.add(stars);
 // periodic scenery: instanced lane dashes (period 6) and posts (period 12), scrolled by distance modulo period
 const ND=32,dash=new THREE.InstancedMesh(box(.16,.02,3),std({color:0xe8e8f0,emissive:0x555555}),ND*2);dash.frustumCulled=false;S.add(dash);
 const NP=16,post=new THREE.InstancedMesh(box(.2,1,.2),std({color:0xdddddd,emissive:0x222222}),NP*2);post.frustumCulled=false;S.add(post);
 for(let i=0;i<ND;i++){M.makeTranslation(-1.5,.01,-i*6);dash.setMatrixAt(i*2,M);M.makeTranslation(1.5,.01,-i*6);dash.setMatrixAt(i*2+1,M)}
 for(let i=0;i<NP;i++){M.makeTranslation(-5.9,.5,-i*12);post.setMatrixAt(i*2,M);M.makeTranslation(5.9,.5,-i*12);post.setMatrixAt(i*2+1,M)}
 // recycled tree segments
 const SEG=26,NS=7,coneG=new THREE.ConeGeometry(1.6,4,7),trunkG=new THREE.CylinderGeometry(.25,.3,1.6,6),coneM=std({color:0x1f6b3a,roughness:.9}),trunkM=std({color:0x5a3a1a});
 function shuffleSeg(g){g.children.forEach((tr,k)=>{const s=.7+Math.random()*.8;tr.position.set((k<2?-1:1)*(7.5+Math.random()*10),0,-Math.random()*SEG);tr.scale.set(s,s,s)})}
 const segs=[];for(let s=0;s<NS;s++){const g=new THREE.Group();g.position.z=-s*SEG;for(let k=0;k<4;k++){const tr=new THREE.Group(),tk=new THREE.Mesh(trunkG,trunkM),cn=new THREE.Mesh(coneG,coneM);tk.position.y=.8;cn.position.y=2.6;tr.add(tk,cn);g.add(tr)}shuffleSeg(g);S.add(g);segs.push(g)}
 // cars built from boxes
 const wheelG=new THREE.CylinderGeometry(.36,.36,.3,12),wheelM=std({color:0x151515,roughness:.9}),glassM=std({color:0x1b2230,roughness:.2,metalness:.4}),tailM=new THREE.MeshBasicMaterial({color:0xff3b3b}),headM=new THREE.MeshBasicMaterial({color:0xfff7cc});
 function mkCar(color,me){const g=new THREE.Group(),b=new THREE.Mesh(box(1.8,.55,4),std({color,roughness:.4,metalness:.2}));b.position.y=.55;const cb=new THREE.Mesh(glassG,glassM);cb.position.set(0,1.05,.1);g.add(b,cb);
  [[-.95,-1.3],[.95,-1.3],[-.95,1.3],[.95,1.3]].forEach(([x,z])=>{const w=new THREE.Mesh(wheelG,wheelM);w.rotation.z=Math.PI/2;w.position.set(x,.36,z);g.add(w)});
  const tl=new THREE.Mesh(lightG,tailM);tl.position.set(0,.65,2.01);g.add(tl);if(me){const hl=new THREE.Mesh(lightG,headM);hl.position.set(0,.6,-2.01);g.add(hl)}return g}
 const glassG=box(1.5,.5,1.9),lightG=box(1.5,.16,.08),COLS=[0x3498db,0xf1c40f,0x2ecc71,0x9b59b6,0xe67e22,0xecf0f1,0x1abc9c,0xff7675];
 const traffic=[];for(let i=0;i<8;i++){const g=mkCar(COLS[i]);g.visible=false;S.add(g);traffic.push({g,on:0,lane:0,x:0,z:0,v:0,passed:0})}
 const car=mkCar(0xe74c3c,1);S.add(car);
 let px,sv,speed,dist,score,bonus,over,crash,ct,t,flashT,shake,hold;
 function init(){px=0;sv=0;speed=28;dist=0;score=0;bonus=0;over=0;crash=0;ct=0;t=0;flashT=0;shake=0;hold=0;traffic.forEach(o=>{o.on=0;o.g.visible=false});car.rotation.set(0,0,0);car.position.set(0,0,0);overlay(st,c,'')}
 function spawn(o){for(let i=0;i<12;i++){const lane=R(3)-1,z=-160-R(90);let ok=1,near=0;
   for(const q of traffic){if(!q.on||q===o)continue;const dz=Math.abs(q.z-z);if(q.lane===lane&&dz<18)ok=0;else if(dz<14)near++}
   if(ok&&near<2){o.on=1;o.lane=lane;o.x=lane*3;o.z=z;o.v=[19,15,12][lane+1];o.passed=0;o.g.visible=true;o.g.position.set(o.x,0,o.z);return}}}
 function doCrash(){crash=1;ct=0;shake=1;beep(90,.5,'sawtooth',.07)}
 function gameOver(){over=1;score=Math.floor(dist)+bonus;best('race3d',score);const o=overlay(st,c,`💥 Gecrasht!<br><span style="font-size:15px;font-weight:600">Afstand ${Math.floor(dist)} m · Score ${score} · Beste ${best('race3d',score)}<br>Tik of druk op een toets om opnieuw te spelen</span>`);o.onpointerdown=e=>{e.preventDefault();init()}}
 const inp=input(st,[['◀','ArrowLeft'],['▶','ArrowRight']],k=>{if(over)init()});
 function setHold(e){const r=c.getBoundingClientRect();hold=(e.clientX-r.left)<r.width/2?-1:1}
 c.onpointerdown=e=>{e.preventDefault();if(over){init();return}try{c.setPointerCapture(e.pointerId)}catch(x){}setHold(e)};
 c.onpointermove=e=>{if(hold)setHold(e)};c.onpointerup=c.onpointercancel=()=>{hold=0};
 const stopLoop=loop(dt=>{t+=dt;
  if(!over){
   if(!crash){speed=Math.min(80,28+t*.7);dist+=speed*dt;score=Math.floor(dist)+bonus;flashT-=dt;
    const dir=Math.max(-1,Math.min(1,(inp.has('ArrowRight')?1:0)-(inp.has('ArrowLeft')?1:0)+hold));sv+=(dir-sv)*Math.min(1,8*dt);px=Math.max(-3.7,Math.min(3.7,px+sv*7.5*dt));
    car.position.x=px;car.rotation.z=-sv*.1;car.rotation.y=-sv*.2;
    const want=Math.min(8,3+Math.floor(dist/350));let n=traffic.filter(o=>o.on).length;for(const o of traffic){if(n>=want)break;if(!o.on){spawn(o);if(o.on)n++}}
    for(const o of traffic){if(!o.on)continue;const dx=Math.abs(o.x-px);if(Math.abs(o.z)<3.9&&dx<1.85){doCrash();break}
     if(!o.passed&&o.z>0){o.passed=1;if(dx<2.9){bonus+=50;flashT=1.2;beep(1200,.07,'triangle',.05)}}}
   }else{ct+=dt;speed*=Math.exp(-3*dt);dist+=speed*dt;car.rotation.y+=7*dt;car.rotation.z=Math.sin(ct*12)*.25*Math.max(0,1-ct);car.position.y=Math.max(0,Math.sin(ct*9)*.3*(1-ct));shake=Math.max(0,1-ct/1.2);if(ct>1.4)gameOver()}
   // scroll world + traffic
   dash.position.z=dist%6;post.position.z=dist%12;
   segs.forEach(g=>{g.position.z+=speed*dt;if(g.position.z>SEG){g.position.z-=NS*SEG;shuffleSeg(g)}});
   for(const o of traffic){if(!o.on)continue;o.z+=(speed-o.v)*dt;o.g.position.z=o.z;if(o.z>16){o.on=0;o.g.visible=false}}
  }
  const cx=px*.6;cam.position.set(cx+(Math.random()-.5)*shake*.7,4+(Math.random()-.5)*shake*.5,9);cam.lookAt(cx,.6,-14);
  T.r.render(S,cam);
  sc.textContent=`Score: ${score} · ${over?0:Math.round(speed*3.6)} km/u · Beste: ${best('race3d',score)}${flashT>0?' · ⚡ Bijna! +50':''}`;
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;T.dispose()}}},
