{id:'lander',n:'Maanlander',e:'🚀',c:'Arcade',g:'#2c3e50,#4ca1af',nw:1,run(st){
 const W=400,H=400,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','▲ / spatie / 🔥 / scherm vasthouden = stuwkracht · ◀ ▶ = draaien · land zacht op een groen platform'));
 const GR=26,TH=80,stars=[];for(let i=0;i<70;i++)stars.push({x:R(W),y:R(260),s:Math.random()<.2?2:1,b:.3+Math.random()*.7});
 let L,ter,pads,fuel,fuel0,score,lives,level,over,overT,state,stT,parts,t,pthr,thr,lastPts;
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 const gy=px=>{const i=Math.max(0,Math.min(39,Math.floor(px/10))),f=px/10-i;return ter[i]+(ter[i+1]-ter[i])*f};
 function genTerrain(){pads=[];const n=2+R(2);let tries=0;while(pads.length<n&&tries++<200){const w=[4,6,8][R(3)],i0=2+R(36-w);if(pads.some(p=>i0<p.i0+p.w+3&&i0+w+3>p.i0))continue;pads.push({i0,w,m:w===4?3:w===6?2:1})}
  ter=[];let y=300+R(60);for(let i=0;i<=40;i++){const p=pads.find(p=>i>=p.i0&&i<=p.i0+p.w);if(p){if(i===p.i0){y=Math.max(262,Math.min(372,y));p.y=y}}else y=Math.max(230,Math.min(385,y+(Math.random()-.5)*64));ter.push(y)}}
 function spawn(){L={x:60+R(W-120),y:36,vx:(R(2)?1:-1)*(12+R(18)),vy:0,a:0};fuel=fuel0;state='fly';stT=0;thr=0;pthr=0}
 function newLevel(){fuel0=Math.max(45,100-12*(level-1));genTerrain();spawn();ov('')}
 function init(){score=0;lives=3;level=1;over=0;overT=0;parts=[];t=0;lastPts=0;newLevel()}
 function boom(bx,by,n){for(let i=0;i<n;i++){const a=Math.random()*7,s=30+Math.random()*140;parts.push({x:bx,y:by,vx:Math.cos(a)*s,vy:Math.sin(a)*s-40,l:.6+Math.random()*.9,c:R(2)?'#ffb347':'#d9dde8'})}}
 function gameOver(){over=1;overT=0;best('lander',score);ov(`💥 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('lander',score)}<br>Tik of druk op een toets om opnieuw te spelen</span>`)}
 function next(){level++;newLevel()}
 const act=()=>{if(over){if(overT>.5)init();return 1}if(state==='landed'){if(stT>.4)next();return 1}return 0};
 const inp=input(st,[['◀','ArrowLeft'],['🔥',' '],['▶','ArrowRight']],k=>{act()});
 c.onpointerdown=e=>{e.preventDefault();if(act())return;pthr=1;try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointerup=c.onpointercancel=()=>{pthr=0};
 const stopLoop=loop(dt=>{
  t+=dt;if(over)overT+=dt;stT+=dt;
  if(!over&&state==='fly'){
   const rot=(inp.has('ArrowLeft')||inp.has('a')?-1:0)+(inp.has('ArrowRight')||inp.has('d')?1:0);L.a=Math.max(-1.9,Math.min(1.9,L.a+rot*2.4*dt));
   thr=(inp.has('ArrowUp')||inp.has(' ')||inp.has('w')||pthr)&&fuel>0;
   if(thr){fuel=Math.max(0,fuel-11*dt);L.vx+=Math.sin(L.a)*TH*dt;L.vy-=Math.cos(L.a)*TH*dt}
   L.vy+=GR*dt;L.x+=L.vx*dt;L.y+=L.vy*dt;
   if(L.x<12){L.x=12;L.vx=Math.abs(L.vx)*.3}if(L.x>W-12){L.x=W-12;L.vx=-Math.abs(L.vx)*.3}if(L.y<14){L.y=14;L.vy=Math.max(0,L.vy)}
   const ca=Math.cos(L.a),sa=Math.sin(L.a),feet=[[-13,13],[13,13]].map(([fx,fy])=>[L.x+fx*ca-fy*sa,L.y+fx*sa+fy*ca]);
   if(feet.some(([fx,fy])=>fy>=gy(fx))||L.y+4>=gy(L.x)){
    const pad=pads.find(p=>feet.every(([fx])=>fx>=p.i0*10-2&&fx<=(p.i0+p.w)*10+2));
    if(pad&&L.vy<15&&Math.abs(L.vx)<10&&Math.abs(L.a)<.2){state='landed';stT=0;L.y=pad.y-13;L.a=0;L.vx=L.vy=0;lastPts=50*pad.m+Math.round(fuel);score+=lastPts;best('lander',score);beep(660,.2,'square',.05);
     ov(`🚀 Geland! ×${pad.m}<br><span style="font-size:15px;font-weight:600">+${lastPts} punten (brandstofbonus ${Math.round(fuel)})<br>Tik of druk op een toets voor level ${level+1}</span>`)}
    else{state='crash';stT=0;lives--;boom(L.x,L.y,36);beep(90,.5,'sawtooth',.06)}}}
  else if(!over&&state==='crash'&&stT>1.8){if(lives<=0)gameOver();else spawn()}
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=60*dt;p.l-=dt;if(p.y>gy(p.x)){p.y=gy(p.x);p.vy=-p.vy*.4;p.vx*=.7}}parts=parts.filter(p=>p.l>0);
  // tekenen
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);for(const s of stars){x.globalAlpha=s.b*(.6+.4*Math.sin(t*1.5+s.x));x.fillStyle='#9aa3d8';x.fillRect(s.x,s.y,s.s,s.s)}x.globalAlpha=1;
  x.beginPath();x.moveTo(0,ter[0]);for(let i=1;i<=40;i++)x.lineTo(i*10,ter[i]);x.lineTo(W,H);x.lineTo(0,H);x.closePath();x.fillStyle='#1a2140';x.fill();x.strokeStyle='#8da2c0';x.lineWidth=2;x.beginPath();x.moveTo(0,ter[0]);for(let i=1;i<=40;i++)x.lineTo(i*10,ter[i]);x.stroke();
  x.strokeStyle='#38ef7d';x.lineWidth=4;x.font='bold 11px system-ui,sans-serif';x.textAlign='center';for(const p of pads){x.beginPath();x.moveTo(p.i0*10,p.y);x.lineTo((p.i0+p.w)*10,p.y);x.stroke();x.fillStyle='#38ef7d';x.fillText('×'+p.m,(p.i0+p.w/2)*10,p.y-8)}
  if(state!=='crash'){x.save();x.translate(L.x,L.y);x.rotate(L.a);x.scale(1.3,1.3);
   x.strokeStyle='#aab';x.lineWidth=2;x.beginPath();x.moveTo(-5,4);x.lineTo(-10,10);x.moveTo(5,4);x.lineTo(10,10);x.stroke();x.fillStyle='#aab';x.fillRect(-13,9,6,2);x.fillRect(7,9,6,2);
   x.fillStyle='#d9dde8';x.beginPath();x.moveTo(-7,-2);x.lineTo(-4,-10);x.lineTo(4,-10);x.lineTo(7,-2);x.lineTo(7,4);x.lineTo(-7,4);x.closePath();x.fill();x.fillStyle='#4ca1af';x.beginPath();x.arc(0,-4,2.6,0,7);x.fill();x.fillStyle='#777';x.fillRect(-3,4,6,3);
   if(thr&&state==='fly'){const fl=12+R(8);x.fillStyle='#ffb347';x.beginPath();x.moveTo(-4,7);x.lineTo(0,7+fl);x.lineTo(4,7);x.closePath();x.fill();x.fillStyle='#fff3a0';x.beginPath();x.moveTo(-2,7);x.lineTo(0,7+fl*.5);x.lineTo(2,7);x.closePath();x.fill()}x.restore()}
  for(const p of parts){x.globalAlpha=Math.min(1,p.l);x.fillStyle=p.c;x.fillRect(p.x-1.5,p.y-1.5,3,3)}x.globalAlpha=1;
  // HUD
  const alt=Math.max(0,Math.round(gy(L.x)-L.y-13)),vy=L.vy/12.5,vx=L.vx/12.5;x.font='bold 12px system-ui,sans-serif';x.textAlign='left';
  x.fillStyle='#8a90b8';x.fillText('HOOGTE',10,18);x.fillText('↓ SNELHEID',10,36);x.fillText('→ SNELHEID',10,54);
  x.fillStyle='#fff';x.fillText(alt,96,18);x.fillStyle=vy<1.2?'#38ef7d':'#ff5c7a';x.fillText(vy.toFixed(1),96,36);x.fillStyle=Math.abs(vx)<.8?'#38ef7d':'#ff5c7a';x.fillText(vx.toFixed(1),96,54);
  x.fillStyle='#8a90b8';x.textAlign='right';x.fillText('BRANDSTOF',W-10,18);x.fillStyle='#262c4a';x.fillRect(W-110,24,100,10);x.fillStyle=fuel/fuel0<.25?'#ff5c7a':'#4ca1af';x.fillRect(W-110,24,100*fuel/fuel0,10);
  x.fillText('LEVEL '+level,W-10,H-10);x.fillStyle='#d9dde8';for(let i=0;i<Math.max(0,lives);i++){x.beginPath();x.moveTo(12+i*16,H-18);x.lineTo(18+i*16,H-8);x.lineTo(6+i*16,H-8);x.closePath();x.fill()}
  if(state==='crash'&&!over){x.fillStyle='#ff5c7a';x.font='bold 22px system-ui,sans-serif';x.textAlign='center';x.fillText('Gecrasht!',W/2,120)}
  sc.textContent='Score: '+score+' · Beste: '+best('lander',score)+' · Level '+level+(over?' · Game over':'');
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointerup=c.onpointercancel=null}}},
