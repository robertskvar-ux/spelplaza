{id:'surprise3d',n:'Minigolf 3D',e:'⛳',c:'3D',g:'#0b8793,#7ed56f',nw:1,run(st){
 const W=360,H=480,T=three(st,W,H,{fov:50,far:120}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','Sleep vanaf de bal naar achteren en laat los (katapult) · of ◀ ▶ richten, − + kracht, spatie slaan'));
 const BG=0x9ad7f0;S.background=new THREE.Color(BG);S.fog=new THREE.Fog(BG,30,70);
 const sun=new THREE.DirectionalLight(0xfff6e5,3);sun.position.set(-4,10,6);S.add(sun,new THREE.AmbientLight(0xffffff,.6),new THREE.HemisphereLight(0xdff4ff,0x3a5a2a,.6));
 const std=(cl,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:cl,roughness:.8},o)),V3=THREE.Vector3,Mx=new THREE.Matrix4(),Q=new THREE.Quaternion(),col=new THREE.Color();
 // holes: # wall · . green · S tee · H cup · O bumper · W windmill gate · w water · ^ v < > slope
 const HOLES=[
  {par:2,m:['#######','#..H..#','#.....#','#.....#','#.....#','#.....#','#.....#','#.....#','#..S..#','#######']},
  {par:3,m:['#########','#......H#','#.......#','#..######','#..#','#.O#','#..#','#..#','#S.#','####']},
  {par:3,m:['#######','#..H..#','#.....#','#.###.#','#.....#','#vvvvv#','#vvvvv#','#.....#','#..S..#','#######']},
  {par:3,m:['#########','#...H...#','#.......#','#.......#','####W####','#.......#','#.......#','#.......#','#...S...#','#########']},
  {par:4,m:['#########','#H......#','#.......#','#wwwww..#','#.......#','#..wwwww#','#.......#','#.......#','#...O...#','#......S#','#########']},
  {par:3,m:['#########','#...H...#','#.>>.<<.#','#.......#','#.O...O.#','#...O...#','#.O...O.#','#.......#','#...S...#','#########']}];
 const NAMES={'-3':'Albatros!','-2':'Eagle!','-1':'Birdie!','0':'Par','1':'Bogey','2':'Dubbel bogey'},PTS=d=>d<=-2?400:d===-1?300:d===0?200:d===1?100:d===2?50:0;
 const BOX=new THREE.BoxGeometry(1,1,1),floor=new THREE.InstancedMesh(BOX,std(0xffffff,{roughness:.95}),200),walls=new THREE.InstancedMesh(BOX,std(0xffffff,{roughness:.7}),200);floor.frustumCulled=walls.frustumCulled=false;S.add(floor,walls);
 const arrows=new THREE.InstancedMesh(new THREE.ConeGeometry(.16,.4,3),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.75}),60);arrows.frustumCulled=false;S.add(arrows);
 const waterM=new THREE.MeshStandardMaterial({color:0x2f8fe0,roughness:.15,metalness:.2,transparent:true,opacity:.9}),water=new THREE.InstancedMesh(new THREE.BoxGeometry(1,.1,1),waterM,60);water.frustumCulled=false;S.add(water);
 const ground=new THREE.Mesh(new THREE.PlaneGeometry(160,160),std(0x4c8c3a,{roughness:1}));ground.rotation.x=-Math.PI/2;ground.position.y=-1.2;S.add(ground);
 const bumpG=new THREE.CylinderGeometry(.28,.3,.4,20),bumpM=std(0xff4d6d,{roughness:.4,emissive:0x400010}),bumps=[];for(let i=0;i<6;i++){const m=new THREE.Mesh(bumpG,bumpM);m.visible=false;S.add(m);bumps.push(m)}
 const cup=new THREE.Mesh(new THREE.CircleGeometry(.23,24),new THREE.MeshBasicMaterial({color:0x0b1a0b}));cup.rotation.x=-Math.PI/2;S.add(cup);
 const pole=new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,1.5,6),std(0xeeeeee)),flag=new THREE.Mesh(new THREE.PlaneGeometry(.55,.35),std(0xe63946,{side:THREE.DoubleSide}));S.add(pole,flag);
 // windmill (gate over a W cell)
 const mill=new THREE.Group(),house=new THREE.Mesh(new THREE.BoxGeometry(1.3,1.1,.7),std(0xf1e3c8)),roof=new THREE.Mesh(new THREE.ConeGeometry(1,.8,4),std(0x9c3d2e));house.position.y=1;roof.position.y=1.95;roof.rotation.y=Math.PI/4;
 const blades=new THREE.Group(),bladeM=std(0xffffff,{roughness:.5});for(let i=0;i<4;i++){const b=new THREE.Mesh(new THREE.BoxGeometry(.3,1.05,.04),bladeM);b.position.y=.6;const p=new THREE.Group();p.rotation.z=i*Math.PI/2;p.add(b);blades.add(p)}
 blades.position.set(0,1.1,.4);blades.add(new THREE.Mesh(new THREE.SphereGeometry(.1,10,8),std(0x7b5a3a)));mill.add(house,roof,blades,new THREE.Mesh(new THREE.BoxGeometry(.7,.55,.75),new THREE.MeshBasicMaterial({color:0x1a120c})));mill.children[3].position.y=.27;S.add(mill);
 const ball=new THREE.Mesh(new THREE.SphereGeometry(.14,20,14),std(0xffffff,{roughness:.3})),shadow=new THREE.Mesh(new THREE.CircleGeometry(.15,16),new THREE.MeshBasicMaterial({color:0,transparent:true,opacity:.3,depthWrite:false}));shadow.rotation.x=-Math.PI/2;S.add(ball,shadow);
 const dotM=new THREE.MeshBasicMaterial({color:0xffffff}),dots=new THREE.InstancedMesh(new THREE.SphereGeometry(.06,8,6),dotM,12);dots.frustumCulled=false;S.add(dots);
 const RB=.14;let G,rows,cols,hole,strokes,total,cards,bx,bz,vx,vz,lx,lz,moving,aim,pow,sunk,sinkT,msgT,msgFn,over,t,overAt=0,drag=null,camT=new V3,look=new V3,wx=0,wz=0;
 const cell=(x,z)=>{const cc=Math.round(x+(cols-1)/2),rr=Math.round(z+(rows-1)/2);return rr<0||rr>=rows||cc<0||cc>=cols?'#':(G[rr][cc]||' ')},CX=cc=>cc-(cols-1)/2,CZ=rr=>rr-(rows-1)/2;
 const millOpen=()=>{for(let i=0;i<4;i++){let a=(blades.rotation.z+i*Math.PI/2)%(Math.PI*2);if(a<0)a+=Math.PI*2;if(Math.abs(a-Math.PI)<.38)return false}return true};
 function load(n){hole=n;const h=HOLES[n];rows=h.m.length;cols=Math.max(...h.m.map(r=>r.length));G=h.m.map(r=>r.padEnd(cols,' '));
  let fi=0,wi=0,ai=0,wa=0,bi=0;bumps.forEach(b=>b.visible=false);mill.visible=false;
  for(let r=0;r<rows;r++)for(let k=0;k<cols;k++){const ch=G[r][k],x=CX(k),z=CZ(r);if(ch===' ')continue;
   if(ch==='#'){Mx.makeScale(1,.45,1).setPosition(x,.12,z);walls.setMatrixAt(wi,Mx);walls.setColorAt(wi++,col.setHex((r+k)%2?0x9a6b43:0x8a5d38));continue}
   if(ch==='w'){Mx.makeTranslation(x,-.12,z);water.setMatrixAt(wa++,Mx);Mx.makeScale(1,.3,1).setPosition(x,-.35,z);floor.setMatrixAt(fi,Mx);floor.setColorAt(fi++,col.setHex(0x6b5a40));continue}
   Mx.makeScale(1,.3,1).setPosition(x,-.15,z);floor.setMatrixAt(fi,Mx);floor.setColorAt(fi++,col.setHex('^v<>'.includes(ch)?((r+k)%2?0x8fd16a:0x84c45f):((r+k)%2?0x4caf50:0x43a047)));
   if('^v<>'.includes(ch)){Q.setFromEuler(new THREE.Euler(ch==='v'?Math.PI/2:-Math.PI/2,0,ch==='<'?Math.PI/2:ch==='>'?-Math.PI/2:0));Mx.compose(new V3(x,.02,z),Q,new V3(1,1,.15));arrows.setMatrixAt(ai++,Mx)}
   if(ch==='S'){bx=x;bz=z}if(ch==='H'){cup.position.set(x,.005,z);pole.position.set(x,.75,z);flag.position.set(x+.28,1.32,z)}
   if(ch==='O'&&bi<bumps.length){const b=bumps[bi++];b.visible=true;b.position.set(x,.2,z)}
   if(ch==='W'){mill.visible=true;mill.position.set(x,0,z)}}
  floor.count=fi;walls.count=wi;arrows.count=ai;water.count=wa;[floor,walls].forEach(m=>{m.instanceMatrix.needsUpdate=true;m.instanceColor.needsUpdate=true});arrows.instanceMatrix.needsUpdate=true;water.instanceMatrix.needsUpdate=true;
  strokes=0;vx=vz=0;moving=0;sunk=0;sinkT=0;lx=bx;lz=bz;aim=-Math.PI/2;pow=.45;ball.position.set(bx,RB,bz);ball.scale.setScalar(1);
  const hgt=Math.max(rows*1.02,cols*1.45)+1.5;camT.set(0,hgt,hgt*.42+1.2);look.set(0,0,.2);cam.position.copy(camT)}
 function init(){total=0;cards=[];over=0;t=0;msgT=0;msgFn=null;load(0);overlay(st,c,'')}
 function msg(h,s,f){msgT=s;msgFn=f;if(!s)overAt=performance.now();const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 const ptsTot=()=>cards.reduce((a,b)=>a+b.p,0);
 function holeDone(ok){const d=strokes-HOLES[hole].par,p=ok?(strokes===1?500:PTS(d)):0;cards.push({s:strokes,p});total+=strokes;
  const nm=!ok?'Max. 8 slagen':strokes===1?'Hole-in-one! 🎉':NAMES[d]||('+'+d);ok&&beep(d<0?990:660,.12,'triangle',.05);ok&&setTimeout(()=>beep(d<0?1320:880,.16,'triangle',.05),120);
  if(hole===HOLES.length-1){over=1;const pt=ptsTot(),b=best('surprise3d',pt),par=HOLES.reduce((a,h)=>a+h.par,0),dd=total-par;
   msg(`🏁 Ronde klaar!<br><span style="font-size:15px;font-weight:600">${nm}<br>${total} slagen (par ${par}, ${dd>0?'+':''}${dd}) · ${pt} punten<br>Beste: ${b} punten<br>Tik of druk op een toets voor een nieuwe ronde</span>`,0);return}
  msg(`${nm}<br><span style="font-size:15px;font-weight:600">Hole ${hole+1}: ${strokes} ${strokes===1?'slag':'slagen'} · +${p} punten</span>`,1.7,()=>{overlay(st,c,'');load(hole+1)})}
 function shoot(){if(moving||sunk||msgT>0||over||pow<.05)return;strokes++;lx=bx;lz=bz;const s=1.5+pow*12.5;vx=Math.cos(aim)*s;vz=Math.sin(aim)*s;moving=1;beep(300+pow*300,.05,'triangle',.05)}
 const again=()=>{if(over&&performance.now()-overAt>700)init()};
 const inp=input(st,[['◀','ArrowLeft'],['−','ArrowDown'],['⛳',' '],['+','ArrowUp'],['▶','ArrowRight']],k=>{if(over){again();return}if(k===' '||k==='Enter')shoot()});
 if(inp.pad)[...inp.pad.children][2].style.cssText+=';min-width:96px;font-size:18px';if(inp.pad)[...inp.pad.children][2].textContent='⛳ Slaan';
 const toW=e=>{const r=c.getBoundingClientRect();return[(e.clientX-r.left)*W/r.width,(e.clientY-r.top)*H/r.height]};
 c.onpointerdown=e=>{e.preventDefault();if(over){again();return}if(moving||msgT>0)return;try{c.setPointerCapture(e.pointerId)}catch(x){}drag=toW(e)};
 c.onpointermove=e=>{if(!drag)return;const p=toW(e),dx=p[0]-drag[0],dy=p[1]-drag[1],l=Math.hypot(dx,dy);if(l<6)return;aim=Math.atan2(-dy,-dx);pow=Math.min(1,l/150)};
 c.onpointerup=e=>{if(!drag)return;const p=toW(e),l=Math.hypot(p[0]-drag[0],p[1]-drag[1]);drag=null;if(l>12)shoot()};c.onpointercancel=()=>{drag=null};
 function wallHit(){for(let r=-1;r<=1;r++)for(let k=-1;k<=1;k++){const cx=Math.round(bx+(cols-1)/2)+k,cz=Math.round(bz+(rows-1)/2)+r,x=CX(cx),z=CZ(cz),ch=(G[cz]||'')[cx]||' ';
  if(!(ch==='#'||ch===' '||(ch==='W'&&!millOpen())))continue;const nx=Math.max(x-.5,Math.min(bx,x+.5)),nz=Math.max(z-.5,Math.min(bz,z+.5));let dx=bx-nx,dz=bz-nz;const d=Math.hypot(dx,dz);if(d>=RB)continue;
  if(d<1e-5){dx=0;dz=bz>z?1:-1}else{dx/=d;dz/=d}bx=nx+dx*RB;bz=nz+dz*RB;const vn=vx*dx+vz*dz;if(vn<0){vx-=1.72*vn*dx;vz-=1.72*vn*dz;if(vn<-1.2)beep(ch==='W'?180:240,.04,'square',.03)}}}
 const stopLoop=loop(dt=>{t+=dt;
  if(msgT>0){msgT-=dt;if(msgT<=0)msgT=0;if(msgT<=0&&msgFn){const f=msgFn;msgFn=null;f()}}
  blades.rotation.z-=dt*1.5;waterM.color.setHSL(.57,.7,.5+Math.sin(t*2)*.04);flag.rotation.y=Math.sin(t*2.4)*.3;
  if(!over&&!moving&&!sunk&&msgT<=0&&!drag){const ra=(inp.has('ArrowRight')||inp.has('d')?1:0)-(inp.has('ArrowLeft')||inp.has('a')?1:0),rp=(inp.has('ArrowUp')||inp.has('w')?1:0)-(inp.has('ArrowDown')||inp.has('s')?1:0);aim+=ra*1.8*dt;pow=Math.max(.05,Math.min(1,pow+rp*.7*dt))}
  if(moving&&!sunk){const N=4,h=dt/N;for(let i=0;i<N;i++){
    const ch=cell(bx,bz);if(ch==='^')vz-=6*h;if(ch==='v')vz+=6*h;if(ch==='<')vx-=6*h;if(ch==='>')vx+=6*h;
    const dxh=cup.position.x-bx,dzh=cup.position.z-bz,dh=Math.hypot(dxh,dzh),sp=Math.hypot(vx,vz);if(dh<.4&&dh>1e-3){vx+=dxh/dh*3*h;vz+=dzh/dh*3*h}
    if(dh<.21&&sp<5.5){sunk=1;sinkT=0;vx=vz=0;beep(520,.06,'sine',.05);setTimeout(()=>beep(780,.1,'sine',.05),80);break}
    const f=Math.max(0,sp-(.75+sp*.55)*h)/(sp||1);vx*=f;vz*=f;bx+=vx*h;bz+=vz*h;wallHit();
    for(const b of bumps)if(b.visible){let dx=bx-b.position.x,dz=bz-b.position.z;const d=Math.hypot(dx,dz),rr=.29+RB;if(d<rr){dx/=d||1;dz/=d||1;bx=b.position.x+dx*rr;bz=b.position.z+dz*rr;const vn=vx*dx+vz*dz;if(vn<0){vx-=2.15*vn*dx;vz-=2.15*vn*dz;b.userData.p=1;beep(700,.05,'square',.04)}}}
    if(cell(bx,bz)==='w'){beep(200,.2,'sine',.05);strokes++;bx=lx;bz=lz;vx=vz=0;moving=0;msg('💦 Plons!<br><span style="font-size:15px;font-weight:600">+1 strafslag</span>',1,()=>{overlay(st,c,'');if(strokes>=8)holeDone(0)});break}}
   const sp=Math.hypot(vx,vz),slope='^v<>'.includes(cell(bx,bz));if(moving&&sp<.06&&!slope){vx=vz=0;moving=0;if(Math.hypot(cup.position.x-bx,cup.position.z-bz)<.33){sunk=1;sinkT=0;beep(520,.06,'sine',.05)}else if(strokes>=8)holeDone(0)}
   if(sp>1e-3){ball.rotateOnWorldAxis(new V3(vz,0,-vx).normalize(),sp*dt/RB)}}
  if(sunk&&msgT<=0){sinkT+=dt;ball.position.set(cup.position.x,RB-sinkT*1.2,cup.position.z);if(sinkT>.35&&sunk===1){sunk=2;holeDone(1)}}else ball.position.set(bx,RB,bz);
  shadow.position.set(ball.position.x+.04,.004,ball.position.z+.03);shadow.visible=!sunk;
  for(const b of bumps)if(b.userData.p>0){b.userData.p-=dt*4;const s=1+Math.max(0,b.userData.p)*.25;b.scale.set(s,1,s)}
  const show=!over&&!moving&&!sunk&&msgT<=0;dots.visible=show;if(show){const L=.4+pow*3.2;col.setHSL(.33-.33*pow,.9,.55);dotM.color.copy(col);for(let i=0;i<12;i++){const k=.25+i/11*L;Mx.makeTranslation(bx+Math.cos(aim)*k,.08,bz+Math.sin(aim)*k);dots.setMatrixAt(i,Mx)}dots.instanceMatrix.needsUpdate=true}
  wx+=((bx*.25)-wx)*Math.min(1,dt*3);wz+=((bz*.2)-wz)*Math.min(1,dt*3);cam.position.set(camT.x+wx,camT.y,camT.z+wz);cam.lookAt(look.x+wx,0,look.z+wz);
  const hp=HOLES[hole].par;sc.textContent=`⛳ ${hole+1}/6 · Par ${hp} · Slag ${strokes} · ${ptsTot()} pt · Beste ${best('surprise3d',0)}`;
  T.r.render(S,cam)});
 init();cur.reset=init;
 return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;T.dispose()}}},
