{id:'flood',n:'Kleurvloed',e:'🎨',c:'Puzzel',g:'#a8c0ff,#3f2b96',nw:1,run(st){
 const COL=['#ff5e5b','#ff9f1c','#ffd93d','#43b85c','#3d8bff','#b259ff'],SYM=['●','▲','■','◆','★','✚'];
 let N=st.clientWidth<520?12:14,MAX,g,moves,won,lost,cells=[];
 const sc=E('div','sc'),sizes=E('div');sizes.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 8px';
 const board=E('div');board.style.cssText='display:grid;gap:2px;width:min(380px,100%);aspect-ratio:1;margin:0 auto;padding:6px;border-radius:12px;background:var(--bg);user-select:none;-webkit-user-select:none';
 const prog=E('div');prog.style.cssText='height:6px;border-radius:99px;background:var(--bg);max-width:380px;margin:10px auto 8px;overflow:hidden';
 const pb=E('div');pb.style.cssText='height:100%;width:0;border-radius:99px;background:var(--ac);transition:width .3s';prog.append(pb);
 const btns=E('div');btns.style.cssText='display:flex;gap:6px;justify-content:center;flex-wrap:wrap';
 const msg=E('div','sc');msg.style.cssText='min-height:24px;margin-top:8px';
 st.append(sc,sizes,board,prog,btns,msg,E('div','hint','Vul vanuit de linkerbovenhoek het hele bord met één kleur · toetsen 1–6'));
 const cb=COL.map((c,k)=>{const b=E('button','btn',SYM[k]);b.style.cssText=`background:${c};width:52px;height:52px;font-size:22px;padding:0;border-radius:14px;color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.45);box-shadow:0 3px 8px rgba(0,0,0,.25);transition:transform .1s,opacity .15s`;b.onpointerdown=e=>{e.preventDefault();play(k)};btns.append(b);return b});
 function lb(s){let b=best('flood',s==null?-1e9:-s);if(s!=null&&!b){try{localStorage.setItem('sp_flood',-s)}catch(e){}b=-s}return b?-b:0}
 function build(){board.innerHTML='';cells=[];board.style.gridTemplateColumns=`repeat(${N},1fr)`;for(let i=0;i<N*N;i++){const d=E('div');d.style.cssText='border-radius:3px;transition:background .3s';cells.push(d);board.append(d)}}
 function region(){const seen=new Uint8Array(N*N),q=[0],c0=g[0];seen[0]=1;for(let h=0;h<q.length;h++){const i=q[h],x=i%N,y=(i/N)|0;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const X=x+dx,Y=y+dy;if(X<0||X>=N||Y<0||Y>=N)continue;const j=Y*N+X;if(!seen[j]&&g[j]===c0){seen[j]=1;q.push(j)}}}return q}
 function draw(){g.forEach((c,i)=>{cells[i].style.background=COL[c]});const r=region().length;pb.style.width=(r/(N*N)*100)+'%';
  cb.forEach((b,k)=>{const cur=k===g[0];b.style.opacity=cur||won||lost?'.35':'1';b.style.transform=cur?'scale(.9)':''});
  const b=lb();sc.textContent='Zet '+moves+'/'+MAX+(b?' · Beste: '+b+' zetten':'')+' · '+N+'×'+N}
 function play(k){if(won||lost||k===g[0])return;const r=region();moves++;r.forEach(i=>g[i]=k);beep(330+k*60,.06,'triangle',.035);
  if(g.every(c=>c===k)){won=1;const b=lb(moves);msg.innerHTML='🎉 Gewonnen in '+moves+' zetten!'+(moves<=b?' Nieuw record!':'');[0,1,2,3].forEach(i=>setTimeout(()=>beep(523*Math.pow(1.19,i),.12,'triangle',.05),i*100))}
  else if(moves>=MAX){lost=1;msg.innerHTML='😞 Geen zetten meer. Tik op Opnieuw voor een nieuw bord.';beep(160,.3,'sawtooth',.04)}
  draw()}
 function drawSizes(){sizes.innerHTML='';[12,14].forEach(n=>{const b=E('button','btn',n+'×'+n+' · '+(n===12?22:25)+' zetten');b.style.cssText='padding:6px 10px;font-size:12px;border-radius:99px;'+(n===N?'':'background:var(--bg);color:var(--tx)');b.onclick=()=>{N=n;init()};sizes.append(b)})}
 const inp=input(st,[],k=>{if(k>='1'&&k<='6')play(+k-1)});
 function init(){MAX=N===12?22:25;g=Array.from({length:N*N},()=>R(6));moves=0;won=0;lost=0;msg.textContent='';if(cells.length!==N*N)build();drawSizes();draw()}
 st.fl={get g(){return g},get moves(){return moves},get won(){return won},get lost(){return lost},get N(){return N},play};
 init();cur.reset=init;return()=>{inp.stop()}}},
