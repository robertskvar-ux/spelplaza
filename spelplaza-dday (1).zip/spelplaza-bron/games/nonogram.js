{id:'nonogram',n:'Nonogram',e:'🖼️',c:'Puzzel',g:'#000428,#004e92',nw:1,run(st){
 // Picross: fill cells so every row/column matches its clues. Solved = all clues satisfied (any filling that fits counts).
 const SZ=[5,10,15];let n=10;try{n=+localStorage.getItem('sp_nono_n')||10}catch(e){}if(!SZ.includes(n))n=10;
 const bestLow=(id,s)=>{let b=best(id,-s);if(b>=0){try{localStorage.setItem('sp_'+id,-s)}catch(e){}b=-s}return-b};
 const sc=E('div','sc'),top=E('div');top.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 6px';
 const szb=SZ.map(s=>{const b=E('button','btn',s+'×'+s);b.style.cssText='font-size:13px;padding:6px 10px';b.onclick=()=>{n=s;try{localStorage.setItem('sp_nono_n',s)}catch(e){}init()};top.append(b);return b});
 const c=mkCanvas(st,360,360),x=c.getContext('2d');st.append(sc,top,c);
 const bar=E('div');bar.style.cssText='display:flex;gap:8px;justify-content:center;margin-top:8px';
 const modeb=E('button','btn','⬛ Vullen'),hintb=E('button','btn','💡 Hint');bar.append(modeb,hintb);
 st.append(bar,E('div','hint','Tik of sleep om vakjes te vullen · ⬛/✖ wisselt de modus (✖ = zeker leeg) · rechtermuisknop = ✖ · pijltjes + spatie / X'));
 // ---------- puzzle ----------
 let pic,rc,cc,cell,ch,cw,grid,mode=0,t0,won,hints,cur_r,cur_c,kb,tm=0,drag=null,ovEl=null;
 const clues=line=>{const out=[];let k=0;for(const v of line){if(v===1)k++;else if(k){out.push(k);k=0}}if(k)out.push(k);return out.length?out:[0]};
 const row=(g,r)=>g[r],col=(g,cI)=>g.map(rw=>rw[cI]);
 function genPic(){let p;do{p=[];for(let r=0;r<n;r++)p.push(Array(n).fill(0));const sym=R(2),k=2+R(3)+Math.floor(n/4);
   for(let i=0;i<k;i++){const el=R(2),cx=R(n),cy=R(n),rx=1+R(Math.max(1,n/3)),ry=1+R(Math.max(1,n/3));for(let r=0;r<n;r++)for(let q=0;q<n;q++){const dx=(q-cx)/rx,dy=(r-cy)/ry;if(el?dx*dx+dy*dy<=1:Math.abs(q-cx)<=rx&&Math.abs(r-cy)<=ry)p[r][q]=1}}
   if(sym)for(let r=0;r<n;r++)for(let q=0;q<n;q++)if(q>=n/2)p[r][q]=p[r][n-1-q];
   for(let r=0;r<n;r++)for(let q=0;q<n;q++)if(Math.random()<.07)p[r][q]^=1;
   const f=p.flat().reduce((a,b)=>a+b,0)/(n*n);if(f>=.45&&f<=.65)break}while(1);return p}
 function init(){pic=genPic();rc=pic.map(r=>clues(r));cc=[];for(let i=0;i<n;i++)cc.push(clues(col(pic,i)));
  const mr=Math.max(...rc.map(a=>a.length)),mc=Math.max(...cc.map(a=>a.length)),fs=n>10?10:n>5?12:14;
  cell=Math.min(44,Math.floor((360-(mr*(fs+2)+8))/n));cw=mr*(fs+2)+8;ch=mc*(fs+2)+8;c.width=cw+n*cell;c.height=ch+n*cell;c.style.width=c.width+'px';x.font='';
  grid=pic.map(r=>r.map(()=>0));t0=performance.now();won=0;hints=0;cur_r=cur_c=0;kb=0;drag=null;if(ovEl){overlay(st,c,'');ovEl=null}draw()}
 const lineOk=(cl,line)=>{const a=clues(line);return a.length===cl.length&&a.every((v,i)=>v===cl[i])};
 const rowOk=r=>lineOk(rc[r],row(grid,r).map(v=>v===1?1:0)),colOk=i=>lineOk(cc[i],col(grid,i).map(v=>v===1?1:0));
 function check(){for(let r=0;r<n;r++)if(!rowOk(r))return;for(let i=0;i<n;i++)if(!colOk(i))return;
  won=performance.now();const s=Math.max(1,Math.floor((won-t0)/1000)),b=bestLow('nono_'+n,s);beep(660,.12,'triangle',.05);tm=setTimeout(()=>beep(990,.25,'triangle',.05),140);
  for(let r=0;r<n;r++)for(let q=0;q<n;q++)if(grid[r][q]===2)grid[r][q]=0;
  ovEl=overlay(st,c,`🎉 Opgelost!<br><span style="font-size:15px;font-weight:600">${n}×${n} · tijd ${fmt(s)} · beste ${fmt(b)}${hints?' · hints '+hints:''}<br>Tik voor een nieuwe puzzel</span>`);ovEl.onpointerdown=e=>{e.preventDefault();init()}}
 const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0'),secs=()=>Math.floor(((won||performance.now())-t0)/1000);
 function set(r,q,v){if(won||r<0||r>=n||q<0||q>=n)return;if(grid[r][q]===v)return;grid[r][q]=v;beep(v===1?520:v===2?380:300,.03,'sine',.02)}
 function doHint(){if(won)return;const bad=[];for(let r=0;r<n;r++)for(let q=0;q<n;q++)if((grid[r][q]===1)!==(pic[r][q]===1))bad.push([r,q]);if(!bad.length)return;
  const[r,q]=bad[R(bad.length)];grid[r][q]=pic[r][q]?1:2;hints++;beep(780,.08,'triangle',.03);check();draw()}
 // ---------- input ----------
 function cellAt(e){const b=c.getBoundingClientRect(),px=(e.clientX-b.left)*c.width/b.width,py=(e.clientY-b.top)*c.height/b.height;return{r:Math.floor((py-ch)/cell),q:Math.floor((px-cw)/cell)}};
 c.oncontextmenu=e=>e.preventDefault();
 c.onpointerdown=e=>{e.preventDefault();if(won)return;const p=cellAt(e);if(p.r<0||p.r>=n||p.q<0||p.q>=n)return;kb=0;try{c.setPointerCapture(e.pointerId)}catch(_){}
  const m=e.button===2?1:mode,want=m?2:1,v=grid[p.r][p.q]===want?0:want;drag={r0:p.r,q0:p.q,v,lock:0};set(p.r,p.q,v);draw()};
 c.onpointermove=e=>{if(!drag||won)return;const p=cellAt(e);if(p.r<0||p.r>=n||p.q<0||p.q>=n)return;let{r,q}=p;
  if(!drag.lock){if(r!==drag.r0||q!==drag.q0)drag.lock=Math.abs(r-drag.r0)>=Math.abs(q-drag.q0)?'v':'h';else return}
  if(drag.lock==='v')q=drag.q0;else r=drag.r0;
  const a=drag.lock==='v'?[Math.min(r,drag.r0),Math.max(r,drag.r0)]:[Math.min(q,drag.q0),Math.max(q,drag.q0)];// fill the whole line segment so fast drags don't skip cells
  for(let k=a[0];k<=a[1];k++){if(drag.lock==='v')set(k,q,drag.v);else set(r,k,drag.v)}draw()};
 c.onpointerup=c.onpointercancel=()=>{if(drag){drag=null;check();draw()}};
 modeb.onclick=()=>{mode=mode?0:1;draw()};hintb.onclick=doHint;
 const inp=input(st,[],k=>{if(won){if(k==='Enter'||k===' ')init();return}
  const d={ArrowUp:[-1,0],ArrowDown:[1,0],ArrowLeft:[0,-1],ArrowRight:[0,1]}[k];
  if(d){kb=1;cur_r=(cur_r+d[0]+n)%n;cur_c=(cur_c+d[1]+n)%n;draw()}
  else if(k===' '||k==='Enter'){kb=1;set(cur_r,cur_c,grid[cur_r][cur_c]===1?0:1);check();draw()}
  else if(k==='x'||k==='X'){kb=1;set(cur_r,cur_c,grid[cur_r][cur_c]===2?0:2);check();draw()}
  else if(k==='m'||k==='M'){mode=mode?0:1;draw()}else if(k==='h'||k==='H')doHint()});
 // ---------- drawing ----------
 function draw(){const W=c.width,H=c.height;x.fillStyle='#0e1020';x.fillRect(0,0,W,H);const fs=n>10?10:n>5?12:14;
  x.fillStyle='#161a2e';x.fillRect(cw,0,n*cell,ch);x.fillRect(0,ch,cw,n*cell);
  if(kb&&!won){x.fillStyle='rgba(108,92,231,.18)';x.fillRect(0,ch+cur_r*cell,W,cell);x.fillRect(cw+cur_c*cell,0,cell,H)}
  for(let r=0;r<n;r++)for(let q=0;q<n;q++){const X=cw+q*cell,Y=ch+r*cell,v=grid[r][q];
   x.fillStyle=v===1?(won?'#ffd166':'#eef0ff'):'#1b1e36';x.fillRect(X+1,Y+1,cell-2,cell-2);
   if(v===2&&!won){x.strokeStyle='#6b7280';x.lineWidth=Math.max(1.5,cell*.08);const m=cell*.3;x.beginPath();x.moveTo(X+m,Y+m);x.lineTo(X+cell-m,Y+cell-m);x.moveTo(X+cell-m,Y+m);x.lineTo(X+m,Y+cell-m);x.stroke()}}
  for(let k=0;k<=n;k++){const th=k%5===0;x.strokeStyle=th?'rgba(255,255,255,.45)':'rgba(255,255,255,.1)';x.lineWidth=th?2:1;const p=k===n?-1:1;
   x.beginPath();x.moveTo(cw+k*cell+(th?0:.5),0);x.lineTo(cw+k*cell+(th?0:.5),H);x.stroke();x.beginPath();x.moveTo(0,ch+k*cell+(th?0:.5));x.lineTo(W,ch+k*cell+(th?0:.5));x.stroke()}
  x.font='bold '+fs+'px system-ui,sans-serif';x.textBaseline='middle';
  for(let r=0;r<n;r++){const ok=rowOk(r);x.fillStyle=ok?'#5a5f80':'#fff';x.textAlign='right';const cl=rc[r];for(let i=0;i<cl.length;i++)x.fillText(cl[cl.length-1-i],cw-4-i*(fs+2),ch+r*cell+cell/2)}
  for(let q=0;q<n;q++){const ok=colOk(q);x.fillStyle=ok?'#5a5f80':'#fff';x.textAlign='center';const cl=cc[q];for(let i=0;i<cl.length;i++)x.fillText(cl[cl.length-1-i],cw+q*cell+cell/2,ch-6-i*(fs+2)-fs/2+2)}
  if(kb&&!won){x.strokeStyle='#fff';x.lineWidth=2;x.strokeRect(cw+cur_c*cell+1.5,ch+cur_r*cell+1.5,cell-3,cell-3)}
  modeb.textContent=mode?'✖ Markeren':'⬛ Vullen';szb.forEach((b,i)=>b.style.opacity=SZ[i]===n?'1':'.5');
  const b=best('nono_'+n,-99999);sc.textContent='⏱ '+fmt(secs())+(b<0?' · Beste: '+fmt(-b):'')+(hints?' · Hints: '+hints:'')+(won?' · 🎉 Opgelost!':'')}
 const iv=setInterval(()=>{if(!won)sc.textContent=sc.textContent.replace(/⏱ [\d:]+/,'⏱ '+fmt(secs()))},500);
 window._nono={pic:()=>pic.map(r=>r.slice()),grid:()=>grid.map(r=>r.slice()),set:(r,q,v)=>{set(r,q,v);check();draw()},size:s=>{n=s;init()},hint:doHint,state:()=>({n,won:!!won,hints,mode,cell,cw,ch})};
 init();cur.reset=init;return()=>{clearInterval(iv);clearTimeout(tm);inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=c.oncontextmenu=null;delete window._nono}}},
