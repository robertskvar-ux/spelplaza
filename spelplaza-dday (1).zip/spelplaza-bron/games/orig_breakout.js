{id:'breakout',n:'Blokken Breken',e:'🏓',c:'Arcade',g:'#ee0979,#ff6a00',run(st){
 const W=360,H=480,PY=448,BR=6,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','Sleep of ◀ ▶ = peddel · tik / spatie = lanceren · vang de power-ups: ↔ breed · ●● multibal · 🐢 traag · ❤ leven'));
 const PU={w:['↔','#38bdf8'],m:['●●','#f472b6'],s:['🐢','#a3e635'],l:['❤','#ef4444']};
 let pad,pw,tx,balls,bricks,drops,parts,score,lives,lvl,state,stT,wideT,slowT,t,shake;
 function layout(){bricks=[];const rows=Math.min(8,4+lvl),pat=(lvl-1)%4;
  for(let j=0;j<rows;j++)for(let i=0;i<8;i++){let on=1;if(pat===1)on=(i+j)%2===0||j<2;if(pat===2)on=Math.abs(i-3.5)<=j*.6+.6;if(pat===3)on=j%3!==2||i%3===0;
   if(!on)continue;const hp=lvl>=6&&j<2?3:lvl>=3&&j<(lvl>=5?3:2)?2:1;bricks.push({x:4+i*44,y:56+j*20,w:40,h:16,hp,mx:hp,c:`hsl(${(j*38+lvl*25)%360},85%,60%)`})}}
 function newBall(){return{x:pad,y:PY-BR-1,vx:0,vy:0,stuck:1}}
 function baseSpeed(){return Math.min(470,270+lvl*22)}
 function init(){pad=W/2;pw=64;tx=null;lvl=1;score=0;lives=3;drops=[];parts=[];state=0;stT=0;wideT=0;slowT=0;t=0;shake=0;layout();balls=[newBall()];ov('')}
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function launch(){if(state===2){if(stT>.6)init();return}if(state===3)return;state=1;for(const b of balls)if(b.stuck){const a=-Math.PI/2+(Math.random()-.5)*.6,s=baseSpeed();b.vx=Math.cos(a)*s;b.vy=Math.sin(a)*s;b.stuck=0;beep(600,.05,'square',.03)}}
 function boom(px,py,col,n){for(let i=0;i<n;i++){const a=Math.random()*7,s=40+Math.random()*140;parts.push({x:px,y:py,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:.5,c:col})}}
 function lose(){lives--;shake=.3;beep(140,.4,'sawtooth',.05);wideT=0;slowT=0;pw=64;drops=[];
  if(lives<=0){state=2;stT=0;best('breakout',score);ov(`💥 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Level ${lvl} · Beste ${best('breakout',score)}<br>Tik of druk op spatie om opnieuw te spelen</span>`)}
  else{balls=[newBall()];state=0}}
 const inp=input(st,[['◀','ArrowLeft'],['🚀',' '],['▶','ArrowRight']],k=>{if(k===' '||k==='ArrowUp'||k==='Enter')launch()});
 const pos=e=>{const r=c.getBoundingClientRect();return(e.clientX-r.left)*W/r.width};let drag=0;
 c.onpointerdown=e=>{e.preventDefault();drag=1;tx=pos(e);try{c.setPointerCapture(e.pointerId)}catch(_){}if(state!==1)launch()};
 c.onpointermove=e=>{if(drag||e.pointerType==='mouse')tx=pos(e)};c.onpointerup=c.onpointercancel=()=>{drag=0};
 function stepBall(b,d){const n=Math.ceil(Math.hypot(b.vx,b.vy)*d/3);const sd=d/n;
  for(let k=0;k<n;k++){const ox=b.x,oy=b.y;b.x+=b.vx*sd;b.y+=b.vy*sd;
   if(b.x<BR){b.x=BR;b.vx=Math.abs(b.vx);beep(300,.02,'triangle',.015)}if(b.x>W-BR){b.x=W-BR;b.vx=-Math.abs(b.vx);beep(300,.02,'triangle',.015)}if(b.y<40+BR){b.y=40+BR;b.vy=Math.abs(b.vy);beep(300,.02,'triangle',.015)}
   if(b.vy>0&&b.y+BR>=PY&&oy+BR<=PY+4&&b.x>pad-pw/2-BR&&b.x<pad+pw/2+BR){const off=(b.x-pad)/(pw/2),a=-Math.PI/2+off*1.05,s=Math.hypot(b.vx,b.vy);b.vx=Math.cos(a)*s;b.vy=Math.sin(a)*s;b.y=PY-BR;beep(420,.04,'square',.025)}
   for(const q of bricks){if(q.hp<=0)continue;if(b.x+BR>q.x&&b.x-BR<q.x+q.w&&b.y+BR>q.y&&b.y-BR<q.y+q.h){
     if(ox+BR<=q.x||ox-BR>=q.x+q.w)b.vx=-b.vx;else b.vy=-b.vy;b.x=ox;b.y=oy;q.hp--;
     if(q.hp<=0){score+=10*lvl;boom(q.x+20,q.y+8,q.c,10);beep(500+R(6)*60,.05,'square',.03);if(Math.random()<.13){const ks=Object.keys(PU);drops.push({x:q.x+20,y:q.y+8,k:ks[R(ks.length)]})}
      const s=Math.hypot(b.vx,b.vy),ns=Math.min(baseSpeed()*1.35,s*1.008);b.vx*=ns/s;b.vy*=ns/s}else{score+=5;beep(800,.04,'triangle',.03)}
     return}}}}
 function power(k){beep(880,.08,'triangle',.04);setTimeout(()=>beep(1175,.1,'triangle',.04),70);
  if(k==='w'){wideT=12;pw=100}else if(k==='s'){slowT=8}else if(k==='l'){lives=Math.min(6,lives+1)}
  else if(k==='m'){const add=[];for(const b of balls.slice(0,3)){if(b.stuck)continue;for(const da of[-.4,.4]){const a=Math.atan2(b.vy,b.vx)+da,s=Math.hypot(b.vx,b.vy);add.push({x:b.x,y:b.y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,stuck:0})}}balls.push(...add)}}
 const stopLoop=loop(dt=>{t+=dt;stT+=dt;shake=Math.max(0,shake-dt);
  if(inp.has('ArrowLeft')||inp.has('a')){pad-=420*dt;tx=null}if(inp.has('ArrowRight')||inp.has('d')){pad+=420*dt;tx=null}
  if(tx!=null){const d=tx-pad;pad+=Math.sign(d)*Math.min(Math.abs(d),900*dt)}pad=Math.max(pw/2,Math.min(W-pw/2,pad));
  if(wideT>0){wideT-=dt;if(wideT<=0)pw=64}if(slowT>0)slowT-=dt;
  if(state===0||state===1){for(const b of balls){if(b.stuck){b.x=pad;b.y=PY-BR-1}else stepBall(b,dt*(slowT>0?.62:1))}
   balls=balls.filter(b=>b.y<H+20);if(!balls.length)lose();
   for(const d of drops){d.y+=130*dt;if(d.y>PY-8&&d.y<PY+12&&Math.abs(d.x-pad)<pw/2+12){d.got=1;power(d.k)}}drops=drops.filter(d=>!d.got&&d.y<H+20);
   if(state===1&&!bricks.some(q=>q.hp>0)){state=3;stT=0;best('breakout',score);[523,659,784,1047].forEach((f,i)=>setTimeout(()=>beep(f,.12,'triangle',.05),i*100));ov(`⭐ Level ${lvl} klaar!`)}}
  else if(state===3&&stT>1.6){lvl++;layout();balls=[newBall()];drops=[];state=0;ov('')}
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=300*dt;p.l-=dt}parts=parts.filter(p=>p.l>0);
  // draw
  x.save();if(shake>0)x.translate((Math.random()-.5)*6,(Math.random()-.5)*6);
  x.fillStyle='#0e1020';x.fillRect(-6,-6,W+12,H+12);x.fillStyle='#14183a';x.fillRect(0,40,W,H-40);
  for(const q of bricks){if(q.hp<=0)continue;x.fillStyle=q.c;x.globalAlpha=q.hp<q.mx?.55+.45*q.hp/q.mx:1;x.beginPath();x.roundRect?x.roundRect(q.x,q.y,q.w,q.h,4):x.rect(q.x,q.y,q.w,q.h);x.fill();x.globalAlpha=1;
   x.fillStyle='rgba(255,255,255,.3)';x.fillRect(q.x+3,q.y+2,q.w-6,3);if(q.mx>1){x.strokeStyle='#fff';x.lineWidth=1.5;x.strokeRect(q.x+1.5,q.y+1.5,q.w-3,q.h-3);if(q.hp<q.mx){x.strokeStyle='#0e102088';x.beginPath();x.moveTo(q.x+12,q.y+2);x.lineTo(q.x+18,q.y+9);x.lineTo(q.x+15,q.y+14);x.stroke()}}}
  for(const d of drops){const[s,col]=PU[d.k];x.fillStyle=col;x.beginPath();x.roundRect?x.roundRect(d.x-15,d.y-9,30,18,9):x.rect(d.x-15,d.y-9,30,18);x.fill();x.fillStyle='#fff';x.font='bold 11px system-ui,sans-serif';x.textAlign='center';x.fillText(s,d.x,d.y+4)}
  const pg=x.createLinearGradient(0,PY,0,PY+12);pg.addColorStop(0,wideT>0?'#7dd3fc':'#ffffff');pg.addColorStop(1,wideT>0?'#0284c7':'#9aa0c8');x.fillStyle=pg;x.beginPath();x.roundRect?x.roundRect(pad-pw/2,PY,pw,12,6):x.rect(pad-pw/2,PY,pw,12);x.fill();
  for(const b of balls){x.fillStyle=slowT>0?'#bef264':'#fff';x.shadowColor=x.fillStyle;x.shadowBlur=10;x.beginPath();x.arc(b.x,b.y,BR,0,7);x.fill();x.shadowBlur=0}
  for(const p of parts){x.globalAlpha=Math.max(0,p.l*2);x.fillStyle=p.c;x.fillRect(p.x-2,p.y-2,4,4)}x.globalAlpha=1;x.restore();
  x.fillStyle='#ff5c7a';x.font='14px system-ui,sans-serif';x.textAlign='left';x.fillText('❤'.repeat(Math.max(0,lives)),10,26);
  x.fillStyle='#cfd3f5';x.font='800 14px system-ui,sans-serif';x.textAlign='right';x.fillText('LEVEL '+lvl,W-10,26);
  x.textAlign='center';x.fillStyle='#8a90b8';x.font='600 11px system-ui,sans-serif';const tags=[];if(wideT>0)tags.push('↔ '+Math.ceil(wideT)+'s');if(slowT>0)tags.push('🐢 '+Math.ceil(slowT)+'s');x.fillText(tags.join('   '),W/2,26);
  if(state===0&&balls.some(b=>b.stuck)){x.fillStyle='#fff';x.font='bold 16px system-ui,sans-serif';x.fillText('Tik of druk op spatie om te lanceren',W/2,PY-60)}
  sc.textContent='Score: '+score+' · Beste: '+best('breakout',score)+' · Level '+lvl+(state===2?' · Game over':'');
 });
 st.t={get bricks(){return bricks},get balls(){return balls},get state(){return state},get lvl(){return lvl},setPad:v=>{tx=v}};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
