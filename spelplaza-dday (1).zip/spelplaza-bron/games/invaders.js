{id:'invaders',n:'Ruimte-invasie',e:'👾',c:'Arcade',g:'#141e30,#243b55',nw:1,run(st){
 const W=360,H=440,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','◀ ▶ of slepen = bewegen · spatie / 🔥 / tik = schieten'));
 // 8x8 pixel sprites: 3 soorten × 2 frames (rijen als bytes)
 const SPR=[[[0x18,0x3C,0x7E,0xDB,0xFF,0x5A,0x81,0x42],[0x18,0x3C,0x7E,0xDB,0xFF,0x24,0x5A,0xA5]],
  [[0x24,0x99,0xBD,0xFF,0x7E,0x24,0x42,0x81],[0x24,0x24,0x7E,0xDB,0xFF,0xBD,0xA5,0x24]],
  [[0x3C,0x7E,0xFF,0xDB,0xFF,0x24,0x5A,0xA5],[0x3C,0x7E,0xFF,0xDB,0xFF,0x5A,0x81,0x42]]];
 const COL=['#ff7eb6','#7ec8ff','#7ec8ff','#9dff7e','#9dff7e'],TYPE=[0,1,1,2,2],PTS=[30,20,20,10,10];
 const ROWS=5,COLS=8,AW=20,AH=20,SX=34,SY=26,PY=398,PW=30,BK=['.1111111.','111111111','111111111','111...111','11.....11'];
 const stars=[];for(let i=0;i<40;i++)stars.push({x:R(W),y:R(H-30),s:Math.random()<.2?2:1});
 let al,dir,stepT,frame,px,tx,drag,bul,bombs,bunk,score,lives,wave,over,overT,deadT,waveT,parts,ufo,ufoT,bombT,inv,t;
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function newWave(){al=[];for(let r=0;r<ROWS;r++)for(let i=0;i<COLS;i++)al.push({x:28+i*SX,y:48+r*SY+Math.min(60,(wave-1)*10),r});
  dir=1;stepT=0;frame=0;bul=null;bombs=[];parts=[];ufo=null;ufoT=9+R(8);bombT=1.6;deadT=0;inv=0;tx=null;px=W/2;
  bunk=[0,1,2].map(i=>({x:38+i*120,y:345,g:BK.map(s=>[...s].map(ch=>ch==='1'?1:0))}))}
 function init(){score=0;lives=3;wave=1;over=0;overT=0;waveT=0;t=0;newWave();ov('')}
 function boom(bx,by,col,n){for(let i=0;i<n;i++){const a=Math.random()*7,s=40+Math.random()*120;parts.push({x:bx,y:by,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:.4+Math.random()*.4,c:col})}}
 function hitBunker(bx,by){for(const b of bunk){if(bx<b.x||bx>=b.x+45||by<b.y||by>=b.y+25)continue;const i=Math.floor((bx-b.x)/5),j=Math.floor((by-b.y)/5);
   if(b.g[j][i]){b.g[j][i]=0;for(let k=0;k<4;k++){const jj=j+R(3)-1,ii=i+R(3)-1;if(b.g[jj]&&b.g[jj][ii]!=null)b.g[jj][ii]=0}return true}}return false}
 function gameOver(msg){over=1;overT=0;best('invaders',score);beep(110,.5,'sawtooth',.05);
  ov(`${msg}<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('invaders',score)}<br>Tik of druk op spatie om opnieuw te spelen</span>`)}
 function fire(){if(over||deadT>0||waveT>0||bul)return;bul={x:px,y:PY-18};beep(880,.05,'square',.025)}
 function die(){deadT=1.3;lives--;boom(px,PY-4,'#7ef0ff',28);beep(160,.35,'sawtooth',.05);bombs=[]}
 const inp=input(st,[['◀','ArrowLeft'],['🔥',' '],['▶','ArrowRight']],k=>{if(over){if(overT>.5)init();return}if(k===' '||k==='ArrowUp')fire()});
 const pos=e=>{const r=c.getBoundingClientRect();return(e.clientX-r.left)*W/r.width};
 c.onpointerdown=e=>{e.preventDefault();if(over){if(overT>.5)init();return}drag=1;tx=pos(e);try{c.setPointerCapture(e.pointerId)}catch(_){}fire()};
 c.onpointermove=e=>{if(drag)tx=pos(e)};
 c.onpointerup=c.onpointercancel=()=>{drag=0;tx=null};
 const stopLoop=loop(dt=>{
  t+=dt;if(over)overT+=dt;
  if(!over){
   if(waveT>0){waveT-=dt;if(waveT<=0)newWave()}
   else if(deadT>0){deadT-=dt;if(deadT<=0){if(lives<=0)gameOver('💀 Game over');else{px=W/2;inv=1.5}}}
   else{inv-=dt;
    // speler
    if(inp.has('ArrowLeft')||inp.has('a'))px-=230*dt;if(inp.has('ArrowRight')||inp.has('d'))px+=230*dt;
    if(tx!=null){const d=tx-px;px+=Math.sign(d)*Math.min(Math.abs(d),420*dt)}
    px=Math.max(PW/2,Math.min(W-PW/2,px));if(inp.has(' '))fire();
    // aliens stappen
    const alive=al.length,stepI=Math.max(.055,(.05+.68*alive/40)*Math.max(.45,1-(wave-1)*.1));
    stepT+=dt;if(stepT>=stepI){stepT=0;frame^=1;let mn=1e9,mx=-1e9;for(const a of al){mn=Math.min(mn,a.x);mx=Math.max(mx,a.x+AW)}
     if((dir>0&&mx+8>W-6)||(dir<0&&mn-8<6)){for(const a of al)a.y+=12;dir=-dir}else for(const a of al)a.x+=8*dir;
     beep(100+(frame?20:0),.04,'triangle',.012);
     for(const a of al){if(a.y+AH>=PY-6){gameOver('👾 Geïnvadeerd!');break}
      if(a.y+AH>340)for(let i=0;i<AW;i+=5)for(let j=0;j<AH;j+=5)hitBunker(a.x+i,a.y+j)}}
    // bommen
    bombT-=dt;if(bombT<=0&&al.length){bombT=Math.max(.3,1.4-wave*.12)*(.5+Math.random());if(bombs.length<2+wave){const cols={};for(const a of al)if(!cols[a.x]||cols[a.x].y<a.y)cols[a.x]=a;const ks=Object.keys(cols),a=cols[ks[R(ks.length)]];bombs.push({x:a.x+AW/2,y:a.y+AH,vy:140+wave*18})}}
    for(const b of bombs){b.y+=b.vy*dt;if(hitBunker(b.x,b.y))b.d=1;else if(inv<=0&&b.y>PY-14&&b.y<PY+8&&Math.abs(b.x-px)<PW/2-2){b.d=1;die()}}
    bombs=bombs.filter(b=>!b.d&&b.y<H);
    // kogel
    if(bul){bul.y-=480*dt;if(bul.y<0||hitBunker(bul.x,bul.y))bul=null;
     else{for(let i=0;i<al.length;i++){const a=al[i];if(bul.x>a.x&&bul.x<a.x+AW&&bul.y>a.y&&bul.y<a.y+AH){score+=PTS[a.r];boom(a.x+AW/2,a.y+AH/2,COL[a.r],10);al.splice(i,1);bul=null;beep(220+a.r*40,.08,'sawtooth',.03);break}}
      if(bul&&ufo&&bul.x>ufo.x-16&&bul.x<ufo.x+16&&bul.y>22&&bul.y<38){score+=ufo.v;boom(ufo.x,30,'#ff5c7a',18);parts.push({x:ufo.x,y:30,vx:0,vy:-20,l:1,c:'#fff',tx:'+'+ufo.v});ufo=null;bul=null;beep(1200,.15,'square',.04)}}}
    if(!al.length){waveT=1.6;wave++;beep(660,.12,'square',.04)}
    // ufo
    if(ufo){ufo.x+=ufo.d*75*dt;if(ufo.x<-30||ufo.x>W+30)ufo=null}else{ufoT-=dt;if(ufoT<=0){const d=R(2)?1:-1;ufo={x:d>0?-28:W+28,d,v:(1+R(3))*50};ufoT=14+R(10);beep(500,.1,'sine',.03)}}
   }}
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.l-=dt}parts=parts.filter(p=>p.l>0);
  // tekenen
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);x.fillStyle='#2a2f55';for(const s of stars)x.fillRect(s.x,s.y,s.s,s.s);
  x.strokeStyle='#38ef7d';x.lineWidth=1;x.beginPath();x.moveTo(0,420.5);x.lineTo(W,420.5);x.stroke();
  for(const a of al){const sp=SPR[TYPE[a.r]][frame];x.fillStyle=COL[a.r];for(let j=0;j<8;j++)for(let i=0;i<8;i++)if(sp[j]>>(7-i)&1)x.fillRect(a.x+i*2.5,a.y+j*2.5,2.5,2.5)}
  if(ufo){x.fillStyle='#ff5c7a';x.beginPath();x.ellipse(ufo.x,30,16,6,0,0,7);x.fill();x.fillStyle='#ffd1dc';x.beginPath();x.ellipse(ufo.x,26,8,5,0,Math.PI,0);x.fill();x.fillStyle=Math.floor(t*8)%2?'#fff':'#ffd200';for(let i=-1;i<2;i++)x.fillRect(ufo.x+i*9-1,30,2,2)}
  x.fillStyle='#38ef7d';for(const b of bunk)for(let j=0;j<5;j++)for(let i=0;i<9;i++)if(b.g[j][i])x.fillRect(b.x+i*5,b.y+j*5,5,5);
  if(deadT<=0&&(inv<=0||Math.floor(t*10)%2)){x.fillStyle='#7ef0ff';x.fillRect(px-15,PY-4,30,8);x.fillRect(px-11,PY-9,22,5);x.fillRect(px-2,PY-16,4,8)}
  if(bul){x.fillStyle='#fff';x.fillRect(bul.x-1,bul.y,2,9)}
  x.fillStyle='#ffd200';for(const b of bombs){const z=Math.floor(t*20+b.y/4)%2?2:-2;x.fillRect(b.x-1+z,b.y,3,4);x.fillRect(b.x-1-z,b.y+4,3,4)}
  for(const p of parts){x.globalAlpha=Math.min(1,p.l*2);if(p.tx){x.fillStyle=p.c;x.font='bold 13px system-ui,sans-serif';x.textAlign='center';x.fillText(p.tx,p.x,p.y)}else{x.fillStyle=p.c;x.fillRect(p.x-1.5,p.y-1.5,3,3)}}x.globalAlpha=1;
  x.fillStyle='#7ef0ff';for(let i=0;i<Math.max(0,lives);i++){const lx=14+i*22;x.fillRect(lx,428,16,4);x.fillRect(lx+2,425,12,3);x.fillRect(lx+7,421,2,4)}
  x.fillStyle='#8a90b8';x.font='bold 12px system-ui,sans-serif';x.textAlign='right';x.fillText('GOLF '+wave,W-10,434);
  if(waveT>0&&!over){x.fillStyle='#fff';x.font='bold 26px system-ui,sans-serif';x.textAlign='center';x.fillText('Golf '+wave,W/2,H/2)}
  sc.textContent='Score: '+score+' · Beste: '+best('invaders',score)+' · Golf '+wave+(over?' · Game over':'');
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
