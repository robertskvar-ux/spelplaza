{id:'woordzoeker',n:'Woordzoeker',e:'🔍',c:'Woorden',g:'#ee9ca7,#ffdde1',nw:1,run(st){
 const TH={
  'Dieren':'HOND,PAARD,SCHAAP,GEIT,KONIJN,OLIFANT,GIRAF,LEEUW,TIJGER,ZEBRA,PANDA,VOGEL,VLINDER,SLANG,KIKKER,DOLFIJN,WALVIS,HAAI,BEER,WOLF,EGEL,MUIS,EEND,HERT,KROKODIL,SCHILDPAD,KAMEEL,PAPEGAAI',
  'Eten & drinken':'BROOD,KAAS,APPEL,PEER,BANAAN,MELK,KOFFIE,THEE,WATER,SOEP,PIZZA,PASTA,RIJST,AARDAPPEL,WORTEL,TOMAAT,KOMKOMMER,SUIKER,BOTER,CHOCOLADE,KOEKJE,TAART,FRIET,SALADE,YOGHURT,HONING,DRUIF,CITROEN,SPINAZIE,KERS',
  'Natuur':'BOOM,BLOEM,GRAS,RIVIER,BERG,STRAND,WOLK,REGEN,SNEEUW,STORM,WIND,STEEN,ZAND,EILAND,BLAD,WOUD,HEUVEL,VULKAAN,WATERVAL,OCEAAN,WOESTIJN,REGENBOOG,BLIKSEM,DONDER,MAAN,STER,LUCHT,AARDE,DAUW,MIST,KUST,DUIN,POLDER,WEIDE,AKKER',
  'Sport':'VOETBAL,TENNIS,HOCKEY,ZWEMMEN,FIETSEN,LOPEN,SCHAATSEN,BASKETBAL,VOLLEYBAL,GOLF,JUDO,KARATE,BOKSEN,TURNEN,DANSEN,RUGBY,HANDBAL,HONKBAL,SURFEN,ZEILEN,ROEIEN,KLIMMEN,WIELRENNEN,ATLETIEK,BADMINTON,DARTS,DUIKEN,WANDELEN,SPRINTEN,SCHERMEN,SKATEN',
  'Huis':'KEUKEN,BADKAMER,SLAAPKAMER,ZOLDER,KELDER,GARAGE,TUIN,DEUR,RAAM,STOEL,TAFEL,BANK,KAST,LAMP,SPIEGEL,TAPIJT,GORDIJN,KUSSEN,DEKEN,KACHEL,OVEN,KOELKAST,DOUCHE,TOILET,TRAP,MUUR,VLOER,PLAFOND,BALKON,GANG,VENSTER,BUREAU,WASMACHINE,BOEKENKAST,SCHUUR'};
 const N=10,DIRS=[[0,1],[1,0],[1,1],[-1,1],[0,-1],[-1,0],[-1,-1],[1,-1]];
 const COL=['#ff6b6b','#ffa94d','#ffd43b','#69db7c','#38d9a9','#4dabf7','#748ffc','#da77f2','#f783ac','#a9e34b'];
 const sc=E('div','sc'),chips=E('div');chips.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:4px 0 8px';
 const box=E('div');box.style.cssText='position:relative;width:min(360px,100%);aspect-ratio:1;margin:0 auto;touch-action:none;user-select:none;-webkit-user-select:none;cursor:pointer;background:var(--bg);border-radius:12px;overflow:hidden';
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox',`0 0 ${N} ${N}`);svg.style.cssText='position:absolute;inset:0;width:100%;height:100%;pointer-events:none';
 const grid=E('div');grid.style.cssText=`position:relative;display:grid;grid-template-columns:repeat(${N},1fr);width:100%;height:100%;font-weight:700;font-size:clamp(14px,5vw,20px)`;
 const cells=[];for(let i=0;i<N*N;i++){const d=E('div');d.style.cssText='display:flex;align-items:center;justify-content:center;pointer-events:none';cells.push(d);grid.append(d)}
 box.append(svg,grid);
 const list=E('div');list.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:10px 0 4px;font-weight:600;font-size:14px';
 const msg=E('div','sc');msg.style.cssText='min-height:22px;color:var(--ac)';
 st.append(sc,chips,box,list,msg,E('div','hint','Sleep over een woord (ook schuin) of tik op de eerste en de laatste letter'));
 let theme='Dieren',g,words,found,place,t0,won,tick,drag=null,tapStart=null,temp=null;
 function lb(th,s){const k='wz_'+th;let b=best(k,s==null?-1e9:-s);if(s!=null&&!b){try{localStorage.setItem('sp_'+k,-s)}catch(e){}b=-s}return b?-b:0}
 const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
 function gen(){const pool=TH[theme].split(',').sort(()=>Math.random()-.5);const want=8+R(3);g=Array.from({length:N},()=>Array(N).fill(''));place=[];
  for(const w of pool){if(place.length>=want)break;if(w.length>N)continue;let ok=0;
   for(let a=0;a<120&&!ok;a++){const[dr,dc]=DIRS[R(8)],r0=R(N),c0=R(N),r1=r0+dr*(w.length-1),c1=c0+dc*(w.length-1);if(r1<0||r1>=N||c1<0||c1>=N)continue;let f=1;
    for(let i=0;i<w.length;i++){const ch=g[r0+dr*i][c0+dc*i];if(ch&&ch!==w[i]){f=0;break}}if(!f)continue;
    for(let i=0;i<w.length;i++)g[r0+dr*i][c0+dc*i]=w[i];place.push({w,r0,c0,r1,c1});ok=1}}
  if(place.length<8)return gen();
  const L='AABCDEEEEGHIIJKLMNNOOPRRSSTTUVWZ';for(let r=0;r<N;r++)for(let c=0;c<N;c++)if(!g[r][c])g[r][c]=L[R(L.length)];
  words=place.map(p=>p.w).sort()}
 function line(r0,c0,r1,c1,col,op){const l=document.createElementNS('http://www.w3.org/2000/svg','line');l.setAttribute('x1',c0+.5);l.setAttribute('y1',r0+.5);l.setAttribute('x2',c1+.5);l.setAttribute('y2',r1+.5);l.setAttribute('stroke',col);l.setAttribute('stroke-width',.82);l.setAttribute('stroke-linecap','round');l.setAttribute('opacity',op);svg.append(l);return l}
 function drawList(){list.innerHTML='';words.forEach(w=>{const s=E('span','',w);const i=found.indexOf(w);s.style.cssText='padding:4px 9px;border-radius:99px;background:var(--bg);'+(i>=0?`text-decoration:line-through;opacity:.6;background:${COL[i%COL.length]}33`:'');list.append(s)})}
 function status(){const el=won?won:Math.floor((performance.now()-t0)/1000);const b=lb(theme);sc.textContent='⏱ '+fmt(el)+' · '+found.length+'/'+words.length+' gevonden'+(b?' · Beste: '+fmt(b):'')}
 function cellAt(e){const r=box.getBoundingClientRect();const c=Math.floor((e.clientX-r.left)/r.width*N),rw=Math.floor((e.clientY-r.top)/r.height*N);return c<0||c>=N||rw<0||rw>=N?null:{r:rw,c}}
 function snap(a,b){let dr=b.r-a.r,dc=b.c-a.c;if(!dr&&!dc)return{r:a.r,c:a.c};const k=Math.round(Math.atan2(dr,dc)/(Math.PI/4));const dy=Math.round(Math.sin(k*Math.PI/4)),dx=Math.round(Math.cos(k*Math.PI/4));let len=dx&&dy?Math.max(Math.abs(dr),Math.abs(dc)):dx?Math.abs(dc):Math.abs(dr);
  while(len>0&&(a.r+dy*len<0||a.r+dy*len>=N||a.c+dx*len<0||a.c+dx*len>=N))len--;return{r:a.r+dy*len,c:a.c+dx*len}}
 function showTemp(a,b,col){temp&&temp.remove();temp=line(a.r,a.c,b.r,b.c,col||'#ffffff',.35)}
 function commit(a,b){temp&&temp.remove();temp=null;tapStart=null;if(won)return;const dr=Math.sign(b.r-a.r),dc=Math.sign(b.c-a.c),n=Math.max(Math.abs(b.r-a.r),Math.abs(b.c-a.c))+1;let s='';for(let i=0;i<n;i++)s+=g[a.r+dr*i][a.c+dc*i];const rv=[...s].reverse().join('');
  const w=words.find(w=>(w===s||w===rv)&&!found.includes(w));
  if(w){found.push(w);line(a.r,a.c,b.r,b.c,COL[(found.length-1)%COL.length],.55);beep(520+found.length*40,.08,'triangle',.05);drawList();
   if(found.length===words.length){won=Math.max(1,Math.round((performance.now()-t0)/1000));const b=lb(theme,won);msg.innerHTML='🎉 Alles gevonden in '+fmt(won)+'!'+(won<=b?' Nieuw record!':'');[1,2,3].forEach(i=>setTimeout(()=>beep(440*Math.pow(1.26,i),.12,'triangle',.05),i*110));status()}}
  else{const l=line(a.r,a.c,b.r,b.c,'#ff3b3b',.4);setTimeout(()=>l.remove(),250);beep(180,.08,'sawtooth',.03)}}
 box.onpointerdown=e=>{e.preventDefault();try{box.setPointerCapture(e.pointerId)}catch(x){}const c=cellAt(e);if(!c||won)return;drag={a:c,moved:0,id:e.pointerId};showTemp(tapStart||c,c)};
 box.onpointermove=e=>{if(!drag||e.pointerId!==drag.id)return;const c=cellAt(e);if(!c)return;if(c.r!==drag.a.r||c.c!==drag.a.c)drag.moved=1;drag.b=snap(drag.a,c);showTemp(drag.a,drag.b)};
 box.onpointerup=e=>{if(!drag)return;const d=drag;drag=null;if(d.moved)commit(d.a,d.b||d.a);else if(tapStart){if(tapStart.r===d.a.r&&tapStart.c===d.a.c){tapStart=null;temp&&temp.remove();temp=null}else commit(tapStart,snap(tapStart,d.a))}else{tapStart=d.a;showTemp(d.a,d.a,'#ffd43b')}};
 box.onpointercancel=()=>{drag=null;tapStart=null;temp&&temp.remove();temp=null};
 function drawChips(){chips.innerHTML='';Object.keys(TH).forEach(t=>{const b=E('button','btn',t);b.style.cssText='padding:7px 11px;font-size:13px;border-radius:99px;'+(t===theme?'':'background:var(--bg);color:var(--tx)');b.onclick=()=>{theme=t;init()};chips.append(b)})}
 function init(){gen();found=[];won=0;drag=null;tapStart=null;temp=null;svg.innerHTML='';msg.textContent='';t0=performance.now();for(let r=0;r<N;r++)for(let c=0;c<N;c++)cells[r*N+c].textContent=g[r][c];drawChips();drawList();status();clearInterval(tick);tick=setInterval(()=>{if(!won)status()},500)}
 st.wz={get place(){return place},get found(){return found},get theme(){return theme},box};
 init();cur.reset=init;return()=>{clearInterval(tick);box.onpointerdown=box.onpointermove=box.onpointerup=box.onpointercancel=null}}},
