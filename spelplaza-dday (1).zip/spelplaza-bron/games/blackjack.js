{id:'blackjack',n:'Blackjack 21',e:'🃏',c:'Kaarten',g:'#000000,#434343',nw:1,run(st){
 // Blackjack tegen de dealer. 6 decks, dealer past op elke 17, blackjack betaalt 3:2. Saldo blijft bewaard.
 const SUITS=['♠','♥','♦','♣'],RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K'],KEY='sp_bj_bank';
 const sc=E('div','sc');
 const felt=E('div');felt.style.cssText='background:radial-gradient(ellipse at 50% 35%,#2f9a52,#14532d 75%);border-radius:18px;padding:10px 8px 8px;box-shadow:inset 0 0 40px rgba(0,0,0,.45),0 4px 14px rgba(0,0,0,.3);width:min(520px,100%);margin:0 auto;overflow:hidden';
 const dl=E('div'),dh=E('div'),pl=E('div'),ph=E('div'),msg=E('div');
 [dl,pl].forEach(l=>l.style.cssText='color:#e8f5e9;font-weight:700;font-size:14px;margin:2px 0 4px;text-shadow:0 1px 2px rgba(0,0,0,.5);min-height:18px');
 [dh,ph].forEach(h=>h.style.cssText='display:flex;justify-content:center;min-height:84px;padding-left:24px');
 msg.style.cssText='min-height:30px;font-weight:800;font-size:17px;color:#fff;margin:6px 0;text-shadow:0 1px 3px rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center';
 felt.append(dl,dh,msg,pl,ph);
 const ctl=E('div');ctl.style.cssText='display:flex;flex-wrap:wrap;gap:8px;justify-content:center;align-items:center;margin:12px 0 4px;min-height:52px';
 const hint=E('div','hint','h = kaart · s = passen · d = verdubbelen · spatie = delen · blackjack betaalt 3:2 · dealer past op 17');
 st.append(sc,felt,ctl,hint);
 // ---------- kaarten ----------
 let shoe=[];function newShoe(){shoe=[];for(let d=0;d<6;d++)for(let s=0;s<4;s++)for(let r=0;r<13;r++)shoe.push({r:RANKS[r],s:SUITS[s],v:r===0?11:Math.min(10,r+1)});for(let i=shoe.length-1;i>0;i--){const j=R(i+1);[shoe[i],shoe[j]]=[shoe[j],shoe[i]]}}
 function take(){if(shoe.length<60)newShoe();return shoe.pop()}
 const val=h=>{let v=0,a=0;for(const c of h){v+=c.v;if(c.v===11)a++}while(v>21&&a){v-=10;a--}return v};
 const isBJ=h=>h.length===2&&val(h)===21;
 function face(d,cd,hidden){if(hidden){d.innerHTML='';d.style.background='repeating-linear-gradient(45deg,#3457b5 0 6px,#1e3c72 6px 12px)';d.style.border='3px solid #f4f4f8';d.style.color='';return}
  const red=cd.s==='♥'||cd.s==='♦';d.style.background='#fff';d.style.border='1px solid #c9ccd6';d.style.color=red?'#d32f2f':'#1b1d2a';
  const sm='font-size:14px;font-weight:800;line-height:1.05;text-align:center;position:absolute';
  d.innerHTML='<span style="'+sm+';top:4px;left:5px">'+cd.r+'<br>'+cd.s+'</span><span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:30px">'+cd.s+'</span><span style="'+sm+';bottom:4px;right:5px;transform:rotate(180deg)">'+cd.r+'<br>'+cd.s+'</span>'}
 function addCard(hand,cd,hidden){const d=E('div');d.style.cssText='width:56px;height:80px;border-radius:7px;margin-left:-24px;position:relative;box-shadow:0 2px 6px rgba(0,0,0,.45);flex:none;transition:transform .35s ease,opacity .35s;transform:translate(-90px,-70px) rotate(-14deg);opacity:0';
  face(d,cd,hidden);hand.append(d);void d.offsetWidth;d.style.transform='none';d.style.opacity='1';beep(hidden?260:520,.04,'triangle',.02);return d}
 // ---------- toestand ----------
 let bank,bet,lastBet,P,D,state,hole,timers=[];
 const later=(f,ms)=>{const id=setTimeout(()=>{timers=timers.filter(t=>t!==id);f()},ms);timers.push(id);return id};
 const clearAll=()=>{timers.forEach(clearTimeout);timers=[]};
 function save(){try{localStorage.setItem(KEY,bank)}catch(e){}}
 function labels(){dl.textContent='Dealer'+(D.length?' · '+(hole?val([D[0]]):val(D)):'');pl.textContent='Jij'+(P.length?' · '+val(P):'')}
 function status(){sc.textContent='💰 Saldo: '+bank+' · Inzet: '+bet+' · Record: '+best('blackjack',bank+bet);if(state==='bet')msg.textContent=bet?'Inzet: '+bet+' · tik op Deel':'Kies je inzet met de fiches'}
 function chip(l,col,f){const b=E('button','btn',l);b.style.cssText='width:46px;height:46px;border-radius:50%;padding:0;font-size:13px;background:'+col+';box-shadow:0 3px 8px rgba(0,0,0,.35),inset 0 0 0 4px rgba(255,255,255,.35)';b.onclick=f;return b}
 function ctrls(){ctl.innerHTML='';
  if(state==='bet'){if(bank<10&&bet<10){ctl.append(E('div','hint','Je bent blut! Druk op 🔄 Opnieuw voor een nieuw saldo van 1000.'));return}
   ctl.append(chip('10','linear-gradient(#5aa9ff,#1f6fd1)',()=>addBet(10)),chip('25','linear-gradient(#6ee07c,#1d9a3b)',()=>addBet(25)),chip('100','linear-gradient(#777,#222)',()=>addBet(100)),chip('Alles','linear-gradient(#ffd54a,#d99a00)',()=>{bet+=bank;bank=0;status();ctrls()}));
   const deal=E('button','btn','🎴 Deel');deal.style.cssText='font-size:16px;padding:9px 12px';deal.disabled=bet<=0;deal.style.opacity=bet>0?'1':'.5';deal.onclick=()=>dealRound();
   const clr=E('button','btn','✕');clr.title='Inzet wissen';clr.style.cssText='background:var(--mu);width:36px;height:36px;padding:0;border-radius:50%';clr.onclick=()=>{bank+=bet;bet=0;status();ctrls()};ctl.append(deal,clr)}
  else if(state==='play'){const mk=(l,f,dis)=>{const b=E('button','btn',l);b.style.fontSize='15px';b.onclick=f;if(dis){b.disabled=1;b.style.opacity='.45'}return b};
   ctl.append(mk('➕ Kaart (h)',hit),mk('✋ Passen (s)',stand),mk('×2 Verdubbel (d)',dbl,!(P.length===2&&bank>=bet)))}
  else if(state==='done'){const b=E('button','btn','▶ Nieuwe ronde (spatie)');b.style.fontSize='15px';b.onclick=newRound;ctl.append(b)}
  else ctl.append(E('div','hint',state==='deal'?'Delen…':'De dealer speelt…'))}
 function addBet(n){if(state!=='bet')return;n=Math.min(n,bank);if(n<=0){beep(200,.08,'square',.03);return}bet+=n;bank-=n;beep(700,.04,'triangle',.03);status();ctrls()}
 function newRound(){clearAll();P=[];D=[];hole=0;dh.innerHTML='';ph.innerHTML='';msg.textContent='';state='bet';
  const b=Math.min(lastBet,bank);bet=b>0?b:0;bank-=bet;if(bank<10&&bet<10){bank+=bet;bet=0}labels();status();ctrls()}
 function dealRound(){if(state!=='bet'||bet<=0)return;lastBet=bet;state='deal';ctrls();msg.textContent='';
  const seq=[()=>addCard(ph,P[P.length]=take()),()=>addCard(dh,D[D.length]=take()),()=>addCard(ph,P[P.length]=take()),()=>{hole=addCard(dh,D[D.length]=take(),1)}];
  seq.forEach((f,i)=>later(()=>{f();labels();if(i===3)afterDeal()},i*220+40))}
 function afterDeal(){if(isBJ(P)||isBJ(D)){reveal();later(()=>settle(),450);return}state='play';ctrls()}
 function reveal(){if(!hole)return;const d=hole;hole=0;try{d.animate([{transform:'rotateY(90deg)'},{transform:'none'}],{duration:260,easing:'ease-out'})}catch(e){}face(d,D[1]);labels()}
 function hit(){if(state!=='play')return;addCard(ph,P[P.length]=take());labels();if(val(P)>21){state='dealer';ctrls();later(()=>{reveal();settle()},400)}else if(val(P)===21)stand();else ctrls()}
 function stand(){if(state!=='play')return;state='dealer';ctrls();later(dealerPlay,300)}
 function dbl(){if(state!=='play'||P.length!==2||bank<bet)return;bank-=bet;bet*=2;status();addCard(ph,P[P.length]=take());labels();state='dealer';ctrls();later(()=>{if(val(P)>21){reveal();settle()}else dealerPlay()},450)}
 function dealerPlay(){reveal();const step=()=>{if(val(D)<17){addCard(dh,D[D.length]=take());labels();later(step,520)}else later(settle,350)};later(step,400)}
 function settle(){const p=val(P),d=val(D);let win=0,t;
  if(isBJ(P)&&isBJ(D)){win=bet;t='🤝 Beiden blackjack · gelijkspel'}
  else if(isBJ(P)){win=Math.floor(bet*2.5);t='🃏 Blackjack! Je wint +'+(win-bet)}
  else if(isBJ(D)){t='Dealer heeft blackjack · je verliest −'+bet}
  else if(p>21){t='💥 Bust! Meer dan 21 · −'+bet}
  else if(d>21){win=bet*2;t='🎉 Dealer bust! Je wint +'+bet}
  else if(p>d){win=bet*2;t='🎉 Je wint met '+p+' tegen '+d+' · +'+bet}
  else if(p<d){t='Dealer wint met '+d+' tegen '+p+' · −'+bet}
  else{win=bet;t='🤝 Gelijkspel · inzet terug'}
  bank+=win;beep(win>bet?880:win?440:160,win>bet?.3:.2,win?'triangle':'sawtooth',.05);bet=0;save();msg.textContent=t;state='done';labels();status();ctrls()}
 const inp=input(st,[],k=>{k=k.toLowerCase();if(k==='h')hit();else if(k==='s')stand();else if(k==='d')dbl();else if(k===' '||k==='enter'){if(state==='bet')dealRound();else if(state==='done')newRound()}});
 function init(){clearAll();let b=1000;try{b=+localStorage.getItem(KEY);if(!(b>=0))b=1000}catch(e){}bank=b;bet=0;if(bank<10)bank=1000;save();lastBet=25;if(!shoe.length)newShoe();newRound()}
 window._bj={state:()=>({state,bank,bet,P:P.slice(),D:D.slice(),pv:val(P),dv:val(D)}),bet:addBet,deal:dealRound,hit,stand,dbl,next:newRound,rig(cards){shoe.push(...cards.reverse())}};
 init();cur.reset=init;return()=>{clearAll();inp.stop();delete window._bj}}},
