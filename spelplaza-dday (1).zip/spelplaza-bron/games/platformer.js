{id:'platformer',n:'Avonturier',e:'🍄',c:'Arcade',g:'#56ab2f,#a8e063',nw:1,run(st){
 const W=400,H=300,T=24,OY=12,c=mkCanvas(st,W,H),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 st.append(E('div','hint','◀ ▶ lopen · ⬆ / spatie / tik = springen (kort = lage sprong) · spring op vijanden · haal de vlag'));
 const LV=[["                                                            ","                                                            ","                                                            ","                                                            ","                          CCC                               ","            C            BBBBB                        CCC   ","          CCC         C      C        C C            BBBBB  ","         BBBB        BBB    BBB      BBBB         E        F","   P         E                      E       ^^  BBBBB      B","  #####   ##########   ######   ##################   #######","  #####   ##########   ######   ##################   #######","  #####   ##########   ######   ##################   #######"],
  ["                                                                      ","                                                                      ","                                                                      ","                                                                      ","                      C            CCC                     CC         ","                     BBB          BBBBB                   BBBB        ","            C            C      C C C C      E    C    BBB            ","   P       BBB          BBB    BBBBBBBB    BBBBB  BBB    ^^^^BBB    F ","  ####  E     ^^   E           C        E                ####   E ####","  #########  #######  ####   ####   #####  ############  ####  #######","  #########  #######  ####   ####   #####  ############  ####  #######","  #########  #######  ####   ####   #####  ############  ####  #######"],
  ["                                                                                ","                                                                                ","                                      CC                                        ","                                     BBBB                                       ","                                  CC                                            ","                                 BBBB                                           ","           C        C        CEC             C       C      C   C   C           ","          BBB      BBB      BBBBB           BBB     BBB    BBB BBB BBB          ","   P   E        E              ^^^ E              ^^  E                  ^^ E F ","  ########   ######   ###   ##########   ###   ############   #####   ##########","  ########   ######   ###   ##########   ###   ############   #####   ##########","  ########   ######   ###   ##########   ###   ############   #####   ##########"]];
 const G=1500,JV=-480,RUN=150;
 let map,MW,p,ens,start,cam,score,lives,level,over,overT,time,deathT,winT,t,coyote,jbuf,ptrHeld,won;
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 const tile=(i,j)=>(j<0||j>=12||i<0||i>=MW)?' ':map[j][i],solid=(i,j)=>{const ch=tile(i,j);return ch==='#'||ch==='B'};
 function loadLevel(){const rows=LV[level-1];MW=rows[0].length;map=rows.map(r=>[...r]);ens=[];
  for(let j=0;j<12;j++)for(let i=0;i<MW;i++){const ch=map[j][i];if(ch==='P'){start={x:i*T+12,y:(j+1)*T};map[j][i]=' '}else if(ch==='E'){ens.push({sx:i*T+12,sy:(j+1)*T});map[j][i]=' '}}
  spawn();cam=Math.max(0,Math.min(MW*T-W,p.x-W/2));winT=0}
 function spawn(){p={x:start.x,y:start.y,vx:0,vy:0,g:0,f:1,an:0,dead:0};deathT=0;coyote=0;jbuf=0;for(const e of ens){e.x=e.sx;e.y=e.sy;e.vx=-45;e.a=1;e.sq=0}}
 function init(){score=0;lives=3;level=1;over=0;overT=0;won=0;time=0;t=0;ptrHeld=0;loadLevel();ov('')}
 function gameOver(){over=1;overT=0;best('platformer',score);ov(`💀 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('platformer',score)}<br>Tik of druk op een toets om opnieuw te spelen</span>`)}
 function win(){over=1;won=1;overT=0;best('platformer',score);beep(880,.3,'square',.05);ov(`🏆 Gewonnen!<br><span style="font-size:15px;font-weight:600">Score ${score} · Tijd ${fmt(time)} · Beste ${best('platformer',score)}<br>Tik of druk op een toets om opnieuw te spelen</span>`)}
 const fmt=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
 function die(){if(p.dead)return;p.dead=1;deathT=1.3;p.vy=-360;p.vx=0;lives--;beep(150,.4,'sawtooth',.05)}
 function jump(){if(over){if(overT>.5)init();return}jbuf=.12}
 const inp=input(st,[['◀','ArrowLeft'],['⬆','ArrowUp'],['▶','ArrowRight']],k=>{if(k==='ArrowUp'||k===' '||k==='w')jump();else if(over&&overT>.5)init()});
 c.onpointerdown=e=>{e.preventDefault();ptrHeld=1;jump();try{c.setPointerCapture(e.pointerId)}catch(_){}};c.onpointerup=c.onpointercancel=()=>{ptrHeld=0};
 const stopLoop=loop(dt=>{
  t+=dt;if(over)overT+=dt;
  if(!over){
   if(winT>0){winT-=dt;if(winT<=0){if(level>=LV.length)win();else{level++;loadLevel()}}}
   else if(p.dead){deathT-=dt;p.vy+=G*dt;p.y+=p.vy*dt;if(deathT<=0){if(lives<=0)gameOver();else spawn()}}
   else{time+=dt;
    const held=inp.has('ArrowUp')||inp.has(' ')||inp.has('w')||ptrHeld;let ax=0;if(inp.has('ArrowLeft')||inp.has('a'))ax=-1;if(inp.has('ArrowRight')||inp.has('d'))ax=1;
    if(ax){p.vx+=ax*(p.g?1100:700)*dt;p.f=ax}else{const d=(p.g?1300:250)*dt;p.vx=Math.abs(p.vx)<=d?0:p.vx-Math.sign(p.vx)*d}p.vx=Math.max(-RUN,Math.min(RUN,p.vx));
    coyote=p.g?.1:coyote-dt;jbuf-=dt;if(jbuf>0&&(p.g||coyote>0)){p.vy=JV;p.g=0;coyote=0;jbuf=0;beep(500,.06,'square',.03)}
    if(!held&&p.vy<-170)p.vy=-170;
    p.x+=p.vx*dt;const j0=Math.floor((p.y-19)/T),j1=Math.floor((p.y-1)/T);
    if(p.vx>0){const i=Math.floor((p.x+7)/T);for(let j=j0;j<=j1;j++)if(solid(i,j)){p.x=i*T-7.01;p.vx=0;break}}else if(p.vx<0){const i=Math.floor((p.x-7)/T);for(let j=j0;j<=j1;j++)if(solid(i,j)){p.x=(i+1)*T+7.01;p.vx=0;break}}
    p.vy+=G*dt;p.y+=p.vy*dt;p.g=0;const i0=Math.floor((p.x-6)/T),i1=Math.floor((p.x+6)/T);
    if(p.vy>0){const j=Math.floor(p.y/T);for(let i=i0;i<=i1;i++)if(solid(i,j)){p.y=j*T;p.vy=0;p.g=1;break}}else if(p.vy<0){const j=Math.floor((p.y-20)/T);for(let i=i0;i<=i1;i++)if(solid(i,j)){p.y=(j+1)*T+20;p.vy=0;break}}
    if(p.g)p.an+=Math.abs(p.vx)*dt/18;
    for(let j=Math.floor((p.y-18)/T);j<=Math.floor((p.y-2)/T);j++)for(let i=Math.floor((p.x-5)/T);i<=Math.floor((p.x+5)/T);i++){const ch=tile(i,j);
     if(ch==='C'){map[j][i]=' ';score+=10;beep(1000,.05,'sine',.03)}else if(ch==='^'&&p.y-2>j*T+8)die();else if(ch==='F'&&winT<=0){winT=1.6;score+=200;beep(700,.25,'square',.05)}}
    if(p.y-20>12*T+20)die();
    for(const e of ens){if(!e.a){e.sq-=dt;continue}e.x+=e.vx*dt;const fx=e.x+Math.sign(e.vx)*9,fi=Math.floor(fx/T);if(solid(fi,Math.floor((e.y-8)/T))||!solid(fi,Math.floor((e.y+1)/T))||fx<0||fx>MW*T){e.vx=-e.vx;e.x+=e.vx*dt*2}
     if(!p.dead&&Math.abs(e.x-p.x)<16&&p.y>e.y-16&&p.y-20<e.y){if(p.vy>0&&p.y<e.y-6){e.a=0;e.sq=.4;p.vy=-300;score+=100;beep(300,.1,'square',.04)}else die()}}
   }
   const tc=Math.max(0,Math.min(MW*T-W,p.x-W/2));cam+=(tc-cam)*Math.min(1,dt*8)}
  // tekenen
  x.fillStyle='#0e1020';x.fillRect(0,0,W,H);
  x.fillStyle='#141a3e';for(let i=-1;i<5;i++){const hx=i*160-((cam*.3)%160);x.beginPath();x.arc(hx,330,110,0,7);x.fill()}
  x.fillStyle='#1a2250';for(let i=-1;i<6;i++){const hx=i*120-((cam*.6)%120);x.beginPath();x.arc(hx,335,75,0,7);x.fill()}
  x.save();x.translate(-Math.round(cam),OY);const ia=Math.max(0,Math.floor(cam/T)),ib=Math.min(MW-1,Math.floor((cam+W)/T)+1);
  for(let j=0;j<12;j++)for(let i=ia;i<=ib;i++){const ch=map[j][i],X=i*T,Y=j*T;if(ch===' ')continue;
   if(ch==='#'){x.fillStyle='#7a4c22';x.fillRect(X,Y,T,T);if(!solid(i,j-1)){x.fillStyle='#5ad85a';x.fillRect(X,Y,T,6);x.fillStyle='#3fae3f';x.fillRect(X,Y+6,T,2)}else{x.fillStyle='#5b3816';x.fillRect(X+5,Y+7,3,3);x.fillRect(X+15,Y+15,3,3)}}
   else if(ch==='B'){x.fillStyle='#c66a3a';x.fillRect(X,Y,T,T);x.fillStyle='#8b3f1f';x.fillRect(X,Y+11,T,2);x.fillRect(X,Y+T-2,T,2);x.fillRect(X+11,Y,2,11);x.fillRect(X,Y+13,2,11);x.fillRect(X+T-2,Y+13,2,11)}
   else if(ch==='C'){const w=Math.abs(Math.cos(t*4+i))*8+1;x.fillStyle='#ffd23f';x.beginPath();x.ellipse(X+12,Y+12,w,9,0,0,7);x.fill();x.fillStyle='#e0a800';x.beginPath();x.ellipse(X+12,Y+12,Math.max(0,w-3),6,0,0,7);x.fill()}
   else if(ch==='^'){x.fillStyle='#c9ccd6';x.beginPath();for(let k=0;k<3;k++){x.moveTo(X+k*8,Y+T);x.lineTo(X+k*8+4,Y+8);x.lineTo(X+k*8+8,Y+T)}x.fill()}
   else if(ch==='F'){x.fillStyle='#c9ccd6';x.fillRect(X+11,Y-T,3,T*2);x.fillRect(X+6,Y+T-4,13,4);x.fillStyle='#ff5c5c';x.beginPath();x.moveTo(X+14,Y-T+2);x.lineTo(X+30+Math.sin(t*6)*2,Y-T+9);x.lineTo(X+14,Y-T+16);x.closePath();x.fill()}}
  for(const e of ens){if(!e.a&&e.sq<=0)continue;x.fillStyle='#b5653a';if(!e.a){x.beginPath();x.ellipse(e.x,e.y-3,11,3,0,0,7);x.fill();continue}
   const lf=Math.sin(t*14)*2;x.fillStyle='#5a3a1a';x.fillRect(e.x-7+lf,e.y-4,5,4);x.fillRect(e.x+2-lf,e.y-4,5,4);x.fillStyle='#b5653a';x.beginPath();x.ellipse(e.x,e.y-9,9,8,0,0,7);x.fill();x.fillStyle='#8b3f1f';x.beginPath();x.ellipse(e.x,e.y-11,9,5,0,Math.PI,0);x.fill();
   x.fillStyle='#fff';x.fillRect(e.x-5,e.y-10,3,3);x.fillRect(e.x+2,e.y-10,3,3);x.fillStyle='#111';x.fillRect(e.x-4+(e.vx<0?-1:1),e.y-9,2,2);x.fillRect(e.x+3+(e.vx<0?-1:1),e.y-9,2,2)}
  // speler
  x.save();x.translate(p.x,p.y);if(p.dead)x.scale(1,-1),x.translate(0,20);if(p.f<0)x.scale(-1,1);const lg=p.g&&Math.abs(p.vx)>10?Math.sin(p.an*Math.PI*2)*3:0;
  x.fillStyle='#5a3a1a';x.fillRect(-6,-6+Math.max(0,lg),4,6-Math.max(0,lg));x.fillRect(2,-6+Math.max(0,-lg),4,6-Math.max(0,-lg));x.fillStyle='#4fb3ff';x.fillRect(-6,-14,12,8);x.fillStyle='#ffd9b3';x.fillRect(-6,-20,12,7);x.fillStyle='#ff5c5c';x.fillRect(-7,-22,14,3);x.fillRect(3,-20,6,2);
  x.fillStyle='#111';x.fillRect(2,-18,2,2);if(p.dead){x.fillRect(-4,-18,2,2)}x.restore();
  x.restore();
  x.fillStyle='rgba(14,16,32,.55)';x.fillRect(0,0,W,22);x.font='bold 13px system-ui,sans-serif';x.textAlign='left';x.fillStyle='#ff5c7a';x.fillText('♥'.repeat(Math.max(0,lives)),10,16);x.fillStyle='#fff';x.fillText('Level '+level,70,16);x.fillStyle='#ffd23f';x.fillText('● '+score,150,16);x.textAlign='right';x.fillStyle='#8a90b8';x.fillText('⏱ '+fmt(time),W-10,16);
  if(winT>0&&!over){x.fillStyle='#fff';x.font='bold 24px system-ui,sans-serif';x.textAlign='center';x.fillText('Level klaar! +200',W/2,H/2)}
  sc.textContent='Score: '+score+' · Beste: '+best('platformer',score)+' · Level '+level+' · ⏱ '+fmt(time)+(over?(won?' · Gewonnen!':' · Game over'):'');
 });
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointerup=c.onpointercancel=null}}},
