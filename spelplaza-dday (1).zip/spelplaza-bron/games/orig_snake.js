{id:'snake',n:'Snake',e:'🐍',c:'Arcade',g:'#11998e,#38ef7d',run(st){
 const N=20,S=18,W=N*S,c=mkCanvas(st,W,W),x=c.getContext('2d'),sc=E('div','sc');st.prepend(sc);
 const opt=E('div');opt.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 8px';sc.after(opt);
 st.append(E('div','hint','Pijltjes / WASD / vegen = sturen · elke appel maakt je sneller · ⭐ = 5 punten'));
 let walls=0;try{walls=+localStorage.getItem('sp_snake_walls')||0}catch(e){}
 let sn,prev,dir,q,ap,star,starT,score,over,overT,started,acc,spd,parts,t,eatT;
 const key=()=>walls?'snake_muren':'snake';
 function drawOpt(){opt.innerHTML='';[[0,'🌀 Zonder muren'],[1,'🧱 Met muren']].forEach(([v,l])=>{const b=E('button','btn',l);b.style.cssText='padding:6px 12px;font-size:12px;border-radius:99px;'+(v===walls?'':'background:var(--bg);color:var(--tx)');b.onclick=()=>{walls=v;try{localStorage.setItem('sp_snake_walls',v)}catch(e){}init()};opt.append(b)})}
 function free(){let p;do p={x:R(N),y:R(N)};while(sn.some(s=>s.x===p.x&&s.y===p.y)||(ap&&ap.x===p.x&&ap.y===p.y));return p}
 function init(){sn=[{x:9,y:10},{x:8,y:10},{x:7,y:10}];prev=sn.map(p=>({...p}));dir={x:1,y:0};q=[];ap=null;ap=free();star=null;starT=6+R(6);
  score=0;over=0;overT=0;started=0;acc=0;spd=7;parts=[];t=0;eatT=0;drawOpt();ov('')}
 function ov(h){const o=overlay(st,c,h);if(o)o.style.pointerEvents='none'}
 function turn(k){const m={ArrowUp:[0,-1],w:[0,-1],ArrowDown:[0,1],s:[0,1],ArrowLeft:[-1,0],a:[-1,0],ArrowRight:[1,0],d:[1,0]}[k];if(!m)return;
  if(over){if(overT>.5)init();return}
  const last=q.length?q[q.length-1]:dir;if((m[0]===-last.x&&m[1]===-last.y)||(m[0]===last.x&&m[1]===last.y))return;
  if(q.length<2)q.push({x:m[0],y:m[1]});started=1}
 function burst(px,py,col,n){for(let i=0;i<n;i++){const a=Math.random()*7,s=30+Math.random()*90;parts.push({x:px,y:py,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:.5,c:col})}}
 function die(){over=1;overT=0;beep(150,.4,'sawtooth',.05);burst(sn[0].x*S+9,sn[0].y*S+9,'#7dffb3',24);
  ov(`💀 Game over<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best(key(),score)}<br>Tik of druk op een pijl om opnieuw te spelen</span>`)}
 function step(){if(q.length)dir=q.shift();prev=sn.map(p=>({...p}));
  let h={x:sn[0].x+dir.x,y:sn[0].y+dir.y};
  if(h.x<0||h.y<0||h.x>=N||h.y>=N){if(walls){die();return}h={x:(h.x+N)%N,y:(h.y+N)%N}}
  const grow=h.x===ap.x&&h.y===ap.y,gs=star&&h.x===star.x&&h.y===star.y;
  if(sn.slice(0,grow?sn.length:sn.length-1).some(p=>p.x===h.x&&p.y===h.y)){die();return}
  sn.unshift(h);
  if(grow){score++;spd=Math.min(16,7+score*.3);ap=free();beep(660+Math.min(score,20)*15,.06,'square',.03);burst(h.x*S+9,h.y*S+9,'#ff5c7a',12);eatT=.15}
  else sn.pop();
  if(gs){score+=5;star=null;starT=8+R(8);beep(1000,.12,'triangle',.04);burst(h.x*S+9,h.y*S+9,'#ffd200',18)}
  prev.length=sn.length}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight']],turn);
 swipe(c,turn);c.onpointerdown=e=>{e.preventDefault();if(over&&overT>.5)init()};
 const stopLoop=loop(dt=>{t+=dt;
  if(over)overT+=dt;else if(started){acc+=dt*spd;while(acc>=1&&!over){acc-=1;step()}
   if(star){star.l-=dt;if(star.l<=0)star=null}else{starT-=dt;if(starT<=0){star=free();star.l=5}}}
  eatT=Math.max(0,eatT-dt);
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.l-=dt}parts=parts.filter(p=>p.l>0);
  // draw
  x.fillStyle='#0e1020';x.fillRect(0,0,W,W);
  for(let j=0;j<N;j++)for(let i=0;i<N;i++)if((i+j)%2){x.fillStyle='#121530';x.fillRect(i*S,j*S,S,S)}
  if(walls){x.strokeStyle='#ff9f43';x.lineWidth=4;x.strokeRect(2,2,W-4,W-4)}
  // apple
  const ab=1+Math.sin(t*6)*.08;x.save();x.translate(ap.x*S+9,ap.y*S+10);x.scale(ab,ab);
  x.fillStyle='#ff4d6d';x.beginPath();x.arc(-3,0,6,0,7);x.arc(3,0,6,0,7);x.fill();x.fillStyle='#ffb3c1';x.beginPath();x.arc(-3,-2,2,0,7);x.fill();
  x.strokeStyle='#8b5a2b';x.lineWidth=2;x.beginPath();x.moveTo(0,-5);x.lineTo(1,-9);x.stroke();x.fillStyle='#38ef7d';x.beginPath();x.ellipse(4,-8,3,1.6,-.5,0,7);x.fill();x.restore();
  if(star){x.save();x.translate(star.x*S+9,star.y*S+9);x.rotate(t*2);x.globalAlpha=star.l<1.5?(Math.floor(t*8)%2?1:.3):1;x.fillStyle='#ffd200';x.beginPath();
   for(let i=0;i<10;i++){const r=i%2?3.5:8.5,a=i*Math.PI/5-Math.PI/2;x.lineTo(Math.cos(a)*r,Math.sin(a)*r)}x.fill();x.restore();x.globalAlpha=1}
  // snake (interpolated)
  const a=over||!started?1:Math.min(1,acc),pts=sn.map((p,i)=>{const o=prev[i]||p;if(Math.abs(o.x-p.x)>1||Math.abs(o.y-p.y)>1)return{x:p.x*S+9,y:p.y*S+9};return{x:(o.x+(p.x-o.x)*a)*S+9,y:(o.y+(p.y-o.y)*a)*S+9}});
  x.lineCap='round';x.lineJoin='round';const L=pts.length;
  for(let i=L-1;i>0;i--){const p=pts[i],n=pts[i-1];const f=1-i/L;x.strokeStyle=`hsl(${150-f*10},75%,${38+f*22}%)`;x.lineWidth=13+f*2;
   x.beginPath();if(Math.hypot(p.x-n.x,p.y-n.y)<S*1.5){x.moveTo(p.x,p.y);x.lineTo(n.x,n.y)}else{x.moveTo(p.x,p.y);x.lineTo(p.x,p.y)}x.stroke()}
  const h=pts[0],hr=8+eatT*12;x.fillStyle=over?'#ff8fa3':'#7dffb3';x.beginPath();x.arc(h.x,h.y,hr,0,7);x.fill();
  const ex=dir.x,ey=dir.y,px=-ey,py=ex;x.fillStyle='#fff';
  for(const s of[-1,1]){x.beginPath();x.arc(h.x+ex*3+px*4*s,h.y+ey*3+py*4*s,2.8,0,7);x.fill()}
  x.fillStyle='#0e1020';for(const s of[-1,1]){x.beginPath();x.arc(h.x+ex*4+px*4*s,h.y+ey*4+py*4*s,1.4,0,7);x.fill()}
  for(const p of parts){x.globalAlpha=Math.max(0,p.l*2);x.fillStyle=p.c;x.fillRect(p.x-1.5,p.y-1.5,3,3)}x.globalAlpha=1;
  if(!started&&!over){x.fillStyle='rgba(14,16,32,.6)';x.fillRect(0,W/2-30,W,60);x.fillStyle='#fff';x.font='bold 18px system-ui,sans-serif';x.textAlign='center';x.fillText('Druk op een pijl of veeg om te starten',W/2,W/2+6)}
  sc.textContent='Score: '+score+' · Beste: '+best(key(),score)+' · Snelheid '+spd.toFixed(1)+(over?' · Game over':'');
 });
 st.t={get ap(){return ap},get sn(){return sn},get dir(){return dir},get score(){return score}};
 init();cur.reset=init;return()=>{stopLoop();inp.stop();c.onpointerdown=null}}},
