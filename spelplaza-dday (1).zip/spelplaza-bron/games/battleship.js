{id:'battleship',n:'Zeeslag',e:'🚢',c:'Bord',g:'#1e3c72,#2a5298',nw:1,run(st){
 // 10x10 Zeeslag tegen de computer. Vloot: 5,4,3,3,2. Minder schoten = beter.
 const N=10,FLEET=[[5,'vliegdekschip'],[4,'slagschip'],[3,'kruiser'],[3,'onderzeeër'],[2,'patrouilleboot']];
 const WATER='linear-gradient(160deg,#2f78d8,#1f58b0)',SHIP='linear-gradient(160deg,#c3cbd8,#7c8798)',HIT='radial-gradient(circle,#ffd1c4 0 28%,#e0432a 38%)',SUNK='#5c1616',MISS='radial-gradient(circle,#eaf2ff 0 15%,transparent 18%),linear-gradient(160deg,#2f78d8,#1f58b0)';
 const lb=(id,s)=>{try{const k='sp_'+id,b=+localStorage.getItem(k)||0;if(s<0&&(!b||s>b)){localStorage.setItem(k,s);return s}return b}catch(e){return 0}};// best() negeert negatieve scores: eigen "minder is beter"-opslag
 const sc=E('div','sc'),info=E('div');info.style.cssText='min-height:42px;font-weight:700;font-size:15px;line-height:1.4';
 const row=E('div');row.style.cssText='display:flex;flex-wrap:wrap;justify-content:center;align-items:flex-start;gap:14px';
 function mkBoard(){const b=E('div','bdr');b.style.cssText+='grid-template-columns:repeat(10,1fr);width:100%;gap:2px;padding:4px;background:#0b2a5c;border-radius:10px;margin:4px 0 0;box-shadow:0 4px 14px rgba(0,0,0,.3)';const cells=[];
  for(let i=0;i<100;i++){const d=E('div');d.style.cssText='border-radius:3px;font-size:18px;line-height:1;transition:background .15s';cells.push(d);b.append(d)}return[b,cells]}
 const[ob,oc]=mkBoard(),[eb,ec]=mkBoard();
 const ow=E('div'),ew=E('div');ow.style.cssText='width:min(380px,100%)';ew.style.cssText='width:min(380px,100%);position:relative';
 const ol=E('div','hint','Jouw vloot'),el=E('div','hint','Vijandelijke wateren · tik om te vuren');ol.style.margin=el.style.margin='0';
 const ov=E('div','ov');ov.style.display='none';ov.onpointerdown=e=>{e.preventDefault();init()};
 ow.append(ol,ob);ew.append(el,eb,ov);row.append(ew,ow);
 const bar=E('div');bar.style.cssText='display:flex;gap:10px;justify-content:center;margin:10px 0 4px';
 const bShuf=E('button','btn','🔀 Schud'),bStart=E('button','btn','⚓ Start');bar.append(bShuf,bStart);
 const hint=E('div','hint');st.append(sc,info,row,bar,hint);
 // ---------- vloot ----------
 function setCells(f,s){const id=f.ships.indexOf(s)+1;s.cells.forEach((i,j)=>{f.grid[i]=id;f.rad[i]=j===0?(s.dir?'45% 45% 3px 3px':'45% 3px 3px 45%'):j===s.len-1?(s.dir?'3px 3px 45% 45%':'3px 45% 45% 3px'):'3px'})}
 function fleet(){const f={grid:new Int8Array(100),shots:new Uint8Array(100),ships:[],rad:[]};
  for(const[len,name]of FLEET){for(;;){const dir=R(2),r=R(dir?N-len+1:N),c=R(dir?N:N-len+1),cells=[];for(let j=0;j<len;j++)cells.push(dir?(r+j)*N+c:r*N+c+j);
   if(cells.every(i=>!f.grid[i])){const s={len,name,dir,cells,hits:0,sunk:0};f.ships.push(s);setCells(f,s);break}}}
  return f}
 function rotate(f,s){const r=(s.cells[0]/N)|0,c=s.cells[0]%N,dir=1-s.dir,id=f.ships.indexOf(s)+1;
  for(let off=0;off<s.len;off++){const r0=dir?Math.min(Math.max(r-off,0),N-s.len):r,c0=dir?c:Math.min(Math.max(c-off,0),N-s.len),cells=[];
   for(let j=0;j<s.len;j++)cells.push(dir?(r0+j)*N+c0:r0*N+c0+j);
   if(cells.every(i=>!f.grid[i]||f.grid[i]===id)){s.cells.forEach(i=>{f.grid[i]=0});s.cells=cells;s.dir=dir;setCells(f,s);return true}}
  return false}
 function fire(f,i){const v=f.grid[i];if(!v){f.shots[i]=1;return{hit:0}}f.shots[i]=2;const s=f.ships[v-1];s.hits++;if(s.hits===s.len)s.sunk=1;return{hit:1,s,sunk:s.sunk}}
 // ---------- computer: jagen met pariteit, dan gericht langs een lijn ----------
 const rr=i=>(i/N)|0,cc=i=>i%N;
 function fits(f,i,len){const r=rr(i),c=cc(i);// past een schip van deze lengte nog over dit vak?
  for(const[dr,dc]of[[0,1],[1,0]])for(let o=0;o<len;o++){let ok=1;for(let j=0;j<len;j++){const Rr=r+dr*(j-o),Cc=c+dc*(j-o);if(Rr<0||Rr>=N||Cc<0||Cc>=N){ok=0;break}const k=Rr*N+Cc;if(f.shots[k]===1||(f.shots[k]===2&&f.ships[f.grid[k]-1].sunk)){ok=0;break}}if(ok)return true}return false}
 function aiPick(){const un=i=>!me.shots[i];
  if(aiHits.length){let cand=[];
   if(aiHits.length>1){const a=aiHits[0],hz=aiHits.some(h=>h!==a&&rr(h)===rr(a)),line=aiHits.filter(h=>hz?rr(h)===rr(a):cc(h)===cc(a));
    if(line.length>1){const lo=Math.min(...line),hi=Math.max(...line),stp=hz?1:N,e1=lo-stp,e2=hi+stp;
     if(e1>=0&&(!hz||cc(lo)>0)&&un(e1))cand.push(e1);if(e2<100&&(!hz||cc(hi)<N-1)&&un(e2))cand.push(e2)}}
   if(!cand.length)for(const h of aiHits)for(const[dr,dc]of[[0,1],[0,-1],[1,0],[-1,0]]){const Rr=rr(h)+dr,Cc=cc(h)+dc;if(Rr>=0&&Rr<N&&Cc>=0&&Cc<N&&un(Rr*N+Cc))cand.push(Rr*N+Cc)}
   if(cand.length)return cand[R(cand.length)]}
  const ml=Math.min(...me.ships.filter(s=>!s.sunk).map(s=>s.len));let cand=[];
  for(let i=0;i<100;i++)if(un(i)&&(rr(i)+cc(i))%ml===0&&fits(me,i,ml))cand.push(i);
  if(!cand.length)for(let i=0;i<100;i++)if(un(i)&&fits(me,i,ml))cand.push(i);
  if(!cand.length)for(let i=0;i<100;i++)if(un(i))cand.push(i);
  return cand[R(cand.length)]}
 // ---------- toestand ----------
 let me,ai,aiHits,shots,busy,phase,lastAi,tm=0,m1,m2;
 const sunkN=f=>f.ships.filter(s=>s.sunk).length;
 function draw(){const over=phase==='over';
  for(let i=0;i<100;i++){const v=me.grid[i],s=me.shots[i],d=oc[i];
   d.style.background=s===2?(me.ships[v-1].sunk?SUNK:HIT):s===1?MISS:v?SHIP:WATER;d.style.borderRadius=v?me.rad[i]:'3px';d.style.boxShadow=i===lastAi?'0 0 0 2px #ffd54a':'none';
   const v2=ai.grid[i],s2=ai.shots[i],e=ec[i],sk=s2===2&&ai.ships[v2-1].sunk,rev=over&&v2&&s2!==2;
   e.style.background=s2===2?(sk?SUNK:HIT):rev?SHIP:s2===1?MISS:WATER;e.style.borderRadius=sk||rev?ai.rad[i]:'3px';e.textContent=s2===2?'💥':'';e.style.cursor=phase==='play'&&!s2?'crosshair':'default'}
  const b=lb('battleship',0);
  sc.textContent=phase==='setup'?'Leg je vloot klaar · Beste: '+(b?-b+' schoten':'–'):'Schoten: '+shots+' · Gezonken: '+sunkN(ai)+'/5 · Beste: '+(b?-b:'–');
  info.innerHTML='<div>'+(m1||'')+'</div><div style="color:var(--mu);font-weight:600">'+(busy?'🤖 De computer richt…':m2||'')+'</div>'}
 function layout(){const s=phase==='setup';ew.style.display=s?'none':'';info.style.minHeight=s?'0':'42px';bar.style.display=s?'flex':'none';ow.style.width=s?'min(380px,100%)':'min(190px,100%)';ol.textContent=s?'Jouw vloot · tik op een schip om het te draaien':'Jouw vloot';
  hint.textContent=s?'🔀 Schud legt de vloot opnieuw · ⚓ Start (of Enter) begint het gevecht':'Tik op een vak in de vijandelijke wateren · 💥 raak · • mis · gezonken schepen worden donkerrood'}
 function tapOwn(i){if(phase!=='setup')return;const v=me.grid[i];if(!v)return;if(rotate(me,me.ships[v-1]))beep(500,.05,'triangle',.03);else{beep(200,.08,'square',.03);m1='Dat schip kan hier niet draaien.'}draw()}
 function tapEnemy(i){if(phase!=='play'||busy||ai.shots[i])return;shots++;const r=fire(ai,i);
  if(r.hit){beep(r.sunk?180:720,r.sunk?.35:.08,r.sunk?'sawtooth':'square',.05);m1=r.sunk?'💥 Je hebt de '+r.s.name+' tot zinken gebracht!':'🎯 Geraakt!'}else{beep(300,.06,'sine',.03);m1='🌊 Mis'}
  m2='';if(ai.ships.every(s=>s.sunk)){end(1);return}busy=1;draw();tm=setTimeout(aiTurn,300)}
 function aiTurn(){tm=0;busy=0;const i=aiPick();const r=fire(me,i);lastAi=i;
  if(r.hit){beep(240,.1,'square',.04);if(r.sunk){aiHits=aiHits.filter(h=>!r.s.cells.includes(h));m2='😱 De computer heeft je '+r.s.name+' tot zinken gebracht!'}else{aiHits.push(i);m2='💢 De computer raakt je '+r.s.name+'!'}}
  else m2='De computer mist 🌊';
  if(me.ships.every(s=>s.sunk)){end(0);return}draw()}
 function end(won){phase='over';busy=0;draw();
  if(won){const b=lb('battleship',-shots);m1='🎉 Je hebt de vijandelijke vloot vernietigd!';beep(880,.4,'triangle',.05);
   ov.innerHTML='🎉 Gewonnen!<br><span style="font-size:15px;font-weight:600">'+shots+' schoten · Beste: '+(-b)+'<br>Tik om opnieuw te spelen</span>'}
  else{m2='💀 Je hele vloot is gezonken.';beep(140,.4,'sawtooth',.05);ov.innerHTML='💀 Verloren<br><span style="font-size:15px;font-weight:600">De computer zonk je hele vloot<br>Tik om opnieuw te spelen</span>'}
  ov.style.display='flex';draw()}
 function start(){if(phase!=='setup')return;phase='play';m1='Jij begint · vuur op de vijandelijke wateren!';m2='';beep(440,.08,'triangle',.04);layout();draw()}
 function shuffle(){if(phase!=='setup')return;me=fleet();m1='';beep(380,.05,'triangle',.03);draw()}
 oc.forEach((d,i)=>d.onpointerdown=e=>{e.preventDefault();tapOwn(i)});ec.forEach((d,i)=>d.onpointerdown=e=>{e.preventDefault();tapEnemy(i)});
 bShuf.onclick=shuffle;bStart.onclick=start;
 const inp=input(st,[],k=>{if(k==='Enter'&&phase==='setup')start();else if(k==='Enter'&&phase==='over')init()});
 function init(){clearTimeout(tm);tm=0;me=fleet();ai=fleet();aiHits=[];shots=0;busy=0;phase='setup';lastAi=-1;m1='';m2='';ov.style.display='none';layout();draw()}
 window._bs={state:()=>({phase,shots,busy}),me:()=>me,ai:()=>ai,start,fire:tapEnemy,_aiTurn:aiTurn};
 init();cur.reset=init;return()=>{clearTimeout(tm);tm=0;inp.stop();delete window._bs}}},
