{id:'checkers',n:'Dammen',e:'⚫',c:'Bord',g:'#8e9eab,#eef2f3',nw:1,run(st){
 // International draughts 10x10: white (human, bottom) vs black (computer). Men capture forwards and backwards, flying kings, majority rule.
 const sc=E('div','sc');st.append(sc);
 const info=E('div','hint');info.style.minHeight='20px';
 const bd=E('div','bdr');bd.style.gridTemplateColumns='repeat(10,1fr)';bd.style.width='min(380px,100%)';bd.style.gap='0';bd.style.borderRadius='8px';bd.style.overflow='hidden';bd.style.boxShadow='0 4px 14px rgba(0,0,0,.35)';
 const hint=E('div','hint','Tik op een schijf en dan op een vakje · slaan is verplicht (meeste stukken) · dammen vliegen');
 st.append(info,bd,hint);
 const sq=[],pc=[];
 for(let i=0;i<100;i++){const d=E('div');const dark=(((i/10)|0)+i%10)%2===1;d.style.backgroundColor=dark?'#7a5a3c':'#ead9b8';d.style.position='relative';
  const p=E('span');p.style.cssText='display:none;width:76%;height:76%;border-radius:50%;align-items:center;justify-content:center;font-size:min(20px,4.8vw);line-height:1;pointer-events:none;box-shadow:0 2px 4px rgba(0,0,0,.55)';d.append(p);pc.push(p);
  d.onpointerdown=e=>{e.preventDefault();tap(i)};sq.push(d);bd.append(d)}
 // ---------- rules ----------
 const DR=[[-1,-1],[-1,1],[1,-1],[1,1]],inB=(r,c)=>r>=0&&r<10&&c>=0&&c<10;
 function capsFrom(b,r,c,p,side,capt,path,out){let any=0;
  for(const[dr,dc]of DR){
   if(p===1){const r1=r+dr,c1=c+dc,r2=r+2*dr,c2=c+2*dc;if(!inB(r2,c2))continue;const i1=r1*10+c1;
    if(b[i1]*side<0&&!capt.includes(i1)&&!b[r2*10+c2]){capt.push(i1);path.push(r2*10+c2);any=1;capsFrom(b,r2,c2,p,side,capt,path,out);capt.pop();path.pop()}}
   else{let r1=r+dr,c1=c+dc;while(inB(r1,c1)&&!b[r1*10+c1]){r1+=dr;c1+=dc}
    if(!inB(r1,c1))continue;const i1=r1*10+c1;if(b[i1]*side>=0||capt.includes(i1))continue;
    let r2=r1+dr,c2=c1+dc;
    while(inB(r2,c2)&&!b[r2*10+c2]){capt.push(i1);path.push(r2*10+c2);any=1;capsFrom(b,r2,c2,p,side,capt,path,out);capt.pop();path.pop();r2+=dr;c2+=dc}}}
  if(!any&&capt.length)out.push({path:path.slice(),caps:capt.slice()})}
 function moves(b,side){let best=[],mx=0;
  for(let i=0;i<100;i++){const v=b[i];if(v*side<=0)continue;const p=Math.abs(v),out=[];b[i]=0;capsFrom(b,(i/10)|0,i%10,p,side,[],[],out);b[i]=v;
   for(const m of out){if(m.caps.length>mx){mx=m.caps.length;best=[]}if(m.caps.length===mx){m.f=i;m.t=m.path[m.path.length-1];best.push(m)}}}
  if(mx)return best;
  const ms=[];
  for(let i=0;i<100;i++){const v=b[i];if(v*side<=0)continue;const r=(i/10)|0,c=i%10;
   if(Math.abs(v)===1){const r1=r-side;for(const dc of[-1,1]){const c1=c+dc;if(inB(r1,c1)&&!b[r1*10+c1])ms.push({f:i,t:r1*10+c1,path:[r1*10+c1],caps:[]})}}
   else for(const[dr,dc]of DR){let r1=r+dr,c1=c+dc;while(inB(r1,c1)&&!b[r1*10+c1]){ms.push({f:i,t:r1*10+c1,path:[r1*10+c1],caps:[]});r1+=dr;c1+=dc}}}
  return ms}
 function apply(b,m,side){const nb=b.slice();let v=nb[m.f];nb[m.f]=0;for(const c of m.caps)nb[c]=0;if(Math.abs(v)===1&&((m.t/10)|0)===(side===1?0:9))v=2*side;nb[m.t]=v;return nb}
 // ---------- AI ----------
 function evalB(b){let e=0;for(let i=0;i<100;i++){const v=b[i];if(!v)continue;const r=(i/10)|0,c=i%10,edge=(c===0||c===9)?-3:0;
   if(v===1)e+=100+(9-r)*2+(r===9?6:0)+edge;else if(v===-1)e-=100+r*2+(r===0?6:0)+edge;else if(v===2)e+=330;else e-=330}return e}
 let nodes=0,deadline=Infinity,aborted=0;
 function search(b,side,d,a,be,ext){nodes++;if((nodes&1023)===0&&performance.now()>deadline)aborted=1;if(aborted)return 0;const ms=moves(b,side);if(!ms.length)return-20000-d;
  const cap=ms[0].caps.length>0;if(d<=0&&!(cap&&ext<4))return side*evalB(b);
  if(ms.length>1)ms.sort((x,y)=>y.caps.length-x.caps.length);
  let best=-Infinity;for(const m of ms){const v=-search(apply(b,m,side),-side,cap?d:d-1,-be,-a,cap?ext+1:ext);if(v>best)best=v;if(v>a)a=v;if(a>=be)break}return best}
 let depth=4,lastMs=0;
 function root(b,side,D){const ms=moves(b,side);for(let i=ms.length-1;i>0;i--){const j=R(i+1);[ms[i],ms[j]]=[ms[j],ms[i]]}// shuffle = variety among equal moves
  let bm=null,bv=-Infinity,a=-Infinity;
  for(const m of ms){const v=-search(apply(b,m,side),-side,D-1,-Infinity,-a,0);if(v>bv){bv=v;bm=m}if(v>a)a=v}return bm}
 function bestMove(b,side,fd){nodes=0;aborted=0;deadline=Infinity;const ms=moves(b,side);if(ms.length===1)return ms[0];const t0=performance.now();depth=fd||4;let m=root(b,side,depth);
  if(!fd&&performance.now()-t0<25){deadline=t0+350;const m5=root(b,side,5);if(m5&&!aborted){m=m5;depth=5}deadline=Infinity;aborted=0}// one ply deeper when there is time (hard limit 350 ms)
  return m}
 // ---------- state ----------
 let b,t,over,sel,cand,step,dispB,dim,tg,lastP,busy,quiet,tm=0,tms=[];
 function status(){over='';const ms=moves(b,t);if(!ms.length)over=t===1?'De computer wint 🤖':'Jij wint! 🎉';else if(quiet>=50)over='Gelijkspel · 25 zetten zonder slag of schijfzet';
  if(over)beep(over.includes('Jij')?880:over.includes('computer')?160:330,.35,over.includes('Jij')?'triangle':'sawtooth',.05);return ms}
 function count(v){let n=0;for(const x of b)if(x*v>0)n++;return n}
 function draw(){const B=dispB||b;
  for(let i=0;i<100;i++){const d=sq[i],v=B[i],dark=(((i/10)|0)+i%10)%2===1;let bg=dark?'#7a5a3c':'#ead9b8';
   if(dark&&lastP&&lastP.includes(i))bg='#9c7d3c';if(i===sel)bg='#c2a23a';d.style.backgroundColor=bg;
   d.style.backgroundImage=tg&&tg.has(i)?'radial-gradient(circle,rgba(255,225,110,.85) 0 19%,transparent 21%)':'none';
   const p=pc[i];if(!v){p.style.display='none';continue}p.style.display='flex';
   p.style.background=v>0?'radial-gradient(circle at 35% 35%,#fff,#dedede 55%,#9a9a9a)':'radial-gradient(circle at 35% 35%,#6a6a6a,#2a2a2a 55%,#000)';
   p.style.opacity=dim&&dim.includes(i)?'.3':'1';p.style.outline=i===sel?'3px solid #ffd54a':'none';p.style.outlineOffset='-1px';
   p.textContent=Math.abs(v)===2?'♛':'';p.style.color=v>0?'#c9a227':'#ffd54a'}
  sc.textContent=(over?over:busy?'🤖 Computer denkt…':step?'Ga verder met slaan…':'Jij bent aan zet (wit)')+' · ⚪ '+count(1)+' – '+count(-1)+' ⚫'}
 function tap(i){if(over||busy||t!==1)return;
  if(step){const nx=cand.filter(m=>m.path[step]===i);if(nx.length){advance(nx,i)}return}
  if(sel>=0&&cand){const nx=cand.filter(m=>m.path[0]===i);if(nx.length){advance(nx,i);return}}
  const all=moves(b,1);if(b[i]>0&&all.some(m=>m.f===i)){sel=i;cand=all.filter(m=>m.f===i);step=0;tg=new Set(cand.map(m=>m.path[0]));info.textContent=all[0].caps.length?'Slaan is verplicht'+(cand[0].caps.length>1?' · '+cand[0].caps.length+' stukken':''):''}
  else{sel=-1;cand=null;tg=null;info.textContent=b[i]>0&&all.length&&all[0].caps.length?'Je moet slaan met een andere schijf':''}
  draw()}
 function advance(nx,i){cand=nx;step++;const m=nx[0];
  if(nx.every(x=>x.path.length===step)){play(m);return}
  dispB=b.slice();dispB[sel]=0;dispB[i]=b[sel];dim=m.caps.slice(0,step);tg=new Set(nx.map(x=>x.path[step]));lastP=[sel,...m.path.slice(0,step)];beep(300,.05,'square',.03);draw()}
 function commit(m,side){const mv=Math.abs(b[m.f])===1||m.caps.length;b=apply(b,m,side);quiet=mv?0:quiet+1;lastP=[m.f,...m.path];sel=-1;cand=null;step=0;dispB=null;dim=null;tg=null;t=-side;beep(m.caps.length?260:520,.06,'square',.03)}
 function play(m){commit(m,1);status();info.textContent='';draw();if(!over){busy=1;draw();tm=setTimeout(aiMove,300)}}
 function aiMove(){tm=0;const t0=performance.now();const m=bestMove(b,-1);lastMs=performance.now()-t0;if(!m){busy=0;status();draw();return}
  // animate the chain step by step
  let k=0;const stepFn=()=>{if(k<m.path.length){dispB=(dispB||b).slice();dispB[k?m.path[k-1]:m.f]=0;dispB[m.path[k]]=b[m.f];dim=m.caps.slice(0,k+1);lastP=[m.f,...m.path.slice(0,k+1)];draw();k++;if(k<m.path.length){tms.push(setTimeout(stepFn,260));return}}
   const d=m.caps.length>1?240:0;tms.push(setTimeout(()=>{busy=0;commit(m,-1);status();draw()},d))};
  stepFn()}
 function init(){clearTimeout(tm);tm=0;tms.forEach(clearTimeout);tms=[];b=Array(100).fill(0);
  for(let i=0;i<100;i++){const r=(i/10)|0;if((r+i%10)%2===1){if(r<4)b[i]=-1;else if(r>5)b[i]=1}}
  t=1;over='';sel=-1;cand=null;step=0;dispB=null;dim=null;tg=null;lastP=null;busy=0;quiet=0;info.textContent='';draw()}
 window._dam={auto:1,board:()=>b.slice(),moves:()=>moves(b,t),
  move(f,to){if(over||busy)return false;const m=moves(b,t).find(m=>m.f===f&&m.t===to);if(!m)return false;commit(m,t);status();draw();if(this.auto&&!over&&t===-1){busy=1;draw();tm=setTimeout(aiMove,300)}return true},
  set(arr,side){b=arr.slice();t=side;over='';sel=-1;cand=null;step=0;dispB=null;dim=null;tg=null;lastP=null;busy=0;quiet=0;status();draw()},
  ai(d){clearTimeout(tm);const t0=performance.now();const m=bestMove(b,t,d);const ms=performance.now()-t0;if(m){commit(m,t);status();draw()}return{ms,nodes,m,depth}},
  state:()=>({over,turn:t,busy,step})};
 init();cur.reset=init;return()=>{clearTimeout(tm);tm=0;tms.forEach(clearTimeout);tms=[];delete window._dam}}},
