{id:'runner3d',n:'Kubus Ren',e:'🏃',c:'3D',g:'#0f2027,#2c5364',nw:1,run(st){
 const W=360,H=480,T=three(st,W,H,{fov:62,far:130}),S=T.s,cam=T.cam,c=T.c,sc=E('div','sc');st.prepend(sc);c.style.margin='0 auto';
 st.append(E('div','hint','◀ ▶ of vegen = baan wisselen · ▲ / spatie / omhoog vegen = springen'));
 const BG=0x16303f;S.background=new THREE.Color(BG);S.fog=new THREE.Fog(BG,18,78);
 const sun=new THREE.DirectionalLight(0xfff2dc,2.8);sun.position.set(4,9,5);S.add(sun,new THREE.HemisphereLight(0xcfe6ff,0x1d2a36,1));
 const M=(col,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:col,roughness:.75,metalness:.05},o));
 // road with scrolling lane texture
 const tc=document.createElement('canvas');tc.width=64;tc.height=128;const tx=tc.getContext('2d');tx.fillStyle='#2b3340';tx.fillRect(0,0,64,128);tx.fillStyle='#e8e4d0';tx.fillRect(20,16,3,52);tx.fillRect(41,16,3,52);tx.fillStyle='#f6c744';tx.fillRect(0,0,3,128);tx.fillRect(61,0,3,128);
 const rt=new THREE.CanvasTexture(tc);rt.wrapT=THREE.RepeatWrapping;rt.colorSpace=THREE.SRGBColorSpace;rt.anisotropy=T.r.capabilities.getMaxAnisotropy();const LEN=180,TILE=6;rt.repeat.set(1,LEN/TILE);
 // sky dome (gradient, unaffected by fog)
 const skc=document.createElement('canvas');skc.width=2;skc.height=128;const sg=skc.getContext('2d'),gr=sg.createLinearGradient(0,0,0,128);gr.addColorStop(0,'#0b1a2a');gr.addColorStop(.55,'#1d4a63');gr.addColorStop(1,'#16303f');sg.fillStyle=gr;sg.fillRect(0,0,2,128);
 const skt=new THREE.CanvasTexture(skc);skt.colorSpace=THREE.SRGBColorSpace;const sky=new THREE.Mesh(new THREE.SphereGeometry(110,16,10,0,Math.PI*2,0,Math.PI/2),new THREE.MeshBasicMaterial({map:skt,side:THREE.BackSide,fog:false}));sky.position.y=-6;S.add(sky);
 const road=new THREE.Mesh(new THREE.PlaneGeometry(6,LEN),M(0xffffff,{map:rt,roughness:.9}));road.rotation.x=-Math.PI/2;road.position.set(0,0,-LEN/2+14);S.add(road);
 const ground=new THREE.Mesh(new THREE.PlaneGeometry(90,LEN),M(0x1a3838,{roughness:1}));ground.rotation.x=-Math.PI/2;ground.position.set(0,-.06,-LEN/2+14);S.add(ground);
 // player
 const player=new THREE.Group(),body=new THREE.Mesh(new THREE.CapsuleGeometry(.38,.5,4,16),M(0xffb703,{roughness:.45}));body.position.y=.63;
 const belt=new THREE.Mesh(new THREE.TorusGeometry(.4,.06,8,20),M(0x1b1d2a));belt.rotation.x=Math.PI/2;belt.position.y=.55;
 const cap=new THREE.Mesh(new THREE.CylinderGeometry(.3,.42,.16,16),M(0xe63946,{roughness:.5}));cap.position.y=1.05;player.add(body,belt,cap);
 const shadow=new THREE.Mesh(new THREE.CircleGeometry(.45,18),new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:.35}));shadow.rotation.x=-Math.PI/2;shadow.position.y=.01;S.add(player,shadow);
 // pools
 const mk=(n,f)=>{const a=[];for(let i=0;i<n;i++){const o=f();o.visible=false;S.add(o);a.push(o)}return a};
 const lowG=new THREE.BoxGeometry(1.7,.6,.5),tallG=new THREE.BoxGeometry(1.7,2.4,.5),coinG=new THREE.CylinderGeometry(.36,.36,.1,20),pilG=new THREE.BoxGeometry(.5,3.2,.5),lampG=new THREE.SphereGeometry(.26,10,8),trunkG=new THREE.CylinderGeometry(.15,.22,1,6),leafG=new THREE.ConeGeometry(.95,2.2,7);
 const lowM=M(0xe76f51),tallM=M(0x8d99ae),coinM=M(0xffd60a,{metalness:.6,roughness:.3,emissive:0x6a4a00}),pilM=M(0x3a4a5c),lampM=M(0xfff0b0,{emissive:0xffd060,emissiveIntensity:1.2}),trunkM=M(0x6b4f3a),leafM=M(0x2a9d8f);
 const lows=mk(12,()=>new THREE.Mesh(lowG,lowM)),talls=mk(12,()=>new THREE.Mesh(tallG,tallM)),coins=mk(40,()=>new THREE.Mesh(coinG,coinM));
 const NP=16,pils=mk(NP,()=>{const g=new THREE.Group(),p=new THREE.Mesh(pilG,pilM),l=new THREE.Mesh(lampG,lampM);p.position.y=1.6;l.position.y=3.35;g.add(p,l);return g});
 const NT=22,trees=mk(NT,()=>{const g=new THREE.Group(),t=new THREE.Mesh(trunkG,trunkM),l=new THREE.Mesh(leafG,leafM);t.position.y=.5;l.position.y=2;g.add(t,l);return g});
 const LX=l=>(l-1)*2;
 let lane,px,py,vy,sp,dist,score,coin,over,spawnD,shake,lastKind,tilt,t,dead,deadAt=0;
 function init(){lane=1;px=0;py=0;vy=0;sp=11;dist=0;score=0;coin=0;over=0;spawnD=30;shake=0;lastKind=0;tilt=0;t=0;dead=0;
  [...lows,...talls,...coins].forEach(o=>o.visible=false);player.rotation.set(0,0,0);player.position.set(0,0,0);rt.offset.y=0;
  pils.forEach((p,i)=>{p.visible=true;p.position.set(i%2?4.3:-4.3,0,8-Math.floor(i/2)*14)});
  trees.forEach((tr,i)=>{tr.visible=true;tr.position.set((i%2?1:-1)*(6.5+Math.random()*4),0,8-i*7.5);tr.scale.setScalar(.8+Math.random()*.5)});
  overlay(st,c,'')}
 const put=(pool,l,z)=>{const o=pool.find(o=>!o.visible);if(!o)return;o.visible=true;o.position.set(LX(l),pool===lows?.3:pool===talls?1.2:.75,z)};
 const coinLine=(l,n)=>{for(let i=0;i<n;i++)put(coins,l,-80-i*1.5)};
 function spawnChunk(){const r=Math.random(),Z=-80;
  if(dist<40||r<.16){coinLine(R(3),5);lastKind=0;return}
  if(r<.5){const l=R(3);put(Math.random()<.5?lows:talls,l,Z);if(Math.random()<.6)coinLine((l+1+R(2))%3,4);lastKind=1;return}
  if(r<.74&&lastKind<2){const f=R(3);for(let l=0;l<3;l++)if(l!==f)put(talls,l,Z);coinLine(f,3);lastKind=2;return}
  const n=lastKind<2?2+R(2):2,f=R(3);for(let l=0;l<3;l++)if(n===3||l!==f)put(lows,l,Z);if(n===2)coinLine(f,3);lastKind=3}
 function jump(){if(over){if(performance.now()-deadAt>900)init();return}if(py<=0){vy=8.6;beep(540,.07,'triangle',.04)}}
 function move(d){if(over)return;const nl=Math.max(0,Math.min(2,lane+d));if(nl!==lane){lane=nl;beep(300,.04,'square',.02)}}
 function die(){over=1;dead=0;deadAt=performance.now();shake=1;best('runner3d',score);beep(120,.35,'sawtooth',.06);setTimeout(()=>beep(90,.3,'sawtooth',.05),120);
  overlay(st,c,`💥 Gebotst!<br><span style="font-size:15px;font-weight:600">Score ${score} · Beste ${best('runner3d',score)}<br>Tik of druk op een toets voor nog een ronde</span>`).style.pointerEvents='none'}
 const inp=input(st,[['◀','ArrowLeft'],['▲',' '],['▶','ArrowRight']],k=>{if(k==='ArrowLeft'||k==='a')move(-1);else if(k==='ArrowRight'||k==='d')move(1);else if(k===' '||k==='ArrowUp'||k==='w')jump();else if(over)jump()});
 let sx=0,sy=0,sw=0;c.onpointerdown=e=>{e.preventDefault();sx=e.clientX;sy=e.clientY;sw=1};
 c.onpointerup=e=>{if(!sw)return;sw=0;const dx=e.clientX-sx,dy=e.clientY-sy;if(Math.abs(dx)<22&&Math.abs(dy)<22)jump();else if(Math.abs(dx)>Math.abs(dy))move(dx>0?1:-1);else if(dy<0)jump()};
 c.onpointercancel=()=>{sw=0};
 const stopLoop=loop(dt=>{t+=dt;
  if(!over){sp=Math.min(30,11+dist/55);dist+=sp*dt;score=Math.floor(dist/2)+coin*10;
   spawnD-=sp*dt;if(spawnD<=0){spawnChunk();spawnD=9+sp*.18+R(5)}
   vy-=26*dt;py+=vy*dt;if(py<=0){py=0;vy=0}
   const tgt=LX(lane),dx=tgt-px;px+=dx*Math.min(1,dt*13);tilt+=((-dx*.35)-tilt)*Math.min(1,dt*10)}
  else{dead+=dt;if(dead<.9){player.rotation.x-=dt*7;py=Math.max(0,py+1.5*dt)}}
  const dz=over?0:sp*dt;rt.offset.y+=dz/TILE;
  for(const o of lows)if(o.visible){o.position.z+=dz;if(o.position.z>8)o.visible=false;else if(!over&&Math.abs(o.position.x-px)<1.15&&Math.abs(o.position.z)<.6&&py<.38)die()}
  for(const o of talls)if(o.visible){o.position.z+=dz;if(o.position.z>8)o.visible=false;else if(!over&&Math.abs(o.position.x-px)<1.15&&Math.abs(o.position.z)<.6)die()}
  for(const o of coins)if(o.visible){o.position.z+=dz;o.rotation.y+=dt*4;o.rotation.z=Math.PI/2;if(o.position.z>8)o.visible=false;else if(!over&&Math.abs(o.position.x-px)<.9&&Math.abs(o.position.z)<.8&&Math.abs(py+.6-o.position.y)<.9){o.visible=false;coin++;beep(880+coin%4*110,.06,'sine',.05)}}
  for(const p of pils){p.position.z+=dz;if(p.position.z>10)p.position.z-=NP/2*14}
  for(const tr of trees){tr.position.z+=dz;if(tr.position.z>10){tr.position.z-=NT*7.5;tr.position.x=(tr.position.x<0?1:-1)*(6.5+Math.random()*4)}}
  player.position.set(px,py,0);if(!over)player.rotation.set(0,0,tilt);body.scale.y=1+Math.sin(t*18)*.03*(py<=0&&!over?1:0);
  shadow.position.set(px,.01,0);const ss=Math.max(.4,1-py*.45);shadow.scale.set(ss,ss,1);shadow.material.opacity=.35*ss;
  if(shake>0)shake=Math.max(0,shake-dt*2.2);const sh=shake*shake*.5,ox=(Math.random()-.5)*sh,oy=(Math.random()-.5)*sh;
  cam.position.set(px*.4+ox,3.2+oy,6.4);cam.lookAt(px*.4,1.1,-4);
  sc.textContent='Score: '+score+' · 🪙 '+coin+' · Beste: '+best('runner3d',score)+(over?' · Gebotst':'');
  T.r.render(S,cam)});
 init();cur.reset=init;
 return()=>{stopLoop();inp.stop();c.onpointerdown=c.onpointerup=c.onpointercancel=null;T.dispose()}}},
