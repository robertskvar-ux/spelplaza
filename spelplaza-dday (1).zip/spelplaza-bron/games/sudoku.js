{id:'sudoku',n:'Sudoku',e:'🧮',c:'Puzzel',g:'#8e2de2,#4a00e0',nw:1,run(st){
 // ---------- generator / solver (bitmask backtracking, MRV) ----------
 const BX=[];for(let i=0;i<81;i++)BX.push((((i/9)|0)/3|0)*3+((i%9)/3|0));
 const PC=new Uint8Array(1024);for(let i=1;i<1024;i++)PC[i]=PC[i>>1]+(i&1);
 function fullGrid(){const g=new Array(81).fill(0),rw=Array(9).fill(0),cl=Array(9).fill(0),bx=Array(9).fill(0);
  function rec(i){if(i===81)return true;const r=(i/9)|0,c=i%9,b=BX[i],used=rw[r]|cl[c]|bx[b];const ds=[1,2,3,4,5,6,7,8,9];for(let k=8;k>0;k--){const j=R(k+1);[ds[k],ds[j]]=[ds[j],ds[k]]}
   for(const d of ds){const m=1<<d;if(used&m)continue;g[i]=d;rw[r]|=m;cl[c]|=m;bx[b]|=m;if(rec(i+1))return true;rw[r]^=m;cl[c]^=m;bx[b]^=m}g[i]=0;return false}
  rec(0);return g}
 function count(g,cap){const rw=Array(9).fill(0),cl=Array(9).fill(0),bx=Array(9).fill(0);for(let i=0;i<81;i++)if(g[i]){const m=1<<g[i];rw[(i/9)|0]|=m;cl[i%9]|=m;bx[BX[i]]|=m}
  let n=0;function rec(){let bi=-1,bc=10,bm=0;for(let i=0;i<81;i++){if(g[i])continue;const m=~(rw[(i/9)|0]|cl[i%9]|bx[BX[i]])&0x3FE,c=PC[m];if(c<bc){bc=c;bi=i;bm=m;if(c<=1)break}}
   if(bi<0){n++;return n>=cap}if(!bc)return false;const r=(bi/9)|0,c=bi%9,b=BX[bi];
   for(let d=1;d<=9;d++){const m=1<<d;if(!(bm&m))continue;g[bi]=d;rw[r]|=m;cl[c]|=m;bx[b]|=m;const s=rec();rw[r]^=m;cl[c]^=m;bx[b]^=m;g[bi]=0;if(s)return true}return false}
  rec();return n}
 function gen(target){const t0=performance.now(),s=fullGrid(),g=s.slice(),ord=[...Array(81).keys()];for(let k=80;k>0;k--){const j=R(k+1);[ord[k],ord[j]]=[ord[j],ord[k]]}
  let giv=81;for(const i of ord){if(giv<=target||performance.now()-t0>800)break;const v=g[i];g[i]=0;if(count(g,2)>1)g[i]=v;else giv--}// keeps a unique solution; time-capped
  return{s,g}}
 // ---------- DOM ----------
 const LV=[['Makkelijk',38],['Gemiddeld',32],['Moeilijk',26]];
 const sc=E('div','sc'),lv=E('div');lv.style.cssText='display:flex;gap:6px;justify-content:center;margin:2px 0 6px';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(360px,100%);margin:6px auto';
 const bd=E('div','bdr');bd.style.cssText+='grid-template-columns:repeat(9,minmax(0,1fr));gap:0;width:100%;margin:0;border:2px solid var(--tx);border-radius:6px;overflow:hidden;background:var(--card)';
 const pad=E('div'),pad2=E('div');pad.style.cssText=pad2.style.cssText='display:flex;gap:4px;width:min(360px,100%);margin:8px auto 0';
 const hint=E('div','hint','Tik op een vakje en dan op een cijfer · toetsen 1–9, pijltjes, Backspace · N = notities · H = hint');
 wrap.append(bd);st.append(sc,lv,wrap,pad,pad2,hint);
 const cells=[];for(let i=0;i<81;i++){const r=(i/9)|0,c=i%9,d=E('div');
  d.style.cssText='font-size:21px;font-weight:600;position:relative;'+(c<8?`border-right:${c%3===2?'2px solid var(--tx)':'1px solid rgba(128,128,140,.35)'};`:'')+(r<8?`border-bottom:${r%3===2?'2px solid var(--tx)':'1px solid rgba(128,128,140,.35)'};`:'');
  d.onpointerdown=e=>{e.preventDefault();select(i)};cells.push(d);bd.append(d)}
 const lvb=LV.map(([n,t],k)=>{const b=E('button','btn',n);b.style.cssText='font-size:13px;padding:6px 10px';b.onclick=()=>{level=k;newGame()};lv.append(b);return b});
 const digb=[];for(let d=1;d<=9;d++){const b=E('button','btn',d);b.style.cssText='flex:1;min-width:0;padding:9px 0;font-size:19px';b.onpointerdown=e=>{e.preventDefault();put(d)};digb.push(b);pad.append(b)}
 const mk=(t,f)=>{const b=E('button','btn',t);b.style.cssText='flex:1;min-width:0;padding:8px 0;font-size:14px';b.onpointerdown=e=>{e.preventDefault();f()};pad2.append(b);return b};
 const clrb=mk('✖ Wissen',()=>put(0)),noteb=mk('✏️ Notities',()=>{notes=!notes;draw()}),hintb=mk('💡 Hint',doHint);
 // ---------- state ----------
 let level=0,sol,val,giv,nts,sel,notes,mist,hints,t0,won,tm=0,ov=null;
 const peers=i=>{const r=(i/9)|0,c=i%9,s=new Set;for(let k=0;k<9;k++){s.add(r*9+k);s.add(k*9+c)}const br=r-r%3,bc=c-c%3;for(let a=0;a<3;a++)for(let b=0;b<3;b++)s.add((br+a)*9+bc+b);s.delete(i);return[...s]};
 const PEERS=[];for(let i=0;i<81;i++)PEERS.push(peers(i));
 const secs=()=>Math.floor(((won||performance.now())-t0)/1000),fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
 // lower-is-better best: best() never stores a first negative score (default 0), so seed it once
 const bestLow=(id,s)=>{let b=best(id,-s);if(b>=0){try{localStorage.setItem('sp_'+id,-s)}catch(e){}b=-s}return-b};
 function conflicts(){const bad=new Set;for(let i=0;i<81;i++)if(val[i])for(const j of PEERS[i])if(val[j]===val[i]){bad.add(i);break}return bad}
 function newGame(){const p=gen(LV[level][1]);sol=p.s;val=p.g.slice();giv=p.g.map(v=>!!v);nts=new Array(81).fill(0);sel=-1;notes=0;mist=0;hints=0;t0=performance.now();won=0;
  if(ov){ov.remove();ov=null}draw()}
 function select(i){if(won)return;sel=i;draw()}
 function put(d){if(won||sel<0||giv[sel])return;
  if(notes&&d){if(val[sel])return;nts[sel]^=1<<d;beep(660,.03,'sine',.02);draw();return}
  if(!d){if(!val[sel]&&!nts[sel])return;val[sel]=0;nts[sel]=0;draw();return}
  if(val[sel]===d)return;val[sel]=d;nts[sel]=0;
  if(d!==sol[sel]){mist++;beep(180,.12,'sawtooth',.04)}else{beep(520,.05,'triangle',.03);for(const j of PEERS[sel])nts[j]&=~(1<<d)}
  check();draw()}
 function doHint(){if(won)return;if(sel<0||giv[sel]||val[sel]===sol[sel]){const e=[];for(let i=0;i<81;i++)if(val[i]!==sol[i])e.push(i);if(!e.length)return;sel=e[R(e.length)]}
  val[sel]=sol[sel];giv[sel]=1;nts[sel]=0;hints++;for(const j of PEERS[sel])nts[j]&=~(1<<sol[sel]);beep(780,.08,'triangle',.03);check();draw()}
 function check(){if(val.every((v,i)=>v===sol[i])){won=performance.now();const s=Math.max(1,secs()),b=bestLow('sudoku_'+level,s);beep(880,.15,'triangle',.05);setTimeout(()=>beep(1100,.25,'triangle',.05),120);
   ov=E('div','ov',`🎉 Opgelost!<br><span style="font-size:15px;font-weight:600">${LV[level][0]} · tijd ${fmt(s)} · beste ${fmt(b)}<br>fouten ${mist} · hints ${hints}<br>Tik voor een nieuwe puzzel</span>`);ov.onpointerdown=e=>{e.preventDefault();newGame()};wrap.append(ov)}}
 function draw(){const bad=conflicts(),sv=sel>=0?val[sel]:0,pr=sel>=0?new Set(PEERS[sel]):null;
  for(let i=0;i<81;i++){const d=cells[i],v=val[i];let bg='',col=giv[i]?'var(--tx)':'var(--ac)';
   if(i===sel){bg='var(--ac)';col='#fff'}else if(sv&&v===sv)bg='rgba(108,92,231,.35)';else if(pr&&pr.has(i))bg='rgba(108,92,231,.12)';
   if(bad.has(i)&&!giv[i]){if(i===sel){bg='#e5484d';col='#fff'}else col='#e5484d'}
   d.style.background=bg;d.style.color=col;d.style.fontWeight=giv[i]?'800':'600';
   if(v){if(d.dataset.k!=='v'+v){d.innerHTML='';d.textContent=v;d.dataset.k='v'+v}}
   else if(nts[i]){const k='n'+nts[i];if(d.dataset.k!==k){d.dataset.k=k;let h='<span style="display:grid;grid-template-columns:repeat(3,1fr);width:100%;height:100%;font-size:9px;font-weight:600;line-height:1;align-items:center;text-align:center">';for(let n=1;n<=9;n++)h+='<i style="font-style:normal">'+(nts[i]>>n&1?n:'')+'</i>';d.innerHTML=h+'</span>'}d.style.color=i===sel?'#fff':'var(--mu)'}
   else if(d.dataset.k!==''){d.innerHTML='';d.dataset.k=''}}
  lvb.forEach((b,k)=>b.style.opacity=k===level?'1':'.5');noteb.style.filter=notes?'brightness(1.35)':'';noteb.style.outline=notes?'2px solid #fff8':'';
  const cnt=Array(10).fill(0);val.forEach(v=>cnt[v]++);digb.forEach((b,k)=>b.style.opacity=cnt[k+1]>=9?'.35':'1');
  const b=best('sudoku_'+level,-99999);
  sc.textContent='⏱ '+fmt(secs())+' · Fouten: '+mist+(b<0?' · Beste: '+fmt(-b):'')+(notes?' · ✏️ notities':'')}
 const inp=input(st,[],k=>{if(k>='1'&&k<='9')put(+k);else if(k==='Backspace'||k==='Delete'||k==='0'||k===' ')put(0);
  else if(k==='n'||k==='N'){notes=!notes;draw()}else if(k==='h'||k==='H')doHint();
  else if(k.startsWith('Arrow')){if(won)return;if(sel<0)sel=0;else{const r=(sel/9)|0,c=sel%9;if(k==='ArrowUp')sel=((r+8)%9)*9+c;if(k==='ArrowDown')sel=((r+1)%9)*9+c;if(k==='ArrowLeft')sel=r*9+(c+8)%9;if(k==='ArrowRight')sel=r*9+(c+1)%9}draw()}
  else if(k==='Enter'&&won)newGame()});
 tm=setInterval(()=>{if(!won)sc.textContent=sc.textContent.replace(/⏱ [\d:]+/,'⏱ '+fmt(secs()))},500);
 window._sud={sol:()=>sol.slice(),val:()=>val.slice(),giv:()=>giv.slice(),select,put,hint:doHint,level:k=>{level=k;newGame()},state:()=>({won:!!won,mist,hints,level,sel,notes,givens:giv.filter(Boolean).length})};
 newGame();cur.reset=newGame;return()=>{clearInterval(tm);inp.stop();delete window._sud}}},
