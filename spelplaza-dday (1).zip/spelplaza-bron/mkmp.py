import sys
base='/tmp/claude-0/-home-claude/5388ee20-f51d-54b4-b00a-6eeb899815a7/scratchpad/'
L=open(base+'sp/games/blokkenland.js').read().split('\n')
m=L.index(' // ===== game layer (solo) =====')
head="{id:'blokkenland',n:'Blokkenland',e:'⛏️',c:'Samen',g:'#56ab2f,#3a7bd5',min:2,max:8,bots:false,restart:false,run(st,net){\n // Blokkenland online: samen bouwen in dezelfde blokkenwereld (seed van de ronde). De host keurt elke blokwijziging goed en stuurt ze door.\n"
body='\n'.join(L[2:m])+'\n'
open(base+'sp/mp/blokkenland.js','w').write(head+body+open(base+'bl_mp_tail.js').read())
