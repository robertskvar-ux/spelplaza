// Clean visual shell for SpelPlaza — applied by build.js after games are spliced in.
module.exports = function applyTheme(html) {
  const css = `
:root{--bg:#f6f6f8;--card:#fff;--tx:#17181f;--mu:#6f7380;--ac:#5b4cf5;--ac2:#ebe9ff;--ln:#e6e7ec;--tint:18%;color-scheme:light}
:root:not([data-theme=light]){color-scheme:light}
@media(prefers-color-scheme:dark){:root:not([data-theme=light]){--bg:#0f1117;--card:#181b24;--tx:#eceef3;--mu:#9397a5;--ac:#8b7dff;--ac2:#2a2650;--ln:#262a36;--tint:30%;color-scheme:dark}}
:root[data-theme=dark]{--bg:#0f1117;--card:#181b24;--tx:#eceef3;--mu:#9397a5;--ac:#8b7dff;--ac2:#2a2650;--ln:#262a36;--tint:30%;color-scheme:dark}
*{box-sizing:border-box}html,body{margin:0}
html{-webkit-text-size-adjust:100%}
body{background:var(--bg);color:var(--tx);font-family:ui-rounded,"SF Pro Rounded","Nunito","Segoe UI Variable","Segoe UI",system-ui,sans-serif;font-size:15px;line-height:1.45;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px);min-height:100%}
button{font:inherit;color:inherit}
:focus-visible{outline:2px solid var(--ac);outline-offset:2px}
header{position:sticky;top:env(safe-area-inset-top,0px);z-index:5;background:var(--card);border-bottom:1px solid var(--ln)}
.hw{max-width:1100px;margin:0 auto;display:flex;align-items:center;gap:12px;padding:10px 16px}
.logo{display:flex;align-items:center;gap:8px;font-weight:800;font-size:19px;letter-spacing:-.02em;cursor:pointer;white-space:nowrap;border:0;background:none;padding:4px 0}
.logo .lg{font-size:22px}
.sr{flex:1;display:flex;align-items:center;max-width:460px;margin-left:auto;background:var(--bg);border:1px solid var(--ln);border-radius:12px;padding:0 10px;gap:8px;color:var(--mu)}
.sr:focus-within{border-color:var(--ac);box-shadow:0 0 0 3px var(--ac2)}
.sr svg{flex:none}
#q{flex:1;min-width:0;background:none;border:0;padding:9px 0;font:inherit;color:var(--tx);outline:0}
#q::placeholder{color:var(--mu)}
#th{border:1px solid var(--ln);background:var(--bg);border-radius:12px;width:40px;height:40px;cursor:pointer;font-size:17px;flex:none}
main{max-width:1100px;margin:0 auto;padding:16px 16px 40px}
.top{display:flex;align-items:end;justify-content:space-between;gap:12px;margin:8px 0 14px}.top .btn{white-space:nowrap;flex:none}
@media(max-width:560px){.top{align-items:center}.top p{display:none}}
.top h1{margin:0;font-size:28px;letter-spacing:-.02em;line-height:1.1}
.top h1 span{color:var(--mu);font-weight:600;font-size:16px;margin-left:8px}
.top p{margin:4px 0 0;color:var(--mu)}
.btn{border:0;border-radius:12px;padding:10px 16px;background:var(--ac);color:#fff;font-weight:700;cursor:pointer;font-size:14px}
.btn:hover{filter:brightness(1.08)}.btn:active{transform:scale(.97)}
.chips{display:flex;gap:6px;overflow-x:auto;padding:2px 0 10px;margin:0 -16px;padding-left:16px;padding-right:16px;scrollbar-width:none}
.chips::-webkit-scrollbar{display:none}
.chips button{flex:none;border:1px solid var(--ln);border-radius:99px;padding:7px 14px;background:var(--card);color:var(--tx);font-weight:600;font-size:14px;cursor:pointer}
.chips button.on{background:var(--tx);color:var(--bg);border-color:var(--tx)}
.grp{margin:18px 0 6px}
.gh2{display:flex;align-items:baseline;gap:8px;margin:0 0 10px}
.gh2 h2{margin:0;font-size:17px;letter-spacing:-.01em}
.gh2 span{color:var(--mu);font-size:14px;font-weight:600}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px 12px}
@media(max-width:560px){.grid{grid-template-columns:repeat(3,1fr);gap:12px 10px}}
.card{position:relative;cursor:pointer;border-radius:16px;outline-offset:3px}
.th{aspect-ratio:1.18;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:44px;background:color-mix(in srgb,var(--c) var(--tint),var(--card));border:1px solid var(--ln);transition:transform .12s ease,background .12s ease}
@media(max-width:560px){.th{font-size:36px;border-radius:14px}}
.card:hover .th{transform:translateY(-2px);background:color-mix(in srgb,var(--c) calc(var(--tint) + 14%),var(--card))}
.card b{display:block;margin:8px 2px 0;font-size:14px;font-weight:700;line-height:1.25;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.card small{display:block;margin:1px 2px 0;color:var(--mu);font-size:12px}
.nw{position:absolute;top:8px;right:8px;background:var(--ac);color:#fff;font-size:11px;font-weight:700;padding:2px 8px;border-radius:99px;line-height:1.5}
.empty{color:var(--mu);padding:30px 0;text-align:center}
.mpbn{display:flex;align-items:center;gap:14px;background:var(--ac2);border:1px solid color-mix(in srgb,var(--ac) 35%,var(--ln));border-radius:18px;padding:14px 16px;margin:4px 0 6px}
.mpbn b{display:block;font-size:15px;margin-bottom:2px}.mpbn span{color:var(--mu);font-size:13.5px;line-height:1.4}.mpbn>div{flex:1;min-width:0}.mpbn .btn{flex:none;white-space:nowrap}
@media(max-width:560px){.mpbn{flex-direction:column;align-items:stretch;text-align:center}}
@media(max-width:560px){#stage .btn{min-height:46px}#stage .sc .btn{min-width:46px}}
footer{text-align:center;color:var(--mu);padding:28px 16px;font-size:13px}
@media(prefers-reduced-motion:reduce){.th,.btn{transition:none}#stage{animation:none}}
body{-webkit-tap-highlight-color:transparent;touch-action:manipulation}
.card:active .th{transform:scale(.96)}
@media(max-width:560px){.grid{grid-template-columns:repeat(2,1fr);gap:14px 12px}.th{font-size:48px;aspect-ratio:1.25}.card b{font-size:15px;white-space:normal}.card small{font-size:12.5px}}
@media(max-width:360px){.grid{gap:10px 8px}}
.ld{text-align:center;color:var(--mu);padding:40px 12px}.ld .sp{width:28px;height:28px;border:3px solid var(--ln);border-top-color:var(--ac);border-radius:50%;margin:0 auto 12px;animation:spin .9s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}
.ld2{opacity:0;animation:ld 0s 6s forwards;max-width:34em;margin:10px auto 0;line-height:1.5}@keyframes ld{to{opacity:1}}
noscript .ld2{opacity:1;animation:none}
#err{display:none;position:fixed;left:12px;right:12px;bottom:12px;z-index:50;background:#2b1a1a;color:#ffd9d9;border:1px solid #7a3a3a;border-radius:14px;padding:12px 14px;font-size:13px;line-height:1.45;box-shadow:0 8px 30px rgba(0,0,0,.35)}
#err b{display:block;margin-bottom:4px;color:#fff}#err code{word-break:break-all;font-family:ui-monospace,Menlo,monospace;font-size:12px}#err button{float:right;margin-left:8px;border:0;background:#fff2;color:#fff;border-radius:8px;padding:4px 8px;cursor:pointer}
#play:fullscreen{background:var(--bg);padding:12px 16px;overflow:auto}
@media(max-width:560px){.pad .btn{min-width:62px;min-height:52px;font-size:22px}}

/* ---- multiplayer ---- */
#mp{display:none;max-width:640px;margin:0 auto}
.hb{border:1px solid var(--ln);background:var(--card);border-radius:12px;padding:0 12px;height:40px;font-weight:600;font-size:14px;cursor:pointer;white-space:nowrap;flex:none}
.hb.live{background:var(--ac2);border-color:var(--ac);color:var(--tx)}
@media(max-width:560px){.hb span{display:none}.hb{padding:0 10px}.sr{min-width:0}.logo{font-size:17px}}
.mpc{background:var(--card);border:1px solid var(--ln);border-radius:20px;padding:20px;margin:0 0 14px}
.mpc h2{margin:0 0 6px;font-size:24px;letter-spacing:-.02em}.mpc h3{margin:14px 0 8px;font-size:16px}.mpc .mu{color:var(--mu);font-weight:500;font-size:14px}
.fld{display:block;font-weight:600;font-size:14px;margin:14px 0 10px}.fld input,#mpc{display:block;width:100%;margin-top:6px;padding:11px 12px;border:1px solid var(--ln);border-radius:12px;background:var(--bg);color:var(--tx);font:inherit;font-size:16px}
.fld input:focus,#mpc:focus{outline:0;border-color:var(--ac);box-shadow:0 0 0 3px var(--ac2)}
#mpc{text-transform:uppercase;letter-spacing:.2em;font-weight:700;margin:0;flex:1}
.mpr{display:flex;gap:8px;margin-top:10px;align-items:stretch}.mpr .btn{flex:none}.mpr>.btn:only-child{flex:1}
.btn.sec{background:var(--bg);color:var(--tx);border:1px solid var(--ln)}
.code{text-align:center;padding:6px 0 10px}.code small{display:block;color:var(--mu);font-size:13px}.code b{display:block;font-size:44px;letter-spacing:.22em;margin:2px 0 6px;font-variant-numeric:tabular-nums}.code .mpr{justify-content:center}
.pl{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:8px}.pl li{background:var(--bg);border:1px solid var(--ln);border-radius:99px;padding:6px 12px;font-weight:600;font-size:14px}
.wait{color:var(--mu);text-align:center;margin:8px 0}
.card.dis{opacity:.4;cursor:not-allowed}.card.dis .th{transform:none}
#mp .grid{grid-template-columns:repeat(auto-fill,minmax(130px,1fr))}

/* ---- profile / avatars ---- */
.pav{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:50%;background:color-mix(in srgb,var(--c) 22%,var(--card));border:2px solid var(--c);font-size:24px;flex:none}
.pav.s{width:26px;height:26px;font-size:15px;border-width:1.5px;margin-right:6px;vertical-align:middle}
.pav.big{width:72px;height:72px;font-size:40px;border-width:3px}
.prof{display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin:14px 0 4px}.pinfo{flex:1;min-width:180px}
.lnk{border:0;background:none;color:var(--ac);font-weight:700;cursor:pointer;padding:6px 0 0;font-size:14px}
.avp{width:100%;margin-top:10px}.avg{display:grid;grid-template-columns:repeat(8,1fr);gap:6px}
@media(max-width:560px){.avg{grid-template-columns:repeat(6,1fr)}}
.av{aspect-ratio:1;border-radius:12px;border:2px solid var(--ln);background:var(--bg);font-size:24px;cursor:pointer;padding:0}
.av.on{border-color:var(--c);background:color-mix(in srgb,var(--c) 22%,var(--card));transform:scale(1.06)}
.cols{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}.cl{width:28px;height:28px;border-radius:50%;border:3px solid transparent;cursor:pointer;padding:0}.cl.on{border-color:var(--tx);transform:scale(1.15)}
.pl li{display:inline-flex;align-items:center;border-color:color-mix(in srgb,var(--c) 45%,var(--ln))}
.stats .srow{display:flex;gap:10px}.stats .srow div{flex:1;background:var(--bg);border:1px solid var(--ln);border-radius:12px;padding:10px;text-align:center}.stats .srow b{display:block;font-size:22px}.stats .srow small{color:var(--mu);font-size:12px}
/* ---- reactions ---- */
#rx{position:fixed;right:12px;bottom:calc(12px + env(safe-area-inset-bottom,0px));z-index:40;display:flex;gap:4px;background:var(--card);border:1px solid var(--ln);border-radius:99px;padding:4px;box-shadow:0 6px 20px rgba(0,0,0,.18)}
#rx button{border:0;background:none;font-size:20px;width:38px;height:38px;border-radius:50%;cursor:pointer;transition:transform .15s}#rx button:hover{background:var(--bg)}#rx button.tap{transform:scale(1.4)}
.rxf{position:fixed;bottom:80px;z-index:39;pointer-events:none;display:flex;flex-direction:column;align-items:center;animation:rxup 2.4s ease-out forwards}
.rxf span{font-size:38px;filter:drop-shadow(0 4px 8px rgba(0,0,0,.25))}.rxf small{background:var(--card);border:1.5px solid var(--c);border-radius:99px;padding:2px 8px;font-size:12px;font-weight:700;white-space:nowrap}
@keyframes rxup{0%{transform:translateY(0) scale(.6);opacity:0}10%{opacity:1;transform:translateY(-10px) scale(1.1)}100%{transform:translateY(-260px) scale(1);opacity:0}}
/* ---- podium ---- */
.podium{position:absolute;inset:0;z-index:20;display:flex;align-items:center;justify-content:center;background:rgba(14,16,32,.55);border-radius:20px;padding:14px;animation:fi .25s}
.pbox{position:relative;background:var(--card);color:var(--tx);border-radius:20px;padding:22px 20px 18px;width:min(380px,100%);max-height:100%;overflow:auto;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.35)}
.pwin{font-size:40px;margin-bottom:6px}.pwin .pav{width:84px;height:84px;font-size:46px;border-width:3px}
.pbox h3{margin:4px 0 6px;font-size:24px;letter-spacing:-.02em}
.prows{list-style:none;margin:12px 0 0;padding:0;text-align:left}.prows li{display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:12px;margin-bottom:4px;background:var(--bg)}.prows li.w{background:var(--ac2)}
.prows .pm{width:26px;text-align:center;font-size:18px}.prows b{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.prows em{font-style:normal;color:var(--mu);font-weight:700}
.pbtns{display:flex;gap:8px;justify-content:center;margin-top:14px;flex-wrap:wrap}
.pclose{position:absolute;top:8px;right:8px;border:0;background:var(--bg);color:var(--mu);border-radius:50%;width:30px;height:30px;cursor:pointer}
#stage canvas.conf,.conf{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;border-radius:20px;background:transparent}

/* ---- round 4: suggestions, tournament, modes, bots ---- */
.card .sgb{position:absolute;top:8px;right:8px;background:var(--ac);color:#fff;font-size:12px;font-weight:800;padding:2px 8px;border-radius:99px}
.card.picked .th{outline:3px solid var(--ac);outline-offset:-3px}
.sugb .sugr{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 10px;border-radius:12px;background:var(--bg);margin-top:6px}.sugr .pav.s{margin:0 0 0 4px}
.trow{display:flex;align-items:center;justify-content:space-between;gap:10px}.trow h3{margin:0}
.tsel{display:flex;flex-wrap:wrap;gap:6px;min-height:28px}.tchip{background:var(--ac2);border:1px solid var(--ac);border-radius:99px;padding:4px 10px;font-weight:700;font-size:13px}
.tourt{margin-top:12px;text-align:left}.tourt ol{list-style:none;padding:0;margin:6px 0}.tourt li{display:flex;align-items:center;gap:6px;padding:4px 8px;border-radius:10px;background:var(--bg);margin-bottom:3px;font-size:14px}.tourt li span:nth-child(2){flex:1}.tourt em{font-style:normal;font-weight:800}
.pl li .pbx{border:0;background:none;color:var(--mu);cursor:pointer;margin-left:4px;font-size:13px}
.modeov{position:fixed;inset:0;z-index:60;background:rgba(10,12,24,.55);display:flex;align-items:center;justify-content:center;padding:16px;animation:fi .15s}
.modebox{position:relative;background:var(--card);color:var(--tx);border-radius:22px;padding:22px 18px 18px;width:min(380px,100%);text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.35)}
.modebox h3{margin:8px 0 2px;font-size:22px}.mth{width:72px;height:72px;margin:0 auto;border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:40px;background:color-mix(in srgb,var(--c) 25%,var(--card))}
.modeb{display:grid;grid-template-columns:44px 1fr;grid-template-rows:auto auto;column-gap:10px;align-items:center;text-align:left;width:100%;margin-top:10px;padding:12px 14px;border-radius:16px;border:1px solid var(--ln);background:var(--bg);cursor:pointer}
.modeb:hover{border-color:var(--ac)}.modeb span{grid-row:1/3;font-size:30px;text-align:center}.modeb b{font-size:16px}.modeb small{color:var(--mu);font-size:13px}

/* ---- play view ---- */
#play{display:none}
#bar{display:flex;align-items:center;gap:8px;margin:4px 0 14px}
#bar h2{margin:0;flex:1;text-align:center;font-size:18px;letter-spacing:-.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#bar .gh{border:1px solid var(--ln);background:var(--card);border-radius:12px;padding:8px 12px;font-weight:600;font-size:14px;cursor:pointer;white-space:nowrap}
#bar .gh:hover{border-color:var(--mu)}
#stage{position:relative;background:var(--card);border:1px solid var(--ln);border-radius:20px;padding:16px;text-align:center;min-height:300px;animation:fi .2s}
@keyframes fi{from{opacity:0;transform:translateY(6px)}}
#stage canvas{max-width:100%;height:auto;touch-action:none;border-radius:12px;background:#0e1020}
#wf{width:100%;height:80vh;border:0;border-radius:12px;background:#fff}
.sc{font-weight:700;margin:6px 0}
.hint{color:var(--mu);font-size:13px;margin:8px auto 0;max-width:46em}
.pad{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:12px}
.pad .btn{min-width:54px;font-size:20px;padding:10px 14px;touch-action:none;user-select:none;-webkit-user-select:none}
.bdr{display:grid;gap:2px;margin:10px auto;touch-action:manipulation;user-select:none;-webkit-user-select:none}
.bdr div{display:flex;align-items:center;justify-content:center;cursor:pointer;aspect-ratio:1}
.ov{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;background:rgba(14,16,32,.74);color:#fff;border-radius:12px;font-weight:800;font-size:22px;text-align:center;padding:16px}
.wrap{position:relative;display:inline-block;max-width:100%}
.g2048{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;width:min(340px,90%);margin:10px auto;background:#bbada0;padding:8px;border-radius:12px;touch-action:none}
.g2048 div{aspect-ratio:1;border-radius:6px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:24px;background:#cdc1b4;color:#776e65}
.mem{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;width:min(340px,90%);margin:10px auto}
.mem div,.ttt div,.mine div,.mole div{aspect-ratio:1;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:34px;cursor:pointer;user-select:none;background:var(--ac);color:#fff}
.mem div.o{background:var(--bg);color:var(--tx)}
.ttt{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;width:min(300px,90%);margin:10px auto}.ttt div{font-size:48px;font-weight:800}
.mine{display:grid;grid-template-columns:repeat(9,1fr);gap:3px;width:min(380px,96%);margin:10px auto}.mine div{font-size:16px;font-weight:800;border-radius:4px;background:#8b86d8}.mine div.o{background:var(--bg);color:var(--tx)}
.simon{display:grid;grid-template-columns:1fr 1fr;gap:10px;width:min(300px,90%);margin:10px auto}.simon div{aspect-ratio:1;border-radius:18px;opacity:.45;cursor:pointer}.simon div.l{opacity:1;filter:brightness(1.3)}
.mole{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;width:min(300px,90%);margin:10px auto}.mole div{background:#7a5230;font-size:44px}
`;
  html = html.replace(/<style>[\s\S]*?<\/style>/, () => '<style>' + css + '</style>');

  const search = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>';
  const markup = `<header><div class="hw"><button class="logo" onclick="home()"><span class="lg">🎮</span>SpelPlaza</button><label class="sr">${search}<input id="q" placeholder="Zoek een spel" autocomplete="off"></label><button id="snd" class="hb" aria-label="Geluid aan/uit" style="padding:0;width:40px">🔊</button><button id="mpbtn" class="hb" onclick="mpOpen()">👥<span> Samen spelen</span></button><button id="th" aria-label="Licht of donker thema">🌙</button></div></header>
<main>
<section id="home"><div class="top"><div><h1>Alle spellen<span id="cnt"></span></h1><p>Gratis, zonder download, op telefoon en computer.</p></div><button class="btn" onclick="launch(G[R(G.length)])">🎲 Verras me</button></div><nav class="chips" id="chips"></nav><div id="lists"><div class="ld"><div class="sp"></div><p>Spellen laden…</p><p class="ld2">Blijft dit staan? Dan draait JavaScript niet in deze weergave — dat gebeurt bij het "voorbeeld" van een gedownload bestand op een telefoon. Open SpelPlaza via de website <a href="https://robertskvar-ux.github.io/spelplaza/">robertskvar-ux.github.io/spelplaza</a> in Safari of Chrome, dan werkt alles.</p></div><noscript><p class="ld2">JavaScript staat uit in deze weergave. Open SpelPlaza via de website <a href="https://robertskvar-ux.github.io/spelplaza/">robertskvar-ux.github.io/spelplaza</a>.</p></noscript></div></section>
<section id="mp"><div id="mpb"></div></section>
<section id="play"><div id="bar"><button class="gh bk">‹ Alle spellen</button><h2 id="pt"></h2><button class="gh fs" title="Volledig scherm" aria-label="Volledig scherm" style="display:none">⛶</button><button class="gh rs">↻<span class="wd"> Opnieuw</span></button></div><div id="stage"></div></section>
</main><footer>SpelPlaza — gratis spelletjes in je browser</footer><div id="err" role="alert"></div>`;
  html = html.replace(/<header>[\s\S]*?<\/footer>/, () => markup);
  const errScript = `<script>(function(){var n=0;function show(m){try{var e=document.getElementById('err');if(!e)return;n++;if(n>3)return;e.style.display='block';e.innerHTML='<button onclick="location.reload()">Herlaad</button><button onclick="this.parentNode.style.display=\\'none\\'">✕</button><b>Er ging iets mis</b><code></code>';e.querySelector('code').textContent=m}catch(x){}}
window.addEventListener('error',function(e){show((e.message||'fout')+(e.filename?'':'')+(e.lineno?' (regel '+e.lineno+')':''))});window.addEventListener('unhandledrejection',function(e){var r=e.reason;show('promise: '+(r&&r.message||r))});})();</script>`;
  html = html.replace('</footer>', () => '</footer>' + errScript);

  const js = `
const RECENT='sp_recent';
function recent(){try{return JSON.parse(localStorage.getItem(RECENT)||'[]')}catch(e){return[]}}
function noteRecent(id){try{const r=[id,...recent().filter(x=>x!==id)].slice(0,6);localStorage.setItem(RECENT,JSON.stringify(r))}catch(e){}}
const sat=h=>{const v=h.replace('#','');const n=v.length==3?v.split('').map(c=>parseInt(c+c,16)):[0,2,4].map(i=>parseInt(v.slice(i,i+2),16));const M=Math.max(...n),m=Math.min(...n);return M?(M-m)/M*Math.min(1,M/120):0};
const tint=g=>{const cs=g.g.split(',').map(s=>s.trim());return cs.sort((a,b)=>sat(b)-sat(a))[0]};
function card(g,click){const d=E('div','card',\`<div class="th" style="--c:\${tint(g)};--c2:\${(g.g.split(',')[1]||tint(g)).trim()}">\${g.e}</div><b>\${g.n}</b><small>\${g.c}\${!click&&typeof BOTH!=='undefined'&&BOTH[g.id]?' · 👥 ook online':''}</small>\`);d.tabIndex=0;d.setAttribute('role','button');const go=click||(()=>pickMode(g));d.onclick=go;d.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}};return d}
function sec(title,gs,n,click){const s=E('section','grp');s.append(E('div','gh2',\`<h2>\${title}</h2>\${n!=null?'<span>'+n+'</span>':''}\`));const gr=E('div','grid');gs.forEach(x=>{const c=card(x,click);if(click)c.querySelector('small').textContent=(x.min===x.max?x.min:x.min+'–'+x.max)+' spelers · online';gr.append(c)});s.append(gr);return s}
function draw(){$('#cnt').textContent=G.length+MP.filter(m=>!(typeof BOTH!=='undefined'&&Object.values(BOTH).includes(m.id))).length;const raw=$('#q').value.trim(),q=raw.toLowerCase();$('#chips').innerHTML='';cats.forEach(c=>{const b=E('button',c==cat?'on':'',c);b.onclick=()=>{cat=c;draw()};$('#chips').append(b)});
 const L=$('#lists');L.innerHTML='';const list=G.filter(g=>(cat=='Alles'||g.c==cat)&&(g.n.toLowerCase().includes(q)||g.c.toLowerCase().includes(q)));
 if(cat=='Alles'&&!q){const rec=recent().map(id=>G.find(g=>g.id===id)).filter(Boolean);if(MP.length){const bn=E('div','mpbn',\`<div><b>👥 Samen spelen met vrienden</b><span>Maak een kamer, deel de code en speel \${MP.length} spellen samen of tegen elkaar — op ieders eigen telefoon.</span></div><button class="btn">Kamer maken of meedoen</button>\`);bn.querySelector('.btn').onclick=mpOpen;L.append(bn)}if(rec.length)L.append(sec('Laatst gespeeld',rec));cats.slice(1).forEach(c=>{const gs=list.filter(g=>g.c==c);if(gs.length)L.append(sec(c,gs,gs.length))});if(MP.length)L.append(sec('Samen spelen met een code',MP,MP.length,mpOpen))}
 else{if(list.length)L.append(sec(q?'Gevonden':cat,list,list.length));const ml=MP.filter(m=>q&&m.n.toLowerCase().includes(q));if(ml.length)L.append(sec('Samen spelen met een code',ml,ml.length,mpOpen))}
 if(!list.length&&!L.children.length)L.append(E('p','empty','Geen spel gevonden voor “'+raw.replace(/</g,'&lt;')+'”. Probeer een ander woord of kies een categorie.'))}
`;
  html = html.replace(/function draw\(\)\{\$\('#cnt'\)[^\n]*\n \$\('#grid'\)[^\n]*\n/, () => js);

  // launch(): plain title, remember as recent
  html = html.replace("$('#pt').textContent=g.e+' '+g.n;", "$('#pt').textContent=g.e+' '+g.n;noteRecent(g.id);STATS.bump('played',g.id);$('#mp').style.display='none';const bk=$('#bar .bk'),rs=$('#bar .rs');bk.textContent='‹ Alle spellen';bk.onclick=home;rs.style.display='';rs.onclick=restart;");
  html = html.replace("function home(){stop();stop=()=>{};cur=null;", "function home(){stop();stop=()=>{};cur=null;$('#mp').style.display='none';mpPill();");
  // theme toggle with icon state
  html = html.replace(/\$\('#th'\)\.onclick=[^\n]*\n/, () => `const isDark=()=>{const d=document.documentElement;return d.dataset.theme?d.dataset.theme=='dark':matchMedia('(prefers-color-scheme:dark)').matches};
const thIcon=()=>{$('#th').textContent=isDark()?'☀️':'🌙'};
$('#th').onclick=()=>{document.documentElement.dataset.theme=isDark()?'light':'dark';thIcon()};
try{const t=localStorage.getItem('sp_theme');if(t)document.documentElement.dataset.theme=t}catch(e){}
addEventListener('click',e=>{if(e.target.id==='th')try{localStorage.setItem('sp_theme',document.documentElement.dataset.theme)}catch(x){}});
thIcon();
const fsb=$('#bar .fs');if(document.fullscreenEnabled&&fsb){fsb.style.display='';fsb.onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else $('#play').requestFullscreen().catch(()=>{})}}
document.addEventListener('fullscreenchange',()=>{if(fsb)fsb.textContent=document.fullscreenElement?'🗗':'⛶'});
function mpPill(){const b=$('#mpbtn');if(!b)return;const on=NET.state!=='off'&&NET.code;b.innerHTML=on?'👥<span> Kamer '+NET.code+'</span>':'👥<span> Samen spelen</span>';b.classList.toggle('live',!!on)}
NET.onStatus(mpPill);NET.onPlayers(mpPill);
`);
  return html;
};
