// Regenerates wordle.z.b64 (raw-deflate, base64) from the pristine WORDLE base64 in original.html, via wordle_fix.js.
// Run: node make_wordle.js   (build.js then picks up wordle.z.b64 unchanged)
const fs = require('fs'), zlib = require('zlib'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, 'original.html'), 'utf8').match(/const WORDLE='([^']+)';/)[1];
const html = require('./wordle_fix')(Buffer.from(src, 'base64').toString('utf8'));
const z = zlib.deflateRawSync(Buffer.from(html, 'utf8'), { level: 9 }).toString('base64');
if (zlib.inflateRawSync(Buffer.from(z, 'base64')).toString('utf8') !== html) throw new Error('roundtrip failed');
fs.writeFileSync(path.join(__dirname, 'wordle.z.b64'), z);
console.log('wordle.z.b64 written:', html.length, 'chars ->', z.length, 'b64');
