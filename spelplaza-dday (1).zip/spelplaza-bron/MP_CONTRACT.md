# SpelPlaza — multiplayer game module contract

Read `CONTRACT.md` first (helpers, CSS, quality bar, Dutch UI). This file adds the multiplayer rules.
Multiplayer games live in `mp/<id>.js`, one object literal each, spliced by `build.js` into the `MP=[...]` array.
You write ONLY your assigned `mp/<id>.js` files (plus throwaway test scripts `t_mp_*.js` in this directory). Never touch `net.js`, `build.js`, `theme.js`, `harness*.js` or other games — if the net layer blocks you, work around it inside your game and report it.

## Module format

```js
{id:'pong',n:'Pong duel',e:'🏓',c:'Samen',g:'#373b44,#4286f4',min:2,max:2,run(st,net){
 // all code inside run(). st = #stage div (already empty). net = the NET object (see API).
 const me=net.myIndex();                // 0 = host, 1.. = joiners (join order). Use it for seat/colour.
 const rnd=net.rng();                   // seeded PRNG, identical on every peer for this round -> same board/deck/order everywhere
 ...
 return()=>{ /* cleanup: stop loops, intervals, listeners, dispose WebGL; net.on() subscriptions are cleared for you */ }
}},
```

Fields: `id` (ascii, unique, = file name), `n` Dutch name, `e` one emoji, `c` always `'Samen'`, `g` two hex colours, `min`/`max` players (host counts), `restart:false` optional (hides the host's "Opnieuw" button; default shows it — it calls `NET.start(id)` again with a new seed on every peer).

## Network model (star, host is the authority)

- Every peer runs the same `run()`; `net.isHost` is true on exactly one of them. Host index is 0.
- `net.players` = `[{id,name,host}]` in seat order, same on every peer. `net.me.id`, `net.me.name`, `net.myIndex()`.
- `net.send(d)`: on a joiner → goes to the host only. On the host → goes to every joiner. `d` must be plain JSON, small (keep under ~2 KB; real-time state at ≤ 20 messages/s).
- `net.sendTo(playerId,d)`: host → one joiner.
- `net.on((d,fromId)=>{})`: receive. `fromId` is the sender's player id (joiners receive `'host'`). Returns an unsubscribe. Subscriptions are cleared automatically when the round ends — but still unsubscribe in cleanup if you keep handles.
- `net.onPlayers(players=>{})`: someone joined or left (also fires on the host when a joiner disconnects). Returns unsubscribe — DO unsubscribe in cleanup.
- Messages can only be lost if a peer disconnects; order between the same two peers is preserved (reliable data channel).

Two patterns — pick one per game:

**A. Host-authoritative (real-time games, party games, anything with hidden info):**
joiners send *inputs* (`{k:'in',up:1}` or `{k:'buzz'}`); the host simulates and broadcasts *absolute state* (`{k:'s',…}`) at a fixed rate (real-time: 20–30/s, small objects; turn/party: whenever it changes). Joiners never simulate authoritative state — they render the last state (interpolate/predict their own paddle locally if it feels laggy). Host applies its own inputs directly.

**B. Lockstep turns (2-player board games):**
each peer holds the full state; the player to move validates locally, applies, then sends the move (`{k:'mv',from,to}`) — joiner → host, host → joiners; the host re-broadcasts a joiner's move to the other joiners if max>2. Every peer applies the same deterministic rules. Reject moves out of turn. Use the seed only for setup.

Late joiners / re-joins: `net.onPlayers` fires on the host; the host should `sendTo(newId, fullState)` so a page that opens mid-round can render. For 2-player games where a seat is required, if `net.players.length < min` show "Wachten op speler…" overlay and pause; if someone leaves mid-game show "⚠️ <naam> heeft het spel verlaten" and the host's Opnieuw hint. Use the player's `name` (escape it — it's untrusted text; use `textContent`, never innerHTML with names).

## UI rules

- Always show whose turn it is / who you are: e.g. `Jij bent ⚫ · Loren is aan zet`. Names from `net.players[i].name`.
- Score line in `.sc`, hints in `.hint`, buttons `.btn`, on-screen pad via `input()`, canvases via `mkCanvas` (≤ 420 px wide); same light/dark rules as CONTRACT.md.
- End of round: clear overlay/line with the winner's name and "De host kan opnieuw starten" (joiners) / `restart` is on the host's bar button.
- No AI opponent in these — the opponents are real people. For 3–8 player games give every player something to do every round (buzzers, votes, simultaneous input); the host is a player too, never just a referee.
- Chat-like free text (draw & guess answers) is untrusted: compare normalised lowercase, render via textContent.
- Sounds via `beep()` sparingly.

## Testing

```
node harness2.js <id> [players]      # builds, starts a local signaling server, opens host + joiners headless, starts your game,
                                     # mashes input on each page, restarts, back to lobby, starts again; prints ✓/✗ with all page errors,
                                     # saves shots/mp-<id>-p<k>-1.png (just started) and -2.png (after input) for every player k
node harness2.js <id> 4              # same with 4 players
```
Then write a real scripted play-through (both/all sides) — this is REQUIRED for every game, the generic mash proves little:
```js
const {openRoom,stopServer}=require('./harness2');
(async()=>{const r=await openRoom('connect4',{players:2});
  // r.pages[0]=host page, r.pages[1..]=joiners (playwright Pages); r.sc(k) score line text; r.stage(k) stage innerText;
  // r.shot(k,'tag') screenshot; r.canvasBox(k) / r.stageBox(k) page-px boxes; r.restart(); r.allErrors(); r.close()
  await r.pages[0].click('#stage .bdr div:nth-child(4)');          // host moves
  await r.pages[1].waitForTimeout(300); console.log(await r.sc(1));  // joiner sees it
  await r.pages[1].click('#stage .bdr div:nth-child(5)');            // joiner moves
  ...play until someone wins; assert the winner text on BOTH pages; try a move out of turn (must be ignored)...
  console.log(r.allErrors()); await r.close(); stopServer(); process.exit(0)})();
```
Headless pages have `hasTouch` when you pass `{touch:true}`; keyboard via `page.keyboard`. For real-time games drive one page with `keyboard.down/up` and read the host's score line; verify the joiner's screen shows the same state (compare `r.sc(0)` vs `r.sc(1)`). Look at the screenshots with the Read tool.
Run scripts from this directory. Always end scripts with `stopServer(); process.exit(0)` (the signaling server is a child process).

Deliver: your files in `mp/`, each passing `node harness2.js <id>` with zero errors and your scripted play-through, plus a one-line summary per game (controls, what you verified, anything unfinished).

## Working next to other builders

Other agents build other games in this same directory at the same time. So that your builds never overwrite theirs, set your own output file in EVERY command you run:

```
SPZ_OUT=dist/mine_<yourgroup>.html node harness2.js pong
SPZ_OUT=dist/mine_<yourgroup>.html node t_mp_pong.js
```
(`build.js`, `harness.js` and `harness2.js` all honour `SPZ_OUT`.) The signaling server port is shared (9123) — that is fine, rooms have unique codes; if a `node harness2.js` run reports "address in use" just run it again.

## Ronde 1 additions: avatars, colours, podium (REQUIRED in every mp game)

Players now carry an avatar and a colour: `net.players[i] = {id, name, host, av:'🦊', col:'#e5383b'}` (colour is unique per player in a room).
- `net.pname(p|id)` → `'🦊 Alex'` — use it EVERYWHERE a player is named (status line, turn indicator, "X wint", chips). Set via `textContent` or build with `esc()`; never trust names as HTML.
- `net.pcol(p|id)` / `p.col` — use the player's colour for everything that belongs to that player: discs (Vier op een rij, Othello pieces keep black/white but the status chip uses col), paddles, tanks, snakes, trails, mallets, drawn lines (dots), cursor/selection colours (sudoku), credit dots (mines), found-word highlights (woordzoeker), quiz/words leaderboard chips, yahtzee column headers. Replace any fixed per-seat palette (e.g. `['#3b82f6','#ef4444',…]`) with `net.players[i].col`.
- Show the avatar next to the name in score lines, e.g. `🦊 Alex (jij) 3 – 1 🐼 Loren`.
- END OF A MATCH: call `net.result({winner: playerId|null, scores: {playerId: points}?, text?: string, unit?: ' pt', buttons?: [{label, fn}]})` on EVERY peer (each peer calls it itself when it knows the game is over — do not send a message just for this). It renders the shared podium overlay (winner avatar, 🥇🥈🥉 rows, confetti, host restart/lobby buttons) and updates the player's local statistics. Rules:
  - `winner: null` with no `scores` = draw. With `scores`, rows are sorted by points (highest first); pass `winner` too when there is one.
  - Keep your own in-game end text minimal (a short line in `.sc` is fine) — remove your old big end overlays; the podium replaces them.
  - Games with their own "next round" flow (ttt best-of, tron/snake/pong rounds): call `net.result` only when the MATCH is decided (e.g. first to 3). For a game that is a series without a fixed end (ttt), call it after every round with `buttons:[{label:'▶ Volgende ronde', fn:()=>startNextRound()}]` and the running series score in `scores`.
  - Co-op games (sudoku, mines, woordzoeker): `winner:null`, `scores` = each player's contribution, `title:'Gelukt! 🎉'` (or `'Boem…'` on a loss), so everyone gets confetti; pass `unit:' vakjes'`/`' woorden'` where fitting.
  - Call it once per round; calling it again just re-renders. Do not call it before the game is really over.
- `net.result` is only available in `mp/` games (it is on the NET object). A late joiner may arrive after the result; that's fine.

## Ronde 4: bots in online rooms (`bots:true`)

The host can add bot players in the lobby. A bot is a normal entry in `net.players`: `{id:'bot-…', name:'Robbie (bot)', bot:true, av:'🤖', col}`. Bots exist ONLY on the host; joiners just see them as players.
- A game that supports bots sets `bots:true` on its module object. Games without it are disabled in the lobby while bots are present.
- `net.isBot(id)` / `net.bots()` — check/list bots. Everything about bots runs on the HOST only (`if(net.isHost)`).
- `net.botAct(botId, d)` — makes the bot "send" message `d`: it is delivered asynchronously to the host's own `net.on(...)` handlers with `fromId = botId`, exactly as if a joiner with that id had sent it. So bots go through the same validation path as humans — never mutate state for a bot directly.
- `net.sendTo(botId, …)` is a no-op. Bots read what they need (their hand, their dice, the key, the board) directly from the host's state — the host already knows all secrets.
- Bot behaviour: decide on the host from the current state with a human-like delay (turn games 600–1500 ms random; real-time games send input every ~100 ms; party games answer after a random 2–10 s), and re-schedule whenever the state changes (keep one timer per bot, clear it in cleanup and when the state moves on). Never let bots act after the game ended or the round changed.
- Strength: "normaal" — beatable but not dumb (e.g. connect4: win if possible, block immediate wins, else prefer centre with randomness; chess: 1–2-ply material search with randomness; quiz: right ~60%; tron/snake: avoid walls/trails with lookahead; pong/hockey: track ball with reaction lag and max speed). It is fine to reuse the AI from the single-player version in `games/<id>.js` (copy the code into the mp file; do not edit games/).
- Bots must work in real-time games too: the host simulation reads a bot's held-input state you keep per bot, updated by `botAct` messages (same message format as a joiner's input).
- UI: bots look like players (avatar 🤖, name with "(bot)"); no "jij" marker; they appear on the podium.
- Tests: add a bot play-through per game in your test script: host + bots only (and also host + 1 human + bots): the game must run to the podium without human input from bot seats, bots must respect turns/rules, and no page errors. Use `await page.evaluate(()=>NET.addBot())` in the lobby before `NET.start(id)`. `openRoom` starts the game immediately, so for bot tests do: `const r=await openRoom(id,{players:1 or 2})`, then `await r.pages[0].evaluate(()=>{NET.toLobby();NET.addBot();NET.addBot()})`, wait, then `await r.pages[0].evaluate(id=>NET.start(id), id)`.
