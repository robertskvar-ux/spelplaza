# SpelPlaza — game module contract

SpelPlaza is a single-file Dutch game portal (`original.html`). Games live in one array `G=[...]`; each entry is an object literal. `build.js` splices every `games/<id>.js` file into that array and writes `dist/spelplaza.html`. You write ONLY the files assigned to you, in `games/<id>.js`, nothing else.

## File format (exactly one object literal, trailing comma)

```js
{id:'invaders',n:'Ruimte-invasie',e:'👾',c:'Arcade',g:'#141e30,#243b55',nw:1,run(st){
 // everything for the game lives inside run(): consts, data, functions
 const c=mkCanvas(st,360,480),x=c.getContext('2d');
 const sc=E('div','sc');st.prepend(sc);          // score line above the canvas
 st.append(E('div','hint','← → bewegen · spatie/tik schiet'));
 let score,over;
 function init(){score=0;over=0;/* ... */}
 const inp=input(st,[['◀','ArrowLeft'],['🔥',' '],['▶','ArrowRight']],k=>{/* press */});
 const stopLoop=loop(dt=>{ /* update + draw, dt in seconds (<=0.05) */ });
 init();cur.reset=init;                           // 🔄 Opnieuw button calls cur.reset()
 return()=>{stopLoop();inp.stop()};               // cleanup: MUST stop every loop/interval/listener
}},
```

Fields: `id` (ascii, unique, = file name) · `n` Dutch display name · `e` one emoji · `c` category — one of `'3D'`, `'Arcade'`, `'Puzzel'`, `'Bord'`, `'Kaarten'`, `'Woorden'`, `'Geheugen'` · `g` two hex colors for the card gradient · `nw:1` always · `run(st)` builds the game inside the `#stage` div `st` (already emptied) and returns a cleanup function.

Rules:
- No top-level statements outside the object; no `</script` substring anywhere; no external URLs, fonts, images or libraries (Three.js is already present as global `THREE`, r158). No `alert/confirm/prompt`.
- All UI text in Dutch (short, friendly). Score line in the `.sc` div, instructions in a `.hint` div.
- Must work on a phone: touch controls (on-screen `input()` pad, or pointer events on the canvas: `onpointerdown/move/up`, `touch-action:none` is already set on canvases) AND keyboard on desktop. Canvas widths ≤ 420 px are safe (portrait phone); the CSS scales canvases down with `max-width:100%` and keeps the aspect ratio. For pointer coordinates always convert through `getBoundingClientRect()` scale (`(e.clientX-r.left)*c.width/r.width`).
- Cleanup: the returned function must cancel rAF loops, intervals, timeouts, key listeners, and dispose WebGL. Opening the game twice in a row must not double anything.
- `cur.reset` must restart cleanly without re-creating DOM (just reset state).
- High score: `best(id,score)` stores and returns the best score (localStorage). Show "Beste: N" in the score line for score-based games.
- Game over must be visible and obvious (use `overlay(st,canvas,html)` for canvas games: dark overlay with text; `overlay(st,canvas,'')` removes it). Offer a way to restart: pressing a key/tapping the canvas when over should call init(), besides the Opnieuw button.
- Quality bar is "best of the best": smooth 60 fps (`loop`), progressive difficulty, polished colors on the `#0e1020` canvas background, small sound effects via `beep()` (subtle, never continuous), no flicker, no scrolling of the page while playing (the helpers already preventDefault arrow/space keys).
- Keep each file reasonably compact (≤ ~250 lines; chess/solitaire may be bigger). Use plain ES2020, no modules.

## Helpers available at run time (defined in the page)

```js
$(sel)                       // querySelector
E(tag, className, innerHTML) // create element
R(n)                         // random int 0..n-1
best(id, score)              // persist + return best score (higher is better; for "lower is better" pass negatives)
mkCanvas(st, w, h)           // appends <canvas> (bg #0e1020, rounded) and returns it
keys(fn)                     // legacy: fn(key) on keydown, return truthy to preventDefault; returns remover
swipe(el, fn)                // fn('ArrowLeft'|'ArrowRight'|'ArrowUp'|'ArrowDown') on touch swipe
loop(fn)                     // rAF loop, fn(dtSeconds); returns stop function
input(st, buttons, onPress)  // keyboard state + optional on-screen pad. buttons=[['◀','ArrowLeft'],...]
                             //   returns {has(key)->bool (held), d:Set, pad:element|null, stop()}
                             //   onPress(key) fires once per key press / pad tap (keys as e.key: 'ArrowUp',' ','a',...)
beep(freq=440, dur=0.08, type='square', vol=0.04)   // tiny synth sound; use sparingly
overlay(st, canvas, html)    // show text overlay over a canvas; overlay(st,canvas,'') hides it
three(st, w, h, {fov,shadow,far})  // → {r:WebGLRenderer, s:Scene, cam:PerspectiveCamera, c:canvas, dispose()}
                             //   call T.dispose() in cleanup. Use MeshStandardMaterial + DirectionalLight(…, 3) + AmbientLight(…, .6)
cur                          // current game slot: set cur.reset = fn
```

CSS you can use: `.sc` (bold score line), `.hint` (muted small text), `.btn` (purple button), `.pad` (row of big touch buttons — created by input()), `.bdr` (grid board: set `style.gridTemplateColumns` and `width`), `.mem` (4-col grid of tiles), `.ov`, `.wrap`. Theme vars: `var(--bg) var(--card) var(--tx) var(--mu) var(--ac)` — page has light and dark mode, so for DOM-based games use these vars (never hard-code white backgrounds for text areas). Inline styles are fine.

## Testing (do this for every game, fix until clean)

```
node harness.js <id> [<id2> ...]     # builds dist with just those games, opens each headless, mashes keys/pointer, restarts, re-opens
                                     # prints ✓/✗ with console errors, saves shots/<id>-1.png (just started) and shots/<id>-2.png (after input)
```
Look at the screenshots with the Read tool and judge them: is the game visible, readable, centred, playable, does game-over appear, does restart work. For deeper checks write a small script:

```js
const {openGame}=require('./harness');
(async()=>{const g=await openGame('invaders',{touch:true});
  const b=await g.canvasBox();            // {x,y,w,h} in page px
  await g.page.keyboard.down('ArrowLeft');await g.page.waitForTimeout(500);await g.page.keyboard.up('ArrowLeft');
  await g.page.mouse.click(b.x+b.w/2,b.y+b.h/2);
  console.log(await g.page.evaluate(()=>document.querySelector('#stage .sc').textContent));
  await g.shot(3); console.log(g.errors); await g.close();})();
```
Run scripts from this directory (`/tmp/claude-0/-home-claude/5388ee20-f51d-54b4-b00a-6eeb899815a7/scratchpad/sp`). Headless WebGL works (SwiftShader). The viewport is a 420×800 phone; also sanity check desktop once with `{viewport:{width:1100,height:800}}`.

Deliver: your files in `games/`, each passing `node harness.js <id>` with zero errors, plus a 1-line-per-game summary of controls and anything you could not finish.
