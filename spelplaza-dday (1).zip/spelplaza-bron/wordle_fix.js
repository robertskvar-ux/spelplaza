// Patches the decoded Wordle HTML so it fits a narrow iframe (phone): keyboard keys flex/shrink,
// board + keyboard laid out in 100dvh with the keyboard at the bottom, tiles sized to the free space.
// Usage: require('./wordle_fix')(html) -> patched html. Idempotent (marker check).
module.exports = function (html) {
  if (html.includes('/*spz-fit*/')) return html;
  const css = `/*spz-fit*/
html,body{height:100%;overflow:hidden}
body{min-height:0;height:100vh;height:100dvh}
.game{height:100%;display:flex;flex-direction:column;padding:8px 8px 6px;max-width:700px}
header{flex:0 0 auto}
.panel{flex:0 0 auto;margin:8px auto;padding:8px 10px;width:100%}
.controls{gap:6px;flex-wrap:nowrap}
input[type=range]{flex:1 1 auto;min-width:50px;width:auto;max-width:180px}
input[type=number]{width:56px;padding:6px;flex:0 0 auto}
#newbtn{flex:0 0 auto;padding:9px 10px;white-space:nowrap}
.chips{flex-wrap:nowrap;overflow-x:auto;justify-content:flex-start;margin-top:8px;padding-bottom:2px;scrollbar-width:none}
.chips::-webkit-scrollbar{display:none}
.chips button{flex:0 0 auto}
#info{flex:0 0 auto;margin:2px 0;gap:12px}
#message{flex:0 0 auto;min-height:24px;font-size:16px;margin:2px 0 4px}
#board{flex:1 1 0;min-height:0;justify-content:center;overflow:auto;padding:4px}
#keyboard{flex:0 0 auto;margin-top:6px;width:100%;gap:6px}
.keyrow{width:100%;justify-content:center;gap:5px}
.keyrow button{flex:1 1 0;min-width:0;max-width:44px;padding:0}
.keyrow button.primary,.keyrow button:not(.key){max-width:none;flex:0 1 auto;height:46px;padding:0 10px;min-width:56px}
.key{width:auto;height:52px}
@media(max-width:480px){.key{width:auto;height:46px}h1{font-size:24px}h1 span{width:26px;height:26px;line-height:26px;font-size:16px}.icons button{width:36px;height:36px;font-size:17px}}
@media(max-width:400px){.game{padding:6px 4px 4px}.keyrow{gap:3px}#keyboard{gap:5px}.key{height:44px;font-size:13px}.panel{padding:6px 8px;margin:6px auto}#newbtn{font-size:13px}}
@media(max-height:720px){.key{height:42px}.keyrow button:not(.key){height:42px}#keyboard{gap:5px;margin-top:4px}.panel{margin:6px auto;padding:6px 10px}.chips{margin-top:6px}h1 span{width:30px;height:30px;line-height:30px;font-size:19px}.icons button{width:36px;height:36px}}
@media(max-height:560px){.key{height:36px}.keyrow button:not(.key){height:36px}#keyboard{gap:4px}.panel{margin:4px auto}}
`;
  const js = `<script>/*spz-fit*/(function(){
function fit(){var b=document.getElementById("board");if(!b||!b.children.length)return;var rows=b.children.length,n=b.children[0].children.length;if(!n)return;
var W=b.clientWidth-10,H=b.clientHeight-10,s=Math.floor(Math.min((W-(n-1)*4)/n,(H-(rows-1)*5)/rows));s=Math.max(18,Math.min(58,s));
b.querySelectorAll(".tile").forEach(function(t){t.style.width=t.style.height=s+"px";t.style.fontSize=Math.max(11,s*.5)+"px"})}
var cb=createBoard;createBoard=function(){cb();fit()};
addEventListener("resize",fit);fit();requestAnimationFrame(fit);
})();</script>`;
  if (!html.includes('</style>') || !html.includes('</body>')) throw new Error('wordle_fix: anchors not found');
  html = html.replace('</style>', () => css + '</style>');
  const i = html.lastIndexOf('</body>');
  return html.slice(0, i) + js + html.slice(i);
};
