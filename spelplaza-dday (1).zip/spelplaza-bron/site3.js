// Round 6 site features (applied after colorful.js):
//  1. chat in online rooms (lobby card + collapsible sheet during games) with profanity filter, host relay, rate limit, history
//  2. "Spel van de dag" + favourites (⭐ on cards, Favorieten section + chip)
//  3. "Hoe speel je?" panel for every solo + online game (texts in howto.js)
//  4. Instellingen sheet (animaties uit, grotere knoppen, kleurenblind-modus, geluid, donker thema)
const fs = require('fs'), path = require('path');
module.exports = function applySite3(html) {
  const HOWTO = require('./howto.js');
  // ---- build-time check: every G and MP id needs a how-to ----
  {
    const g0 = html.indexOf('const G=['), g1 = html.indexOf('\nconst cats=', g0);
    const gIds = [...html.slice(g0, g1).matchAll(/\n\{id:'([^']+)'/g)].map(m => m[1]);
    const m0 = html.indexOf('const MP=['), m1 = html.indexOf('\n];', m0);
    const mIds = [...html.slice(m0, m1 < 0 ? m0 : m1).matchAll(/\n\{id:'([^']+)'/g)].map(m => m[1]);
    const miss = [...gIds.filter(id => !HOWTO.solo[id]).map(id => 'solo:' + id), ...mIds.filter(id => !HOWTO.mp[id]).map(id => 'mp:' + id)];
    const bad = [...Object.entries(HOWTO.solo).map(([k, v]) => ['solo:' + k, v]), ...Object.entries(HOWTO.mp).map(([k, v]) => ['mp:' + k, v])].filter(([, v]) => !Array.isArray(v) || v.length < 3 || v.length > 6).map(([k]) => k);
    if (miss.length) console.warn('HOWTO missing for: ' + miss.join(', '));
    if (bad.length) console.warn('HOWTO needs 3–6 bullets: ' + bad.join(', '));
    console.log('howto: ' + gIds.length + ' solo + ' + mIds.length + ' online ids checked, ' + miss.length + ' missing');
  }
  const css = `
/* ---- round 6: header settings button ---- */
#set{padding:0;width:40px;font-size:17px}
@media(max-width:560px){header .hw{gap:8px}#th{display:none}}
/* ---- sheets (settings, chat) ---- */
.sheet{position:fixed;inset:0;z-index:65;background:rgba(10,12,24,.5);display:flex;align-items:flex-end;justify-content:center;animation:fi .15s}
.shp{position:relative;background:var(--card);color:var(--tx);width:min(460px,100%);max-height:86vh;overflow:auto;border-radius:22px 22px 0 0;padding:16px 16px calc(16px + env(safe-area-inset-bottom,0px));box-shadow:0 -10px 40px rgba(0,0,0,.3)}
@media(min-width:561px){.sheet{align-items:center;padding:16px}.shp{border-radius:22px}}
.shp h3{margin:0 0 10px;font-size:20px;padding-right:40px}
.shp .pclose{top:12px;right:12px}
.srow2{display:flex;align-items:center;gap:12px;padding:11px 4px;border-top:1px solid var(--ln);cursor:pointer}
.srow2:first-of-type{border-top:0}.srow2>span{font-size:22px;width:30px;text-align:center;flex:none}.srow2 div{flex:1;min-width:0}.srow2 b{display:block;font-size:15px}.srow2 small{display:block;color:var(--mu);font-size:12.5px;line-height:1.35}
.sw{appearance:none;-webkit-appearance:none;flex:none;width:50px;height:30px;border-radius:99px;background:var(--ln);position:relative;cursor:pointer;margin:0;transition:background .15s}
.sw::after{content:"";position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:transform .15s}
.sw:checked{background:var(--ac)}.sw:checked::after{transform:translateX(20px)}
.spz-cb .sw:checked::after{content:"✓";color:var(--ac);font-weight:900;font-size:15px;line-height:24px;text-align:center}
/* ---- how to play ---- */
#bar .hlp[aria-expanded=true]{background:var(--ac2);border-color:var(--ac)}
#howto{display:none;background:var(--card);border-radius:18px;padding:12px 16px 12px 14px;margin:-4px 0 12px;box-shadow:0 6px 18px rgba(60,40,140,.10);text-align:left}
#howto.open{display:block;animation:fi .15s}
#howto b{display:block;font-family:"Fredoka","Nunito",ui-rounded,system-ui,sans-serif;font-size:16px;margin-bottom:4px}
#howto ul{margin:0;padding:0;list-style:none}#howto li{padding:4px 0;font-size:14px;line-height:1.4;border-top:1px dashed var(--ln)}#howto li:first-child{border-top:0}
/* ---- spel van de dag ---- */
.sotd{position:relative;overflow:hidden;display:flex;align-items:center;gap:14px;border-radius:24px;padding:16px;margin:4px 0 12px;color:#fff;background:linear-gradient(130deg,var(--c1),var(--c2));box-shadow:0 12px 28px -12px var(--c1);cursor:pointer}
.sotd::before{content:"";position:absolute;inset:0;background:radial-gradient(260px 160px at 20% 0,rgba(255,255,255,.35),transparent 60%);pointer-events:none}
.sotd .se{flex:none;width:84px;height:84px;border-radius:20px;background:rgba(255,255,255,.22);display:flex;align-items:center;justify-content:center;font-size:52px;text-shadow:0 4px 10px rgba(0,0,0,.25);animation:wob 5s ease-in-out infinite}
.sotd>div{position:relative;flex:1;min-width:0}
.sotd small{display:inline-block;background:rgba(0,0,0,.22);border-radius:99px;padding:2px 10px;font-weight:800;font-size:12px;letter-spacing:.02em}
.sotd h2{margin:6px 0 2px;font-size:24px;line-height:1.1;text-shadow:0 2px 0 rgba(0,0,0,.15)}
.sotd p{margin:0;font-size:13.5px;font-weight:700;opacity:.95;line-height:1.35}
.sotd .btn{position:relative;flex:none;background:#fff;color:#1d1640;font-size:15px}
@media(max-width:560px){.sotd{flex-wrap:wrap;padding:14px}.sotd .se{width:68px;height:68px;font-size:42px;border-radius:16px}.sotd h2{font-size:21px}.sotd .btn{flex:1 0 100%;min-height:46px}}
/* ---- favourites ---- */
.card .fav{position:absolute;top:6px;left:6px;z-index:2;width:34px;height:34px;border-radius:50%;border:0;padding:0;background:rgba(0,0,0,.22);color:#fff;font-size:17px;line-height:34px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .12s}
.card .fav:hover{transform:scale(1.12)}.card .fav[aria-pressed=true]{background:rgba(255,255,255,.92);color:#f5a700}
.card .fav:focus-visible{outline:2px solid #fff;outline-offset:1px;box-shadow:0 0 0 4px var(--ac)}
/* ---- chat ---- */
#mp{padding-bottom:64px}
.chatc h3{display:flex;align-items:center;gap:8px;margin:0 0 8px}
.chl{max-height:220px;min-height:64px;overflow-y:auto;display:flex;flex-direction:column;gap:6px;padding:8px;background:var(--bg);border-radius:14px;overscroll-behavior:contain}
.shp .chl{max-height:min(46vh,340px)}
.chm{display:flex;align-items:flex-start;gap:6px;font-size:14px;line-height:1.35;text-align:left}
.chm .pav.s{margin:0;flex:none}.chm>div{min-width:0;flex:1;background:var(--card);border-radius:4px 14px 14px 14px;padding:5px 10px;border-left:3px solid var(--c);overflow-wrap:anywhere}
.chm b{display:block;font-size:12px;color:color-mix(in srgb,var(--c) 70%,var(--tx))}
.chm.me{flex-direction:row-reverse}.chm.me>div{border-radius:14px 4px 14px 14px;border-left:0;border-right:3px solid var(--c);background:var(--ac2)}
.che{color:var(--mu);font-size:13px;text-align:center;padding:12px 4px}
.chf{display:flex;gap:8px;margin-top:8px}.chf input{flex:1;min-width:0;padding:10px 12px;border:1px solid var(--ln);border-radius:12px;background:var(--bg);color:var(--tx);font:inherit;font-size:16px}
.chf input:focus{outline:0;border-color:var(--ac);box-shadow:0 0 0 3px var(--ac2)}.chf .btn{flex:none}
.chn{min-height:1em;margin:6px 2px 0;font-size:12.5px}
#rx #chb{position:relative;display:inline-block;font-size:19px}
#chb i{position:absolute;top:-3px;right:-3px;min-width:18px;height:18px;border-radius:99px;background:#ff3b5c;color:#fff;font-style:normal;font-size:11px;font-weight:800;line-height:18px;padding:0 4px;display:none;box-shadow:0 0 0 2px var(--card)}
#chb.unread i{display:block}
/* ---- settings: animations off ---- */
html.spz-noanim *,html.spz-noanim *::before,html.spz-noanim *::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}
html.spz-noanim .card:hover .th,html.spz-noanim .card:active .th,html.spz-noanim .btn:active,html.spz-noanim .chips button.on,html.spz-noanim .card .fav:hover{transform:none!important}
html.spz-noanim .rxf{bottom:110px;opacity:1}
html.spz-noanim .top::after{transform:none}
/* ---- settings: bigger buttons (~1.25x) ---- */
html.spz-big .btn{font-size:17px;padding:13px 20px;border-radius:14px}
html.spz-big #stage .btn{min-height:56px}
html.spz-big .pad{gap:10px}
html.spz-big .pad .btn,html.spz-big #stage .pad .btn{min-width:72px;min-height:66px;font-size:27px;padding:12px 16px}
html.spz-big #bar .gh{padding:11px 15px;font-size:16px;min-height:48px}
html.spz-big .chips button{padding:10px 17px;font-size:16px}
html.spz-big .modeb{padding:16px 16px}
html.spz-big #rx button{width:46px;height:46px;font-size:24px}
html.spz-big .card .fav{width:42px;height:42px;font-size:21px}
html.spz-big .bk-tb{grid-template-columns:repeat(2,70px);gap:10px}html.spz-big .bk-tb button{width:70px;height:70px;font-size:32px}
html.spz-big .bk-s{max-width:62px}
/* ---- settings: colour-blind mode (shape markers next to player colours) ---- */
.pav{position:relative}
html.spz-cb .pav[data-sh]::after{content:attr(data-sh);position:absolute;right:-6px;bottom:-5px;width:15px;height:15px;border-radius:50%;background:var(--card);color:var(--tx);border:1.5px solid var(--c);font-size:9px;line-height:12px;text-align:center;font-weight:900;font-family:system-ui,sans-serif}
html.spz-cb .pav.big[data-sh]::after{width:24px;height:24px;font-size:14px;line-height:21px;right:-4px;bottom:-2px}
html.spz-cb .cl[data-sh]::after{content:attr(data-sh);color:#fff;font-size:12px;font-weight:900;text-shadow:0 0 2px #000,0 0 2px #000}
html.spz-cb .cl{display:inline-flex;align-items:center;justify-content:center}
html.spz-cb .card .fav[aria-pressed=true]::after{content:"";position:absolute;inset:3px;border:2px solid #f5a700;border-radius:50%}
`;
  html = html.replace('</style></head>', () => css + '</style></head>');
  // header: settings button (before the theme toggle)
  const th = '<button id="th"';
  if (!html.includes(th)) throw new Error('site3: #th not found');
  html = html.replace(th, () => '<button id="set" class="hb" aria-label="Instellingen" title="Instellingen" aria-haspopup="dialog">⚙️</button>' + th);
  // play view: how-to button in the bar + panel between bar and stage
  const rs = '<button class="gh rs">';
  if (!html.includes(rs)) throw new Error('site3: restart button not found');
  html = html.replace(rs, () => '<button class="gh hlp" aria-expanded="false" aria-controls="howto" title="Hoe speel je?">❓<span class="wd"> Uitleg</span></button>' + rs);
  html = html.replace('<div id="stage"></div>', () => '<div id="howto" role="region" aria-label="Hoe speel je?"></div><div id="stage"></div>');

  const js = `
;(function(){
const HOWTO=${JSON.stringify(HOWTO)};
const lsg=(k,d)=>{try{const v=localStorage.getItem(k);return v==null?d:v}catch(e){return d}};
const lss=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
// ================= settings =================
const STD=COLORS.slice(),CBP=['#0072b2','#d55e00','#009e73','#e69f00','#56b4e9','#cc79a7','#f0e442','#8c8c8c'];
const SHAPES=['●','▲','■','◆','★','✚','▼','✖'];
const toLocal=c=>{if(!c)return c;const s=String(c).toLowerCase();let i=STD.map(x=>x.toLowerCase()).indexOf(s);if(i<0)i=CBP.indexOf(s);return i<0?c:COLORS[i]};
let SET={};try{SET=JSON.parse(lsg('sp_set','{}'))||{}}catch(e){SET={}}
if(SET.anim==null)SET.anim=!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
const hexOf=c=>{const m=String(c).match(/rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)/);return m?'#'+[m[1],m[2],m[3]].map(v=>(+v).toString(16).padStart(2,'0')).join(''):String(c).trim().toLowerCase()};
let shRaf=0;function markShapes(){shRaf=0;if(!SET.cb)return;document.querySelectorAll('.pav,.cl').forEach(el=>{const c=hexOf(el.classList.contains('cl')?el.style.background:el.style.getPropertyValue('--c'));const i=COLORS.map(x=>x.toLowerCase()).indexOf(c);const s=i<0?'':SHAPES[i];if(el.dataset.sh!==s){if(s)el.dataset.sh=s;else delete el.dataset.sh}})}
const mo=new MutationObserver(()=>{if(SET.cb&&!shRaf)shRaf=requestAnimationFrame(markShapes)});
function applySettings(){const d=document.documentElement;d.classList.toggle('spz-noanim',!SET.anim);d.classList.toggle('spz-big',!!SET.big);d.classList.toggle('spz-cb',!!SET.cb);
  window.SPZ_NOANIM=!SET.anim;window.SPZ_BIG=!!SET.big;window.SPZ_CB=!!SET.cb;
  const want=SET.cb?CBP:STD;if(COLORS[0]!==want[0]){COLORS.splice(0,COLORS.length,...want);
    try{const p=JSON.parse(localStorage.getItem('sp_profile')||'null');if(p&&p.col){const n=toLocal(p.col);if(n!==p.col){p.col=n;localStorage.setItem('sp_profile',JSON.stringify(p))}}}catch(e){}
    NET.me.col=toLocal(NET.me.col);NET.players.forEach(p=>p.col=toLocal(p.col));CHAT.forEach(m=>m.col=toLocal(m.col));
    if(NET.state!=='off'){if(NET.isHost)NET._bcast(NET._playersMsg());NET._emitPlayers();if($('#mp').style.display==='block'&&!NET.game&&NET.state==='lobby')showLobby();renderChat()}
    else if($('#mp').style.display==='block'&&$('#mpb .prof'))mpStart()}
  if(SET.cb){mo.observe(document.body,{childList:true,subtree:true});markShapes()}else{mo.disconnect();document.querySelectorAll('[data-sh]').forEach(el=>delete el.dataset.sh)}}
function saveSet(){lss('sp_set',JSON.stringify(SET));applySettings()}
window.SPZ_SET=()=>Object.assign({},SET);
function sheet(cls,inner){const o=E('div','sheet '+cls);o.innerHTML='<div class="shp" role="dialog" aria-modal="true"><button class="pclose" aria-label="Sluiten">✕</button>'+inner+'</div>';
  const close=()=>{o.remove();removeEventListener('keydown',esc,true);o.dispatchEvent(new Event('closed'))};const esc=e=>{if(e.key==='Escape'){e.stopPropagation();close()}};addEventListener('keydown',esc,true);
  o.onclick=e=>{if(e.target===o)close()};o.querySelector('.pclose').onclick=close;o.close=close;document.body.append(o);return o}
function openSettings(){const ex=$('.sheet.sets');if(ex){ex.close();return}
  const rows=[['snd','🔊','Geluid','Korte geluidjes in de spellen',()=>!window.SPZ_MUTE],['dark','🌙','Donker thema','Rustig voor je ogen, ook ’s avonds',()=>isDark()],
    ['anim','✨','Animaties','Uit = geen bewegende logo’s, confetti of zwevende reacties',()=>!!SET.anim],['big','👆','Grotere knoppen','Knoppen en bedieningspads ongeveer 25% groter',()=>!!SET.big],
    ['cb','🎨','Kleurenblind-modus','Kleurveilige spelerskleuren met een vormpje (● ▲ ■ …) erbij',()=>!!SET.cb]];
  const o=sheet('sets','<h3>⚙️ Instellingen</h3>'+rows.map(([k,i,t,s])=>'<label class="srow2"><span>'+i+'</span><div><b>'+t+'</b><small>'+s+'</small></div><input type="checkbox" role="switch" class="sw" data-k="'+k+'"></label>').join('')+'<p class="hint" style="margin-top:10px">Wordt bewaard op dit toestel.</p>');
  const sync=()=>rows.forEach(([k,,,,get])=>{o.querySelector('[data-k='+k+']').checked=get()});sync();
  o.querySelectorAll('.sw').forEach(sw=>sw.onchange=()=>{const k=sw.dataset.k;
    if(k==='snd'){$('#snd').click()}else if(k==='dark'){$('#th').click()}else{SET[k]=sw.checked;saveSet()}sync()});
  o.querySelector('.sw').focus()}
$('#set').onclick=openSettings;
// ================= how to play =================
const hb=$('#bar .hlp'),hp=$('#howto');
function setHowto(kind,id,name){const L=kind&&HOWTO[kind]&&HOWTO[kind][id];hp.classList.remove('open');hb.setAttribute('aria-expanded','false');
  if(!L){hb.style.display='none';hp.innerHTML='';hp.dataset.id='';return}hb.style.display='';hp.dataset.id=kind+':'+id;
  hp.innerHTML='<b></b><ul></ul>';hp.querySelector('b').textContent='Hoe speel je '+name+'?';const ul=hp.querySelector('ul');L.forEach(t=>{const li=E('li');li.textContent=t;ul.append(li)})}
hb.onclick=()=>{const o=!hp.classList.contains('open');hp.classList.toggle('open',o);hb.setAttribute('aria-expanded',String(o))};
const _launch3=launch;launch=function(g){_launch3(g);setHowto('solo',g.id,g.n)};
const _launchMP3=launchMP;launchMP=function(id,late){_launchMP3(id,late);const m=MP.find(x=>x.id===id);setHowto(m?'mp':'',id,m?m.n:'');chatUI()};
const _ste=showTourEnd;showTourEnd=function(){_ste();setHowto('','','')};
window.SPZ_HOWTO=HOWTO;
// ================= favourites + spel van de dag =================
const FAVK='sp_favs',FAVCAT='⭐ Favorieten';
const favs=()=>{try{const a=JSON.parse(lsg(FAVK,'[]'));return Array.isArray(a)?a.filter(id=>G.some(g=>g.id===id)):[]}catch(e){return[]}};
const isFav=id=>favs().includes(id);
function toggleFav(id,anchor){const f=favs();const i=f.indexOf(id);if(i>=0)f.splice(i,1);else f.unshift(id);lss(FAVK,JSON.stringify(f));
  const y0=anchor&&anchor.getBoundingClientRect().top;
  document.querySelectorAll('.card .fav[data-id="'+id+'"]').forEach(b=>favState(b,i<0));
  if($('#home').style.display!=='none'){if(cat===FAVCAT)draw();else placeFavSec()}
  if(anchor&&anchor.isConnected){const dy=anchor.getBoundingClientRect().top-y0;if(Math.abs(dy)>1)scrollBy(0,dy)}}
function favState(b,on){b.setAttribute('aria-pressed',String(on));b.textContent=on?'★':'☆';b.title=on?'Uit favorieten halen':'Aan favorieten toevoegen';b.setAttribute('aria-label',(on?'Uit favorieten: ':'Favoriet maken: ')+b.dataset.n)}
const _card3=card;card=function(g,click){const d=_card3(g,click);if(!click&&G.includes(g)){const b=E('button','fav');b.type='button';b.dataset.id=g.id;b.dataset.n=g.n;favState(b,isFav(g.id));
  b.onclick=e=>{e.stopPropagation();e.preventDefault();toggleFav(g.id,d)};b.onkeydown=e=>e.stopPropagation();b.onpointerdown=e=>e.stopPropagation();d.prepend(b)}return d};
function dayKey(d){d=d||new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function dayGame(d){const k=dayKey(d);let h=2166136261;for(let i=0;i<k.length;i++){h^=k.charCodeAt(i);h=Math.imul(h,16777619)}h^=h>>>13;h=Math.imul(h,0x5bd1e995);h^=h>>>15;
  const pool=G.slice().sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);return pool[(h>>>0)%pool.length]}
window.SPZ_DAY=()=>{const g=dayGame();return g&&g.id};
function sotdCard(){const g=dayGame();if(!g)return null;const cs=g.g.split(',').map(s=>s.trim());const goal=((HOWTO.solo[g.id]||[])[0]||'').replace(/^\\S+\\s+/,'');
  const d=E('div','sotd');d.id='sotd';d.style.setProperty('--c1',tint(g));d.style.setProperty('--c2',cs[1]||cs[0]);
  d.innerHTML='<div class="se" aria-hidden="true"></div><div><small>🌟 Spel van de dag</small><h2></h2><p></p></div><button class="btn">▶ Speel nu</button>';
  d.querySelector('.se').textContent=g.e;d.querySelector('h2').textContent=g.n;d.querySelector('p').textContent=goal||g.c;
  const go=()=>launch(g);d.querySelector('.btn').onclick=e=>{e.stopPropagation();go()};d.onclick=go;return d}
function favSec(){const f=favs().map(id=>G.find(g=>g.id===id)).filter(Boolean);if(!f.length)return null;const s=sec('⭐ Favorieten',f,f.length);s.id='favsec';return s}
function placeFavSec(){const L=$('#lists');const old=$('#favsec');const q=$('#q').value.trim();if(!L||q||cat!=='Alles'){if(old)old.remove();return}
  const s=favSec();if(old){if(s)old.replaceWith(s);else old.remove();return}if(!s)return;const a=$('#sotd');if(a)a.after(s);else L.prepend(s)}
if(!cats.includes(FAVCAT))cats.splice(1,0,FAVCAT);
const _draw3=draw;draw=function(){_draw3();const L=$('#lists');if(!L)return;const raw=$('#q').value.trim(),q=raw.toLowerCase();
  if(cat===FAVCAT){[...L.children].forEach(x=>{if(!x.classList.contains('inst'))x.remove()});const f=favs().map(id=>G.find(g=>g.id===id)).filter(g=>g&&(!q||g.n.toLowerCase().includes(q)||g.c.toLowerCase().includes(q)));
    if(f.length)L.append(sec(FAVCAT,f,f.length));else L.append(E('p','empty',q?'Geen favoriet gevonden voor deze zoekterm.':'Nog geen favorieten. Tik op ☆ linksboven op een spelkaart om ze hier te bewaren.'));return}
  if(cat==='Alles'&&!q){const s=sotdCard();const inst=L.querySelector('.inst');if(inst)inst.after(s);else L.prepend(s);placeFavSec()}};
// ================= chat =================
const CHAT=[];let chatSeq=0,unread=0,lastSend=0;const chatT={};
// --- profanity filter (Dutch + English); entries are in "collapsed" form (no repeated letters) ---
const BAD_SUB=['fuck','fuk','shit','bitch','cunt','kanker','kut','tyfus','godverdom','godver','pusy','ashole','bastard','whore','slut','fagot','debiel','dikzak','klotzak'];
const BAD_PRE=['tering','klote','lul','hoer','idiot','sukel','retard','slet','motherf','klote','kloten'];
const BAD_WHOLE=['fck','fk','gvd','kkr','stfu','eikel','eikels','fliker','flikers','mongol','mongolen','mongoltje','niger','nigers','niga','nigas','neger','negers','trut','trutje','truten','teef','fag','fags','dick','tit','tits','kys'];
const NOT_BAD=['hoera','lula','lulu'];
const LEET={'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','8':'b','9':'g','@':'a','$':'s','!':'i','€':'e','|':'i','+':'t'};
function profanity(s){s=String(s);const out=s.split('');const toks=[];const re=/\\S+/g;let m;
  while((m=re.exec(s))){let a=m.index,b=a+m[0].length;while(a<b&&!/[\\p{L}\\p{N}@$!€|+]/u.test(s[a]))a++;while(b>a&&!/[\\p{L}\\p{N}]/u.test(s[b-1]))b--;const ch=[];
    for(let i=a;i<b;i++){let c=s[i].toLowerCase().normalize('NFD').charAt(0);if(LEET[c])c=LEET[c];if(/[a-z]/.test(c))ch.push({c,i})}if(ch.length)toks.push(ch)}
  const groups=[];for(const t of toks){const prev=groups[groups.length-1];if(t.length===1&&prev&&prev.single)prev.ch.push(...t);else groups.push({ch:t.slice(),single:t.length===1})}
  const mask=(i0,i1)=>{for(let i=i0;i<=i1;i++)if(!/\\s/.test(out[i]))out[i]='★'};
  for(const g of groups){const col=[];g.ch.forEach(x=>{const l=col[col.length-1];if(l&&l.c===x.c)l.i1=x.i;else col.push({c:x.c,i0:x.i,i1:x.i})});const S=col.map(x=>x.c).join('');if(!S)continue;
    if(!NOT_BAD.some(w=>S.startsWith(w))&&(BAD_WHOLE.includes(S)||BAD_PRE.some(p=>S.startsWith(p)))){mask(col[0].i0,col[col.length-1].i1);continue}
    for(const w of BAD_SUB){let k=S.indexOf(w);while(k>=0){mask(col[k].i0,col[k+w.length-1].i1);k=S.indexOf(w,k+1)}}}
  return out.join('')}
window.SPZ_FILTER=profanity;
const cleanText=t=>profanity(String(t==null?'':t).replace(/[\\u0000-\\u001f\\u007f\\u200b-\\u200f\\u202a-\\u202e\\u2066-\\u2069]/g,' ').replace(/\\s+/g,' ').trim().slice(0,120));
function addChat(m){if(!m||typeof m.t!=='string')return;CHAT.push({id:m.id,from:String(m.from||''),name:String(m.name||'?').slice(0,16),av:String(m.av||'🙂').slice(0,4),col:toLocal(String(m.col||COLORS[0])),t:String(m.t).slice(0,120),ts:+m.ts||Date.now()});
  if(CHAT.length>50)CHAT.splice(0,CHAT.length-50);if(!chatVisible()&&m.from!==NET.me.id){unread++}renderChat()}
function hostChat(from,t){if(!NET.isHost||NET.isBot(from))return false;const now=Date.now();if(now-(chatT[from]||0)<1000)return false;t=cleanText(t);if(!t)return false;chatT[from]=now;
  const p=NET.players.find(x=>x.id===from);if(!p)return false;const m={k:'chat',id:++chatSeq,from,name:p.name,av:p.av,col:p.col,t,ts:now};NET._bcast(m);addChat(m);return true}
function sendChat(raw){const t=cleanText(raw);if(!t||NET.state==='off')return 'leeg';const now=Date.now();if(now-lastSend<1000)return 'snel';lastSend=now;
  if(NET.isHost){hostChat(NET.me.id,t)}else if(NET.hostConn&&NET.hostConn.open){try{NET.hostConn.send({k:'chat',t})}catch(e){return 'fout'}}else return 'fout';return 'ok'}
window.SPZ_CHAT={list:()=>CHAT.slice(),send:sendChat,unread:()=>unread};
const _hr=NET._hostRecv;NET._hostRecv=function(m,c){if(m&&typeof m==='object'){
    if(m.k==='chat'){hostChat(c.peer,m.t);return}
    if(m.k==='hello'){if(m.col)m.col=toLocal(m.col);const r=_hr.call(this,m,c);if(this.players.some(p=>p.id===c.peer))try{c.send({k:'chatH',list:CHAT.slice(-20)})}catch(e){}return r}}
  return _hr.call(this,m,c)};
const _cr=NET._clientRecv;NET._clientRecv=function(m){if(m&&typeof m==='object'){
    if(m.k==='chat'){addChat(m);return}
    if(m.k==='chatH'){CHAT.length=0;(Array.isArray(m.list)?m.list:[]).slice(-20).forEach(x=>{if(x&&typeof x.t==='string')CHAT.push({id:x.id,from:String(x.from||''),name:String(x.name||'?').slice(0,16),av:String(x.av||'🙂').slice(0,4),col:toLocal(String(x.col||COLORS[0])),t:String(x.t).slice(0,120),ts:+x.ts||0})});unread=0;renderChat();return}
    if(m.k==='players'&&Array.isArray(m.players))m.players.forEach(p=>{if(p&&p.col)p.col=toLocal(p.col)})}
  return _cr.call(this,m)};
const _leave=NET.leave;NET.leave=function(){CHAT.length=0;unread=0;lastSend=0;for(const k in chatT)delete chatT[k];const s=$('.sheet.chs');if(s)s.close();const r=_leave.apply(this,arguments);if(box)box.remove();return r};
// --- chat UI: one box, moved between the lobby card and the in-game sheet ---
let box=null;
function mkBox(){const b=E('div','chbox');b.innerHTML='<div class="chl" role="log" aria-live="polite" aria-label="Chatberichten"></div><form class="chf" autocomplete="off"><input maxlength="120" placeholder="Typ een berichtje…" enterkeyhint="send" aria-label="Chatbericht"><button class="btn">Stuur</button></form><p class="chn hint" aria-live="polite"></p>';
  const f=b.querySelector('form'),inp=b.querySelector('input'),n=b.querySelector('.chn');
  ['keydown','keyup','keypress'].forEach(t=>inp.addEventListener(t,e=>{if(e.key!=='Escape')e.stopPropagation()}));
  f.onsubmit=e=>{e.preventDefault();const r=sendChat(inp.value);if(r==='ok'){inp.value='';n.textContent=''}else if(r==='snel')n.textContent='Even rustig aan — max. 1 bericht per seconde.';else if(r==='fout')n.textContent='Niet verbonden met de kamer.'};
  inp.oninput=()=>{n.textContent=inp.value.length>100?(120-inp.value.length)+' tekens over':''};return b}
function renderChat(){chatUI();if(!box)return;const l=box.querySelector('.chl');const near=l.scrollHeight-l.scrollTop-l.clientHeight<40;l.innerHTML='';
  if(!CHAT.length)l.append(E('div','che','Nog geen berichten. Zeg hallo! 👋'));
  CHAT.forEach(m=>{const me=m.from===NET.me.id;const r=E('div','chm'+(me?' me':''));r.style.setProperty('--c',m.col);const av=E('span','pav s');av.style.setProperty('--c',m.col);av.textContent=m.av;
    const d=E('div');const b=E('b');b.textContent=m.name+(me?' (jij)':'');const t=E('span');t.textContent=m.t;d.append(b,t);r.append(av,d);l.append(r)});
  if(near||!l.dataset.init){l.scrollTop=l.scrollHeight;l.dataset.init=1}}
const chatVisible=()=>!!($('.sheet.chs')||(box&&box.isConnected&&$('#mp').style.display==='block'&&$('#mp').contains(box)&&document.visibilityState!=='hidden'));
function chatUI(){const b=$('#chb');if(chatVisible())unread=0;if(b){b.classList.toggle('unread',unread>0);b.querySelector('i').textContent=unread>9?'9+':String(unread);b.setAttribute('aria-label','Chat'+(unread?' ('+unread+' nieuw)':''))}}
function openChat(){if(NET.state==='off')return;const ex=$('.sheet.chs');if(ex){ex.close();return}
  if($('#mp').style.display==='block'&&box&&$('#mp').contains(box)){const i=box.querySelector('input');box.scrollIntoView({block:'center'});i.focus();return}
  box=box||mkBox();const o=sheet('chs','<h3>💬 Chat <span class="mu" style="font-size:13px;font-weight:600">kamer '+esc(NET.code||'')+'</span></h3>');o.querySelector('.shp').append(box);
  o.addEventListener('closed',()=>{if(box&&!$('#mp').contains(box))box.remove();chatUI()});unread=0;renderChat();box.querySelector('.chl').scrollTop=1e6;
  if(!matchMedia('(pointer:coarse)').matches)box.querySelector('input').focus()}
const _rxBar=rxBar;rxBar=function(){_rxBar.apply(this,arguments);const r=$('#rx');if(r&&!r.querySelector('#chb')){const b=E('button','','💬<i></i>');b.type='button';b.id='chb';b.title='Chat';
  b.onclick=e=>{e.stopPropagation();openChat()};r.prepend(b);chatUI()}};
const _sl=showLobby;showLobby=function(){const ae=document.activeElement,had=box&&box.contains(ae),val=had?ae.value:null,ss=had?ae.selectionStart:0;
  _sl.apply(this,arguments);if(NET.state==='off'||!NET.code)return;const sh=$('.sheet.chs');if(sh)sh.close();
  box=box||mkBox();let c=$('#chatc');if(!c){c=E('div','mpc chatc','<h3>💬 Chat</h3>');c.id='chatc'}c.append(box);const first=$('#mpb > .mpc');if(first)first.after(c);else $('#mpb').append(c);
  unread=0;renderChat();if(had){const i=box.querySelector('input');i.focus();try{i.setSelectionRange(ss,ss)}catch(e){}}};
document.addEventListener('visibilitychange',chatUI);
// ================= apply on load =================
applySettings();
const _conf=confetti;confetti=function(){if(window.SPZ_NOANIM)return;return _conf.apply(this,arguments)};
draw();
})();
`;
  const i = html.lastIndexOf('</script>');
  return html.slice(0, i) + js + html.slice(i);
};
