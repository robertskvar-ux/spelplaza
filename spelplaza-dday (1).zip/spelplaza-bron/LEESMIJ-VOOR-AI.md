# SpelPlaza — overdracht voor een andere AI / ontwikkelaar

SpelPlaza is een Nederlandstalige spelletjeswebsite: 59 solo-spellen en 28 online spellen (kamer met code, tot 8 spelers, bots), alles in **één HTML-bestand**. Live: https://robertskvar-ux.github.io/spelplaza/

## Belangrijkste regel
**Bewerk `site/index.html` NIET rechtstreeks.** Dat is een gebouwd bestand (4 MB, gecomprimeerd en omgezet). Werk in de bronbestanden en bouw opnieuw:

```
npm install            # installeert peerjs, peer, three, esbuild, fflate, playwright-core
node build.js          # maakt dist/spelplaza.html
```
Lever terug: de hele map (zip) met je wijzigingen in de bron, plus de nieuwe `dist/spelplaza.html`.

## Structuur
| Bestand / map | Wat |
|---|---|
| `original.html` | Basispagina + ingebedde Wordle (niet aanpassen) |
| `games/<id>.js` | Solo-spellen, één object `{id,n,e,c,g,run(st){…}}` per bestand. `orig_<id>.js` vervangt een spel uit original.html |
| `mp/<id>.js` | Online spellen `{id,n,e,c:'Samen',g,min,max,bots?,run(st,net){…}}` |
| `net.js` | Multiplayer (PeerJS), lobby, profiel/avatars, podium, reacties, bots, toernooi, keuzescherm solo/online |
| `theme.js` | Basisschil: startpagina, kaarten, speelscherm |
| `shell2.js` | Veilig verlaten, terug-knop, geluid, "zet op beginscherm" |
| `presence.js` | Live teller "X online" |
| `colorful.js` | Kleurrijk uiterlijk |
| `site3.js` + `howto.js` | Chat, spel van de dag, favorieten, uitleg per spel, instellingen |
| `build.js` | Voegt alles samen (volgorde staat erin) |
| `CONTRACT.md` | **Lees eerst**: regels en helpers voor solo-spellen |
| `MP_CONTRACT.md` | **Lees eerst**: regels voor online spellen (netwerk-API, avatars, podium, bots) |
| `mkmp.py` + `bl_mp_tail.js` | `mp/blokkenland.js` wordt gegenereerd uit `games/blokkenland.js` + deze staart (`python3 mkmp.py`, pas paden aan) |
| `harness.js` / `harness2.js` | Automatische tests (headless Chromium): `node harness.js all`, `node harness2.js all` |
| `manifest.webmanifest`, `sw.js`, `icon-*.png` | App-installatie voor de website |

## Afspraken
- Alle tekst in het Nederlands, werkt op telefoon (390 px, touch) én computer, licht en donker thema.
- Geen externe bestanden behalve wat al gebruikt wordt (Three.js en PeerJS zitten ingebakken; lettertype via Google Fonts alleen op https).
- Nieuw spel = nieuw bestand in `games/` of `mp/`; voeg het id toe aan de volgorde in `build.js` en een uitleg in `howto.js`.
- Voor je teruggeeft: `node harness.js all` en `node harness2.js all` moeten "all clean" geven.
