 // ===== game layer (online, host-authoritative block edits, water, animals, chat, saved worlds) =====
 const HOST=net.isHost,MYID=net.me.id,mode='c',PLACE=[1,2,3,4,5,6,10,8,9,11,12,13,14,15,16,7,TORCH,LAMP,20,21,22,23,STAIR,DOOR];
 const OKB=new Uint8Array(64);PLACE.forEach(b=>OKB[b]=1);for(let o=0;o<4;o++)OKB[24+o]=1;for(let k=0;k<8;k++)OKB[32+k]=1;
 const css2=E('style');css2.textContent=`.bk-log{position:absolute;left:8px;top:8px;text-align:left;align-items:flex-start;max-width:min(62%,340px);display:flex;flex-direction:column;gap:3px;pointer-events:none;line-height:1.25;font:600 12px system-ui,sans-serif}.bk-log div{background:rgba(14,16,32,.62);color:#fff;padding:3px 8px;border-radius:9px;transition:opacity .6s;overflow-wrap:anywhere;font-size:11px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.bk-log b{font-weight:800}
.bk-ci{position:absolute;left:8px;right:8px;bottom:8px;display:none;gap:6px;line-height:1}.bk-ci input{flex:1;min-width:0;font-size:16px;padding:9px 12px;border-radius:12px;border:2px solid #f5b82e;background:rgba(14,16,32,.88);color:#fff;outline:none}.bk-ci .btn{min-height:40px;padding:6px 12px;font-size:15px}
.bk-wl{display:flex;flex-direction:column;gap:6px;width:min(100%,430px);max-height:48%;overflow:auto}.bk-wr{display:flex;align-items:center;gap:8px;background:#ffffff14;border:1px solid #ffffff30;border-radius:10px;padding:6px 8px;text-align:left;line-height:1.25}.bk-wr div{flex:1;min-width:0}.bk-wr b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bk-wr small{font-weight:500}.bk-ov .bk-wr .btn{min-width:0;font-size:13px;padding:6px 10px;min-height:34px}
.bk-ov input.bk-nm{font-size:16px;padding:9px 12px;border-radius:12px;border:2px solid #f5b82e;background:#0e1020;color:#fff;width:min(100%,320px)}`;st.append(css2);
 const ROW=E('div','bk-row');st.append(ROW);const btn=(l,f)=>{const b=E('button','btn sec',l);b.onclick=f;ROW.append(b);return b};
 if(!TOUCH){btn('🎒 Blokken',()=>pal(1));btn('🖱️ Muis vast',()=>{try{c.requestPointerLock()}catch(e){}})}btn('💬 Chat',()=>chatOpen());const bSave=HOST?btn('💾 Opslaan',()=>saveUI()):null;const bStop=HOST?btn('🏁 Stoppen',()=>stopGame()):null;if(TOUCH)ROW.style.flexWrap='nowrap';
 st.append(E('div','hint',(TOUCH?'Links slepen = lopen · rechts slepen = kijken · ⛏️ breken/dier aaien · 🧱 plaatsen of deur open/dicht · ⤒ springen (2× = vliegen) · 💬 praten':'WASD lopen · slepen/🖱️ kijken · klik/X breken · rechtsklik/C plaatsen of deur open/dicht · 1–9/wiel kiezen · spatie springen · F vliegen · E blokken · T of Enter = chat')+(HOST?' · 💾 bewaart deze wereld op dit toestel · 🏁 rondt de sessie af':' · de host bewaart en rondt de sessie af')));
 let reqT=0,hot=[1,2,3,10,5,8,TORCH,DOOR,12],selI=0,hit=null,ehit=null,t=0,hudT=0,visT=0,bCool=0,pCool=0,eCool=0,ready=0,ended=0,placed=0,netT=0,wT=0,saveT=0,animT=0,bLog='',dayT=.3,wready=0,slot=null,wname='',uiEl=null,cin=0;
 const SCORE={},EDITS=new Map(),POS=new Map(),RATE=new Map(),AV=new Map(),CHR=new Map(),WB=[];
 const playing=()=>!ended&&wready&&!uiEl&&PAL.style.display!=='flex';
 const r2=v=>Math.round(v*100)/100;
 // same world on every peer from the round seed; the host may swap it for a saved world (message W)
 const seed0=Math.floor(net.rng()()*2**31);let seed=seed0;
 function loadWorld(sd,edits){const t0=performance.now();seed=sd;clearEnts();wReset();gen(sd);EDITS.clear();for(let i=0;i+1<(edits||[]).length;i+=2){const k=edits[i]|0,b=edits[i+1]|0;if(k>=0&&k<V.length&&(b===0||BL[b])){V[k]=b;EDITS.set(k,b);if(LEM[b])LSRC.add(k)}}
  if(EDITS.size)for(let z=0;z<WS;z++)for(let x=0;x<WS;x++)colH(x,z);relightAll();bLog='gen '+Math.round(performance.now()-t0)+'ms';DIRTY.clear();queueAll();ready=0;delete c.dataset.build}
 function toSpawn(){const me=Math.max(0,net.myIndex()),s0=spawnPt(),sp=spawnPt(s0[0]+(me%3-1)*4,s0[2]+((me/3|0)%3-1)*4);[P.x,P.y,P.z]=sp;P.cy=P.y;P.vx=P.vy=P.vz=0;P.yaw=Math.PI*.25+me*.6;P.pitch=-.15;cam.position.set(P.x,P.y+EYE,P.z);sortQ()}
 loadWorld(seed0,[]);toSpawn();for(let i=0;i<9&&Q.length;i++)build(Q.shift());sky(dayT);
 const blocked=(x,y,z)=>{for(const a of AV.values())if(inPl(x,y,z,a.tx,a.ty,a.tz))return 1;return 0};
 function canEdit(x,y,z,b,pp){if(![x,y,z,b].every(Number.isInteger)||x<0||z<0||x>=WS||z>=WS||y<1||y>=WH)return 0;if(b!==0&&!OKB[b])return 0;const cu=V[I(x,y,z)];if(cu===BED)return 0;
  if(pp&&Math.hypot(x+.5-pp.x,y+.5-pp.y-EYE,z+.5-pp.z)>8.5)return 0;if(b===0)return cu&&!WAT[cu]?1:0;
  if(b>=32&&b<40){if(cu>=32&&cu<40)return 1;const up=g(x,y+1,z);if(y+1>=WH||(up&&!WAT[up]))return 0}return !cu||WAT[cu]?1:0}
 function hostEdit(from,x,y,z,b){const pp=from===MYID?P:POS.get(from),now=performance.now(),r=RATE.get(from)||{t:0,n:0};if(now-r.t>1000){r.t=now;r.n=0}RATE.set(from,r);
  const L=Number.isInteger(x)&&Number.isInteger(y)&&Number.isInteger(z)?expand(x,y,z,b):[],tog=b>=32&&b<40&&g(x,y,z)>=32&&g(x,y,z)<40;
  const bad=++r.n>20||!pp||!canEdit(x,y,z,b,pp)||L.some(([a,bb,cc,d])=>d&&SOL[d]&&!tog&&((from!==MYID&&inPl(a,bb,cc,P.x,P.y,P.z))||[...POS].some(([id,q])=>id!==from&&inPl(a,bb,cc,q.x,q.y,q.z))));
  if(bad){if(from!==MYID&&Number.isInteger(x)&&Number.isInteger(y)&&Number.isInteger(z)&&x>=0&&z>=0&&x<WS&&z<WS)for(let k=-1;k<=1;k++)if(y+k>=0&&y+k<WH)net.sendTo(from,{k:'fix',i:I(x,y+k,z),b:V[I(x,y+k,z)]});return 0}
  for(const [a,bb,cc,d] of L)if(setB(a,bb,cc,d)){const i=I(a,bb,cc);EDITS.set(i,d);net.send({k:'set',i,b:d,by:from});touchW(a,bb,cc)}
  if(b&&!tog){SCORE[from]=(SCORE[from]||0)+1;if(from===MYID)placed++}return 1}
 function edit(x,y,z,b){if(ended||!wready)return 0;if(HOST)return hostEdit(MYID,x,y,z,b);if(!canEdit(x,y,z,b,P))return 0;for(const [a,bb,cc,d] of expand(x,y,z,b))setB(a,bb,cc,d);net.send({k:'set',x,y,z,b});return 1}
 onW=HOST?(i,b)=>{EDITS.set(i,b);WB.push(i,b)}:null;
 const at=i=>{const y=Math.floor(i/(WS*WS)),r=i-y*WS*WS;return[r%WS,y,Math.floor(r/WS)]};
 function brk(){if(ehit){hitAnimal();return}if(!hit||hit.b===BED)return;if(edit(hit.x,hit.y,hit.z,0))beep(150+R(60),.05,'square',.03)}
 function place(){if(!hit)return;if(isDoor(hit.b)){const yb=hit.b>=40?hit.y-1:hit.y,bb=g(hit.x,yb,hit.z);if(bb>=32&&bb<40&&edit(hit.x,yb,hit.z,bb^4))beep(bb&4?300:420,.05,'triangle',.03);return}
  const b0=hot[selI];if(!b0)return;const x=hit.px,y=hit.py,z=hit.pz,o=g(x,y,z);if(o&&!WAT[o])return;const b=orient(b0,x,y,z);if(b<0){beep(120,.06,'sine',.03);toast('Zet dit op een blok');return}
  if(SOL[b]&&(inPl(x,y,z,P.x,P.y,P.z)||blocked(x,y,z)))return;if(b0===DOOR&&(inPl(x,y+1,z,P.x,P.y,P.z)||blocked(x,y+1,z)))return;if(edit(x,y,z,b))beep(330,.04,'triangle',.03)}
 function hitAnimal(){if(eCool>0||!ehit)return;eCool=.35;const e=ehit;beep(520,.05,'sine',.035);if(HOST)hitEnt(e,P.x,P.z,false);else{e.hurt=.3;net.send({k:'hit',id:e.id})}}
 function pick(i){selI=i;hotUI();beep(700,.02,'sine',.02)}
 function hotUI(){slots.forEach((s,i)=>{const b=hot[i];s.className='bk-s'+(i===selI?' on':'');const im=s.firstChild;if(b){if(im.dataset.b!=b){im.src=ico(b);im.dataset.b=b}im.style.visibility=''}else im.style.visibility='hidden';s.children[1].textContent='';s.title=b?BL[b][0]:''});setHand(hot[selI])}
 function pal(on){TB.style.opacity=on?'0':'';TB.style.pointerEvents=on?'none':'';if(!on){PAL.style.display='none';return}PAL.replaceChildren();PAL.style.display='flex';const top=E('div');top.style.cssText='display:flex;justify-content:space-between;align-items:center';const h=E('h4');h.textContent='🎨 Kies een blok voor vakje '+(selI+1);const x=E('button','btn','✕');x.onclick=()=>pal(0);top.append(h,x);PAL.append(top);
  const gr=E('div','bk-g');PAL.append(gr);PLACE.forEach(b=>{const k=E('button');k.innerHTML='<img src="'+ico(b)+'">';k.append(BL[b][0]);k.onclick=()=>{const j=hot.indexOf(b);if(j>=0&&j!==selI)hot[j]=hot[selI];hot[selI]=b;hotUI();pal(0)};gr.append(k)})}
 function press(k){if(ended)return;if((k==='KeyT'||k==='Enter')&&!uiEl){chatOpen();return}if(k==='KeyE'){pal(PAL.style.display==='flex'?0:1);return}if(!playing())return;
  if(/^Digit[1-9]$/.test(k))pick(+k[5]-1);else if(k==='KeyF')toggleFly();else if(k==='Space')jumpTap();else if(k==='KeyX'){brk();bCool=.25}else if(k==='KeyC'){place();pCool=.28}}
 // --- other players: blocky figures in their colour, avatar emoji on the head, name tag, chat bubble ---
 const BOX=new THREE.BoxGeometry(1,1,1);
 const rr_=(x,X,Y,w,h,r)=>{x.beginPath();if(x.roundRect)x.roundRect(X,Y,w,h,r);else x.rect(X,Y,w,h)};
 function tagTex(p){const cv=document.createElement('canvas');cv.width=256;cv.height=64;const x=cv.getContext('2d'),s=net.pname(p);x.font='bold 28px system-ui,sans-serif';const w=Math.min(250,x.measureText(s).width+30);x.fillStyle='rgba(14,16,32,.75)';rr_(x,(256-w)/2,6,w,52,16);x.fill();x.strokeStyle=net.pcol(p);x.lineWidth=4;x.stroke();x.fillStyle='#fff';x.textAlign='center';x.textBaseline='middle';x.fillText(s,128,33,236);const tt=new THREE.CanvasTexture(cv);tt.colorSpace=THREE.SRGBColorSpace;return tt}
 function headTex(p,tint){const cv=document.createElement('canvas');cv.width=cv.height=128;const x=cv.getContext('2d');x.fillStyle='#'+tint.getHexString();x.fillRect(0,0,128,128);x.fillStyle='rgba(0,0,0,.2)';x.fillRect(0,0,128,6);x.fillRect(0,122,128,6);x.fillRect(0,0,6,128);x.fillRect(122,0,6,128);
  x.font='100px "Noto Color Emoji","Apple Color Emoji","Segoe UI Emoji",sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(String(p.av||'🙂').slice(0,8),64,72,116);const tt=new THREE.CanvasTexture(cv);tt.colorSpace=THREE.SRGBColorSpace;return tt}
 function bubTex(s){const cv=document.createElement('canvas');cv.width=320;cv.height=128;const x=cv.getContext('2d');x.font='600 24px system-ui,sans-serif';const words=s.split(/\s+/),lines=[];let ln='';
  for(const w of words){const tt=ln?ln+' '+w:w;if(x.measureText(tt).width>280&&ln){lines.push(ln);ln=w}else ln=tt;if(lines.length>=3)break}if(ln&&lines.length<3)lines.push(ln);
  const h=lines.length*28+18,w=Math.min(310,Math.max(...lines.map(l=>x.measureText(l).width))+30);x.fillStyle='rgba(255,255,255,.95)';rr_(x,(320-w)/2,104-h,w,h,16);x.fill();x.beginPath();x.moveTo(150,104);x.lineTo(160,122);x.lineTo(170,104);x.fill();
  x.fillStyle='#1d2030';x.textAlign='center';x.textBaseline='middle';lines.forEach((l,i)=>x.fillText(l,160,104-h+23+i*28,290));const tt=new THREE.CanvasTexture(cv);tt.colorSpace=THREE.SRGBColorSpace;return tt}
 function mkAv(p){const col=new THREE.Color(net.pcol(p)),tint=col.clone().lerp(new THREE.Color(0xffffff),.6),G=new THREE.Group(),M=cl=>new THREE.MeshLambertMaterial({color:cl}),body=M(col),dark=M(col.clone().multiplyScalar(.45)),skin=M(tint),top=M(col.clone().lerp(tint,.4)),ht=headTex(p,tint),face=new THREE.MeshBasicMaterial({map:ht}),mats=[body,dark,skin,top,face];
  const part=(par,m,w,h,d,x,y,z)=>{const o=new THREE.Mesh(BOX,m);o.scale.set(w,h,d);o.position.set(x,y,z);par.add(o);return o},piv=(x,y)=>{const q=new THREE.Group();q.position.set(x,y,0);G.add(q);return q};
  const lL=piv(-.13,.75),lR=piv(.13,.75),aL=piv(-.37,1.45),aR=piv(.37,1.45);part(lL,dark,.25,.75,.27,0,-.375,0);part(lR,dark,.25,.75,.27,0,-.375,0);part(aL,body,.22,.72,.24,0,-.33,0);part(aR,body,.22,.72,.24,0,-.33,0);part(aL,skin,.2,.12,.22,0,-.72,0);part(aR,skin,.2,.12,.22,0,-.72,0);
  part(G,body,.5,.72,.28,0,1.11,0);const head=new THREE.Mesh(BOX,[skin,skin,top,skin,skin,face]);head.scale.setScalar(.52);head.position.y=1.74;G.add(head);
  const tag=new THREE.Sprite(new THREE.SpriteMaterial({map:tagTex(p),depthWrite:false}));tag.scale.set(1.7,.425,1);tag.position.y=2.32;G.add(tag);SC.add(G);
  return{G,lL,lR,aL,aR,head,tag,mats,ht,face,x:0,y:-99,z:0,a:0,tx:0,ty:-99,tz:0,ta:0,tp:0,ph:0,id:p.id,nm:net.pname(p),av:p.av||'',bub:null,bubT:0,bubS:''}}
 function avTarget(id,x,y,z,a,pt){if(id===MYID)return;let v=AV.get(id);if(!v){const p=net.players.find(q=>q.id===id);if(!p)return;v=mkAv(p);AV.set(id,v);v.x=x;v.y=y;v.z=z;v.a=a}v.tx=x;v.ty=y;v.tz=z;v.ta=a;v.tp=pt||0}
 function dropBub(v){if(!v.bub)return;v.G.remove(v.bub);v.bub.material.map.dispose();v.bub.material.dispose();v.bub=null;v.bubS=''}
 function dropAv(id){const v=AV.get(id);if(!v)return;dropBub(v);SC.remove(v.G);v.mats.forEach(m=>m.dispose());v.ht.dispose();v.tag.material.map.dispose();v.tag.material.dispose();AV.delete(id)}
 function avStep(dt){const k=1-Math.exp(-12*dt);for(const v of AV.values()){const ox=v.x,oz=v.z;v.x+=(v.tx-v.x)*k;v.y+=(v.ty-v.y)*k;v.z+=(v.tz-v.z)*k;let d=v.ta-v.a;d=Math.atan2(Math.sin(d),Math.cos(d));v.a+=d*k;
  const sp=Math.hypot(v.x-ox,v.z-oz)/Math.max(dt,1e-3);v.ph+=sp*dt*3.2;const sw=Math.sin(v.ph)*Math.min(1,sp/3)*.7;v.lL.rotation.x=sw;v.lR.rotation.x=-sw;v.aL.rotation.x=-sw;v.aR.rotation.x=sw;v.head.rotation.x=-v.tp*.6;v.G.position.set(v.x,v.y,v.z);v.G.rotation.y=v.a;v.face.color.setScalar(Math.max(.62,Math.sqrt(LIGHT)));
  if(v.bub){v.bubT-=dt;if(v.bubT<=0)dropBub(v);else v.bub.material.opacity=Math.min(1,v.bubT*2)}}}
 // --- chat: 💬 opens an input; host rate-limits, masks bad words, relays; bubbles above heads + small log (all via textContent / canvas) ---
 const BADS=['fuck','kanker','shit','cunt','motherf'],BADP=['kut','klote','tering','tyfus','tiefus','godver','hoer','kloot','neuk','flikker','fck','fuk','sh1t','bitch','whore','slut','bastard','asshole','wanker','kech','klootzak','sukkel'],BADX=['lul','pik','eikel','mongool','debiel','ass','dick','cock','fag','piss','tit','tits','idioot'];
 const RXS=new RegExp('(?:'+BADS.join('|')+')[a-z]*','gi'),RXP=new RegExp('\\b(?:'+BADP.join('|')+')[a-z]*','gi'),RXX=new RegExp('\\b(?:'+BADX.join('|')+')\\b','gi'),star=w=>w[0]+'*'.repeat(w.length-1);
 const mask=s=>s.replace(RXS,star).replace(RXP,star).replace(RXX,star),clean=s=>String(s==null?'':s).replace(/[\u0000-\u001f\u007f\u2028\u2029]/g,' ').replace(/\s+/g,' ').trim().slice(0,80);
 const LOG=E('div','bk-log'),CI=E('div','bk-ci'),CIN=E('input'),CSB=E('button','btn','Stuur'),CX=E('button','btn sec','✕');CIN.maxLength=80;CIN.placeholder='Zeg iets… (max 80)';CIN.enterKeyHint='send';CI.append(CIN,CSB,CX);wrap.append(LOG,CI);const LT_=new Set;
 function chatOpen(){if(ended)return;CI.style.display='flex';cin=1;Kd.clear();setTimeout(()=>{try{CIN.focus()}catch(e){}},0)}
 function chatClose(){CI.style.display='none';cin=0;CIN.value='';try{CIN.blur()}catch(e){}}
 CIN.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();sendChat(CIN.value);chatClose()}else if(e.key==='Escape')chatClose()};CSB.onclick=()=>{sendChat(CIN.value);chatClose()};CX.onclick=chatClose;
 function sendChat(m){m=clean(m);if(!m||ended)return;if(HOST)hostChat(MYID,m);else net.send({k:'chat',m})}
 function hostChat(from,m){m=clean(m);if(!m||!net.players.some(p=>p.id===from))return;const now=performance.now(),r=CHR.get(from)||{last:-9e9,ts:[]};r.ts=r.ts.filter(x=>now-x<15000);
  if(now-r.last<1200||r.ts.length>=5){if(from===MYID)toast('⏳ Even wachten met de volgende chat');else net.sendTo(from,{k:'chatno'});CHR.set(from,r);return}r.last=now;r.ts.push(now);CHR.set(from,r);m=mask(m);net.send({k:'chat',id:from,m});showChat(from,m)}
 function showChat(id,m){const p=net.players.find(q=>q.id===id);if(!p)return;const d=E('div'),b=E('b');b.textContent=net.pname(p)+(id===MYID?' (jij)':'')+': ';b.style.color=net.pcol(p);d.append(b,document.createTextNode(m));LOG.append(d);while(LOG.children.length>3)LOG.firstChild.remove();
  const t1=setTimeout(()=>{d.style.opacity='0';LT_.delete(t1);const t2=setTimeout(()=>{d.remove();LT_.delete(t2)},650);LT_.add(t2)},8000);LT_.add(t1);
  const v=AV.get(id);if(v){dropBub(v);const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:bubTex(m),depthWrite:false,transparent:true}));sp.scale.set(2.3,.92,1);sp.position.y=3.08;sp.renderOrder=6;v.G.add(sp);v.bub=sp;v.bubT=8;v.bubS=m}beep(880,.04,'sine',.025)}
 // --- saved worlds (host only, in this browser's localStorage): seed + edit list + time of day ---
 const WKEY='blokkenland_mp_worlds',lw=()=>{try{const a=JSON.parse(localStorage.getItem(WKEY));return Array.isArray(a)?a.filter(w=>w&&w.id&&Array.isArray(w.e)):[]}catch(e){return[]}},sw=a=>{try{localStorage.setItem(WKEY,JSON.stringify(a));return 1}catch(e){return 0}};
 const nBlocks=()=>{let n=0;EDITS.forEach(b=>{if(b&&!WAT[b])n++});return n},defName=()=>'Wereld van '+new Date().toLocaleString('nl-BE',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
 function saveWorld(name,quiet){if(!HOST||!wready)return 0;const a=lw(),e=[];EDITS.forEach((b,i)=>e.push(i,b));let w=a.find(x=>x.id===slot);if(!w){w={id:'w'+Date.now().toString(36)+R(1e4)};a.unshift(w);slot=w.id}w.name=clean(name||wname||w.name||defName()).slice(0,40)||defName();wname=w.name;
  Object.assign(w,{v:1,seed,e,t:r2(dayT),d:Date.now(),n:nBlocks()});a.sort((p,q)=>q.d-p.d);const ok=sw(a.slice(0,10));if(!quiet)toast(ok?'💾 Bewaard: '+w.name:'⚠️ Bewaren mislukt (geheugen vol?)');saveT=0;return ok}
 function closeUI(){if(uiEl){uiEl.remove();uiEl=null}}
 function saveUI(){if(!HOST||!wready||ended)return;closeUI();uiEl=E('div','bk-ov');const h=E('h2');h.textContent='💾 Wereld bewaren';const s=E('small');s.textContent='De wereld wordt op dit toestel bewaard; volgende keer kan je hem weer laden.';const inp=E('input','bk-nm');inp.maxLength=40;inp.value=wname||defName();
  const ok=E('button','btn','💾 Bewaar'),no=E('button','btn sec','Annuleer');ok.onclick=()=>{saveWorld(inp.value);closeUI()};no.onclick=closeUI;inp.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter')ok.click();if(e.key==='Escape')closeUI()};uiEl.append(h,s,inp,ok,no);wrap.append(uiEl)}
 function picker(){closeUI();const a=lw().sort((p,q)=>q.d-p.d);if(!a.length){hostBegin(null);return}uiEl=E('div','bk-ov');const h=E('h2');h.textContent='🌍 Kies een wereld';const s=E('small');s.textContent='Je bewaarde werelden staan op dit toestel. Iedereen in de kamer speelt mee in de gekozen wereld.';
  const nb=E('button','btn','🌱 Nieuwe wereld');nb.onclick=()=>{closeUI();hostBegin(null)};const L=E('div','bk-wl');
  a.forEach(w=>{const r=E('div','bk-wr'),d=E('div'),b=E('b'),m=E('small');b.textContent=w.name||'Wereld';m.textContent=new Date(w.d||0).toLocaleString('nl-BE',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})+' · 🧱 '+(w.n|0)+' blokken';d.append(b,m);
   const lb=E('button','btn','▶ Laden'),db=E('button','btn sec','🗑️');lb.onclick=()=>{closeUI();hostBegin(w)};let arm=0;db.onclick=()=>{if(!arm){arm=1;db.textContent='Zeker?';setTimeout(()=>{arm=0;db.textContent='🗑️'},2500);return}sw(lw().filter(x=>x.id!==w.id));r.remove();if(!L.children.length){closeUI();hostBegin(null)}};r.append(d,lb,db);L.append(r)});
  uiEl.append(h,s,nb,L);wrap.append(uiEl)}
 const sendAll=to=>{const a=[];EDITS.forEach((b,i)=>a.push(i,b));for(let k=0;k<a.length||k===0;k+=600){const m={k:'all',e:a.slice(k,k+600)};if(to)net.sendTo(to,m);else net.send(m)}};
 function hostBegin(w){if(w){loadWorld(w.seed|0,w.e);dayT=+w.t>=0&&+w.t<1?+w.t:.3;slot=w.id;wname=w.name||''}else{loadWorld(seed0,[]);dayT=.3;slot=null;wname=''}wready=1;toSpawn();sky(dayT);
  for(let k=0;k<8;k++){const q=grassSpot(P.x,P.z,5,40);if(q)mkEnt(SPN[k%3],q[0],q[1],q[2])}net.send({k:'W',seed,t:dayT});sendAll(null);if(w)toast('🌍 '+(w.name||'Wereld')+' geladen')}
 const WAIT=HOST?null:E('div','bk-ov','<h2>⏳</h2><small>De host kiest een wereld…</small>');if(WAIT)wrap.append(WAIT);
 // --- network ---
 const num=(v,a,b)=>{v=+v;return isFinite(v)?Math.max(a,Math.min(b,v)):a};
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(HOST){if(d.k==='p'){const q={x:num(d.x,-2,WS+2),y:num(d.y,-2,WH+40),z:num(d.z,-2,WS+2),a:num(d.a,-1e3,1e3),t:num(d.t,-2,2)};POS.set(from,q);avTarget(from,q.x,q.y,q.z,q.a,q.t)}
   else if(d.k==='set'){if(wready)hostEdit(from,d.x,d.y,d.z,d.b)}
   else if(d.k==='chat')hostChat(from,d.m);
   else if(d.k==='hit'){const e=ENT.find(q=>q.id===d.id),q=POS.get(from);if(e&&q&&Math.hypot(e.x-q.x,e.z-q.z)<7)hitEnt(e,q.x,q.z,false)}
   else if(d.k==='req'){if(wready){net.sendTo(from,{k:'W',seed,t:dayT});sendAll(from);if(ended)net.sendTo(from,{k:'end',s:scores()})}}return}
  if(d.k==='P'&&Array.isArray(d.a)){for(const e of d.a)if(Array.isArray(e))avTarget(String(e[0]),+e[1],+e[2],+e[3],+e[4],+e[5]);if(isFinite(d.t))dayT=num(d.t,0,1);if(Array.isArray(d.n))syncAnimals(d.n)}
  else if(d.k==='W'){EMAP.clear();loadWorld(d.seed|0,[]);dayT=num(d.t,0,1);sky(dayT);if(!wready){wready=1;toSpawn();if(WAIT)WAIT.remove()}}
  else if(d.k==='set'||d.k==='fix'){const i=d.i|0;const b=d.b|0;if(i<0||i>=V.length||(b&&!BL[b]))return;const [x,y,z]=at(i);setB(x,y,z,b);if(d.k==='set'&&d.by===MYID&&d.b&&!isDoor(d.b))placed++}
  else if(d.k==='S'&&Array.isArray(d.a)){for(let k=0;k+1<d.a.length;k+=2){const i=d.a[k]|0,b=d.a[k+1]|0;if(i<0||i>=V.length||(b&&!WAT[b]))continue;const [x,y,z]=at(i);setB(x,y,z,b)}}
  else if(d.k==='all'&&Array.isArray(d.e)){const cols=new Set;for(let k=0;k+1<d.e.length;k+=2){const i=d.e[k]|0,b=d.e[k+1]|0;if(i<0||i>=V.length||(b&&!BL[b]))continue;if(LEM[V[i]])LSRC.delete(i);V[i]=b;if(LEM[b])LSRC.add(i);const [x,,z]=at(i);cols.add(x+z*WS)}cols.forEach(h=>colH(h%WS,h/WS|0));if(cols.size){relightAll();queueAll()}}
  else if(d.k==='chat'&&typeof d.m==='string')showChat(String(d.id),clean(d.m));
  else if(d.k==='chatno')toast('⏳ Even wachten met de volgende chat');
  else if(d.k==='end'&&d.s&&typeof d.s==='object')finish(d.s)});
 const EMAP=new Map;
 function syncAnimals(a){const seen=new Set;for(const r of a){if(!Array.isArray(r))continue;const id=r[0]|0,sp=SPN[r[1]|0];if(!sp||sp==='slijm')continue;seen.add(id);let e=EMAP.get(id);if(!e){e=mkEnt(sp,+r[2],+r[3],+r[4]);e.id=id;EMAP.set(id,e)}e.tx=num(r[2],0,WS);e.ty=num(r[3],0,WH+5);e.tz=num(r[4],0,WS);e.ta=+r[5]||0}
  for(const [id,e] of EMAP)if(!seen.has(id)){rmEnt(e);EMAP.delete(id)}}
 const offP=net.onPlayers(ps=>{for(const id of [...AV.keys()])if(!ps.some(p=>p.id===id)){dropAv(id);POS.delete(id);RATE.delete(id);CHR.delete(id)}});
 if(!HOST)net.send({k:'req'});
 const scores=()=>{const s={};net.players.forEach(p=>s[p.id]=HOST?SCORE[p.id]||0:0);return s};
 function stopGame(){if(!HOST||ended)return;if(slot||EDITS.size)saveWorld('',1);const s=scores();net.send({k:'end',s});finish(s)}
 function finish(s){if(ended)return;ended=1;pal(0);chatClose();closeUI();hB=hP=0;try{if(document.pointerLockElement===c)document.exitPointerLock()}catch(e){}if(bStop)bStop.disabled=true;if(bSave)bSave.disabled=true;net.result({winner:null,title:'Mooi gebouwd! 🏗️',scores:s,unit:' blokken',text:'Blokken geplaatst in deze bouwsessie'+(HOST&&wname?' · bewaard als “'+wname+'”':'')})}
 // --- main loop ---
 const dir=new THREE.Vector3();
 const stopLoop=loop(dt=>{t+=dt;if(playing())phys(dt);cam.position.set(P.x,P.cy+EYE+Math.sin(P.bob*2.2)*.04,P.z);cam.rotation.set(P.pitch,P.yaw,0);
  dir.set(-Math.sin(P.yaw)*Math.cos(P.pitch),Math.sin(P.pitch),-Math.cos(P.yaw)*Math.cos(P.pitch));hit=playing()?ray(cam.position.x,cam.position.y,cam.position.z,dir.x,dir.y,dir.z,6):null;
  ehit=playing()?rayEnt(cam.position.x,cam.position.y,cam.position.z,dir.x,dir.y,dir.z,Math.min(4.5,hit?hit.t+.01:4.5)):null;CR.className='bk-x'+(ehit?' en':'');sel.visible=!!hit&&!ehit;if(hit)sel.position.set(hit.x+.5,hit.y+.5,hit.z+.5);eCool-=dt;
  const mh=mouse&&!mouse.look&&!mouse.touch&&performance.now()-mouse.t>220,bh=hB||Kd.has('KeyX')||(mh&&mouse.btn!==2),ph=hP||Kd.has('KeyC')||(mh&&mouse.btn===2);
  if(bh&&ehit)hitAnimal();else if(bh&&hit){bCool-=dt;if(bCool<=0){brk();bCool=.25}}else bCool=0;if(ph){pCool-=dt;if(pCool<=0){place();pCool=.28}}else pCool=0;hand.position.y=-.46+Math.sin(P.bob*2.2)*.015;
  if(HOST&&wready&&!ended){dayT=(dayT+dt/600)%1;wT+=dt;if(wT>.15){wT=0;wTick(24)}
   for(const e of ENT){if(e.y<1){e.die=.01}nearP(e);aiAnimal(e,dt,NP[0],NP[1]);estep(e,dt);visE(e,dt)}for(let k=ENT.length-1;k>=0;k--)if(ENT[k].die)rmEnt(ENT[k]);
   animT+=dt;if(animT>12){animT=0;if(ENT.length<8){const q=grassSpot(P.x,P.z,10,40);if(q)mkEnt(SPN[R(3)],q[0],q[1],q[2])}}saveT+=dt;if(saveT>120&&(slot||EDITS.size))saveWorld('',1)}
  else if(!HOST){if(!wready){reqT+=dt;if(reqT>1.5){reqT=0;net.send({k:'req'})}}for(const e of ENT){const k=1-Math.exp(-10*dt);e.x+=(e.tx-e.x)*k;e.y+=(e.ty-e.y)*k;e.z+=(e.tz-e.z)*k;visE(e,dt)}}
  netT+=dt;if(netT>=.1){netT=0;if(HOST){const a=[[MYID,r2(P.x),r2(P.y),r2(P.z),r2(P.yaw),r2(P.pitch)]];POS.forEach((q,id)=>{if(net.players.some(p=>p.id===id))a.push([id,r2(q.x),r2(q.y),r2(q.z),r2(q.a),r2(q.t)])});
    net.send({k:'P',a,t:Math.round(dayT*1e4)/1e4,n:wready?ENT.map(e=>[e.id,SPN.indexOf(e.sp),r2(e.x),r2(e.y),r2(e.z),r2(e.ta)]):undefined});while(WB.length)net.send({k:'S',a:WB.splice(0,600)})}
   else if(wready)net.send({k:'p',x:r2(P.x),y:r2(P.y),z:r2(P.z),a:r2(P.yaw),t:r2(P.pitch)})}
  avStep(dt);ptStep(dt);flush();{const hx_=Math.floor(cam.position.x),hy_=Math.floor(cam.position.y),hz_=Math.floor(cam.position.z);hand.material.color.setScalar(Math.max(.18,Math.min(1,Math.sqrt(Math.max(skyAt(hx_,hy_,hz_)*LIGHT,LF[lightAt(hx_,hy_,hz_)])))))}
  const t0=performance.now();while(Q.length&&performance.now()-t0<(ready?6:12))build(Q.shift());if(!Q.length&&!ready){ready=1;c.dataset.build=bLog+' · '+bcnt+' chunks '+Math.round(bms)+'ms'}
  visT+=dt;if(visT>.3){visT=0;for(let i=0;i<CK.length;i++){const v=chunkVis(i),C=CK[i];if(C.o)C.o.visible=v;if(C.w)C.w.visible=v}sky(dayT)}
  ctex.offset.x=(t*.004)%1;dome.position.copy(cam.position);tv.copy(sunD).multiplyScalar(250);sun.position.copy(cam.position).add(tv);sun.lookAt(cam.position);moon.position.copy(cam.position).sub(tv);moon.lookAt(cam.position);
  hudT+=dt;if(hudT>.2){hudT=0;hud()}T.r.render(SC,cam)});
 const NP=[0,0];function nearP(e){let bx=P.x,bz=P.z,bd=(e.x-P.x)**2+(e.z-P.z)**2;POS.forEach(q=>{const d=(e.x-q.x)**2+(e.z-q.z)**2;if(d<bd){bd=d;bx=q.x;bz=q.z}});NP[0]=bx;NP[1]=bz;return NP}
 function hud(){const b=hot[selI],h=(dayT*24+6)%24;sc.textContent=net.pname(net.me.id)+(PHONE?'':' (jij)')+' · '+(b?'🧱 '+BL[b][0]:'✋')+' · '+(h>=6&&h<19?'☀️':'🌙')+(PHONE?'':' '+String(h|0).padStart(2,'0')+':'+String((h%1)*60|0).padStart(2,'0'))+' · 📍 '+(P.x|0)+','+(P.y|0)+','+(P.z|0)+' · 🏗️ '+placed+(PHONE?'':' · 👥 '+net.players.length)+(P.fly?' · 🕊️':'')+(ended?' · klaar!':'')}
 st.bl={get:(x,y,z)=>g(x,y,z),P,hit:()=>hit&&{...hit},av:()=>[...AV.values()].map(v=>({id:v.id,x:v.x,y:v.y,z:v.z,nm:v.nm,av:v.av,face:!!(v.head.material[5].map&&v.head.material[5].map.image),bub:v.bubS})),edits:()=>EDITS.size,placed:()=>placed,score:()=>({...SCORE}),build:()=>c.dataset.build,stop:()=>stopGame(),
  ready:()=>wready,seed:()=>seed,worlds:()=>lw().map(w=>({id:w.id,name:w.name,n:w.n,t:w.t})),save:n=>saveWorld(n),ui:()=>uiEl?uiEl.innerText:'',chat:m=>sendChat(m),log:()=>[...LOG.children].map(d=>d.textContent),mask:s=>mask(s),
  ents:()=>ENT.map(e=>({id:e.id,sp:e.sp,x:e.x,z:e.z})),day:v=>{dayT=v;sky(v)},dayT:()=>dayT,light:(x,y,z)=>lightAt(x,y,z),edit:(x,y,z,b)=>edit(x,y,z,b),hash:()=>{let h=0;for(let i=0;i<V.length;i++)h=(Math.imul(h,31)+V[i])|0;return h},perf:()=>({bms,bcnt,fms,fcnt,lcnt,lms})};
 hotUI();hud();if(HOST)picker();
 return()=>{if(HOST&&wready&&!ended&&(slot||EDITS.size))saveWorld('',1);stopLoop();off();offP();LT_.forEach(x=>clearTimeout(x));clearTimeout(toastT);removeEventListener('keydown',kd);removeEventListener('keyup',ku);removeEventListener('blur',blur);c.removeEventListener('wheel',wheel);document.removeEventListener('pointerlockchange',plc);document.removeEventListener('mousemove',pmv);
  try{if(document.pointerLockElement===c)document.exitPointerLock()}catch(e){}c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=c.oncontextmenu=null;delete st.bl;[...AV.keys()].forEach(dropAv);clearEnts();Object.values(MG).forEach(x=>x.dispose());slimeOG.dispose();halo.dispose();BOX.dispose();[wtex,ctex].forEach(x=>x.dispose());T.dispose()}}},
