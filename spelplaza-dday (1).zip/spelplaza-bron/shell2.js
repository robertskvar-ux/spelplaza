// Round 5 shell polish: safe leaving of online games, phone back button, scroll restore, mute, install-as-app.
module.exports = function applyShell2(html) {
  const css = `
#bar .wd{display:inline}
@media(max-width:560px){#bar .wd{display:none}#bar .gh{padding:8px 10px}#bar h2{font-size:16px}}
#rx{gap:2px}#rx button[data-e]{display:none}#rx.open button[data-e]{display:inline-block}#rx .rxt{font-size:20px}#rx.open .rxt{opacity:.6}
.lvc{position:fixed;left:12px;right:12px;bottom:calc(14px + env(safe-area-inset-bottom,0px));z-index:70;background:var(--card);color:var(--tx);border:1px solid var(--ln);border-radius:16px;padding:12px 14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;box-shadow:0 10px 30px rgba(0,0,0,.25);max-width:520px;margin:0 auto}
.lvc span{flex:1 1 180px;font-weight:600}
.inst{display:flex;align-items:center;gap:12px;background:var(--card);border:1px solid var(--ln);border-radius:16px;padding:12px 14px;margin:6px 0 10px}
.inst b{display:block}.inst span{color:var(--mu);font-size:13px}.inst>div{flex:1}.inst .x{border:0;background:none;color:var(--mu);font-size:18px;cursor:pointer}
`;
  html = html.replace('</style></head>', () => css + '</style></head>');

  // mute support in beep()
  const b0 = "let _ac;const beep=(fr=440,d=.08,type='square',v=.04)=>{try{";
  if (!html.includes(b0)) throw new Error('beep helper not found');
  html = html.replace(b0, () => "let _ac;const beep=(fr=440,d=.08,type='square',v=.04)=>{if(window.SPZ_MUTE)return;try{");

  // PWA tags (harmless where the files do not exist)
  html = html.replace('<title>', () => '<link rel="manifest" href="manifest.webmanifest"><link rel="apple-touch-icon" href="icon-192.png"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="SpelPlaza"><meta name="theme-color" content="#5b4cf5"><title>');

  const js = `
;(function(){
try{window.SPZ_MUTE=localStorage.getItem('sp_mute')==='1'}catch(e){}
const sb=$('#snd');const sIcon=()=>{if(sb)sb.textContent=window.SPZ_MUTE?'🔇':'🔊'};sIcon();
if(sb)sb.onclick=()=>{window.SPZ_MUTE=!window.SPZ_MUTE;try{localStorage.setItem('sp_mute',window.SPZ_MUTE?'1':'0')}catch(e){}sIcon()};
const _home=home,_launch=launch,_launchMP=launchMP,_mpOpen=mpOpen;let homeY=0,onHome=true;
const inMpGame=()=>NET.state!=='off'&&NET.code&&NET.game&&$('#play').style.display==='block'&&cur&&cur.mp;
function confirmLeave(go){let b=$('#lvc');if(b)b.remove();b=E('div','lvc','<span>Spel verlaten? Je verlaat dan ook de kamer.</span><button class="btn">Verlaten</button><button class="btn sec">Blijven</button>');b.id='lvc';
  b.querySelector('.btn').onclick=()=>{b.remove();NET.leave();go()};b.querySelector('.sec').onclick=()=>b.remove();document.body.append(b)}
const leaveHome=()=>{onHome=false;try{if(!history.state||history.state.spz!=='in')history.pushState({spz:'in'},'')}catch(e){}};
home=function(){if(inMpGame()&&!NET.isHost){confirmLeave(()=>home());return}
  if(inMpGame()&&NET.isHost)NET.toLobby();const lv=$('#lvc');if(lv)lv.remove();
  const was=onHome;_home();onHome=true;if(!was)requestAnimationFrame(()=>scrollTo(0,homeY));try{if(history.state&&history.state.spz==='in')history.replaceState({spz:'home'},'')}catch(e){}};
launch=function(g){if(onHome)homeY=scrollY;_launch(g);leaveHome();const bk=$('#bar .bk');if(bk)bk.innerHTML='‹<span class="wd"> Alle spellen</span>'};
mpOpen=function(){if(inMpGame()&&!NET.isHost){confirmLeave(()=>mpOpen());return}if(onHome)homeY=scrollY;_mpOpen();leaveHome()};
launchMP=function(id,late){_launchMP(id,late);leaveHome();const bk=$('#bar .bk');if(!bk)return;
  if(NET.isHost){bk.innerHTML='‹<span class="wd"> Lobby</span>'}else{bk.innerHTML='‹<span class="wd"> Verlaten</span>';bk.onclick=()=>confirmLeave(()=>mpStart&&(mpOpen()))}};
addEventListener('popstate',()=>{if(onHome)return;
  if(inMpGame()&&!NET.isHost){try{history.pushState({spz:'in'},'')}catch(e){}confirmLeave(()=>home());return}
  if(inMpGame()&&NET.isHost){try{history.pushState({spz:'in'},'')}catch(e){}NET.toLobby();return}
  if(NET.state!=='off'&&NET.code&&$('#mp').style.display==='block'&&$('#play').style.display!=='block'){try{history.pushState({spz:'in'},'')}catch(e){}}
  else home()});
// ---- install as app ----
const standalone=matchMedia('(display-mode: standalone)').matches||navigator.standalone;
let dismissed=false;try{dismissed=localStorage.getItem('sp_inst')==='1'}catch(e){}
let deferred=null;
function instCard(){if(standalone||dismissed||location.protocol!=='https:'||!/github\\.io$/.test(location.hostname))return null;
  const ios=/iphone|ipad|ipod/i.test(navigator.userAgent),mob=/android|iphone|ipad|ipod|mobile/i.test(navigator.userAgent);if(!mob&&!deferred)return null;
  const c=E('div','inst',\`<span style="font-size:30px">📲</span><div><b>Zet SpelPlaza op je beginscherm</b><span>\${ios?'Tik onderaan in Safari op <b>Deel</b> (□↑) en kies <b>Zet op beginscherm</b>.':deferred?'Dan opent het als een app, schermvullend.':'Open het menu ⋮ van je browser en kies <b>App installeren</b> of <b>Toevoegen aan startscherm</b>.'}</span></div>\${deferred?'<button class="btn" id="instb">Installeren</button>':''}<button class="x" aria-label="Sluiten">✕</button>\`);
  c.querySelector('.x').onclick=()=>{dismissed=true;try{localStorage.setItem('sp_inst','1')}catch(e){}c.remove()};
  const ib=c.querySelector('#instb');if(ib)ib.onclick=async()=>{deferred.prompt();try{await deferred.userChoice}catch(e){}deferred=null;c.remove()};return c}
const _draw=draw;draw=function(){_draw();const L=$('#lists');const q=$('#q').value.trim();if(L&&!q&&cat==='Alles'){const c=instCard();if(c)L.prepend(c)}};
addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferred=e;if(onHome)draw()});
if('serviceWorker' in navigator&&location.protocol==='https:'&&/github\\.io$/.test(location.hostname)){addEventListener('load',()=>{navigator.serviceWorker.register('sw.js').catch(()=>{})})}
draw();
})();
`;
  const i = html.lastIndexOf('</script>');
  html = html.slice(0, i) + js + html.slice(i);
  return html;
};
