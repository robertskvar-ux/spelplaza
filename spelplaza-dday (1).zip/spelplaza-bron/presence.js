// Live "X online" counter: one visitor's browser acts as the hub (fixed PeerJS id); the others connect to it.
// If the hub leaves, the others race to become the new hub. Runs only on the website (or in tests with SPZ_PEER).
module.exports = function applyPresence(html) {
  const css = `
#onl{display:none;align-items:center;gap:6px;height:40px;padding:0 12px;border-radius:12px;border:1px solid var(--ln);background:var(--card);font-weight:700;font-size:13px;white-space:nowrap;flex:none}
#onl i{width:9px;height:9px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 0 rgba(34,197,94,.6);animation:onp 2s infinite}
@keyframes onp{0%{box-shadow:0 0 0 0 rgba(34,197,94,.55)}70%{box-shadow:0 0 0 8px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
@media(max-width:560px){#onl{padding:0 9px;font-size:12px}#onl .ol{display:none}}
`;
  html = html.replace('</style></head>', () => css + '</style></head>');
  html = html.replace('<button id="snd"', () => '<span id="onl" title="Mensen nu op SpelPlaza"><i></i><b id="onn">1</b><span class="ol"> online</span></span><button id="snd"');
  const js = `
;(function(){
const on=window.SPZ_PRESENCE||(location.protocol==='https:'&&/github\\.io$/.test(location.hostname));
if(!on||typeof Peer==='undefined'||typeof RTCPeerConnection==='undefined')return;
const HUB='spz-presence-v1';const el=$('#onl'),nn=$('#onn');let peer=null,hub=null,conns=new Set(),dead=false,retry=0;
const show=n=>{if(!el)return;n=Math.max(1,n|0);nn.textContent=n;el.style.display='inline-flex';el.title=n===1?'Alleen jij is nu op SpelPlaza':n+' mensen nu op SpelPlaza'};
const cfg=()=>{const c=PEER_CFG();c.debug=0;return c};
const seen=new Map();
function bcast(){const n=conns.size+1;show(n);conns.forEach(c=>{try{c.open&&c.send({n})}catch(e){}})}
let gen=0,mode='idle';
function becomeHub(){if(dead||mode==='hub')return;const g=++gen;mode='hub';try{peer&&peer.destroy()}catch(e){}peer=null;const h=new Peer(HUB,cfg());hub=h;
  h.on('open',()=>{if(g!==gen)return;retry=0;bcast()});
  h.on('connection',c=>{c.on('open',()=>{if(g!==gen)return;conns.add(c);seen.set(c,Date.now());bcast()});c.on('data',()=>seen.set(c,Date.now()));const rm=()=>{if(g!==gen)return;conns.delete(c);seen.delete(c);bcast()};c.on('close',rm);c.on('error',rm)});
  h.on('error',e=>{if(g!==gen)return;const t=e&&e.type;if(t==='unavailable-id'){try{h.destroy()}catch(x){}hub=null;mode='idle';setTimeout(join,300+Math.random()*700)}else if(t==='network'||t==='server-error'||t==='socket-error'||t==='socket-closed')again()});
  h.on('disconnected',()=>{if(g!==gen)return;try{h.reconnect()}catch(e){again()}})}
setInterval(()=>{if(hub&&mode==='hub'&&!dead){const t=Date.now();conns.forEach(c=>{if(t-(seen.get(c)||0)>16000){conns.delete(c);seen.delete(c);try{c.close()}catch(e){}}});bcast()}},5000);
function again(){if(dead)return;gen++;try{hub&&hub.destroy()}catch(e){}try{peer&&peer.destroy()}catch(e){}hub=null;peer=null;conns.clear();mode='idle';retry=Math.min(retry+1,6);setTimeout(join,1000*retry+Math.random()*1000)}
function join(){if(dead||mode!=='idle')return;const g=++gen;mode='client';const p=new Peer(undefined,cfg());peer=p;let got=false;
  const fail=()=>{if(g!==gen||got)return;becomeHub()};
  p.on('open',()=>{if(g!==gen)return;const c=p.connect(HUB,{reliable:true,serialization:'json'});const to=setTimeout(fail,6000);let last=Date.now();const hb=setInterval(()=>{if(g!==gen){clearInterval(hb);return}try{c.open&&c.send({p:1})}catch(e){}if(got&&Date.now()-last>16000){clearInterval(hb);try{c.close()}catch(e){}try{p.destroy()}catch(e){}peer=null;mode='idle';setTimeout(join,200+Math.random()*1500)}},5000);
    c.on('data',m=>{if(g!==gen)return;got=true;last=Date.now();clearTimeout(to);retry=0;if(m&&typeof m.n==='number')show(m.n)});
    c.on('close',()=>{clearTimeout(to);clearInterval(hb);if(g!==gen||dead)return;try{p.destroy()}catch(e){}peer=null;mode='idle';setTimeout(join,300+Math.random()*1500)})});
  p.on('error',e=>{if(g!==gen)return;const t=e&&e.type;if(t==='peer-unavailable')fail();else if(t==='network'||t==='server-error'||t==='socket-error'||t==='socket-closed')again()})}
addEventListener('pagehide',()=>{dead=true;try{hub&&hub.destroy()}catch(e){}try{peer&&peer.destroy()}catch(e){}});
window.__presence={count:()=>+nn.textContent,isHub:()=>mode==='hub'};
setTimeout(join,400);
})();
`;
  const i = html.lastIndexOf('</script>');
  return html.slice(0, i) + js + html.slice(i);
};
