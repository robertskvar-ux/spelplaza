// Colourful skin on top of the clean theme: vivid header, playful type, gradient tiles, coloured categories.
module.exports = function applyColorful(html) {
  const font = '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Nunito:wght@500;700;800&display=swap" rel="stylesheet">';
  const loader = '<script>if(location.protocol==="https:"){document.write('+JSON.stringify(font)+')}</'+'script>';
  html = html.replace('<title>', () => loader + '<title>');
  const css = `
:root{--bg:#f3f0ff;--ln:#e4defa;--ac:#6d4aff;--ac2:#ece6ff}
@media(prefers-color-scheme:dark){:root:not([data-theme=light]){--bg:#120f24;--card:#1c1836;--ln:#2e2850;--ac:#9b85ff;--ac2:#2c2456}}
:root[data-theme=dark]{--bg:#120f24;--card:#1c1836;--ln:#2e2850;--ac:#9b85ff;--ac2:#2c2456}
body{font-family:"Nunito",ui-rounded,system-ui,sans-serif;background:var(--bg) radial-gradient(1200px 600px at 10% -10%,rgba(255,111,180,.18),transparent 60%),radial-gradient(900px 500px at 100% 0,rgba(80,200,255,.16),transparent 60%);background-attachment:fixed}
h1,h2,h3,.logo,#bar h2,.card b,.btn,.chips button,.code b,.modebox h3,.pbox h3{font-family:"Fredoka","Nunito",ui-rounded,system-ui,sans-serif;letter-spacing:0}
header{background:linear-gradient(100deg,#6d4aff 0%,#b64cff 38%,#ff5fa2 70%,#ff9f43 100%);border-bottom:0;box-shadow:0 6px 24px rgba(109,74,255,.25)}
header .logo{color:#fff;font-size:22px;text-shadow:0 2px 0 rgba(0,0,0,.12)}
header .logo .lg{display:inline-block;animation:wob 4s ease-in-out infinite}@keyframes wob{0%,100%{transform:rotate(-8deg)}50%{transform:rotate(8deg) scale(1.08)}}
header .sr{background:rgba(255,255,255,.95);border-color:transparent;color:#6b6290}
header #q{color:#1d1640}
header .hb,header #th,header #onl{background:rgba(255,255,255,.18);border-color:rgba(255,255,255,.35);color:#fff}
header .hb.live{background:#fff;color:#6d4aff}
.top{position:relative;overflow:hidden;align-items:center;padding:20px 20px;border-radius:24px;margin:14px 0 14px;color:#fff;
 background:linear-gradient(120deg,#ff5fa2,#ff9f43 45%,#ffd23f);box-shadow:0 12px 30px rgba(255,95,162,.28)}
.top::after{content:"🎮 🧩 🎲 🏆 🃏 🚀";position:absolute;right:-10px;bottom:-14px;font-size:44px;opacity:.22;letter-spacing:6px;white-space:nowrap;transform:rotate(-8deg);pointer-events:none}
.top h1{font-size:30px;color:#fff;text-shadow:0 2px 0 rgba(0,0,0,.12)}.top h1 span{color:rgba(255,255,255,.85)}.top p{color:rgba(255,255,255,.92);font-weight:700}
.top .btn{background:#fff;color:#ff5fa2;box-shadow:0 6px 0 rgba(0,0,0,.12);position:relative;z-index:1}
@media(max-width:560px){.top{padding:16px}.top h1{font-size:24px}.top::after{font-size:34px}}
.chips button{border:0;color:#fff;font-weight:700;box-shadow:0 3px 0 rgba(0,0,0,.12)}
.chips button:nth-child(8n+1){background:#6d4aff}.chips button:nth-child(8n+2){background:#ff5fa2}.chips button:nth-child(8n+3){background:#ff9f43}.chips button:nth-child(8n+4){background:#20c997}
.chips button:nth-child(8n+5){background:#3b82f6}.chips button:nth-child(8n+6){background:#e8590c}.chips button:nth-child(8n+7){background:#a855f7}.chips button:nth-child(8n+8){background:#0ea5e9}
.chips button{opacity:.55}.chips button.on{opacity:1;transform:translateY(-2px);box-shadow:0 5px 0 rgba(0,0,0,.18);background-blend-mode:normal;color:#fff;border:0}
.gh2 h2{font-size:20px}.gh2 span{background:var(--ac2);color:var(--ac);padding:1px 9px;border-radius:99px;font-weight:800}
.grp:nth-of-type(6n+1) .gh2 h2{color:#6d4aff}.grp:nth-of-type(6n+2) .gh2 h2{color:#e8457f}.grp:nth-of-type(6n+3) .gh2 h2{color:#e8590c}.grp:nth-of-type(6n+4) .gh2 h2{color:#12a37a}.grp:nth-of-type(6n+5) .gh2 h2{color:#2f6fe0}.grp:nth-of-type(6n) .gh2 h2{color:#9b3ff0}
:root[data-theme=dark] .gh2 h2{filter:brightness(1.45)}
@media(prefers-color-scheme:dark){:root:not([data-theme=light]) .gh2 h2{filter:brightness(1.45)}}
.th{background:linear-gradient(140deg,var(--c),var(--c2,var(--c)));border:0;box-shadow:0 8px 18px -8px var(--c),inset 0 -6px 0 rgba(0,0,0,.12);text-shadow:0 4px 10px rgba(0,0,0,.25);position:relative;overflow:hidden}
.th::before{content:"";position:absolute;inset:0;background:radial-gradient(120px 80px at 25% 15%,rgba(255,255,255,.45),transparent 60%);pointer-events:none}
.card:hover .th{transform:translateY(-4px) rotate(-1deg);background:linear-gradient(140deg,var(--c),var(--c2,var(--c)));box-shadow:0 14px 24px -10px var(--c),inset 0 -6px 0 rgba(0,0,0,.12)}
.card:active .th{transform:scale(.95)}
.card b{font-size:15px}
.nw{background:linear-gradient(90deg,#ff5fa2,#ff9f43);top:8px;right:8px}
.mpbn{background:linear-gradient(120deg,#6d4aff,#3b82f6);border:0;color:#fff;box-shadow:0 10px 26px rgba(109,74,255,.3)}.mpbn span{color:rgba(255,255,255,.9)}.mpbn .btn{background:#fff;color:#6d4aff}
.btn{box-shadow:0 4px 0 rgba(0,0,0,.14)}.btn:active{transform:translateY(2px);box-shadow:0 2px 0 rgba(0,0,0,.14)}
.btn.sec{box-shadow:none}
#stage{border:0;box-shadow:0 10px 30px rgba(60,40,140,.12)}
.mpc{border:0;box-shadow:0 8px 24px rgba(60,40,140,.10)}
.code b{background:linear-gradient(90deg,#6d4aff,#ff5fa2);-webkit-background-clip:text;background-clip:text;color:transparent}
footer{font-weight:700}
@media(max-width:560px){header .hw{flex-wrap:wrap;row-gap:8px;padding-bottom:10px}header .sr{order:9;flex:1 0 100%;max-width:none;margin:0}header .logo{margin-right:auto}}
@media(prefers-reduced-motion:reduce){header .logo .lg{animation:none}}
`;
  return html.replace('</style></head>', () => css + '</style></head>');
};
