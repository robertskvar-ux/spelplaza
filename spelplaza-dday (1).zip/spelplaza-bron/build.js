// Assembles dist/spelplaza.html from original.html + three.min.js + helpers + games/*.js
const fs = require('fs'), path = require('path');
const ROOT = __dirname;
let html = fs.readFileSync(path.join(ROOT, 'original.html'), 'utf8');
const three = fs.readFileSync(path.join(ROOT, 'three.min.js'), 'utf8');

// ---- preferred order of new games (unknown files are appended alphabetically) ----
const ORDER = [
  // 3D
  'blokkenland', 'runner3d', 'helix', 'stack3d', 'ball3d', 'race3d', 'space3d', 'maze3d', 'tunnel3d', 'platform3d', 'surprise3d',
  // arcade
  'invaders', 'asteroids', 'pacman', 'frogger', 'dino', 'doodle', 'lander', 'platformer',
  // mobile hits
  'bubble', 'towerdef', 'fruit', 'piano', 'cookie', 'flood',
  // puzzle
  'mahjong', 'kleurbal', 'sudoku', 'match3', 'sokoban', 'mastermind', 'nonogram', 'hanoi',
  // words / quiz
  'woordzoeker', 'quiz',
  // board & cards
  'chess', 'connect4', 'checkers', 'othello', 'battleship', 'blackjack', 'solitaire', 'dots', 'yahtzee',
];
const files = fs.readdirSync(path.join(ROOT, 'games')).filter(f => f.endsWith('.js') && !f.startsWith('orig_')); // orig_<id>.js = in-place replacements (see below)
const only = process.argv.slice(2); // optional: build with a subset of ids
const ids = files.map(f => f.replace(/\.js$/, '')).filter(id => !only.length || only.includes(id));
ids.sort((a, b) => {
  const ia = ORDER.indexOf(a), ib = ORDER.indexOf(b);
  if (ia === -1 && ib === -1) return a.localeCompare(b);
  if (ia === -1) return 1; if (ib === -1) return -1; return ia - ib;
});
let games = '';
for (const id of ids) {
  let src = fs.readFileSync(path.join(ROOT, 'games', id + '.js'), 'utf8').trim();
  if (!src.endsWith(',')) src += ',';
  if (src.includes('</script')) { console.warn('SKIP ' + id + ': contains </script'); continue; }
  try { new (require('vm').Script)('[' + src + ']'); } catch (e) { console.warn('SKIP ' + id + ': syntax error: ' + e.message); continue; }
  games += '\n' + src + '\n';
}

// ---- extra CSS ----
const css = `
#stage canvas{height:auto}
.pad{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:10px}
.pad .btn{min-width:54px;font-size:20px;padding:10px 14px;touch-action:none;user-select:none;-webkit-user-select:none}
.bdr{display:grid;gap:2px;margin:10px auto;touch-action:manipulation;user-select:none;-webkit-user-select:none}
.bdr div{display:flex;align-items:center;justify-content:center;cursor:pointer;aspect-ratio:1}
.hint{color:var(--mu);font-size:14px;margin:6px 0}
.ov{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;background:rgba(14,16,32,.72);color:#fff;border-radius:10px;font-weight:800;font-size:22px;text-align:center;padding:16px}
.wrap{position:relative;display:inline-block;max-width:100%}
.hero .btn{background:#fff3;border:1px solid #fff6}
`;
html = html.replace('</style></head>', () => css + '</style></head>');

// ---- helpers (inserted right after the swipe() helper) ----
const helpers = `
// ---- shared helpers (v2) ----
const ARR=['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '];
const loop=f=>{let id,last=performance.now(),on=1;const s=t=>{if(!on)return;const dt=Math.min(.05,(t-last)/1000);last=t;f(dt);id=requestAnimationFrame(s)};id=requestAnimationFrame(s);return()=>{on=0;cancelAnimationFrame(id)}};
let _ac;const beep=(fr=440,d=.08,type='square',v=.04)=>{try{_ac=_ac||new(window.AudioContext||window.webkitAudioContext)();if(_ac.state==='suspended')_ac.resume();const o=_ac.createOscillator(),g=_ac.createGain();o.type=type;o.frequency.value=fr;g.gain.value=v;o.connect(g);g.connect(_ac.destination);o.start();g.gain.exponentialRampToValueAtTime(.0001,_ac.currentTime+d);o.stop(_ac.currentTime+d)}catch(e){}};
function input(st,btns=[],press){const d=new Set;const kd=e=>{if(e.target.tagName==='INPUT')return;if(ARR.includes(e.key))e.preventDefault();if(e.repeat)return;d.add(e.key);press&&press(e.key)};const ku=e=>d.delete(e.key);addEventListener('keydown',kd);addEventListener('keyup',ku);let w=null;if(btns.length){w=E('div','pad');btns.forEach(([l,k])=>{const b=E('button','btn',l);b.onpointerdown=e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(x){}d.add(k);press&&press(k)};const up=()=>d.delete(k);b.onpointerup=b.onpointercancel=b.onpointerleave=up;b.oncontextmenu=e=>e.preventDefault();w.append(b)});st.append(w)}return{d,pad:w,has:k=>d.has(k),stop(){removeEventListener('keydown',kd);removeEventListener('keyup',ku);d.clear()}}}
function overlay(st,c,html){let o=st.querySelector('.ov');if(!html){o&&o.remove();return}if(!o){o=E('div','ov');let w=c.parentElement;if(!w||!w.classList.contains('wrap')){w=E('div','wrap');c.replaceWith(w);w.append(c)}w.append(o)}o.innerHTML=html;return o}
function three(st,w,h,opt={}){const r=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});r.setPixelRatio(Math.min(devicePixelRatio||1,2));r.setSize(w,h,false);const c=r.domElement;c.style.width=w+'px';c.style.height='auto';c.style.touchAction='none';r.shadowMap.enabled=!!opt.shadow;const s=new THREE.Scene();const cam=new THREE.PerspectiveCamera(opt.fov||60,w/h,.1,opt.far||500);st.append(c);return{r,s,cam,c,dispose(){try{s.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material)[].concat(o.material).forEach(m=>{m.map&&m.map.dispose();m.dispose()})});r.dispose();r.forceContextLoss()}catch(e){}}}}
`;
html = html.replace(/(function swipe\(el,f\)\{[^\n]*\n)/, (m, a) => a + helpers);

// ---- multiplayer: net layer + mp games ----
const peerjs = fs.readFileSync(path.join(ROOT, 'node_modules/peerjs/dist/peerjs.min.js'), 'utf8').replace(/\/\/# sourceMappingURL=.*$/m, '');
let net = fs.readFileSync(path.join(ROOT, 'net.js'), 'utf8');
const mpFiles = fs.existsSync(path.join(ROOT, 'mp')) ? fs.readdirSync(path.join(ROOT, 'mp')).filter(f => f.endsWith('.js') && !f.startsWith('_')) : [];
const MP_ORDER = ['dday','blokkenland','ttt','connect4','checkers','othello','battleship','chess','dots','pong','tanks','tron','hockey','snakeduel','quiz','draw','words','yahtzee','weerwolven','spionnen','jeopardy','stadland','bluf','kleurkaart','pesten','drawteams','sudoku','mines','woordzoeker'];
const mpIds = mpFiles.map(f => f.replace(/\.js$/, '')).filter(id => !only.length || only.includes(id) || !only.some(o => mpFiles.includes(o + '.js')));
mpIds.sort((a, b) => { const ia = MP_ORDER.indexOf(a), ib = MP_ORDER.indexOf(b); if (ia === -1 && ib === -1) return a.localeCompare(b); if (ia === -1) return 1; if (ib === -1) return -1; return ia - ib; });
let mpg = '';
for (const id of mpIds) {
  let src = fs.readFileSync(path.join(ROOT, 'mp', id + '.js'), 'utf8').trim();
  if (!src.endsWith(',')) src += ',';
  if (src.includes('</script')) { console.warn('SKIP mp/' + id + ': contains </script'); continue; }
  try { new (require('vm').Script)('[' + src + ']'); } catch (e) { console.warn('SKIP mp/' + id + ': syntax error: ' + e.message); continue; }
  mpg += '\n' + src + '\n';
}
net = net.replace('const MP=[];', () => 'const MP=[' + mpg + '];');
html = html.replace('// ---- shared helpers (v2) ----', () => net + '\n// ---- shared helpers (v2) ----');
html = html.replace('</footer>\n<script>', () => '</footer>\n<script>' + peerjs + '</script>\n<script>');
console.log('mp games:', mpIds.join(', ') || '(none)');

// ---- Three.js before main script ----
html = html.replace('</footer>\n<script>', () => '</footer>\n<script>' + three + '</script>\n<script>');

// ---- replace original G[] entries with games/orig_<id>.js (same position, same order) ----
{
  // find the end of the object literal that starts at html[start] === '{' (respects strings, template literals, comments, regex literals)
  const matchObj = (s, start) => {
    let i = start, depth = 0; const stack = []; // stack of '`' (inside template) or '{' (normal brace) / '${' (template expr)
    let prev = '';
    while (i < s.length) {
      const ch = s[i];
      const top = stack[stack.length - 1];
      if (top === '`') { // inside template literal text
        if (ch === '\\') { i += 2; continue; }
        if (ch === '`') { stack.pop(); i++; prev = '`'; continue; }
        if (ch === '$' && s[i + 1] === '{') { stack.push('${'); i += 2; continue; }
        i++; continue;
      }
      if (ch === "'" || ch === '"') { const q = ch; i++; while (i < s.length && s[i] !== q) { if (s[i] === '\\') i++; if (s[i] === '\n') throw new Error('unterminated string at ' + i); i++; } i++; prev = q; continue; }
      if (ch === '`') { stack.push('`'); i++; continue; }
      if (ch === '/' && s[i + 1] === '/') { while (i < s.length && s[i] !== '\n') i++; continue; }
      if (ch === '/' && s[i + 1] === '*') { i = s.indexOf('*/', i + 2) + 2; continue; }
      if (ch === '/' && (prev === '' || '(,=:[!&|?{};+-*%<>~^'.includes(prev) || /\b(return|typeof|case|in|of)$/.test(s.slice(Math.max(0, i - 8), i).trimEnd()))) { // regex literal
        i++; let cls = 0; while (i < s.length && (s[i] !== '/' || cls)) { if (s[i] === '\\') i++; else if (s[i] === '[') cls = 1; else if (s[i] === ']') cls = 0; if (s[i] === '\n') throw new Error('unterminated regex at ' + i); i++; }
        i++; while (/[a-z]/i.test(s[i])) i++; prev = '/'; continue;
      }
      if (ch === '{') { stack.push('{'); depth++; }
      else if (ch === '}') {
        const t = stack.pop();
        if (t === '{') { depth--; if (depth === 0 && stack.length === 0) return i + 1; }
        else if (t === '${') { /* back into template text */ }
        else throw new Error('unbalanced } at ' + i);
      }
      if (!/\s/.test(ch)) prev = ch;
      i++;
    }
    throw new Error('object literal not closed');
  };
  const origFiles = fs.readdirSync(path.join(ROOT, 'games')).filter(f => /^orig_.+\.js$/.test(f));
  const gStart = html.indexOf('const G=[');
  if (origFiles.length && gStart < 0) throw new Error('const G=[ not found');
  const replaced = [];
  for (const f of origFiles) {
    const id = f.slice(5, -3);
    if (id === 'wordle') { console.warn('SKIP ' + f + ': wordle stays untouched'); continue; }
    let src = fs.readFileSync(path.join(ROOT, 'games', f), 'utf8').trim();
    if (src.endsWith(',')) src = src.slice(0, -1);
    if (src.includes('</script')) { console.warn('SKIP ' + f + ': contains </script'); continue; }
    try { new (require('vm').Script)('[' + src + ']'); } catch (e) { console.warn('SKIP ' + f + ': syntax error: ' + e.message); continue; }
    if (!src.startsWith(`{id:'${id}',`)) { console.warn('SKIP ' + f + `: must start with {id:'${id}',`); continue; }
    const tag = `\n{id:'${id}',`;
    const at = html.indexOf(tag, gStart);
    if (at < 0) { console.warn('SKIP ' + f + ': original entry not found'); continue; }
    const s0 = at + 1, s1 = matchObj(html, s0);
    html = html.slice(0, s0) + src + html.slice(s1);
    replaced.push(id);
  }
  if (replaced.length) {
    // syntax check of the whole main script that holds G[]
    const g = html.indexOf('const G=['), a = html.lastIndexOf('<script>', g) + 8, b = html.indexOf('</script>', g);
    try { new Function(html.slice(a, b)); } catch (e) { throw new Error('orig_ replacement broke the main script: ' + e.message); }
    console.log('replaced original games:', replaced.join(', '));
  }
}

// ---- splice games into G[] ----
if (!html.includes('\n\n];\nconst cats=')) throw new Error('G[] terminator not found');
html = html.replace('\n\n];\nconst cats=', () => ',\n' + games + '\n];\nconst cats=');

// ---- old NIEUW badges off (only the new batch is new) ----
html = html.replace(/,nw:1,run\(st\)\{\n const c=mkCanvas\(st,200,400\)/, ',run(st){\n const c=mkCanvas(st,200,400)'); // tetris
for (const id of ['breakout', 'pong', 'galgje', 'slide', 'lights', 'react']) {
  html = html.replace(new RegExp(`(\\{id:'${id}',[^\\n]*?),nw:1,run\\(st\\)`), '$1,run(st)');
}

// ---- category order, counts, random button ----
html = html.replace(
  "const cats=['Alles',...new Set(G.map(g=>g.c))];",
  "const cats=[...new Set(['Alles','3D','Arcade','Puzzel','Bord','Kaarten','Woorden','Geheugen',...G.map(g=>g.c)])];"
);
html = html.replace('<p>16 spellen · geen download · werkt op telefoon en computer</p></div><div class="hb">🎮🕹️🏆</div>',
  '<p><span id="cnt"></span> spellen · geen download · werkt op telefoon en computer</p><button class="btn" style="margin-top:10px" onclick="launch(G[R(G.length)])">🎲 Verras me</button></div><div class="hb">🎮🕹️🏆</div>');
html = html.replace("function draw(){const q=$('#q').value.toLowerCase();", "function draw(){$('#cnt').textContent=G.length;const q=$('#q').value.toLowerCase();");
html = html.replace("<h2 id=\"ht\">🔥 Alle spellen</h2>", "<h2 id=\"ht\">🔥 Alle spellen</h2>");
// stage can hold position:relative wrappers
html = html.replace('#stage{background:var(--card);', '#stage{position:relative;background:var(--card);');

// ---- Wordle payload: raw-deflate + tiny inflater (file shrinks by ~4 MB) ----
{
  const z = fs.readFileSync(path.join(ROOT, 'wordle.z.b64'), 'utf8');
  const before = html.length;
  html = html.replace(/const WORDLE='[^']+';/, () => "const WORDLE='" + z + "';");
  html = html.replace("f.srcdoc=new TextDecoder().decode(Uint8Array.from(atob(WORDLE),c=>c.charCodeAt(0)));", "f.srcdoc=new TextDecoder().decode(__inflate(Uint8Array.from(atob(WORDLE),c=>c.charCodeAt(0))));");
  if (!html.includes('__inflate(')) throw new Error('wordle decode line not found');
  const inflate = fs.readFileSync(path.join(ROOT, 'inflate.min.js'), 'utf8');
  html = html.replace('</footer>\n<script>', () => '</footer>\n<script>' + inflate + '</script>\n<script>');
  console.log('wordle compressed:', before, '->', html.length);
}
html = require('./theme')(html);
html = require('./shell2')(html);
html = require('./presence')(html);
html = require('./colorful')(html);
html = require('./site3')(html);
// ---- transpile the main (last) script for older phone browsers ----
{
  const i = html.lastIndexOf('<script>'), j = html.lastIndexOf('</script>');
  const js = html.slice(i + 8, j);
  const out = require('esbuild').transformSync(js, { target: ['safari13', 'chrome80', 'firefox78'], charset: 'utf8', legalComments: 'none' }).code;
  if (out.includes('</script')) throw new Error('transpiled script contains </script');
  html = html.slice(0, i + 8) + out + html.slice(j);
  console.log('transpiled main script:', js.length, '->', out.length);
}
fs.writeFileSync((process.env.SPZ_OUT ? path.resolve(ROOT, process.env.SPZ_OUT) : path.join(ROOT, 'dist', 'spelplaza.html')), html);
console.log('built', process.env.SPZ_OUT || 'dist/spelplaza.html', 'with', ids.length, 'new games:', ids.join(', '), '| size', (html.length / 1e6).toFixed(2), 'MB');
