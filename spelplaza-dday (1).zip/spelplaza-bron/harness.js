// Headless test harness. Usage:
//   node harness.js <id> [<id>...]     -> builds, opens each game, presses keys/pointer, reports errors, saves shots/<id>-1.png, -2.png
//   node harness.js all                -> every game in G (old + new)
// From code:  const {openGame}=require('./harness'); const g=await openGame('snake'); ... await g.close()
const { chromium } = require('playwright-core');
const path = require('path'), fs = require('fs'), { execSync } = require('child_process');
const ROOT = __dirname;
const EXE = '/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell';
const ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required', '--mute-audio'];

async function launchBrowser(opts = {}) {
  return chromium.launch({ executablePath: EXE, headless: true, args: ARGS });
}

async function openGame(id, opts = {}) {
  const browser = opts.browser || await launchBrowser();
  const ctx = await browser.newContext({ viewport: opts.viewport || { width: 420, height: 800 }, hasTouch: !!opts.touch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGEERROR: ' + (e.stack || e.message)));
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type().toUpperCase() + ': ' + m.text()); });
  await page.goto('file://' + (process.env.SPZ_OUT ? path.resolve(ROOT, process.env.SPZ_OUT) : path.join(ROOT, 'dist', 'spelplaza.html')));
  await page.waitForTimeout(300);
  const found = await page.evaluate(id => { const g = G.find(g => g.id === id); if (!g) return false; launch(g); return true; }, id);
  if (!found) { errors.push('NO SUCH GAME: ' + id); }
  await page.waitForTimeout(opts.wait || 1200);
  return {
    page, browser, ctx, errors,
    shot: async (n) => { const f = path.join(ROOT, 'shots', `${id}-${n}.png`); await page.screenshot({ path: f }); return f; },
    stageBox: async () => page.evaluate(() => { const r = document.querySelector('#stage').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; }),
    canvasBox: async () => page.evaluate(() => { const c = document.querySelector('#stage canvas'); if (!c) return null; const r = c.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; }),
    restart: async () => page.evaluate(() => restart()),
    home: async () => page.evaluate(() => home()),
    close: async () => { await ctx.close(); if (!opts.browser) await browser.close(); },
  };
}

async function smoke(id, browser) {
  const g = await openGame(id, { browser, touch: true });
  const s1 = await g.shot(1);
  // generic interaction: keys + pointer on canvas/stage
  const cb = (await g.canvasBox()) || (await g.stageBox());
  if (cb) {
    const cx = cb.x + cb.w / 2, cy = cb.y + cb.h / 2;
    await g.page.mouse.move(cx, cy); await g.page.mouse.down(); await g.page.mouse.move(cx + 40, cy + 10, { steps: 5 }); await g.page.mouse.up();
    await g.page.mouse.click(cx, cy);
  }
  for (const k of ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space', 'ArrowLeft', 'ArrowUp', 'Space']) { await g.page.keyboard.press(k); await g.page.waitForTimeout(120); }
  await g.page.waitForTimeout(1500);
  const s2 = await g.shot(2);
  await g.restart(); await g.page.waitForTimeout(400);
  await g.home(); await g.page.waitForTimeout(200);
  // re-open once more to catch cleanup bugs (double listeners, leaked timers)
  await g.page.evaluate(id => launch(G.find(g => g.id === id)), id); await g.page.waitForTimeout(600);
  await g.home();
  const errs = [...new Set(g.errors)];
  await g.close();
  return { id, errs, shots: [s1, s2] };
}

if (require.main === module) {
  (async () => {
    let ids = process.argv.slice(2);
    const subset = ids.length && ids[0] !== 'all';
    execSync('node ' + path.join(ROOT, 'build.js') + (subset ? ' ' + ids.join(' ') : ''), { stdio: 'inherit' });
    const browser = await launchBrowser();
    if (ids[0] === 'all' || !ids.length) {
      const p = await (await browser.newContext()).newPage();
      await p.goto('file://' + (process.env.SPZ_OUT ? path.resolve(ROOT, process.env.SPZ_OUT) : path.join(ROOT, 'dist', 'spelplaza.html')));
      ids = await p.evaluate(() => G.map(g => g.id)); await p.context().close();
    }
    let bad = 0;
    for (const id of ids) {
      try {
        const r = await smoke(id, browser);
        if (r.errs.length) { bad++; console.log(`✗ ${id}\n   ` + r.errs.join('\n   ')); } else console.log(`✓ ${id}  (${r.shots.map(s => path.relative(ROOT, s)).join(', ')})`);
      } catch (e) { bad++; console.log(`✗ ${id} harness failure: ${e.message}`); }
    }
    await browser.close();
    console.log(bad ? `${bad} game(s) with problems` : 'all clean');
    process.exit(bad ? 1 : 0);
  })();
}
module.exports = { openGame, launchBrowser, smoke };
