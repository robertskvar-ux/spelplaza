// ---- SpelPlaza multiplayer: transport (PeerJS, star topology, host = authority) + lobby + profile/avatars + podium/reactions ----
const MP=[]; // multiplayer game modules are pushed here by build.js
const CODE_CHARS='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const mkCode=()=>Array.from({length:5},()=>CODE_CHARS[R(CODE_CHARS.length)]).join('');
const PEER_CFG=()=>Object.assign({host:'0.peerjs.com',port:443,path:'/',secure:true,debug:0,
  config:{iceServers:[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun1.l.google.com:19302'}]}},window.SPZ_PEER||{});
function mulberry(seed){let a=seed>>>0;return()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
const LS=(k,v)=>{try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}};
// ---- profile (on this device, no password) ----
const AVATARS=['🦊','🐼','🐸','🐙','🦄','🐯','🐨','🐷','🐵','🐧','🦁','🐶','🐱','🦉','🐰','🐲','🦝','👻','👽','🦖','🐳','🦋','🐝','🍄'];
const COLORS=['#5b4cf5','#e5383b','#2a9d8f','#f4a261','#2f80ed','#e63fa0','#7cb518','#8338ec'];
const PROFILE={
  get(){let p=null;try{p=JSON.parse(localStorage.getItem('sp_profile')||'null')}catch(e){}
    if(!p||typeof p!=='object')p={};if(!AVATARS.includes(p.av))p.av=AVATARS[R(AVATARS.length)];if(!COLORS.includes(p.col))p.col=COLORS[R(COLORS.length)];
    p.name=String(p.name||LS('sp_name')||'').slice(0,16);return p},
  set(p){LS('sp_profile',JSON.stringify({name:String(p.name||'').slice(0,16),av:p.av,col:p.col}))}
};
const STATS={
  get(){try{const s=JSON.parse(localStorage.getItem('sp_stats')||'{}');return s&&typeof s==='object'?s:{}}catch(e){return{}}},
  bump(kind,id){const s=this.get();s[kind]=s[kind]||{};s[kind][id]=(s[kind][id]||0)+1;LS('sp_stats',JSON.stringify(s))},
  sum(kind){const o=this.get()[kind]||{};return Object.values(o).reduce((a,b)=>a+b,0)}
};
const NET={
  code:null,isHost:false,me:{id:null,name:'',av:'🙂',col:COLORS[0]},players:[],peer:null,conns:{},hostConn:null,game:null,seed:0,state:'off',
  _h:[],_ph:[],_sh:[],_round:0,sug:{},tour:null,want:null,_botN:0,
  // ---- bots (host only). Bot players live in NET.players with bot:true; their moves are injected with botAct(). ----
  isBot(id){const p=this.players.find(x=>x.id===id);return !!(p&&p.bot)},
  bots(){return this.players.filter(p=>p.bot)},
  addBot(){if(!this.isHost||this.players.length>=8)return;const used=this.players.map(p=>p.col);const col=COLORS.find(c=>!used.includes(c))||COLORS[R(COLORS.length)];
    const names=['Robbie','Bliep','Pixel','Turbo','Chip','Bolt','Nova','Byte'];const usedN=this.players.map(p=>p.name);const nm=names.find(n=>!usedN.includes(n+' (bot)'))||('Bot '+(++this._botN));
    this.players.push({id:'bot-'+(++this._botN)+'-'+R(1e6),name:nm.includes('Bot ')?nm:nm+' (bot)',host:false,bot:true,av:'🤖',col});this._bcast(this._playersMsg());this._emitPlayers()},
  removeBot(id){if(!this.isHost||!this.isBot(id))return;this.players=this.players.filter(p=>p.id!==id);this._bcast(this._playersMsg());this._emitPlayers()},
  botAct(id,d){if(!this.isHost||!this.isBot(id))return;const g=this.game;setTimeout(()=>{if(this.game===g&&this.isBot(id))this._deliver(d,id)},0)},
  myIndex(){return this.players.findIndex(p=>p.id===this.me.id)},
  on(f){this._h.push(f);return()=>{this._h=this._h.filter(x=>x!==f)}},
  onPlayers(f){this._ph.push(f);return()=>{this._ph=this._ph.filter(x=>x!==f)}},
  onStatus(f){this._sh.push(f);return()=>{this._sh=this._sh.filter(x=>x!==f)}},
  rng(){return mulberry(this.seed)},
  // display helpers for games
  pname(p){if(typeof p==='string')p=this.players.find(x=>x.id===p);return p?(p.av||'🙂')+' '+p.name:'?'},
  pcol(p){if(typeof p==='string')p=this.players.find(x=>x.id===p);return p&&p.col||COLORS[0]},
  _emitPlayers(){this._ph.forEach(f=>{try{f(this.players)}catch(e){console.error(e)}})},
  _status(s,msg){this.state=s;this._sh.forEach(f=>{try{f(s,msg)}catch(e){}})},
  _deliver(d,from){this._h.forEach(f=>{try{f(d,from)}catch(e){console.error(e)}})},
  _mkPeer(id){const p=new Peer(id,PEER_CFG());this.peer=p;p.on('error',e=>{const t=e.type||'';if(t==='unavailable-id')this._status('error','Die code is al in gebruik, probeer opnieuw');else if(t==='peer-unavailable')this._status('error','Geen kamer gevonden met die code');else if(t==='network'||t==='server-error'||t==='socket-error'||t==='socket-closed')this._status('error','Geen verbinding met de koppelserver. Controleer je internet en probeer opnieuw');else if(t==='browser-incompatible')this._status('error','Deze browser ondersteunt geen rechtstreekse verbindingen');else this._status('error','Verbindingsfout ('+t+')')});return p},
  _setMe(prof){this.me.name=prof.name;this.me.av=prof.av;this.me.col=prof.col},
  host(prof){this.leave();this.isHost=true;this._setMe(prof);this.code=mkCode();this._status('connecting','Kamer maken…');
    const p=this._mkPeer('spz-'+this.code);
    p.on('open',id=>{this.me.id=id;this.players=[{id,name:this.me.name,host:true,av:this.me.av,col:this.me.col}];this._status('lobby');this._emitPlayers()});
    p.on('connection',c=>{c.on('open',()=>{this.conns[c.peer]=c});c.on('data',m=>this._hostRecv(m,c));c.on('close',()=>this._drop(c.peer));c.on('error',()=>this._drop(c.peer))})},
  join(code,prof){this.leave();this.isHost=false;this._setMe(prof);this.code=code.toUpperCase().replace(/[^A-Z0-9]/g,'');this._status('connecting','Verbinden met kamer '+this.code+'…');
    const p=this._mkPeer(undefined);
    p.on('open',id=>{this.me.id=id;const c=p.connect('spz-'+this.code,{reliable:true,serialization:'json'});this.hostConn=c;
      const to=setTimeout(()=>{if(this.state==='connecting')this._status('error','Geen antwoord van de kamer. Klopt de code en is de host nog online?')},12000);
      c.on('open',()=>{c.send({k:'hello',name:this.me.name,av:this.me.av,col:this.me.col})});
      c.on('data',m=>{clearTimeout(to);this._clientRecv(m)});c.on('close',()=>{if(this.state!=='off')this._status('error','De host heeft de kamer gesloten')});c.on('error',()=>this._status('error','Verbinding met de host verbroken'))})},
  leave(){try{this.peer&&this.peer.destroy()}catch(e){}this.peer=null;this.conns={};this.hostConn=null;this.players=[];this.code=null;this.game=null;this.isHost=false;this.state='off';this._h=[];rxBar()},
  // ---- host side ----
  _playersMsg(){return {k:'players',players:this.players,code:this.code,game:this.game,seed:this.seed,round:this._round,sug:this.sug,tour:this.tour}},
  _hostRecv(m,c){if(!m||typeof m!=='object')return;
    if(m.k==='hello'){if(this.players.length>=8){c.send({k:'full'});return}const name=String(m.name||'Speler').slice(0,16);
      const av=AVATARS.includes(m.av)?m.av:AVATARS[R(AVATARS.length)];let col=COLORS.includes(m.col)?m.col:COLORS[0];const used=this.players.map(p=>p.col);if(used.includes(col)){const free=COLORS.find(x=>!used.includes(x));if(free)col=free}
      this.players.push({id:c.peer,name,host:false,av,col});this.conns[c.peer]=c;this._bcast(this._playersMsg());this._emitPlayers();return}
    if(m.k==='sug'){const g=String(m.game||'');if(g&&!MP.some(x=>x.id===g))return;if(!g||this.sug[c.peer]===g)delete this.sug[c.peer];else this.sug[c.peer]=g;this._bcast({k:'sug',sug:this.sug});if(this.state==='lobby'&&!this.game)showLobby();return}
    if(m.k==='rx'){const e=String(m.e||'').slice(0,4);if(!RX.includes(e))return;const d={k:'rx',e,from:c.peer};this._bcast(d,c.peer);showReaction(e,c.peer);return}
    if(m.k==='g')this._deliver(m.d,c.peer)},
  _drop(id){if(!this.conns[id]&&!this.players.some(p=>p.id===id))return;delete this.conns[id];delete this.sug[id];this.players=this.players.filter(p=>p.id!==id);this._bcast(this._playersMsg());this._emitPlayers()},
  _bcast(m,except){Object.values(this.conns).forEach(c=>{if(c.open&&c.peer!==except)try{c.send(m)}catch(e){}})},
  start(gameId){if(!this.isHost)return;this.game=gameId;this.seed=(Math.random()*2**32)>>>0;this._round++;this._h=[];this.sug={};this.want=null;this._bcast({k:'start',game:gameId,seed:this.seed,round:this._round,tour:this.tour});launchMP(gameId)},
  suggest(gameId){if(this.isHost)return;const cur=this.sug[this.me.id];if(cur===gameId)delete this.sug[this.me.id];else this.sug[this.me.id]=gameId;try{this.hostConn&&this.hostConn.open&&this.hostConn.send({k:'sug',game:cur===gameId?'':gameId})}catch(e){}showLobby()},
  toLobby(){if(this.isHost){this.game=null;this._h=[];this._bcast({k:'lobby',tour:this.tour})}showLobby()},
  // ---- tournament (host) ----
  tourStart(list){if(!this.isHost||!list.length)return;this.tour={list:list.slice(0,5),i:0,pts:{},log:[],done:false};this.start(this.tour.list[0])},
  tourNext(){const t=this.tour;if(!this.isHost||!t)return;if(t.i+1<t.list.length){t.i++;this.start(t.list[t.i])}else{t.done=true;this._bcast({k:'tourEnd',tour:t});showTourEnd()}},
  tourStop(){if(!this.isHost)return;this.tour=null;this._bcast({k:'lobby',tour:null});showLobby()},
  // ---- client side ----
  _clientRecv(m){if(!m||typeof m!=='object')return;
    if(m.k==='full'){this._status('error','De kamer is vol (max. 8 spelers)');return}
    if(m.k==='sug'){this.sug=m.sug||{};if(this.state==='lobby'&&!this.game&&$('#mp').style.display==='block')showLobby();return}
    if(m.k==='tourEnd'){this.tour=m.tour;showTourEnd();return}
    if(m.k==='players'){this.players=m.players;this.sug=m.sug||{};if('tour' in m)this.tour=m.tour;if(this.state==='connecting'){this._status('lobby');if(m.game){this.game=m.game;this.seed=m.seed;this._round=m.round||0;launchMP(m.game,true)}}this._emitPlayers();return}
    if(m.k==='start'){if('tour' in m)this.tour=m.tour;this.game=m.game;this.seed=m.seed;this._round=m.round||this._round+1;this._h=[];launchMP(m.game);return}
    if(m.k==='lobby'){if('tour' in m)this.tour=m.tour;this.game=null;this._h=[];showLobby();return}
    if(m.k==='rx'){showReaction(String(m.e||''),m.from);return}
    if(m.k==='g')this._deliver(m.d,'host')},
  // ---- game API ----
  // send(d): client -> host; host -> everyone else. sendTo(id,d): host -> one player.
  send(d){if(this.isHost)this._bcast({k:'g',d});else if(this.hostConn&&this.hostConn.open)try{this.hostConn.send({k:'g',d})}catch(e){}},
  sendTo(id,d){if(this.isBot(id))return;const c=this.conns[id];if(c&&c.open)try{c.send({k:'g',d})}catch(e){}},
  react(e){if(this.state==='off'||!RX.includes(e))return;showReaction(e,this.me.id);if(this.isHost)this._bcast({k:'rx',e,from:this.me.id});else if(this.hostConn&&this.hostConn.open)try{this.hostConn.send({k:'rx',e})}catch(x){}},
  // result({winner:id|null, scores:{id:pts}?, text?, title?}) -> podium overlay on this peer + stats. Call once per round on every peer.
  _resultRound:-1,
  result(r){r=r||{};const st=$('#stage');if(!st||!this.game)return;const key=this.game+':'+this._round;
    if(this._resultRound!==key){this._resultRound=key;tourScore(r,key);STATS.bump('mpDone',this.game);if(r.winner===this.me.id)STATS.bump('mpWon',this.game);if(r.scores&&r.scores[this.me.id]!=null){const b=+r.scores[this.me.id];if(!isNaN(b))bestMP(this.game,b)}}
    podium(st,r)}
};
function rankRows(r){let rows=NET.players.map(p=>({p,pts:r.scores&&r.scores[p.id]!=null?+r.scores[p.id]:null}));
  if(r.scores){const sc=rows.filter(x=>x.pts!=null);if(sc.length)rows=sc;rows.sort((a,b)=>(b.pts||0)-(a.pts||0))}else if(r.winner)rows.sort((a,b)=>(b.p.id===r.winner)-(a.p.id===r.winner));return rows}
// placement points: last 0, each place above +2; equal scores share a place; a draw gives everyone N-1
function tourScore(r,key){const t=NET.tour;if(!t||t.done||t.log.some(l=>l.key===key))return;const rows=rankRows(r);const N=rows.length;const add={};
  if(!r.winner&&!r.scores)rows.forEach(x=>add[x.p.id]=N-1);
  else{let place=0;rows.forEach((x,i)=>{if(i>0){const prev=rows[i-1];const tie=r.scores?prev.pts===x.pts:false;if(!tie)place=i}add[x.p.id]=2*(N-1-place)/ (N>1?1:1)});if(r.winner&&!r.scores)rows.forEach(x=>{if(x.p.id!==r.winner)add[x.p.id]=0;else add[x.p.id]=2*(N-1)})}
  Object.keys(add).forEach(id=>t.pts[id]=(t.pts[id]||0)+add[id]);t.log.push({key,game:NET.game,add})}
function tourTable(){const t=NET.tour;if(!t)return '';const rows=NET.players.map(p=>({p,v:t.pts[p.id]||0})).sort((a,b)=>b.v-a.v);
  return `<div class="tourt"><b>🏆 Toernooi · spel ${Math.min(t.i+1,t.list.length)}/${t.list.length}</b><ol>${rows.map(x=>`<li><span class="pav s" style="--c:${x.p.col}">${x.p.av}</span><span>${esc(x.p.name)}${x.p.id===NET.me.id?' (jij)':''}</span><em>${x.v} pt</em></li>`).join('')}</ol><p class="hint">${t.list.map((g,i)=>{const m=MP.find(x=>x.id===g);return (i<t.i?'✓ ':i===t.i?'▶ ':'')+(m?m.e+' '+esc(m.n):g)}).join(' · ')}</p></div>`}
function showTourEnd(){const t=NET.tour;if(!t)return;stop();stop=()=>{};$('#home').style.display='none';$('#mp').style.display='none';$('#play').style.display='block';$('#pt').textContent='🏆 Toernooi-uitslag';$('#bar .rs').style.display='none';$('#bar .bk').textContent='‹ Lobby';$('#bar .bk').onclick=()=>{if(NET.isHost)NET.tourStop();else showLobby()};
  const st=$('#stage');st.innerHTML='';st.style.minHeight='520px';const scores={};NET.players.forEach(p=>scores[p.id]=t.pts[p.id]||0);const rows=NET.players.slice().sort((a,b)=>scores[b.id]-scores[a.id]);const top=rows[0];const tie=rows[1]&&scores[rows[1].id]===scores[top.id];
  st.append(E('div','hint','Eindklassement na '+t.list.length+' spellen'));
  podium(st,{winner:tie?null:top.id,scores,unit:' pt',title:tie?'🏆 Gedeelde eerste plaats!':(top.id===NET.me.id?'🏆 Jij wint het toernooi!':'🏆 '+top.name+' wint het toernooi!'),text:t.list.map(g=>{const m=MP.find(x=>x.id===g);return m?m.e:''}).join(' '),noDefault:true,buttons:NET.isHost?[{label:'Nieuw toernooi',fn:()=>{NET.tour=null;tourPicker()}},{label:'Lobby',fn:()=>NET.tourStop()}]:[]})}
function bestMP(id,s){try{const k='sp_mp_'+id,b=+localStorage.getItem(k)||0;if(s>b)localStorage.setItem(k,s)}catch(e){}}
// ---- reactions ----
const RX=['👍','😂','🔥','😱','❤️'];
function rxBar(){let b=$('#rx');if(NET.state==='off'||!NET.code){if(b)b.remove();return}if(b)return;b=E('div','',`<button type="button" class="rxt" aria-label="Reacties">😀</button>`+RX.map(e=>`<button type="button" data-e="${e}">${e}</button>`).join(''));b.querySelector('.rxt').onclick=ev=>{ev.stopPropagation();b.classList.toggle('open')};b.id='rx';b.onclick=ev=>{const t=ev.target.closest('button');if(t){NET.react(t.dataset.e);t.classList.add('tap');setTimeout(()=>t.classList.remove('tap'),200)}};document.body.append(b)}
let _rxLast=0;
function showReaction(e,from){if(!RX.includes(e))return;const now=Date.now();if(now-_rxLast<40)return;_rxLast=now;const p=NET.players.find(x=>x.id===from);const d=E('div','rxf',`<span>${e}</span><small></small>`);d.querySelector('small').textContent=p?(p.av+' '+p.name):'';d.style.left=(12+Math.random()*60)+'%';d.style.setProperty('--c',p&&p.col||'#888');document.body.append(d);setTimeout(()=>d.remove(),2400)}
// ---- podium overlay with confetti ----
const SING={' vakjes':' vakje',' woorden':' woord',' rondes':' ronde',' treffers':' treffer',' goals':' goal',' juist':' juist',' schijven':' schijf',' hokjes':' hokje'};
function podium(st,r){st.querySelector('.podium')&&st.querySelector('.podium').remove();const me=NET.me.id;
  let rows=rankRows(r);
  const draw=!r.winner&&!r.scores;const win=NET.players.find(p=>p.id===r.winner);
  const o=E('div','podium');const title=r.title||(draw?'Gelijkspel':win?(win.id===me?'Jij wint! 🎉':win.name+' wint!'):'Einde');
  o.innerHTML=`<div class="pbox"><div class="pwin">${win?`<span class="pav" style="--c:${win.col}">${win.av}</span>`:'🤝'}</div><h3></h3>${r.text?'<p class="hint"></p>':''}<ol class="prows"></ol><div class="pbtns"></div></div>`;
  o.querySelector('h3').textContent=title;if(r.text)o.querySelector('p').textContent=r.text;
  const ol=o.querySelector('.prows');const medals=['🥇','🥈','🥉'];rows.forEach((row,i)=>{const li=E('li','',`<span class="pm">${rows.length>1&&(r.scores||r.winner)?(medals[i]||(i+1)+'.'):''}</span><span class="pav s" style="--c:${row.p.col}">${row.p.av}</span><b></b><em></em>`);li.querySelector('b').textContent=row.p.name+(row.p.id===me?' (jij)':'');li.querySelector('em').textContent=row.pts!=null?row.pts+(row.pts===1&&SING[r.unit]?SING[r.unit]:(r.unit||' pt')):'';if(row.p.id===r.winner)li.classList.add('w');ol.append(li)});
  const bt=o.querySelector('.pbtns');(r.buttons||[]).forEach(b=>{const x=E('button','btn',b.label);x.onclick=()=>{o.remove();b.fn&&b.fn()};bt.append(x)});const T=NET.tour;if(r.noDefault){}else if(T&&!T.done){if(NET.isHost){const last=T.i+1>=T.list.length;const nm=last?'':(MP.find(x=>x.id===T.list[T.i+1])||{}).n||'';const a=E('button','btn',last?'🏆 Eindklassement':'▶ Volgend spel: '+nm);a.onclick=()=>NET.tourNext();const l=E('button','btn sec','Stoppen');l.onclick=()=>NET.tourStop();bt.append(a,l)}else bt.append(E('p','hint','De host start het volgende spel'))}
  else if(NET.isHost){const a=E('button','btn','↻ Opnieuw');a.onclick=()=>NET.start(NET.game);const l=E('button','btn sec','Lobby');l.onclick=()=>NET.toLobby();bt.append(a,l)}else bt.append(E('p','hint','De host kan opnieuw starten'));
  if(T&&!r.noDefault){const tt=E('div','',tourTable());o.querySelector('.pbox').append(tt)}
  const x=E('button','pclose','✕');x.title='Sluiten';x.onclick=()=>o.remove();o.querySelector('.pbox').prepend(x);
  st.append(o);const iWon=win?win.id===me:!!(r.scores&&rows[0]&&rows[0].p.id===me&&rows.length>1);if(iWon)confetti(o);else if(win||r.scores)confetti(o,.3)}
function confetti(host,amount=1){const c=E('canvas','conf');host.append(c);const w=c.width=host.clientWidth||360,h=c.height=host.clientHeight||400,x=c.getContext('2d');const cols=['#f94144','#f3722c','#f9c74f','#90be6d','#43aa8b','#577590','#ff6ad5'];
  const ps=Array.from({length:Math.round(120*amount)},()=>({x:Math.random()*w,y:-20-Math.random()*h*.5,vx:(Math.random()-.5)*2,vy:2+Math.random()*3,r:4+Math.random()*5,a:Math.random()*6,c:cols[R(cols.length)]}));let t0=performance.now();
  (function f(t){const dt=Math.min(.05,(t-t0)/1000);t0=t;x.clearRect(0,0,w,h);let alive=0;ps.forEach(p=>{p.y+=p.vy*dt*60;p.x+=p.vx+Math.sin(p.y/20);p.a+=dt*4;if(p.y<h+20)alive++;x.save();x.translate(p.x,p.y);x.rotate(p.a);x.fillStyle=p.c;x.fillRect(-p.r/2,-p.r/4,p.r,p.r/2);x.restore()});if(alive&&c.isConnected)requestAnimationFrame(f);else c.remove()})(t0)}
// ---- lobby UI ----
function mpOpen(){home();$('#home').style.display='none';$('#mp').style.display='block';if(NET.state==='off')mpStart();else showLobby();scrollTo(0,0)}
const SITE='https://robertskvar-ux.github.io/spelplaza/';
const NET_OK=()=>typeof RTCPeerConnection!=='undefined'&&typeof WebSocket!=='undefined';
function avatarPicker(prof,onChange){const w=E('div','avp');const g=E('div','avg');AVATARS.forEach(a=>{const b=E('button','av'+(a===prof.av?' on':''),a);b.type='button';b.style.setProperty('--c',prof.col);b.onclick=()=>{prof.av=a;g.querySelectorAll('.av').forEach(x=>x.classList.toggle('on',x.textContent===a));onChange(prof)};g.append(b)});
  const cs=E('div','cols');COLORS.forEach(c=>{const b=E('button','cl'+(c===prof.col?' on':''));b.type='button';b.style.background=c;b.setAttribute('aria-label','kleur');b.onclick=()=>{prof.col=c;cs.querySelectorAll('.cl').forEach(x=>x.classList.toggle('on',x.style.background===b.style.background));g.querySelectorAll('.av').forEach(x=>x.style.setProperty('--c',c));onChange(prof)};cs.append(b)});
  w.append(g,cs);return w}
function profileCard(prof,onChange){const c=E('div','prof');c.innerHTML=`<div class="pav big" style="--c:${prof.col}">${prof.av}</div><div class="pinfo"><label class="fld" style="margin:0">Je naam<input id="mpn" maxlength="16" placeholder="Bijv. Alex"></label><button type="button" class="lnk" id="avtoggle">Personage kiezen ▾</button></div>`;
  c.querySelector('#mpn').value=prof.name;const pick=avatarPicker(prof,p=>{c.querySelector('.pav').textContent=p.av;c.querySelector('.pav').style.setProperty('--c',p.col);onChange(p)});pick.style.display='none';c.append(pick);
  c.querySelector('#avtoggle').onclick=()=>{const o=pick.style.display==='none';pick.style.display=o?'':'none';c.querySelector('#avtoggle').textContent=o?'Klaar ▴':'Personage kiezen ▾'};
  c.querySelector('#mpn').oninput=e=>{prof.name=e.target.value.trim().slice(0,16);onChange(prof)};return c}
function statsCard(){const s=STATS.get();const solo=Object.values(s.played||{}).reduce((a,b)=>a+b,0),mp=Object.values(s.mpPlayed||{}).reduce((a,b)=>a+b,0),won=Object.values(s.mpWon||{}).reduce((a,b)=>a+b,0);
  if(!solo&&!mp)return null;const best=[];G.forEach(g=>{const b=+(LS('sp_'+g.id)||0);if(b>0)best.push([g,b])});best.sort((a,b)=>b[1]-a[1]);
  const c=E('div','mpc stats',`<h3>Jouw statistieken</h3><div class="srow"><div><b>${solo}</b><small>solo gespeeld</small></div><div><b>${mp}</b><small>online gespeeld</small></div><div><b>${won}</b><small>online gewonnen</small></div></div>${best.length?'<p class="hint" style="margin-top:10px">Beste scores: '+best.slice(0,5).map(([g,b])=>g.e+' '+esc(g.n)+' '+b).join(' · ')+'</p>':''}`);return c}
function mpStart(){const b=$('#mpb');b.innerHTML='';const prof=PROFILE.get();
  if(!NET_OK()){b.append(E('div','mpc',`<h2>Samen spelen</h2><p class="hint" style="font-size:14px;line-height:1.5">In deze omgeving (de ingebouwde Claude-weergave) zijn rechtstreekse verbindingen tussen browsers geblokkeerd, dus een kamer maken lukt hier niet.</p><p class="hint" style="font-size:14px;line-height:1.5">Open SpelPlaza via de website — daar werkt samen spelen op elke telefoon en computer, zonder account. Solo-spellen werken hier gewoon.</p><div class="mpr"><a class="btn" href="${SITE}" target="_blank" rel="noopener" style="text-decoration:none;text-align:center">Open de website ↗</a></div><p class="hint" style="margin-top:10px">${SITE.replace('https://','')}</p>`));
    const bk=E('button','btn sec','‹ Terug naar de spellen');bk.onclick=home;b.append(bk);return}
  const card=E('div','mpc',`<h2>Samen spelen</h2><p class="hint">Eén speler maakt een kamer en deelt de code. De anderen voeren de code in. De host kiest daarna het spel.</p>`);
  card.append(profileCard(prof,p=>PROFILE.set(p)));
  card.append(E('div','mpr','<button class="btn" id="mkh">Kamer maken</button>'),E('div','mpr','<input id="mpc" maxlength="12" inputmode="text" placeholder="Code" autocapitalize="characters" autocomplete="off"><button class="btn sec" id="mkj">Meedoen</button>'),E('p','hint',''));card.lastChild.id='mps';
  b.append(card);const sc=statsCard();if(sc)b.append(sc);
  const getProf=()=>{prof.name=($('#mpn').value.trim()||'Speler').slice(0,16);PROFILE.set(prof);return prof};
  $('#mkh').onclick=()=>NET.host(getProf());
  $('#mkj').onclick=()=>{const c=$('#mpc').value.trim();if(c.length<5){$('#mps').textContent='Vul de code van 5 tekens in.';return}NET.join(c,getProf())};
  $('#mpc').onkeydown=e=>{if(e.key==='Enter')$('#mkj').click()};$('#mpc').oninput=e=>{const v=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,5);if(v!==e.target.value)e.target.value=v};
  const u=new URL(location.href).searchParams.get('kamer');if(u){$('#mpc').value=u.toUpperCase()}
}
NET.onStatus((s,msg)=>{rxBar();if(s==='connecting'){const el=$('#mps');if(el)el.textContent=msg;const h=$('#mkh'),j=$('#mkj');if(h)h.disabled=true;if(j)j.disabled=true}
  else if(s==='error'){if($('#mp').style.display!=='block')mpOpen();mpStart();$('#mps').textContent='⚠️ '+msg;NET.leave()}
  else if(s==='lobby')showLobby()});
NET.onPlayers(()=>{if($('#mp').style.display==='block'&&NET.state==='lobby'&&!NET.game)showLobby();const pl=$('#mpl');if(pl)pl.textContent=NET.players.length+' speler'+(NET.players.length==1?'':'s')});
function shareLink(){const u=new URL(location.href);u.search='?kamer='+NET.code;return u.href}
const chip=p=>`<li style="--c:${p.col}"${p.bot?` data-bot="${esc(p.id)}"`:''}><span class="pav s" style="--c:${p.col}">${p.av||'🙂'}</span>${esc(p.name)}${p.host?' 👑':''}${p.id===NET.me.id?' <span class="mu">(jij)</span>':''}</li>`;
function showLobby(){$('#home').style.display='none';$('#play').style.display='none';$('#stage').innerHTML='';stop();stop=()=>{};cur=null;$('#mp').style.display='block';const b=$('#mpb');b.innerHTML='';rxBar();
  const n=NET.players.length;
  const top=E('div','mpc',`<div class="code"><small>Kamercode</small><b>${NET.code}</b><div class="mpr"><button class="btn sec" id="cpc">Code kopiëren</button>${location.protocol==='file:'?'':'<button class="btn sec" id="cpl">Link delen</button>'}</div></div><p class="hint">Deel de code${location.protocol==='file:'?'':' of de link'} met je vrienden. Zij tikken bovenaan op <strong>👥 Samen spelen</strong> en voeren de code in.</p>
   <h3>Spelers <span class="mu" id="mpl">${n} speler${n==1?'':'s'}</span></h3><ul class="pl">${NET.players.map(chip).join('')}</ul>`);
  b.append(top);
  $('#cpc').onclick=()=>{try{navigator.clipboard&&navigator.clipboard.writeText(NET.code)}catch(e){}$('#cpc').textContent='Gekopieerd ✓'};
  if($('#cpl'))$('#cpl').onclick=async()=>{const url=shareLink();if(navigator.share){try{await navigator.share({title:'SpelPlaza',text:'Doe mee in kamer '+NET.code,url})}catch(e){}}else{try{navigator.clipboard&&navigator.clipboard.writeText(url)}catch(e){}$('#cpl').textContent='Link gekopieerd ✓'}};
  // bots (host)
  if(NET.isHost){const bb=E('div','mpr');const ab=E('button','btn sec','🤖 Bot toevoegen');ab.disabled=n>=8;ab.onclick=()=>NET.addBot();bb.append(ab);if(NET.bots().length){const rb=E('button','btn sec','Bots weg');rb.onclick=()=>NET.bots().forEach(x=>NET.removeBot(x.id));bb.append(rb)}top.append(bb);
    top.querySelectorAll('.pl li[data-bot]').forEach(li=>{const x=E('button','pbx','✕');x.title='Bot verwijderen';x.onclick=()=>NET.removeBot(li.dataset.bot);li.append(x)})}
  const hasBots=NET.bots().length>0;
  const fits=m=>n>=m.min&&n<=m.max&&(!hasBots||m.bots);
  const why=m=>hasBots&&!m.bots?'geen bots':n<m.min?'min. '+m.min:n>m.max?'max. '+m.max:'';
  if(NET.tour&&!NET.tour.done)b.append(E('div','mpc',tourTable()+(NET.isHost?'<div class="mpr"><button class="btn" id="tnx">▶ Verder met toernooi</button><button class="btn sec" id="tst">Toernooi stoppen</button></div>':'')));
  if($('#tnx')){$('#tnx').onclick=()=>NET.start(NET.tour.list[NET.tour.i]);$('#tst').onclick=()=>NET.tourStop()}
  // suggestions summary
  const sugCount={};Object.entries(NET.sug||{}).forEach(([pid,g])=>{if(NET.players.some(p=>p.id===pid))(sugCount[g]=sugCount[g]||[]).push(pid)});
  const sugList=Object.entries(sugCount).sort((a,b)=>b[1].length-a[1].length);
  const want=NET.isHost&&NET.want&&MP.find(x=>x.id===NET.want);
  if(NET.isHost&&(sugList.length||want)){const s=E('div','mpc sugb','<h3>💡 Voorstellen</h3>');
    if(want&&fits(want)){const r=E('div','sugr',`<span>${want.e} <b>${esc(want.n)}</b> <span class="mu">— jouw keuze</span></span>`);const go=E('button','btn','▶ Start');go.onclick=()=>NET.start(want.id);r.append(go);s.append(r)}
    sugList.forEach(([g,ids])=>{const m=MP.find(x=>x.id===g);if(!m)return;const r=E('div','sugr',`<span>${m.e} <b>${esc(m.n)}</b> ${ids.map(id=>{const p=NET.players.find(x=>x.id===id);return p?`<span class="pav s" style="--c:${p.col}" title="${esc(p.name)}">${p.av}</span>`:''}).join('')}</span>`);if(fits(m)){const go=E('button','btn','▶ Start');go.onclick=()=>NET.start(m.id);r.append(go)}else r.append(E('span','mu',why(m)));s.append(r)});b.append(s)}
  const s=E('div','mpc',NET.isHost?'<div class="trow"><h3>Kies een spel</h3><button class="btn sec" id="tour">🏆 Toernooi</button></div><p class="hint">Tik op een spel om te starten. Uitgegrijsd = past niet bij het aantal spelers'+(hasBots?' of speelt niet met bots':'')+'.</p>':'<h3>Stel een spel voor</h3><p class="hint">Tik op een spel om het voor te stellen aan de host (nog eens tikken = intrekken).</p>');const g=E('div','grid');
  MP.forEach(m=>{const ok=fits(m);const d=card(m,true);d.classList.toggle('dis',!ok&&NET.isHost);d.querySelector('small').textContent=(m.min===m.max?m.min+' spelers':m.min+'–'+m.max+' spelers')+(m.bots?' · 🤖':'')+(!ok&&why(m)?' · '+why(m):'');
    const sg=sugCount[m.id];if(sg){const bd=E('span','sgb','💡 '+sg.length);d.append(bd)}if(!NET.isHost&&NET.sug[NET.me.id]===m.id)d.classList.add('picked');
    if(NET.isHost)d.onclick=ok?()=>NET.start(m.id):null;else d.onclick=()=>NET.suggest(m.id);g.append(d)});s.append(g);b.append(s);
  if($('#tour'))$('#tour').onclick=()=>tourPicker();
  if(!NET.isHost&&NET.want&&!NET.sug[NET.me.id]){const w=NET.want;NET.want=null;NET.suggest(w);return}
  const lv=E('button','btn sec','Kamer verlaten');lv.style.marginTop='16px';lv.onclick=()=>{NET.leave();mpStart()};b.append(lv)}
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function tourPicker(){const b=$('#mpb');b.innerHTML='';const n=NET.players.length,hasBots=NET.bots().length>0;const sel=[];
  const c=E('div','mpc','<h2>🏆 Toernooi</h2><p class="hint">Kies tot 5 spellen in de volgorde waarin jullie ze spelen. Na elk spel krijgt iedereen punten volgens zijn plaats; na het laatste spel volgt het eindklassement.</p><p class="tsel" id="tsel"></p><div class="mpr"><button class="btn" id="tgo" disabled>▶ Start toernooi</button><button class="btn sec" id="tbk">Annuleren</button></div>');
  const g=E('div','grid');const upd=()=>{$('#tsel').innerHTML=sel.length?sel.map((id,i)=>{const m=MP.find(x=>x.id===id);return `<span class="tchip">${i+1}. ${m.e} ${esc(m.n)}</span>`}).join(''):'<span class="mu">Nog geen spellen gekozen</span>';$('#tgo').disabled=!sel.length;g.querySelectorAll('.card').forEach(d=>{const i=sel.indexOf(d.dataset.id);d.classList.toggle('picked',i>=0);const bd=d.querySelector('.sgb');if(bd)bd.remove();if(i>=0)d.append(E('span','sgb',String(i+1)))})};
  MP.forEach(m=>{const ok=n>=m.min&&n<=m.max&&(!hasBots||m.bots);const d=card(m,true);d.dataset.id=m.id;d.classList.toggle('dis',!ok);d.querySelector('small').textContent=m.min===m.max?m.min+' spelers':m.min+'–'+m.max+' spelers';d.onclick=ok?()=>{const i=sel.indexOf(m.id);if(i>=0)sel.splice(i,1);else if(sel.length<5)sel.push(m.id);upd()}:null;g.append(d)});
  c.append(g);b.append(c);upd();$('#tgo').onclick=()=>NET.tourStart(sel);$('#tbk').onclick=()=>showLobby();
  const rnd=E('button','lnk','🎲 Kies 5 willekeurige spellen');rnd.onclick=()=>{const pool=MP.filter(m=>n>=m.min&&n<=m.max&&(!hasBots||m.bots)).map(m=>m.id);sel.length=0;while(sel.length<Math.min(5,pool.length)){const x=pool[R(pool.length)];if(!sel.includes(x))sel.push(x)}upd()};c.insertBefore(rnd,g)}
// ---- solo or online chooser for games that exist in both ----
const BOTH={blokkenland:'blokkenland',chess:'chess',connect4:'connect4',checkers:'checkers',othello:'othello',battleship:'battleship',ttt:'ttt',dots:'dots',yahtzee:'yahtzee',pong:'pong',sudoku:'sudoku',mines:'mines',woordzoeker:'woordzoeker',quiz:'quiz',snake:'snakeduel'};
const AI_SOLO=['chess','connect4','checkers','othello','battleship','ttt','dots','pong'];
function pickMode(g){const mid=BOTH[g.id];const m=mid&&MP.find(x=>x.id===mid);if(!m)return launch(g);
  const o=E('div','modeov');o.innerHTML=`<div class="modebox"><button class="pclose" aria-label="Sluiten">✕</button><div class="mth" style="--c:${g.g.split(',')[0]}">${g.e}</div><h3></h3><p class="hint">Hoe wil je spelen?</p><button class="modeb" id="mb1"><span>${AI_SOLO.includes(g.id)?'🤖':'🙂'}</span><b>${AI_SOLO.includes(g.id)?'Tegen de computer':'Alleen spelen'}</b><small>${AI_SOLO.includes(g.id)?'Direct starten, op dit toestel':'Direct starten, op dit toestel'}</small></button><button class="modeb" id="mb2"><span>👥</span><b>Met vrienden online</b><small>${m.min===m.max?m.min+' spelers':m.min+'–'+m.max+' spelers'} · kamer met code${m.bots?' · bots mogelijk':''}</small></button></div>`;
  o.querySelector('h3').textContent=g.n;const close=()=>o.remove();o.onclick=e=>{if(e.target===o)close()};o.querySelector('.pclose').onclick=close;
  o.querySelector('#mb1').onclick=()=>{close();launch(g)};o.querySelector('#mb2').onclick=()=>{close();NET.want=m.id;mpOpen()};document.body.append(o);o.querySelector('#mb1').focus()}
function launchMP(id,late){const m=MP.find(x=>x.id===id);if(!m)return;stop();stop=()=>{};$('#stage').innerHTML='';$('#home').style.display='none';$('#mp').style.display='none';$('#play').style.display='block';
  $('#pt').textContent=m.e+' '+m.n;$('#bar .bk').textContent='‹ Lobby';$('#bar .bk').onclick=()=>NET.toLobby();$('#bar .rs').style.display=NET.isHost&&m.restart!==false?'':'none';$('#bar .rs').onclick=()=>NET.start(id);if(NET.tour&&!NET.tour.done)$('#bar .rs').style.display='none';$('#stage').style.minHeight='';
  if(!late)STATS.bump('mpPlayed',id);rxBar();
  cur={g:m,mp:true};const st=$('#stage');stop=m.run(st,NET)||(()=>{});scrollTo(0,0)}
