{id:'mines',n:'Mijnenveger samen',e:'💣',c:'Samen',g:'#434343,#6c5ce7',min:2,max:4,bots:true,run(st,net){
 // Coöp mijnenveger 16×16 / 40 mijnen. Host is de baas (patroon A): mijnen uit de seed, eerste klik altijd veilig (host verplaatst mijnen), iedereen graaft/vlagt.
 // Kleuren: elke speler krijgt zijn profielkleur (net.players[i].col), vastgelegd in S.P bij registratie zodat de stipjes hun kleur houden
 // als iemand vertrekt. w[i] = stoelnummer (S.P[id].c) van wie het vakje opende.
 const N=16,M=40,NC=['','#3b82f6','#16a34a','#e5484d','#7c3aed','#b45309','#0891b2','var(--tx)','#6b7280'];
 const rnd=net.rng(),R=n=>Math.floor(rnd()*n),fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
 const NB=[];for(let i=0;i<N*N;i++){const a=[],x=i%N,y=(i/N)|0;for(let dy=-1;dy<2;dy++)for(let dx=-1;dx<2;dx++){const X=x+dx,Y=y+dy;if((dx||dy)&&X>=0&&X<N&&Y>=0&&Y<N)a.push(Y*N+X)}NB.push(a)}
 // ---------- DOM ----------
 const sc=E('div','sc'),pan=E('div'),info=E('div','hint');pan.style.cssText='display:flex;gap:4px;flex-wrap:wrap;justify-content:center;margin:2px 0 4px;max-width:100%';info.style.cssText='min-height:18px;margin:0 0 4px';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(392px,100%);margin:4px auto';
 const bd=E('div','bdr');bd.style.cssText+=`grid-template-columns:repeat(${N},minmax(0,1fr));gap:1px;width:100%;margin:0;touch-action:none`;
 wrap.append(bd);
 const row=E('div');row.style.cssText='display:flex;gap:8px;justify-content:center;margin:8px 0 0';const modeb=E('button','btn');row.append(modeb);
 st.append(sc,pan,info,wrap,row,E('div','hint','Tik = graven · lang drukken / rechtsklik / vlag-modus = 🚩 · tik op een cijfer met genoeg vlaggen = buren openen · F wisselt modus'));
 const cells=[],dots=[];for(let i=0;i<N*N;i++){const d=E('div');d.style.cssText='position:relative;font-size:12px;font-weight:800;border-radius:3px;background:#8b86d8;line-height:1;overflow:hidden';
  const o=E('i');o.style.cssText='position:absolute;top:1px;right:1px;width:5px;height:5px;border-radius:50%;display:none';d.append(o);dots.push(o);cells.push(d);bd.append(d);
  let tmr=null,long=0;
  d.onpointerdown=e=>{e.preventDefault();long=0;clearTimeout(tmr);if(e.button===2||e.pointerType==='mouse'&&e.buttons===2){act({k:'flag',i});long=1;return}tmr=setTimeout(()=>{long=1;act({k:'flag',i});beep(330,.05,'sine',.03)},420)};
  d.onpointerup=e=>{clearTimeout(tmr);if(long)return;act({k:flag?'flag':'dig',i})};d.onpointerleave=d.onpointercancel=()=>clearTimeout(tmr);d.oncontextmenu=e=>e.preventDefault()}
 // ---------- toestand ----------
 let flag=0;const setMode=f=>{flag=f;modeb.textContent=flag?'🚩 Vlag-modus':'🔨 Graaf-modus';modeb.style.background=flag?'#e5484d':''};modeb.onclick=()=>setMode(!flag);setMode(0);
 const me=net.me.id,S={P:{},left:N*N-M,over:0,hit:null,started:0,flags:0},mine=new Uint8Array(N*N),op=new Uint8Array(N*N),fl=new Uint8Array(N*N),w=new Int8Array(N*N).fill(-1);
 let V={o:[],w:[],m:null},t0=0,tm,gone={},podDone=0;
 const reg=(q,c)=>({n:q.name,c,av:q.av||'🙂',col:q.col||net.pcol(q),ok:0});
 net.players.forEach((q,k)=>{S.P[q.id]=reg(q,k%4)});
 const seatCol=()=>{const m={};for(const id in S.P)m[S.P[id].c]=S.P[id].col;return m};
 {let k=0;while(k<M){const i=R(N*N);if(!mine[i]){mine[i]=1;k++}}}
 const nOf=i=>NB[i].reduce((a,j)=>a+mine[j],0),secs=()=>S.over?S.won:S.started?Math.floor((performance.now()-t0)/1000):0;
 const pack=()=>({k:'s',o:Array.from(op,(v,i)=>fl[i]?'F':v?String(nOf(i)):'.').join(''),w:Array.from(w,x=>x<0?'.':x).join(''),P:S.P,left:S.left,over:S.over,won:S.won,hit:S.hit,started:S.started,flags:S.flags,m:S.over===1?Array.from(mine).join(''):null,el:S.started?(performance.now()-t0)/1000:0});
 function unpack(d){V={o:[...d.o],w:[...d.w].map(x=>x==='.'?-1:+x),m:d.m?[...d.m].map(Number):null};S.P=d.P;S.left=d.left;S.over=d.over;S.won=d.won;S.hit=d.hit;S.flags=d.flags;if(d.started&&!S.started)t0=performance.now()-d.el*1000;S.started=d.started;draw()}
 function act(d){if(net.isHost)apply(d,me);else net.send(d)}
 function dig(i,id){if(op[i]||fl[i])return;const stk=[i];while(stk.length){const j=stk.pop();if(op[j]||fl[j])continue;op[j]=1;w[j]=S.P[id].c;S.P[id].ok++;S.left--;if(!nOf(j))for(const q of NB[j])if(!op[q])stk.push(q)}}
 function apply(d,id){if(!d||typeof d!=='object'||!S.P[id]||S.over)return;const i=d.i|0;if(i<0||i>=N*N)return;
  if(d.k==='flag'){if(op[i])return;fl[i]^=1;S.flags+=fl[i]?1:-1}
  else if(d.k==='dig'){
   if(!S.started){S.started=1;t0=performance.now();const safe=new Set([i,...NB[i]]);for(const j of safe)if(mine[j]){mine[j]=0;let q;do q=Math.floor(Math.random()*N*N);while(mine[q]||safe.has(q));mine[q]=1}}
   if(op[i]){const n=nOf(i);if(!n||NB[i].reduce((a,j)=>a+fl[j],0)!==n)return;for(const j of NB[i])if(!op[j]&&!fl[j]){if(mine[j]){lose(j,id);break}dig(j,id)}}
   else if(fl[i])return;else if(mine[i])lose(i,id);else dig(i,id);
   if(!S.over&&S.left<=0){S.won=Math.max(1,secs());S.over=2;beep(880,.15,'triangle',.05);setTimeout(()=>beep(1100,.25,'triangle',.05),120)}}
  else return;
  unpack(pack());net.send(pack())}
 function lose(i,id){S.won=secs();S.over=1;S.hit={id,i};op[i]=1;beep(120,.4,'sawtooth',.06)}
 // ---------- tekenen ----------
 // naam met avatar uit S.P (blijft kloppen als de speler al weg is), anders via net
 const pn=id=>{const q=S.P[id];return q?(q.av||'🙂')+' '+q.n:net.pname(id)};
 function panel(){pan.replaceChildren();for(const id in S.P){const q=S.P[id],live=net.players.some(x=>x.id===id),on=id===me,ch=E('span');
  ch.style.cssText='display:inline-flex;align-items:center;white-space:nowrap;line-height:1.2;padding:1px 7px 1px 1px;border-radius:99px;font-size:12px;font-weight:'+(on?'700':'600')+';color:var(--tx);border:2px solid '+q.col+';background:'+(on?'color-mix(in srgb,'+q.col+' 18%,var(--bg))':'var(--bg)')+(live?'':';opacity:.45');
  const av=E('span','pav s');av.style.setProperty('--c',q.col);av.style.cssText+=';width:20px;height:20px;font-size:12px;margin:0 4px 0 0';av.textContent=q.av||'🙂';const nm=E('span');nm.style.cssText='max-width:76px;overflow:hidden;text-overflow:ellipsis';nm.textContent=q.n+(on?' (jij)':'');const ok=E('span','','⛏ '+q.ok);ok.style.marginLeft='4px';ch.append(av,nm,ok);pan.append(ch)}}
 function draw(){const PC=seatCol();for(let i=0;i<N*N;i++){const d=cells[i],c=V.o[i]||'.',isM=V.m&&V.m[i],hit=S.hit&&S.hit.i===i;let bg='#8b86d8',tx='',col='var(--tx)';
   if(hit){bg='#e5484d';tx='💥'}else if(isM){bg='#555b73';tx='💣'}else if(c==='F'){tx='🚩'}else if(c!=='.'){bg='var(--bg)';tx=c==='0'?'':c;col=NC[+c]}
   d.style.background=bg;d.style.color=col;if(d.textContent!==tx)d.textContent=tx;if(!d.contains(dots[i]))d.append(dots[i]);
   const o=V.w[i];dots[i].style.display=o>=0&&c!=='.'&&c!=='F'&&!hit?'':'none';if(o>=0)dots[i].style.background=PC[o]||'var(--mu)'}
  sc.textContent=S.over===1?'💥 Boem! · ⏱ '+fmt(S.won)+' · '+S.left+' vakjes te gaan':S.over===2?'🎉 Veld geveegd · ⏱ '+fmt(S.won):'💣 '+(M-S.flags)+' over · ⏱ '+fmt(secs())+' · '+S.left+' vakjes te gaan';panel();
  // einde: gedeeld podium (coöp -> geen winnaar, ieders bijdrage = geopende vakjes); bij een mijn wordt de dader genoemd
  if(S.over&&!podDone){podDone=1;const scores={};for(const id in S.P)scores[id]=S.P[id].ok;
   if(S.over===1)net.result({winner:null,scores,unit:' vakjes',title:'💥 Boem!',text:pn(S.hit.id)+' raakte een mijn · na '+fmt(S.won)});
   else net.result({winner:null,scores,unit:' vakjes',title:'Gelukt! 🎉',text:'Veld geveegd in '+fmt(S.won)})}}
 // ---------- net ----------
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;if(net.isHost)apply(d,from);else if(d.k==='s')unpack(d)});
 const offP=net.onPlayers(pl=>{for(const id in S.P)if(!pl.some(x=>x.id===id)&&!gone[id]){gone[id]=1;info.textContent='⚠️ '+pn(id)+' heeft het spel verlaten'}
  if(net.isHost){const used=new Set(Object.values(S.P).map(q=>q.c));let add=0;for(const q of pl)if(!S.P[q.id]){let c=0;while(used.has(c)&&c<4)c++;used.add(c%4);S.P[q.id]=reg(q,c%4);add=1}if(add)net.send(pack())}draw()});
 const inp=input(st,[],k=>{if(k==='f'||k==='F')setMode(!flag)});
 tm=setInterval(()=>{if(!S.over)sc.textContent=sc.textContent.replace(/⏱ [\d:]+/,'⏱ '+fmt(secs()))},500);
 window.__dbg={mines:()=>net.isHost?Array.from(mine):null,view:()=>({o:V.o.join(''),w:V.w.join(',')}),P:()=>JSON.parse(JSON.stringify(S.P)),state:()=>({over:S.over,left:S.left,flags:S.flags,started:S.started,hit:S.hit,won:S.won}),act,setMode};
 // ---------- bots (host): elke 4–8 s één vakje graven. Alleen zichtbare info: cijfers van open vakjes + vlaggen; eenvoudige afleiding
 // (alle verborgen buren zijn mijnen / alle mijnen gevonden → rest veilig) tot er niets meer verandert; geen veilig vakje → willekeurig gokken.
 const bTm={};
 function botPick(){const known=new Uint8Array(N*N);for(let i=0;i<N*N;i++)if(fl[i])known[i]=1;const safe=new Set;let ch=1;
  while(ch){ch=0;for(let i=0;i<N*N;i++){if(!op[i])continue;const n=nOf(i);if(!n)continue;const hid=NB[i].filter(j=>!op[j]&&!known[j]&&!safe.has(j)),km=NB[i].filter(j=>known[j]).length;
    if(!hid.length)continue;if(km===n){hid.forEach(j=>safe.add(j));ch=1}else if(km+hid.length===n){hid.forEach(j=>known[j]=1);ch=1}}}
  const sf=[...safe].filter(j=>!op[j]&&!fl[j]);if(sf.length)return sf[Math.floor(Math.random()*sf.length)];
  const rest=[];for(let i=0;i<N*N;i++)if(!op[i]&&!fl[i]&&!known[i])rest.push(i);if(rest.length)return rest[Math.floor(Math.random()*rest.length)];
  const fs=[];for(let i=0;i<N*N;i++)if(fl[i])fs.push(i);return fs.length?-2-fs[Math.floor(Math.random()*fs.length)]:-1}// niets meer te doen: een (verdachte) vlag weghalen
 function botGo(id){clearTimeout(bTm[id]);bTm[id]=setTimeout(()=>{if(S.over||!net.isBot(id))return;const i=botPick();if(i>=0)net.botAct(id,{k:'dig',i});else if(i<=-2)net.botAct(id,{k:'flag',i:-2-i});botGo(id)},(4000+Math.random()*4000)*(window.__botT>0?window.__botT:1))}
 if(net.isHost)net.bots().forEach(b=>botGo(b.id));
 unpack(pack());return()=>{for(const id in bTm)clearTimeout(bTm[id]);clearInterval(tm);inp.stop();off();offP();delete window.__dbg}}},
