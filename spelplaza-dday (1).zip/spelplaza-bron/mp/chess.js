{id:'chess',n:'Schaken',e:'♟️',c:'Samen',g:'#434343,#000000',min:2,max:2,bots:true,run(st,net){
 // Schaken voor 2 spelers: host = wit (begint), joiner = zwart (bord gespiegeld). Volledige regels: rokade, en passant, promotie (keuze), schaak, mat, pat, 50 zetten, driemaal dezelfde stelling. Opgeven kan. Spelerchips (avatar + kleur) in de statusregel, podium aan het einde.
 const me=net.myIndex(),W=me===0,MY=W?'w':'b',FLIP=!W,D2B=d=>FLIP?63-d:d;
 let opp=null;const P=t=>net.players[t==='w'?0:1]||(t===MY?net.me:opp),nm=t=>{const p=P(t);return p?net.pname(p):'…'},cl=t=>{const p=P(t);return p&&p.col||'#888'},pid=t=>{const p=P(t);return p?p.id:null},SYM=t=>t==='w'?'♔':'♚';
 const tint=(h,a)=>{const v=[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0);return'rgba('+v.join(',')+','+a+')'};
 const sc=E('div','sc'),who=E('div','hint');who.style.cssText='min-height:26px;line-height:2;font-weight:600;color:var(--tx);margin:0 auto';
 const info=E('div','hint');info.style.cssText='min-height:22px;margin:2px auto;display:flex;gap:6px;justify-content:center;align-items:center;flex-wrap:wrap';
 const capTop=E('div','hint'),capBot=E('div','hint');for(const c of[capTop,capBot])c.style.cssText='min-height:20px;font-size:16px;margin:4px auto;color:var(--tx)';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(380px,100%);margin:0 auto';
 const bd=E('div','bdr');bd.style.cssText+='grid-template-columns:repeat(8,1fr);width:100%;gap:0;border-radius:8px;overflow:hidden;box-shadow:0 4px 14px rgba(0,0,0,.35);font-size:min(36px,9vw);margin:0';
 const ov=E('div','ov');ov.style.display='none';wrap.append(bd,ov);
 const bar=E('div');bar.style.cssText='display:flex;gap:10px;justify-content:center;align-items:center;margin:8px 0 0;flex-wrap:wrap';
 const bRes=E('button','btn sec','🏳️ Opgeven');bar.append(bRes);
 const list=E('div','hint');list.style.cssText='max-height:48px;overflow:auto;font-size:12px;line-height:1.5;margin:6px auto 0;text-align:left;font-family:ui-monospace,monospace';
 const hint=E('div','hint','Tik op een stuk en dan op een doelvak');
 st.append(sc,who,info,capTop,wrap,capBot,bar,list,hint);
 // ---------- spelerchips ----------
 function chip(t,on){const k=cl(t),c=E('span');c.style.cssText='display:inline-flex;align-items:center;gap:5px;padding:1px 9px;border-radius:99px;border:1.5px solid '+k+';background:'+tint(k,.14)+';white-space:nowrap;vertical-align:middle;line-height:1.5;'+(on===1?'box-shadow:0 0 0 3px '+tint(k,.3)+';font-weight:800':on===-1?'opacity:.55':'');
  c.append(document.createTextNode(SYM(t)+' '+nm(t)+(t===MY?' (jij)':'')));return c}
 function setWho(t,msg){who.replaceChildren();['w','b'].forEach((x,i)=>{if(i)who.append(document.createTextNode(' · '));who.append(chip(x,t?(t===x?1:-1):0));if(t===x)who.append(document.createTextNode(x===MY?' bent aan zet':' is aan zet'))});if(msg)who.append(document.createTextNode(' · '+msg))}
 const GL={k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'},FILES='abcdefgh';
 const sq=[];for(let d=0;d<64;d++){const el=E('div');el.style.position='relative';el.style.lineHeight='1';const pc=E('span');pc.style.fontFamily="'Segoe UI Symbol','Apple Symbols','Noto Sans Symbols2','DejaVu Sans',sans-serif";pc.style.pointerEvents='none';el.append(pc);
  const i=D2B(d),r=i>>3,c=i&7,light=(r+c)%2===0;
  const lbl=(txt,pos)=>{const lb=E('span','',txt);lb.style.cssText='position:absolute;font-size:10px;font-weight:800;pointer-events:none;color:'+(light?'#6e4a2a':'#2b1a0c')+pos;el.append(lb)};
  if(d%8===0)lbl(8-r,';top:1px;left:2px');if(d>=56)lbl(FILES[c],';bottom:1px;right:2px');
  el.onpointerdown=e=>{e.preventDefault();tap(i)};sq.push(el);bd.append(el)}
 // ---------- regels ----------
 const KN=[[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]],KG=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]],BD=[[-1,-1],[-1,1],[1,-1],[1,1]],RD=[[-1,0],[1,0],[0,-1],[0,1]];
 const isB=p=>p>='a',inb=(r,c)=>r>=0&&r<8&&c>=0&&c<8;
 function start(){const b=Array(64).fill('');'rnbqkbnr'.split('').forEach((p,i)=>{b[i]=p;b[8+i]='p';b[48+i]='P';b[56+i]=p.toUpperCase()});return{b,t:'w',cr:'KQkq',ep:-1,hm:0,fm:1}}
 function attacked(b,i,byW){const r=i>>3,c=i&7,pr=byW?r+1:r-1,pp=byW?'P':'p';
  if(pr>=0&&pr<8){if(c>0&&b[pr*8+c-1]===pp)return 1;if(c<7&&b[pr*8+c+1]===pp)return 1}
  const kn=byW?'N':'n',kg=byW?'K':'k',bi=byW?'B':'b',ro=byW?'R':'r',qu=byW?'Q':'q';
  for(const[dr,dc]of KN){const R=r+dr,C=c+dc;if(inb(R,C)&&b[R*8+C]===kn)return 1}
  for(const[dr,dc]of KG){const R=r+dr,C=c+dc;if(inb(R,C)&&b[R*8+C]===kg)return 1}
  for(const[dr,dc]of BD){let R=r+dr,C=c+dc;while(inb(R,C)){const q=b[R*8+C];if(q){if(q===bi||q===qu)return 1;break}R+=dr;C+=dc}}
  for(const[dr,dc]of RD){let R=r+dr,C=c+dc;while(inb(R,C)){const q=b[R*8+C];if(q){if(q===ro||q===qu)return 1;break}R+=dr;C+=dc}}
  return 0}
 const kingSq=(b,t)=>b.indexOf(t==='w'?'K':'k');
 const inCheck=s=>attacked(s.b,kingSq(s.b,s.t),s.t!=='w');
 function gen(s){const b=s.b,w=s.t==='w',m=[],mine=q=>q&&isB(q)!==w,enemy=q=>q&&isB(q)===w;
  for(let i=0;i<64;i++){const p=b[i];if(!mine(p))continue;const r=i>>3,c=i&7,P=p.toLowerCase();
   if(P==='p'){const d=w?-8:8,sr=w?6:1,pr=w?0:7,t=i+d;
    if(!b[t]){if((t>>3)===pr)m.push({f:i,t,p:'q'});else{m.push({f:i,t});if(r===sr&&!b[t+d])m.push({f:i,t:t+d})}}
    for(const dc of[-1,1]){const C=c+dc;if(C<0||C>7)continue;const tt=t+dc;if(enemy(b[tt]))m.push({f:i,t:tt,p:(tt>>3)===pr?'q':0});else if(tt===s.ep)m.push({f:i,t:tt,e:1})}}
   else if(P==='n'||P==='k'){for(const[dr,dc]of(P==='n'?KN:KG)){const R=r+dr,C=c+dc;if(!inb(R,C))continue;const t=R*8+C;if(mine(b[t]))continue;m.push({f:i,t})}
    if(P==='k'){const cr=s.cr;
     if(w&&i===60){if(cr.includes('K')&&!b[61]&&!b[62]&&!attacked(b,60,0)&&!attacked(b,61,0)&&!attacked(b,62,0))m.push({f:60,t:62,c:1});if(cr.includes('Q')&&!b[59]&&!b[58]&&!b[57]&&!attacked(b,60,0)&&!attacked(b,59,0)&&!attacked(b,58,0))m.push({f:60,t:58,c:1})}
     if(!w&&i===4){if(cr.includes('k')&&!b[5]&&!b[6]&&!attacked(b,4,1)&&!attacked(b,5,1)&&!attacked(b,6,1))m.push({f:4,t:6,c:1});if(cr.includes('q')&&!b[3]&&!b[2]&&!b[1]&&!attacked(b,4,1)&&!attacked(b,3,1)&&!attacked(b,2,1))m.push({f:4,t:2,c:1})}}}
   else{const ds=P==='b'?BD:P==='r'?RD:KG;for(const[dr,dc]of ds){let R=r+dr,C=c+dc;while(inb(R,C)){const t=R*8+C,q=b[t];if(q){if(enemy(q))m.push({f:i,t});break}m.push({f:i,t});R+=dr;C+=dc}}}}
  return m}
 function make(s,m){const b=s.b.slice(),p=b[m.f],w=s.t==='w',cap=b[m.t];let cr=s.cr,ep=-1,hm=s.hm+1;
  b[m.t]=m.p?(w?m.p.toUpperCase():m.p):p;b[m.f]='';
  if(p==='P'||p==='p'){hm=0;if(m.e)b[m.t+(w?8:-8)]='';if(Math.abs(m.t-m.f)===16)ep=(m.f+m.t)/2}
  if(cap)hm=0;
  if(m.c){if(m.t===62){b[61]='R';b[63]=''}else if(m.t===58){b[59]='R';b[56]=''}else if(m.t===6){b[5]='r';b[7]=''}else{b[3]='r';b[0]=''}}
  if(p==='K')cr=cr.replace(/[KQ]/g,'');else if(p==='k')cr=cr.replace(/[kq]/g,'');
  if(cr){for(const i of[m.f,m.t]){if(i===63)cr=cr.replace('K','');else if(i===56)cr=cr.replace('Q','');else if(i===7)cr=cr.replace('k','');else if(i===0)cr=cr.replace('q','')}}
  return{b,t:w?'b':'w',cr,ep,hm,fm:s.fm+(w?0:1)}}
 const legalAfter=(s,ns)=>!attacked(ns.b,kingSq(ns.b,s.t),ns.t==='w');
 function legal(s){return gen(s).filter(m=>legalAfter(s,make(s,m)))}
 const PV={p:1,n:3,b:3,r:5,q:9,k:0};
 // ---------- toestand ----------
 let s,sel,tg,last,over,chk,capW,capB,rep,moves,pend,gone=0,shown=0;
 const key=s=>s.b.map(p=>p||'.').join('')+s.t+s.cr+s.ep;
 function insufficient(b){let minors=[0,0];for(const p of b){if(!p)continue;const P=p.toLowerCase();if(P==='p'||P==='r'||P==='q')return 0;if(P==='n'||P==='b')minors[isB(p)?1:0]++}return minors[0]<=1&&minors[1]<=1}
 function showOv(big,small){ov.replaceChildren();const x=E('div');x.textContent=big;const sm=E('div');sm.style.cssText='font-size:15px;font-weight:600';sm.textContent=small||'';ov.append(x,sm);ov.style.textShadow='0 1px 4px #000';ov.style.display='flex'}
 function refresh(){if(gone)showOv(opp?'⚠️ '+nm(MY==='w'?'b':'w')+' heeft het spel verlaten':'Wachten op speler…',net.isHost?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten');else ov.style.display='none';bRes.style.display=over||gone?'none':'';draw();
  if(over&&!shown){shown=1;net.result({winner:over.w?pid(over.w):null,text:over.why})}botTick()}
 function status(){chk=inCheck(s);over=null;const ms=legal(s);
  if(!ms.length)over=chk?{w:s.t==='w'?'b':'w',why:'Schaakmat'}:{w:'',why:'Pat'};
  else if(s.hm>=100)over={w:'',why:'50 zetten zonder slag of pionzet'};
  else if(insufficient(s.b))over={w:'',why:'Te weinig materiaal'};
  else if((rep.get(key(s))||0)>=3)over={w:'',why:'Driemaal dezelfde stelling'};
  if(over)beep(over.w===MY?880:over.w?160:330,.35,over.w===MY?'triangle':'sawtooth',.05);else if(chk)beep(990,.1,'square',.04)}
 const alg=i=>FILES[i&7]+(8-(i>>3));
 function apply(m){const cap=s.b[m.t]||(m.e?(s.t==='w'?'p':'P'):'');if(cap)(isB(cap)?capB:capW).push(cap);
  const txt=(s.t==='w'?s.fm+'. ':'')+(m.c?(m.t>m.f?'O-O':'O-O-O'):(s.b[m.f].toLowerCase()==='p'?'':GL[s.b[m.f].toLowerCase()])+alg(m.f)+(cap?'x':'-')+alg(m.t)+(m.p?'='+GL[m.p]:''));
  s=make(s,m);last=m;sel=-1;tg=new Set;pend=null;info.replaceChildren();const k=key(s);rep.set(k,(rep.get(k)||0)+1);moves.push(txt);beep(cap?300:520,.05,'square',.03)}
 function mat(l){return l.reduce((a,p)=>a+PV[p.toLowerCase()],0)}
 function capLine(el,t,caps,diff){el.replaceChildren();const a=E('span');a.textContent=(t==='w'?'♔ ':'♚ ')+nm(t)+(t===MY?' (jij)':'')+' · geslagen: ';a.style.color='var(--mu)';const b=E('span');b.textContent=caps.map(p=>GL[p.toLowerCase()]).join('')||'–';el.append(a,b);if(diff>0){el.append(E('b','',' +'+diff))}}
 function draw(){
  for(let d=0;d<64;d++){const i=D2B(d),el=sq[d],p=s.b[i],light=((i>>3)+(i&7))%2===0;let bg=light?'#f0d9b5':'#b58863';
   if(last&&(i===last.f||i===last.t))bg=light?'#cdd26a':'#aaa23a';if(i===sel)bg=light?'#f6f669':'#baca2b';el.style.backgroundColor=bg;
   let img='none';if(chk&&p===(s.t==='w'?'K':'k'))img='radial-gradient(circle,#ff2d2d 0 16%,rgba(255,40,40,.6) 42%,transparent 70%)';
   else if(tg.has(i))img=p?'radial-gradient(circle,transparent 0 56%,rgba(0,0,0,.3) 58%)':'radial-gradient(circle,rgba(0,0,0,.3) 0 21%,transparent 23%)';
   el.style.backgroundImage=img;const pc=el.firstChild;pc.textContent=p?GL[p.toLowerCase()]:'';
   if(p){const w=!isB(p);pc.style.color=w?'#fff':'#1a1a20';pc.style.webkitTextStroke=w?'1px #222':'0.5px #000';pc.style.textShadow=w?'0 2px 3px rgba(0,0,0,.55)':'0 0 3px rgba(255,255,255,.35)'}}
  const dw=mat(capB)-mat(capW),topT=FLIP?'w':'b',botT=FLIP?'b':'w';
  capLine(capTop,topT,topT==='w'?capB:capW,topT==='w'?dw:-dw);capLine(capBot,botT,botT==='w'?capB:capW,botT==='w'?dw:-dw);
  sc.textContent='♔ '+nm('w')+(MY==='w'?' (jij)':'')+' tegen '+nm('b')+(MY==='b'?' (jij)':'')+' ♚ · zet '+s.fm+(over?over.w?(over.w===MY?' · 🎉 jij wint':' · 🏆 '+nm(over.w)+' wint')+' · '+over.why:' · 🤝 gelijkspel · '+over.why:'');
  setWho(over?0:s.t,over?'spel voorbij':chk?'Schaak!':'');
  list.textContent=moves.join('  ');list.scrollTop=list.scrollHeight}
 function tap(i){if(gone||over||s.t!==MY||pend)return;const p=s.b[i];
  if(sel>=0&&tg.has(i)){const m=legal(s).find(m=>m.f===sel&&m.t===i);if(m){if(m.p)promo(m);else play(m);return}}
  if(p&&(isB(p)?'b':'w')===MY){sel=i;tg=new Set(legal(s).filter(m=>m.f===i).map(m=>m.t))}else{sel=-1;tg=new Set}draw()}
 function promo(m){pend=m;info.replaceChildren();const l=E('span','','Promoveren tot:');info.append(l);for(const q of'qrbn'){const b=E('button','btn',GL[q]);b.style.cssText='padding:4px 10px;font-size:20px';b.onclick=()=>{m.p=q;play(m)};info.append(b)}}
 function play(m){apply(m);status();refresh();net.send({k:'mv',f:m.f,t:m.t,p:m.p||0})}
 function remote(d){if(over||s.t===MY)return;const m=legal(s).find(m=>m.f===d.f&&m.t===d.t);if(!m)return;if(m.p){if(!'qrbn'.includes(d.p))return;m.p=d.p}apply(m);status();refresh();return true}
 bRes.onclick=()=>{if(over||gone)return;over={w:MY==='w'?'b':'w',why:'Opgegeven · '+nm(MY)+' geeft op'};net.send({k:'resign'});beep(160,.35,'sawtooth',.05);refresh()};
 const pack=()=>({k:'st',s,last,capW,capB,moves,rep:[...rep],over});
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='mv'){const ok=remote(d);botRes(from,ok,d)}
  else if(d.k==='resign'){if(!over){over={w:MY,why:'Opgegeven · '+nm(MY==='w'?'b':'w')+' geeft op'};beep(880,.35,'triangle',.05);refresh()}}
  else if(d.k==='st'&&!net.isHost){s=d.s;last=d.last;capW=d.capW;capB=d.capB;moves=d.moves;rep=new Map(d.rep);sel=-1;tg=new Set;pend=null;shown=0;status();if(d.over&&typeof d.over==='object')over={w:d.over.w==='w'||d.over.w==='b'?d.over.w:'',why:String(d.over.why||'').slice(0,60)};refresh()}});
 function conn(){const o=net.players.find(p=>p.id!==net.me.id);const was=gone;if(o){opp=Object.assign({},o);gone=0;if(net.isHost&&was)net.sendTo(o.id,pack())}else gone=1;refresh()}
 const offP=net.onPlayers(conn);
 // ---------- bot (alleen op de host): 2 ply materiaal (eigen zet + beste antwoord), mat in 1 herkennen, wat ontwikkeling en toeval ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]});let botT=0;
 const botId=()=>{const p=net.isHost&&net.players[1];return p&&p.bot?p.id:null};
 const botRes=(from,ok,d)=>{if(net.isHost&&net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}};
 const matB=(b,t)=>b.reduce((a,p)=>p?a+(isB(p)===(t==='b')?1:-1)*PV[p.toLowerCase()]:a,0);
 function aiMove(){const me_=s.t,ms=legal(s);if(!ms.length)return null;let best=-1e9,bm=ms[0];
  for(const m of ms){const ns=make(s,m),rep=legal(ns);let v;
   if(!rep.length)v=inCheck(ns)?1e4:(matB(ns.b,me_)>0?-500:0);
   else{let worst=1e9;for(const r of rep){const x=make(ns,r);let val=matB(x.b,me_);if(val<worst)worst=val}v=worst*10;
    const P=s.b[m.f].toLowerCase(),tr=m.t>>3,tc=m.t&7;if((P==='n'||P==='b')&&(m.f>>3)===(me_==='w'?7:0))v+=1.5;if(P==='p'&&tc>=2&&tc<=5)v+=.8;if(tr>=2&&tr<=5&&tc>=2&&tc<=5)v+=.6;if(P==='k'&&!m.c&&s.fm<30)v-=2;if(m.c)v+=2;if(inCheck(ns))v+=1;
    if((rep.length&&(rep.length<=3)))v+=.5}
   v+=Math.random()*6;if(v>best){best=v;bm=m}}return bm}
 function botTick(){clearTimeout(botT);botT=0;const id=botId();if(!id||gone||over||s.t!=='b')return;const k=key(s);
  botT=setTimeout(()=>{botT=0;if(gone||over||s.t!=='b'||key(s)!==k||botId()!==id)return;const m=aiMove();if(!m)return;BT.sent++;net.botAct(id,{k:'mv',f:m.f,t:m.t,p:m.p||0})},BT.fast?25+R(40):700+R(900))}
 s=start();sel=-1;tg=new Set;last=null;over=null;chk=0;capW=[];capB=[];rep=new Map;rep.set(key(s),1);moves=[];pend=null;conn();
 const a2i=a=>(7-(a.charCodeAt(1)-49))*8+(a.charCodeAt(0)-97);
 window._chess={legal:()=>legal(s).map(m=>alg(m.f)+alg(m.t)),state:()=>({over,chk,turn:s.t,fm:s.fm,moves:moves.length}),sq:a2i,fen(){let f='';for(let r=0;r<8;r++){let e=0;for(let c=0;c<8;c++){const p=s.b[r*8+c];if(p){if(e){f+=e;e=0}f+=p}else e++}if(e)f+=e;if(r<7)f+='/'}return f+' '+s.t+' '+(s.cr||'-')+' '+(s.ep>=0?alg(s.ep):'-')}};
 return()=>{clearTimeout(botT);off();offP();delete window._chess}}},
