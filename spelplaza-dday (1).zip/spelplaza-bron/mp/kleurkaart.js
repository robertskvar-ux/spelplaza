{id:'kleurkaart',n:'Kleurkaart',e:'🌈',c:'Samen',g:'#ff512f,#2f6fed',min:2,max:6,bots:true,run(st,net){
 // tekstkleur op een effen spelerskleur: zwart of wit, wat het meeste contrast geeft (altijd ≥ 4.5:1)
 const inkOn=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(String(h||'').trim());if(!m)return'#fff';const n=parseInt(m[1],16),L=[n>>16,n>>8&255,n&255].map(v=>{v/=255;return v<=.03928?v/12.92:((v+.055)/1.055)**2.4}),l=.2126*L[0]+.7152*L[1]+.0722*L[2];return (l+.05)/.05>1.05/(l+.05)?'#000':'#fff'};
 // Kleurkaart (host-authoritatief). De host schudt met echte willekeur (niet de gedeelde seed) en stuurt elke speler alleen zijn eigen hand (sendTo).
 // Publieke staat: alleen aantallen kaarten, bovenste kaart, kleur, beurt, richting.
 const isH=net.isHost,me=net.me.id,TURN=30000,DBG=!!window.SPZ_PEER;
 const COL={r:'#e5383b',y:'#f2a900',g:'#21a35a',b:'#2f6fed'},CN={r:'rood',y:'geel',g:'groen',b:'blauw'},CO='rygbw',VO='0123456789sr+2w+4';
 const GL={s:'⊘',r:'⇄','+2':'+2',w:'✦','+4':'+4'},VN={s:'Sla over',r:'Draai om','+2':'+2',w:'Kleurwissel','+4':'+4 Kleurwissel'};
 const pinfo=id=>net.players.find(x=>x.id===id),pn=(id,n)=>{const q=pinfo(id);return q?net.pname(q):(n||'?')},pcol=id=>{const q=pinfo(id);return q&&q.col||'var(--mu)'};
 const pts=c=>/^\d$/.test(c.v)?+c.v:c.c==='w'?50:20,cname=c=>c.c==='w'?VN[c.v]:CN[c.c]+' '+(VN[c.v]||c.v);
 const okOn=(c,S)=>S.pend>0?c.v==='+2':c.c==='w'||c.c===S.col||c.v===S.top.v;
 // ---- kaarten tekenen ----
 function card(c,w){const h=Math.round(w*1.5),d=E('div'),wild=c.c==='w',col=COL[c.c]||'#1b1d2a',g=GL[c.v]||c.v,big=g.length>1?w*.36:w*.5;
  d.style.cssText=`flex:none;position:relative;width:${w}px;height:${h}px;border-radius:${w*.16}px;border:${Math.max(2,w*.05)}px solid #fff;box-sizing:border-box;box-shadow:0 3px 10px rgba(0,0,0,.28);overflow:hidden;color:#fff;font-weight:900;user-select:none;transition:transform .15s,opacity .15s,box-shadow .15s;background:${wild?'#1b1d2a':`linear-gradient(150deg,${col},color-mix(in srgb,${col} 70%,#000))`}`;
  const ring=E('div');ring.style.cssText=`position:absolute;left:50%;top:50%;width:${w*.74}px;height:${w*.74}px;transform:translate(-50%,-50%);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:${big}px;text-shadow:0 2px 0 rgba(0,0,0,.35);`+(wild?'background:conic-gradient(#e5383b 0 25%,#f2a900 0 50%,#21a35a 0 75%,#2f6fed 0);box-shadow:inset 0 0 0 3px #fff':'background:rgba(255,255,255,.18);box-shadow:inset 0 0 0 2px rgba(255,255,255,.55)');ring.textContent=g;if(g==='6'||g==='9')ring.style.textDecoration='underline';
  const k1=E('div'),k2=E('div');[k1,k2].forEach(k=>{k.textContent=g;k.style.cssText=`position:absolute;font-size:${w*.2}px;line-height:1`});k1.style.left=k1.style.top=w*.07+'px';k2.style.right=k2.style.bottom=w*.07+'px';k2.style.transform='rotate(180deg)';d.append(ring,k1,k2);return d}
 function back(w,n){const d=E('div');d.style.cssText=`flex:none;position:relative;width:${w}px;height:${w*1.5}px;border-radius:${w*.16}px;border:3px solid #fff;box-sizing:border-box;box-shadow:0 3px 10px rgba(0,0,0,.28),4px 4px 0 -1px var(--ln),7px 7px 0 -2px var(--ln);background:repeating-linear-gradient(45deg,#24264a 0 6px,#2d3060 6px 12px);display:flex;align-items:center;justify-content:center`;
  const r=E('div');r.style.cssText=`width:${w*.6}px;height:${w*.6}px;border-radius:50%;background:conic-gradient(#e5383b 0 25%,#f2a900 0 50%,#21a35a 0 75%,#2f6fed 0);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;font-size:${w*.22}px;box-shadow:0 0 0 3px #fff`;r.textContent=n;d.append(r);return d}
 // ---- UI ----
 const sc=E('div','sc'),seats=E('div'),table=E('div'),who=E('div'),acts=E('div'),fan=E('div'),info=E('div','hint'),opts=E('div'),rend=E('div'),pick=E('div');
 seats.style.cssText='display:flex;gap:8px 4px;flex-wrap:wrap;justify-content:center;margin:6px 0 10px';
 table.style.cssText='display:flex;align-items:center;justify-content:center;gap:16px;padding:10px;border-radius:22px;max-width:380px;margin:0 auto;background:color-mix(in srgb,var(--ac) 7%,var(--bg));border:3px solid var(--ln);transition:border-color .3s';
 who.style.cssText='font-weight:800;font-size:16px;min-height:24px;margin:8px 0 2px';acts.style.cssText='display:flex;gap:8px;justify-content:center;flex-wrap:wrap;min-height:46px;margin:4px 0';
 fan.style.cssText='display:flex;overflow-x:auto;padding:22px 10px 12px;scrollbar-width:thin;-webkit-overflow-scrolling:touch;min-height:130px';
 // hand-wrapper: vervaagde randen + ◀ ▶ zodra er kaarten buiten beeld zitten (tik op de pijl = verder schuiven)
 const fw=E('div');fw.style.cssText='position:relative;margin:0 -8px';fw.append(fan);
 const edge=(L)=>{const e=E('button','',L?'◀':'▶');e.setAttribute('aria-label',L?'Meer kaarten links':'Meer kaarten rechts');e.style.cssText='position:absolute;top:0;bottom:0;'+(L?'left:0':'right:0')+';width:30px;border:0;padding:0;margin:0;font-size:16px;font-weight:900;color:var(--tx);cursor:pointer;display:none;align-items:center;justify-content:'+(L?'flex-start':'flex-end')+';padding-'+(L?'left':'right')+':4px;background:linear-gradient(to '+(L?'right':'left')+',var(--card) 25%,transparent);z-index:2';
  e.onclick=ev=>{ev.preventDefault();fan.scrollBy({left:(L?-1:1)*fan.clientWidth*.7,behavior:'smooth'})};fw.append(e);return e};
 const edL=edge(1),edR=edge(0);let fanK='';
 function edges(){const mx=fan.scrollWidth-fan.clientWidth,on=fan.style.display!=='none'&&mx>4;edL.style.display=on&&fan.scrollLeft>4?'flex':'none';edR.style.display=on&&fan.scrollLeft<mx-4?'flex':'none'}
 fan.addEventListener('scroll',edges,{passive:true});
 opts.style.cssText='max-width:380px;margin:8px auto;padding:14px;border-radius:16px;background:var(--bg);border:1px solid var(--ln)';rend.style.cssText='max-width:380px;margin:10px auto;padding:12px;border-radius:16px;background:var(--bg);border:1px solid var(--ln);display:none';
 pick.style.cssText='display:none;position:absolute;inset:0;z-index:15;background:rgba(14,16,32,.6);border-radius:20px;align-items:center;justify-content:center';
 st.append(sc,seats,opts,table,who,acts,rend,fw,info,E('div','hint','Speel dezelfde kleur, hetzelfde getal of symbool · tik op een kaart · ←/→ kies · Enter speel · D pak/pas · L laatste kaart'),pick);
 let S=null,myH={h:[],dr:-1},sel=0,lEnd=0,lastKey='',podDone=0,pickId=-1,tKey='',known={};net.players.forEach(p=>known[p.id]=1);
 const cur=()=>S&&S.ph==='play'&&S.pl[S.t],myTurn=()=>{const c=cur();return!!c&&c.id===me},meP=()=>S&&S.pl.find(p=>p.id===me);
 const sorted=()=>myH.h.slice().sort((a,b)=>CO.indexOf(a.c)-CO.indexOf(b.c)||VO.indexOf(a.v)-VO.indexOf(b.v)||a.i-b.i);
 const playable=c=>myTurn()&&(!S.drew||c.i===myH.dr)&&okOn(c,S);
 function seat(p){const q=pinfo(p.id),col=pcol(p.id),on=cur()&&cur().id===p.id,d=E('div');d.title=pn(p.id,p.n);
  d.style.cssText='display:flex;flex-direction:column;align-items:center;width:64px;gap:3px;transition:transform .2s'+(on?';transform:translateY(-3px)':'');
  const a=E('div','pav');a.style.cssText='--c:'+col+';position:relative;transition:box-shadow .2s'+(on?`;box-shadow:0 0 0 3px var(--card),0 0 0 6px ${col},0 0 18px ${col}`:'');a.textContent=q&&q.av||'🙂';
  const b=E('span');b.textContent=p.c;b.style.cssText=`position:absolute;right:-9px;bottom:-6px;min-width:24px;height:24px;border-radius:7px;background:${col};color:${inkOn(col)};font-size:13px;font-weight:800;display:flex;align-items:center;justify-content:center;border:2px solid var(--card);box-sizing:border-box;padding:0 4px`;a.append(b);
  if(p.uno&&p.c===1||S.vuln&&S.vuln.id===p.id){const u=E('span');u.textContent=p.uno?'1!':'?!';u.style.cssText='position:absolute;left:-8px;top:-6px;background:'+(p.uno?'#f2a900':'#e5383b')+';color:#fff;font-size:11px;font-weight:900;border-radius:8px;padding:1px 5px';a.append(u)}
  const nm=E('div');nm.textContent=p.id===me?'Jij':q?q.name:p.n;nm.style.cssText='font-size:12px;font-weight:700;max-width:64px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:'+(on?col:'var(--tx)');
  const s2=E('div');s2.textContent=p.sc+' pt';s2.style.cssText='font-size:11px;color:var(--mu)';d.append(a,nm,s2);return d}
 function btn(t,f,bg){const b=E('button','btn',t);b.style.cssText='min-height:46px;font-size:16px'+(bg?';background:'+bg:'');b.onclick=f;return b}
 function render(){if(!S)return;const m=meP();if(S.ph==='play'){const k=S.rnd+'|'+S.turn;if(k!==tKey){tKey=k;lEnd=performance.now()+S.left}}
  sc.textContent=S.ph==='setup'?'Kleurkaart · instellingen':S.ph==='fin'?'Spel klaar!':'Ronde '+(S.rnd+1)+' · '+(S.opt.goal?'doel '+S.opt.goal+' pt':'één ronde')+(S.opt.stack?' · +2 stapelen':'')+(m?' · jij: '+m.sc+' pt':'');
  info.textContent=(S.log||[]).slice(-3).join(' · ');info.style.display=S.log&&S.log.length?'':'none';
  seats.replaceChildren(...(S.pl.length?S.pl:net.players.map(p=>({id:p.id,n:p.name,c:0,sc:0}))).map(seat));
  renderOpts();table.style.display=fan.style.display=S.ph==='play'||S.ph==='rend'?'flex':'none';
  if(S.top){table.replaceChildren();const dk=back(56,S.dk);dk.style.cursor=myTurn()&&!S.drew?'pointer':'default';dk.onclick=()=>act({k:'draw'});dk.title='Pak een kaart';
   const tp=card(S.top,72);tp.style.transform='rotate(-4deg)';const inf=E('div');inf.style.cssText='display:flex;flex-direction:column;gap:6px;align-items:center;font-weight:800;font-size:13px;min-width:62px';
   const cd=E('div');cd.style.cssText=`width:34px;height:34px;border-radius:50%;background:${COL[S.col]};box-shadow:0 0 0 3px var(--card),0 0 0 5px ${COL[S.col]}`;const cl=E('div');cl.textContent=CN[S.col];
   const dr=E('div');dr.textContent=S.dir>0?'↻ rechtsom':'↺ linksom';dr.style.color='var(--mu)';inf.append(cd,cl,dr);
   if(S.pend){const pe=E('div');pe.textContent='+'+S.pend+' te pakken';pe.style.cssText='background:#e5383b;color:#fff;border-radius:8px;padding:2px 6px';inf.append(pe)}
   table.append(dk,tp,inf);table.style.borderColor=COL[S.col]}
  const c=cur();who.textContent=S.ph==='setup'?(isH?'Kies de regels en start':'⏳ De host kiest de regels…'):S.ph==='play'?(myTurn()?(S.pend?'Jij bent aan zet: stapel een +2 of pak '+S.pend:S.drew?'Speel de gepakte kaart of pas':'Jij bent aan zet'):c?pn(c.id,c.n)+' is aan zet':''):S.ph==='rend'?'🏆 '+pn(S.rw.id)+' wint de ronde!':S.ph==='fin'?'🏆 '+pn(S.win)+' wint!':'';who.dataset.base=who.textContent;who.style.color='var(--tx)';
  acts.replaceChildren();if(S.ph==='play'&&m){if(myTurn())acts.append(S.drew?btn('Pas ▶',()=>act({k:'pass'})):btn(S.pend?'Pak '+S.pend+' kaarten':'Pak een kaart',()=>act({k:'draw'})));
   const n=myH.h.length;if(!m.uno&&(n===2&&myTurn()||n===1&&S.vuln&&S.vuln.id===me))acts.append(btn('Laatste kaart! ☝️',()=>act({k:'last'}),'linear-gradient(135deg,#f2a900,#f77f00)'));
   if(S.vuln&&S.vuln.id!==me&&S.pl.some(p=>p.id===S.vuln.id))acts.append(btn('Betrapt! 🫵 '+pn(S.vuln.id),()=>act({k:'catch'}),'linear-gradient(135deg,#e5383b,#b5179e)'))}
  renderFan();edges();renderRend();if(S.ph!=='play'||!myTurn())closePick();
  if(S.ph==='fin'&&!podDone){podDone=1;st.style.minHeight=(320+60*S.pl.length)+'px';const scores={};S.pl.forEach(p=>scores[p.id]=p.sc);net.result({winner:S.win,scores,unit:' pt',text:S.rw?pn(S.rw.id)+' pakte '+S.rw.pts+' pt in de laatste ronde':''})}}
 function renderFan(){fan.replaceChildren();if(S.ph==='setup')return;const m=meP();
  if(!m){const t=E('div','hint');t.textContent='Je kijkt mee 👀';t.style.cssText='margin:auto;font-size:15px';fan.append(t);return}
  const H=sorted();if(sel>=H.length)sel=Math.max(0,H.length-1);const key=S.rnd+'|'+S.turn+'|'+H.map(c=>c.i).join(',');
  if(key!==lastKey&&myTurn()){lastKey=key;const f=H.findIndex(playable);if(f>=0)sel=f}
  H.forEach((c,k)=>{const ok=playable(c),d=card(c,66);d.dataset.i=c.i;d.dataset.ok=ok?1:0;d.style.marginLeft=k?'-16px':'auto';if(k===H.length-1)d.style.marginRight='auto';d.style.cursor=ok?'pointer':'default';
   if(myTurn()){if(ok)d.style.transform='translateY(-16px)';else d.style.filter='saturate(.3) brightness(.78)'}if(k===sel&&myTurn())d.style.boxShadow='0 0 0 3px var(--ac),0 6px 14px rgba(0,0,0,.35)';
   d.onclick=()=>{sel=k;tryPlay(c)};fan.append(d)});
  const sd=fan.children[sel],fk=sel+'/'+fan.children.length+'/'+myTurn();if(sd&&fk!==fanK){fanK=fk;const fr=fan.getBoundingClientRect(),r=sd.getBoundingClientRect();// geselecteerde kaart altijd in beeld (naast de pijlranden)
   if(r.left<fr.left+30)fan.scrollLeft-=fr.left+30-r.left;else if(r.right>fr.right-30)fan.scrollLeft+=r.right-(fr.right-30)}edges()}
 function renderOpts(){opts.style.display=S.ph==='setup'?'':'none';if(S.ph!=='setup')return;opts.replaceChildren();const o=S.opt,row=(lab,el)=>{const r=E('div');r.style.cssText='display:flex;align-items:center;justify-content:space-between;gap:8px;margin:6px 0;font-weight:700;flex-wrap:wrap';const l=E('span');l.textContent=lab;r.append(l,el);return r};
  const seg=(vals,curV,lab,f)=>{const w=E('div');w.style.cssText='display:flex;gap:4px';vals.forEach(v=>{const b=E('button','btn'+(v===curV?'':' sec'),lab(v));b.style.cssText='padding:8px 12px;font-size:14px';b.disabled=!isH;b.onclick=()=>f(v);w.append(b)});return w};
  opts.append(row('+2 op +2 stapelen',seg([1,0],o.stack,v=>v?'Aan':'Uit',v=>{o.stack=v;pub()})),row('Spel tot',seg([0,100,300,500],o.goal,v=>v?v+'':'1 ronde',v=>{o.goal=v;pub()})));
  if(isH){const b=btn('Delen en starten ▶',()=>{if(S.ph==='setup'){S.pl=net.players.map(p=>({id:p.id,n:p.name,c:0,sc:0,uno:0}));newRound()}});b.style.marginTop='8px';opts.append(b)}else opts.append(E('div','hint','De host kiest de regels en start het spel'))}
 function renderRend(){rend.style.display=S.ph==='rend'?'':'none';if(S.ph!=='rend')return;rend.replaceChildren();const h=E('div');h.style.cssText='font-weight:800;margin-bottom:6px';h.textContent='+'+S.rw.pts+' pt voor '+pn(S.rw.id)+' · doel '+S.opt.goal;rend.append(h);
  S.pl.slice().sort((a,b)=>b.sc-a.sc).forEach(p=>{const r=E('div');r.style.cssText='display:flex;justify-content:space-between;padding:3px 8px;border-left:4px solid '+pcol(p.id)+';margin:3px 0';const a=E('span'),b=E('b');a.textContent=pn(p.id,p.n);b.textContent=p.sc+' pt';r.append(a,b);rend.append(r)});
  if(isH)rend.append(btn('Volgende ronde ▶',()=>{if(S.ph==='rend')newRound()}));else rend.append(E('div','hint','De volgende ronde begint zo…'))}
 function tryPlay(c){if(!playable(c)){beep(160,.05,'triangle',.02);return}if(c.c==='w')openPick(c.i);else act({k:'play',i:c.i})}
 function openPick(i){pickId=i;pick.replaceChildren();const b=E('div');b.style.cssText='background:var(--card);border-radius:18px;padding:16px;width:260px;box-shadow:0 10px 30px rgba(0,0,0,.4)';const h=E('div');h.textContent='Kies een kleur';h.style.cssText='font-weight:800;margin-bottom:10px';const g=E('div');g.style.cssText='display:grid;grid-template-columns:1fr 1fr;gap:10px';
  'rygb'.split('').forEach((k,n)=>{const x=E('button');x.dataset.col=k;x.textContent=(n+1)+' · '+CN[k];x.style.cssText=`min-height:64px;border:0;border-radius:14px;background:${COL[k]};color:#fff;font-weight:800;font-size:16px;cursor:pointer`;x.onclick=()=>{act({k:'play',i:pickId,col:k});closePick()};g.append(x)});
  const cx=E('button','btn sec','Annuleer');cx.style.marginTop='10px';cx.onclick=closePick;b.append(h,g,cx);pick.append(b);pick.style.display='flex'}
 function closePick(){pickId=-1;pick.style.display='none'}
 function act(d){if(isH)hAct(me,d);else net.send(d)}
 // ---- host ----
 let deck=[],disc=[],HD={},DR={},tm=0,tT=0,tR=0;
 const shuf=a=>{for(let i=a.length-1;i>0;i--){const j=R(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
 function mkDeck(){const d=[];for(const c of'rygb'){d.push({c,v:'0'});for(const v of['1','2','3','4','5','6','7','8','9','s','r','+2'])d.push({c,v},{c,v})}for(let k=0;k<4;k++)d.push({c:'w',v:'w'},{c:'w',v:'+4'});shuf(d);d.forEach((c,k)=>c.i=k);return d}
 const P=id=>S.pl.find(p=>p.id===id),nx=(i,k)=>((i+S.dir*k)%S.pl.length+S.pl.length)%S.pl.length;
 const log=t=>{S.log=(S.log||[]).concat(t).slice(-3)};
 function draw(id,n){const got=[];for(let k=0;k<n;k++){if(!deck.length&&disc.length>1){const top=disc.pop();deck=shuf(disc);disc=[top];log('🔀 Aflegstapel geschud')}if(!deck.length)break;const c=deck.pop();HD[id].push(c);got.push(c)}const p=P(id);if(p)p.uno=0;return got}
 function pub(){S.seq=(S.seq||0)+1;S.pl.forEach(p=>p.c=(HD[p.id]||[]).length);S.dk=deck.length;S.left=S.ph==='play'?Math.max(0,TURN-(Date.now()-tT)):0;net.send(S);
  S.pl.forEach(p=>{if(p.id!==me)net.sendTo(p.id,{k:'h',rnd:S.rnd,h:HD[p.id]||[],dr:DR[p.id]??-1})});myH={h:(HD[me]||[]).slice(),dr:DR[me]??-1};render();botSched()}
 function adv(k){S.t=nx(S.t,k);S.turn++;S.drew=0;DR={};tT=Date.now();if(S.vuln&&S.turn>S.vuln.n+1)S.vuln=null}
 function hAct(id,d,auto){if(!S||!d)return;const p=P(id);if(!p||S.ph!=='play')return;const h=HD[id],isCur=S.pl[S.t].id===id;
  if(d.k==='last'){if(h.length<=2&&!p.uno){p.uno=1;if(S.vuln&&S.vuln.id===id)S.vuln=null;log('☝️ '+pn(id)+': laatste kaart!');beep(700,.08,'triangle',.04);pub()}return}
  if(d.k==='catch'){const v=S.vuln;if(v&&v.id!==id&&HD[v.id]&&HD[v.id].length===1){draw(v.id,2);S.vuln=null;log('🫵 '+pn(id)+' betrapt '+pn(v.id)+': +2');beep(220,.15,'sawtooth',.03);pub()}return}
  if(!isCur)return;
  if(d.k==='draw'){if(S.drew)return;if(S.pend){draw(id,S.pend);log((auto?'⏱ ':'')+pn(id)+' pakt '+S.pend);S.pend=0;adv(1)}
   else{const g=draw(id,1)[0];if(g&&okOn(g,S)&&!auto){S.drew=1;DR[id]=g.i}else{log((auto?'⏱ ':'')+pn(id)+' pakt een kaart');adv(1)}}beep(330,.04,'triangle',.03);pub();return}
  if(d.k==='pass'){if(S.drew){log(pn(id)+' pakt en past');adv(1);pub()}return}
  if(d.k!=='play')return;const ci=h.findIndex(c=>c.i===d.i),c=h[ci];if(!c||!okOn(c,S)||S.drew&&c.i!==DR[id]||c.c==='w'&&!COL[d.col])return;
  h.splice(ci,1);disc.push(c);S.top={c:c.c,v:c.v,i:c.i};S.col=c.c==='w'?d.col:c.c;log(pn(id)+' speelt '+cname(c)+(c.c==='w'?' → '+CN[S.col]:''));beep(520,.05,'triangle',.03);
  if(!h.length){endRound(id);return}const n=S.pl.length;
  if(c.v==='s')adv(2);else if(c.v==='r'){if(n===2)adv(2);else{S.dir*=-1;adv(1)}}
  else if(c.v==='+2'){if(S.opt.stack){S.pend+=2;adv(1)}else{draw(S.pl[nx(S.t,1)].id,2);adv(2)}}else if(c.v==='+4'){draw(S.pl[nx(S.t,1)].id,4);adv(2)}else adv(1);
  if(h.length===1&&!p.uno)S.vuln={id,n:S.turn-1};pub()}
 function endRound(id){let s=0;S.pl.forEach(p=>{if(p.id!==id)s+=(HD[p.id]||[]).reduce((a,c)=>a+pts(c),0)});const p=P(id);p.sc+=s;S.rw={id,pts:s};S.pend=0;S.vuln=null;S.drew=0;
  if(!S.opt.goal||p.sc>=S.opt.goal){S.ph='fin';S.win=id;[0,1,2].forEach(i=>setTimeout(()=>beep(523*Math.pow(1.26,i),.12,'triangle',.05),i*120))}else{S.ph='rend';tR=Date.now()}pub()}
 function newRound(){deck=mkDeck();disc=[];HD={};DR={};S.pl.forEach(p=>{HD[p.id]=[];p.uno=0});S.pl.forEach(p=>draw(p.id,7));let k=deck.length-1;while(!/^\d$/.test(deck[k].v))k--;const t=deck.splice(k,1)[0];disc.push(t);
  S.rnd++;S.top={c:t.c,v:t.v,i:t.i};S.col=t.c;S.t=S.rnd%S.pl.length;S.dir=1;S.pend=0;S.vuln=null;S.drew=0;S.turn=0;S.rw=null;S.ph='play';S.log=[];tT=Date.now();pub()}
 function auto(){const p=S.pl[S.t];if(!p)return;if(S.drew)hAct(p.id,{k:'pass'});else hAct(p.id,{k:'draw'},1)}
 function tick(){if(!S)return;if(S.ph==='play'&&Date.now()-tT>=TURN)auto();else if(S.ph==='rend'&&Date.now()-tR>=10000)newRound()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(isH){if(d.k==='hi'&&S){net.sendTo(from,S);if(HD[from])net.sendTo(from,{k:'h',rnd:S.rnd,h:HD[from],dr:DR[from]??-1})}else if(net.isBot(from)){const q=S&&S.seq;hAct(from,d);if(S&&S.seq!==q)BT.ok++;else BT.bad.push(d)}else hAct(from,d)}
  else if(d.k==='s'){S=d;render()}else if(d.k==='h'&&Array.isArray(d.h)){myH={h:d.h,dr:d.dr};if(S)render()}});
 const offP=net.onPlayers(ps=>{const ids=new Set(ps.map(p=>p.id));
  Object.keys(known).forEach(id=>{if(ids.has(id))return;delete known[id];if(!isH||!S)return;const i=S.pl.findIndex(p=>p.id===id);log('⚠️ '+(i>=0?S.pl[i].n:'Iemand')+' heeft het spel verlaten');if(i<0)return;
   const wasCur=i===S.t;deck.unshift(...(HD[id]||[]));delete HD[id];S.pl.splice(i,1);if(S.vuln&&S.vuln.id===id)S.vuln=null;const n=S.pl.length;
   if(i<S.t)S.t--;if(wasCur){S.t=S.dir>0?i%n:(i-1+n)%n;S.drew=0;DR={};tT=Date.now()}if(S.t>=n)S.t=0;
   if(n===1&&S.ph!=='setup'){S.ph='fin';S.win=S.pl[0].id;S.rw=null}});
  ps.forEach(p=>{if(!known[p.id]){known[p.id]=1;if(isH&&S)log('👋 '+net.pname(p)+' kijkt mee')}});if(isH&&S)pub();else render()});
 const inp=input(st,[],k=>{if(!S||S.ph!=='play')return;if(pickId>=0){const n='1234'.indexOf(k);if(n>=0){act({k:'play',i:pickId,col:'rygb'[n]});closePick()}else if(k==='Escape')closePick();return}
  const H=sorted();if(k==='ArrowLeft'||k==='ArrowRight'){if(!H.length)return;sel=(sel+(k==='ArrowRight'?1:-1)+H.length)%H.length;renderFan()}else if(k==='Enter'){if(H[sel])tryPlay(H[sel])}else if(k==='d'||k==='D'){if(myTurn())act({k:S.drew?'pass':'draw'})}else if(k==='l'||k==='L')act({k:'last'})});
 const stopLoop=loop(()=>{if(!S||S.ph!=='play')return;const s=Math.max(0,Math.ceil((lEnd-performance.now())/1000)),t=(who.dataset.base||'')+' · ⏱ '+s+' s';if(who.textContent!==t)who.textContent=t;who.style.color=s<=5?'#e5383b':'var(--tx)'});
 // ---- bots (alleen host): spelen een legale kaart; pestkaarten tegen een volgende speler met weinig kaarten; kleur = waar ze er het meest van hebben;
 //      "Laatste kaart" meestal wel, 20% vergeten (dan kun je ze betrappen); betrappen zelf ook een vergeetachtige mens ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]}),bT={},cDec={};
 const bAct=(id,d)=>{BT.sent++;net.botAct(id,d)};
 function botKey(id){if(!S||S.ph!=='play'||!HD[id])return null;const c=S.pl[S.t];
  const v=S.vuln;if(v&&v.id!==id&&HD[v.id]&&HD[v.id].length===1){const ck=v.id+'|'+v.n+'|'+id;if(!(ck in cDec))cDec[ck]=Math.random()<(BT.catchP??.5);if(cDec[ck])return'C|'+ck}
  return c&&c.id===id?'T|'+S.rnd+'|'+S.turn+'|'+S.drew+'|'+S.pend:null}
 function botSched(){if(!isH)return;net.bots().forEach(b=>{const k=botKey(b.id),o=bT[b.id];if(o&&o.k===k)return;if(o)clearTimeout(o.tm);delete bT[b.id];if(!k)return;
  const ms=BT.fast?30+R(50):k[0]==='C'?1500+R(2500):700+R(900);bT[b.id]={k,tm:setTimeout(()=>{delete bT[b.id];if(botKey(b.id)!==k){botSched();return}botDo(b.id,k)},ms)}})}
 function botCol(h,skip){const n={r:0,y:0,g:0,b:0};h.forEach(c=>{if(c.i!==skip&&n[c.c]!=null)n[c.c]++});return Object.keys(n).sort((a,b)=>n[b]-n[a]||R(3)-1)[0]}
 function botDo(id,k){if(k[0]==='C'){bAct(id,{k:'catch'});return}const h=HD[id],p=P(id);
  let c=null;if(S.drew){c=h.find(x=>x.i===DR[id]);if(!c||!okOn(c,S)){bAct(id,{k:'pass'});return}}
  else{const ok=h.filter(x=>okOn(x,S));if(!ok.length){bAct(id,{k:'draw'});return}const nxt=S.pl[nx(S.t,1)],low=nxt&&nxt.c<=2,act=x=>!/^\d$/.test(x.v);
   const sc=x=>(low?(act(x)?20:0):(x.c==='w'?-12:act(x)?-3:0))+(x.c===S.col?2:0)+(/^\d$/.test(x.v)?+x.v*.3:0)+Math.random()*2;c=ok.sort((a,b)=>sc(b)-sc(a))[0]}
  if(h.length===2&&!p.uno&&Math.random()>=(BT.forgetP??.2))bAct(id,{k:'last'});
  bAct(id,c.c==='w'?{k:'play',i:c.i,col:botCol(h,c.i)}:{k:'play',i:c.i})}
 let dbg=null;if(DBG){dbg=window.__dbg={get S(){return S},get H(){return isH?HD:null},get my(){return myH},get deck(){return isH?deck:null},okOn,
  rig(id,cards){HD[id]=cards;pub()},top(c,col){S.top=c;S.col=col||c.c;pub()},force:()=>{if(isH&&S&&S.ph==='play')auto()},next:()=>{if(isH&&S.ph==='rend')newRound()}}}
 if(isH){S={k:'s',ph:'setup',rnd:-1,t:0,dir:1,pend:0,top:null,col:'r',pl:[],opt:{stack:1,goal:300},log:[],turn:0,dk:0};tm=setInterval(tick,200);pub()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{st.style.minHeight='';off();offP();inp.stop();stopLoop();clearInterval(tm);Object.values(bT).forEach(o=>clearTimeout(o.tm));if(dbg&&window.__dbg===dbg)delete window.__dbg}}},
