{id:'draw',n:'Tekenen & raden',e:'🎨',c:'Samen',g:'#f7971e,#ffd200',min:2,max:8,run(st,net){
 // Tekenen & raden (host-authoritatief): één speler tekent een geheim woord, de rest raadt. 2 rondes per speler, 90 s per ronde.
 const WORDS='aap,appel,auto,baby,bal,banaan,bank,bed,bij,bloem,boek,boom,boot,bord,bril,brood,brug,bus,cactus,camera,clown,computer,dak,deur,dolfijn,draak,drum,eend,egel,ei,fiets,fles,gitaar,glas,haai,hamer,hand,hart,hoed,hond,huis,ijsje,jas,kaars,kaas,kameel,kasteel,kat,kerk,kers,ketting,kikker,kip,klok,koe,koffer,konijn,krab,kroon,laars,ladder,lamp,leeuw,lepel,maan,mes,mier,molen,muis,muts,neus,olifant,oog,paard,paddenstoel,pan,papegaai,paraplu,piano,pijl,pinguïn,pizza,planeet,pop,raket,regenboog,ring,robot,schaar,schaap,schip,schoen,schildpad,slak,slang,sleutel,sneeuwpop,sok,spin,spook,ster,stoel,strand,tafel,tand,tandenborstel,tent,tijger,tomaat,toren,tractor,trein,trommel,trui,uil,varken,veer,vis,vlag,vlieger,vlinder,voet,vork,vuur,vuurtoren,walvis,wolk,wortel,zaag,zebra,zee,zeilboot,zon,zwaan,zwaard,ananas,emmer,gieter,heks,kameleon,ketel,koekje,krokodil,kwast,lantaarn,pannenkoek,puzzel,schommel,sleutelbos,snor,taart,telefoon,thee,vliegtuig,vogelhuisje'.split(',');
 const COL=['#1b1d2a','#e74c3c','#2e86de','#27ae60','#f39c12','#8e5a3c'],SZ=[3,7,14],TL=90000,W=360,H=300,isH=net.isHost,me=net.me.id;
 const norm=s=>String(s).toLowerCase().trim().replace(/\s+/g,' ');
 const sc=E('div','sc'),note=E('div','hint'),board=E('div');board.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:4px 0 8px';
 const word=E('div');word.style.cssText='font-size:22px;font-weight:800;letter-spacing:.15em;min-height:32px;margin:4px 0;font-variant-numeric:tabular-nums';
 const barW=E('div');barW.style.cssText='height:6px;border-radius:99px;background:var(--bg);overflow:hidden;max-width:360px;margin:0 auto 8px';const bar=E('div');bar.style.cssText='height:100%;width:100%;border-radius:99px;background:#38d9a9';barW.append(bar);
 st.append(sc,note,board,word,barW);
 const c=mkCanvas(st,W,H),x=c.getContext('2d',{willReadFrequently:true});c.style.background='#fffdf7';c.style.cursor='crosshair';
 const tools=E('div');tools.style.cssText='display:none;gap:6px;justify-content:center;align-items:center;flex-wrap:wrap;margin:8px 0';
 let col=0,sz=1;const cbs=COL.map((cc,i)=>{const b=E('button');b.style.cssText='width:30px;height:30px;border-radius:50%;border:3px solid transparent;background:'+cc+';cursor:pointer';b.onclick=()=>{col=i;toolUI()};tools.append(b);return b});
 const sbs=SZ.map((s,i)=>{const b=E('button','btn');b.style.cssText='width:36px;height:36px;padding:0;border-radius:50%;background:var(--bg);color:var(--tx);display:flex;align-items:center;justify-content:center';const d=E('span');d.style.cssText='display:block;border-radius:50%;background:currentColor;width:'+(s+4)+'px;height:'+(s+4)+'px';b.append(d);b.onclick=()=>{sz=i;toolUI()};tools.append(b);return b});
 const bClr=E('button','btn','🗑️ Wis');bClr.style.cssText='background:var(--bg);color:var(--tx)';bClr.onclick=()=>{if(!amDrawer())return;clear();if(isH)strokes=[];net.send({k:'clr'})};tools.append(bClr);
 const pick=E('div');pick.style.cssText='display:none;gap:8px;justify-content:center;flex-wrap:wrap;margin:10px 0';
 const gRow=E('div');gRow.style.cssText='display:none;gap:6px;justify-content:center;margin:8px auto;max-width:360px';
 const gIn=E('input');gIn.maxLength=30;gIn.placeholder='Wat is het?';gIn.autocomplete='off';gIn.style.cssText='flex:1;min-width:0;padding:10px 12px;border:1px solid var(--ln,#ccc);border-radius:12px;background:var(--bg);color:var(--tx);font:inherit;font-size:16px';
 const gBtn=E('button','btn','Raad!');gRow.append(gIn,gBtn);
 const feed=E('div');feed.style.cssText='max-width:360px;margin:6px auto 0;text-align:left;font-size:13px;min-height:20px;line-height:1.5';
 const info=E('div');info.style.cssText='font-weight:700;min-height:22px;margin-top:6px';
 st.append(tools,pick,gRow,info,feed,E('div','hint','Teken met je vinger of muis · raders typen hun gok en drukken Enter · snel raden = meer punten'));
 let S=null,notes=[],known={},lEnd=0,lKey='',drawing=0,pend=[],last=null,flushT=0,chosen=-1,tms=[],scBase='',podDone=0;
 net.players.forEach(p=>known[p.id]=net.pname(p));
 const amDrawer=()=>S&&S.ph==='draw'&&S.dr===me;
 // naam met avatar; valt terug op de naam uit de toestand/feed als de speler al weg is
 const nm=(id,n)=>{const q=net.players.find(x=>x.id===id);if(q)return net.pname(q);const p=S&&S.pl.find(p=>p.id===id);return p?p.n:(n||'…')};
 function clear(){x.fillStyle='#fffdf7';x.fillRect(0,0,W,H)}
 function seg(ci,w,p){x.strokeStyle=COL[ci]||COL[0];x.lineWidth=SZ[w]||SZ[1];x.lineCap=x.lineJoin='round';x.beginPath();x.moveTo(p[0],p[1]);if(p.length===2)x.lineTo(p[0]+.1,p[1]);for(let i=2;i<p.length;i+=2)x.lineTo(p[i],p[i+1]);x.stroke()}
 function toolUI(){cbs.forEach((b,i)=>b.style.borderColor=i===col?'var(--ac)':'transparent');sbs.forEach((b,i)=>{b.style.background=i===sz?'var(--ac)':'var(--bg)';b.style.color=i===sz?'#fff':'var(--tx)'})}
 // scorechip: avatar-bolletje + tekst, rand in de kleur van de speler, eigen chip licht ingekleurd
 function chip(p,txt){const q=net.players.find(x=>x.id===p.id),col=q&&q.col||'var(--mu)',on=p.id===me,d=E('div');
  d.style.cssText='display:inline-flex;align-items:center;padding:2px 9px 2px 2px;border-radius:99px;font-size:13px;font-weight:'+(on?'700':'600')+';color:var(--tx);border:2px solid '+col+';background:'+(on?'color-mix(in srgb,'+col+' 18%,var(--bg))':'var(--bg)');
  const av=E('span','pav s');av.style.setProperty('--c',col);av.textContent=q&&q.av||'🙂';const t=E('span');t.textContent=txt;d.append(av,t);return d}
 function mmss(ms){const s=Math.max(0,Math.ceil(ms/1000));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
 function render(){if(!S)return;const key=S.r+':'+S.ph;const dr=S.dr===me;
  if(key!==lKey){lKey=key;lEnd=performance.now()+(S.tl||0);if(S.ph==='pick'){clear();chosen=-1;gIn.value=''}}
  note.textContent=notes.slice(-3).join(' · ');note.style.display=notes.length?'':'none';const m=S.pl.find(p=>p.id===me),myOk=m&&m.ok;
  sc.textContent=scBase=S.ph==='fin'?'Spel klaar!':'Ronde '+(S.r+1)+'/'+S.tot+' · '+(dr?'jij tekent':nm(S.dr)+' tekent')+(m?' · Jij: '+m.sc+' pt':'');
  board.replaceChildren(...S.pl.slice().sort((a,b)=>b.sc-a.sc).map(p=>chip(p,(p.id===S.dr&&S.ph!=='fin'?'🖌️ ':'')+p.n+(p.id===me?' (jij)':'')+' · '+p.sc+(p.ok?' ✅':''))));
  tools.style.display=dr&&S.ph==='draw'?'flex':'none';pick.style.display=dr&&S.ph==='pick'?'flex':'none';gRow.style.display=!dr&&S.ph==='draw'&&m?'flex':'none';barW.style.visibility=S.ph==='draw'?'visible':'hidden';
  word.style.letterSpacing='0';if(S.ph==='fin'){const r=S.pl.slice().sort((a,b)=>b.sc-a.sc),tie=r.length>1&&r[0].sc===r[1].sc;word.textContent=r.length&&!tie?'🏆 '+nm(r[0].id,r[0].n)+' wint!':'Gelijkspel!';info.textContent='';feed.replaceChildren();
   if(!podDone){podDone=1;const scores={};r.forEach(p=>scores[p.id]=p.sc);net.result({winner:!tie&&r[0]?r[0].id:null,scores,unit:' pt',title:tie?'Gelijkspel 🤝':undefined})}return}
  if(S.ph==='pick'){word.textContent=dr?'Kies een woord':nm(S.dr)+' kiest een woord…';info.textContent='';if(dr&&chosen<0){pick.replaceChildren(...(S.ch||[]).map((w,i)=>{const b=E('button','btn',w);b.style.fontSize='16px';b.onclick=()=>{chosen=i;if(isH)hChoose(me,i);else net.send({k:'ch',i})};return b}))}}
  else if(S.ph==='draw'){word.textContent=dr?'Teken: '+S.w:S.mask.split('').join(' ');word.style.letterSpacing=dr?'0':'.15em';info.textContent=dr?'':myOk?'✅ Geraden! Wachten op de rest…':'';gIn.disabled=!!myOk;gBtn.disabled=!!myOk}
  else{word.textContent='Het woord was: '+S.w;info.textContent=S.pl.some(p=>p.ok)?'Geraden door '+S.pl.filter(p=>p.ok).map(p=>nm(p.id,p.n)).join(', '):'Niemand heeft het geraden 😅'}
  feed.replaceChildren(...(S.feed||[]).slice(-8).map(f=>{const d=E('div');d.textContent=f.ok?'✅ '+nm(f.id,f.n)+' heeft het geraden!':nm(f.id,f.n)+': '+f.t;d.style.color=f.ok?'#27ae60':'var(--tx)';return d}))}
 // ---- tekenen ----
 const pos=e=>{const r=c.getBoundingClientRect();return[Math.round((e.clientX-r.left)*W/r.width),Math.round((e.clientY-r.top)*H/r.height)]};
 function flush(){if(!pend.length)return;const p=last?[...last,...pend]:pend,msg={k:'st',c:col,w:sz,p};if(isH)strokes.push(msg);net.send(msg);last=pend.slice(-2);pend=[]}
 c.onpointerdown=e=>{if(!amDrawer())return;e.preventDefault();try{c.setPointerCapture(e.pointerId)}catch(x){}drawing=1;const q=pos(e);pend=q;last=null;seg(col,sz,q);flushT=setInterval(flush,50)};
 c.onpointermove=e=>{if(!drawing)return;e.preventDefault();const q=pos(e);const prev=pend.length?pend.slice(-2):last;if(prev)seg(col,sz,[...prev,...q]);pend.push(...q)};
 c.onpointerup=c.onpointercancel=e=>{if(!drawing)return;drawing=0;clearInterval(flushT);flush();last=null};
 function guess(){const t=norm(gIn.value),m=S&&S.pl.find(p=>p.id===me);if(!t||!S||S.ph!=='draw'||amDrawer()||!m||m.ok)return;gIn.value='';if(isH)hGuess(me,t);else net.send({k:'g',t})}
 gBtn.onclick=guess;gIn.onkeydown=e=>{if(e.key==='Enter')guess()};
 // ---- host ----
 let order=[],strokes=[],t0=0,hints=0,tm=0,rng,wq=[];
 const live=()=>S.pl.filter(p=>p.id!==S.dr);
 function pub(){if(S.ph==='draw')S.tl=Math.max(0,TL-(Date.now()-t0));const out=Object.assign({},S);delete out.ch;if(S.ph==='pick'||S.ph==='draw')delete out.w;net.send(out);
  if(S.dr!==me){if(S.ph==='draw')net.sendTo(S.dr,Object.assign({},out,{w:S.w}));if(S.ph==='pick')net.sendTo(S.dr,Object.assign({},out,{ch:S.ch}))}render()}
 function startRound(){S.ph='pick';S.dr=S.pl[S.r%S.pl.length].id;S.pl.forEach(p=>{p.ok=0});S.feed=[];S.ch=[wq.pop(),wq.pop(),wq.pop()];S.w='';S.mask='';strokes=[];hints=0;clear();pub();const r=S.r;tms.push(setTimeout(()=>{if(S.ph==='pick'&&S.r===r)hChoose(S.dr,0)},20000))}
 function hChoose(id,i){if(S.ph!=='pick'||id!==S.dr||!(i>=0&&i<3))return;S.w=S.ch[i];S.mask=S.w.replace(/[^ ]/g,'_');S.ph='draw';t0=Date.now();pub()}
 function hGuess(id,t){if(S.ph!=='draw'||id===S.dr)return;const p=S.pl.find(p=>p.id===id);if(!p||p.ok)return;
  if(t===norm(S.w)){const tl=Math.max(0,TL-(Date.now()-t0));p.ok=1;p.sc+=50+Math.round(tl/TL*100);const d=S.pl.find(p=>p.id===S.dr);if(d)d.sc+=30;S.feed.push({n:p.n,id:p.id,ok:1});beep(880,.15,'triangle',.05);if(live().every(p=>p.ok))endRound();else pub()}
  else{S.feed.push({n:p.n,id:p.id,t:t.slice(0,30)});S.feed=S.feed.slice(-10);pub()}}
 function next(){S.r++;S.tot=Math.max(S.r,2*S.pl.length);if(S.r>=S.tot||S.pl.length<2){S.ph='fin';pub()}else startRound()}
 function endRound(){if(S.ph!=='draw')return;S.ph='end';pub();tms.push(setTimeout(next,5000))}
 function tick(){if(S.ph!=='draw')return;const tl=TL-(Date.now()-t0);if(tl<=0){endRound();return}
  const want=Math.min(Math.floor((TL-tl)/20000),Math.floor(S.w.replace(/ /g,'').length/2));
  if(want>hints){const idx=[];for(let i=0;i<S.w.length;i++)if(S.mask[i]==='_')idx.push(i);if(idx.length){const i=idx[Math.floor(rng()*idx.length)];S.mask=S.mask.slice(0,i)+S.w[i]+S.mask.slice(i+1)}hints++;pub()}}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='st'){if(from!=='host'&&(!S||from!==S.dr))return;if(d.by===me)return;if(Array.isArray(d.p)&&d.p.length<=400){seg(d.c|0,d.w|0,d.p.map(v=>+v||0));if(isH){strokes.push(d);if(strokes.length>400)strokes.shift();net.send(Object.assign({by:from},d))}}return}
  if(d.k==='clr'){if(from!=='host'&&(!S||from!==S.dr))return;clear();if(isH){strokes=[];net.send({k:'clr'})}return}
  if(isH){if(d.k==='g')hGuess(from,norm(d.t));else if(d.k==='ch')hChoose(from,d.i|0);
   else if(d.k==='hi'&&S){const out=Object.assign({},S);delete out.w;delete out.ch;if(S.ph==='end'||S.ph==='fin')out.w=S.w;if(S.ph==='draw')out.tl=Math.max(0,TL-(Date.now()-t0));net.sendTo(from,out);for(let i=0;i<strokes.length;i+=25)net.sendTo(from,{k:'all',s:strokes.slice(i,i+25)})}}
  else if(d.k==='s'){const was=S&&S.ph;if(S&&d.r===S.r){if(d.w==null&&S.w)d.w=S.w;if(!d.ch&&S.ch)d.ch=S.ch}S=d;if(S.ph==='end'&&was!=='end')beep(S.pl.some(p=>p.ok)?660:200,.15,'triangle',.04);render()}
  else if(d.k==='all'&&Array.isArray(d.s))d.s.forEach(s=>seg(s.c|0,s.w|0,s.p))});
 const offP=net.onPlayers(ps=>{const ids=new Set(ps.map(p=>p.id));
  Object.keys(known).forEach(id=>{if(!ids.has(id)){notes.push('⚠️ '+known[id]+' heeft het spel verlaten');delete known[id];if(isH&&S){S.pl=S.pl.filter(p=>p.id!==id);S.tot=Math.max(S.r+1,2*S.pl.length);if(S.ph!=='fin'&&S.pl.length<2){S.ph='fin';S.w=S.w||'';pub()}else if(id===S.dr&&S.ph==='draw')endRound();else if(id===S.dr&&S.ph==='pick'){tms.forEach(clearTimeout);next()}else if(S.ph==='draw'&&live().every(p=>p.ok))endRound()}}});
  ps.forEach(p=>{if(!known[p.id]){known[p.id]=net.pname(p);if(isH&&S&&!S.pl.some(x=>x.id===p.id)){S.pl.push({id:p.id,n:p.name,sc:0,ok:0});S.tot=Math.max(S.r+1,2*S.pl.length)}}});
  if(isH&&S)pub();else render()});
 const stopLoop=loop(()=>{if(!S||S.ph!=='draw')return;const f=Math.max(0,(lEnd-performance.now())/TL);bar.style.width=f*100+'%';bar.style.background=`hsl(${Math.round(f*120)},70%,50%)`;
  sc.textContent=scBase+' · ⏱ '+mmss(lEnd-performance.now())});
 c.before(pick,tools);clear();toolUI();st.dr={get S(){return S},strokes:()=>strokes.length};
 if(net.players.length<3)notes.push('Met 2 spelers is het een oefenpotje — vanaf 3 wordt het echt leuk');
 if(isH){rng=net.rng();wq=WORDS.slice();for(let i=wq.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[wq[i],wq[j]]=[wq[j],wq[i]]}
  S={k:'s',ph:'pick',r:0,tot:2*net.players.length,dr:null,pl:net.players.map(p=>({id:p.id,n:p.name,sc:0,ok:0})),feed:[]};tm=setInterval(tick,250);startRound()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{off();offP();stopLoop();clearInterval(tm);clearInterval(flushT);tms.forEach(clearTimeout)}}},
