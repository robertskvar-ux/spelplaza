{id:'sudoku',n:'Sudoku samen',e:'🧮',c:'Samen',g:'#8e2de2,#4a00e0',min:2,max:4,bots:true,run(st,net){
 // tekstkleur op een effen spelerskleur: zwart of wit, wat het meeste contrast geeft (altijd ≥ 4.5:1)
 const inkOn=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(String(h||'').trim());if(!m)return'#fff';const n=parseInt(m[1],16),L=[n>>16,n>>8&255,n&255].map(v=>{v/=255;return v<=.03928?v/12.92:((v+.055)/1.055)**2.4}),l=.2126*L[0]+.7152*L[1]+.0722*L[2];return (l+.05)/.05>1.05/(l+.05)?'#000':'#fff'};
 // Coöp sudoku: iedereen vult hetzelfde rooster; host is de baas over de toestand (patroon A). De seed geeft overal dezelfde puzzel.
 // Kleuren: elke speler krijgt zijn eigen profielkleur (net.players[i].col); die wordt bij het registreren in S.P vastgelegd zodat
 // ingevulde cijfers hun kleur houden, ook als de speler later vertrekt. S.w[i] = stoelnummer (S.P[id].c) van wie het vakje vulde, 9 = hint.
 const rnd=net.rng(),R=n=>Math.floor(rnd()*n);
 // ---------- generator / solver (uit de single-player, deterministisch via seed, geen tijdslimiet) ----------
 const BX=[];for(let i=0;i<81;i++)BX.push((((i/9)|0)/3|0)*3+((i%9)/3|0));
 const PC=new Uint8Array(1024);for(let i=1;i<1024;i++)PC[i]=PC[i>>1]+(i&1);
 function fullGrid(){const g=new Array(81).fill(0),rw=Array(9).fill(0),cl=Array(9).fill(0),bx=Array(9).fill(0);
  function rec(i){if(i===81)return true;const r=(i/9)|0,c=i%9,b=BX[i],used=rw[r]|cl[c]|bx[b];const ds=[1,2,3,4,5,6,7,8,9];for(let k=8;k>0;k--){const j=R(k+1);[ds[k],ds[j]]=[ds[j],ds[k]]}
   for(const d of ds){const m=1<<d;if(used&m)continue;g[i]=d;rw[r]|=m;cl[c]|=m;bx[b]|=m;if(rec(i+1))return true;rw[r]^=m;cl[c]^=m;bx[b]^=m}g[i]=0;return false}
  rec(0);return g}
 function count(g,cap){const rw=Array(9).fill(0),cl=Array(9).fill(0),bx=Array(9).fill(0);for(let i=0;i<81;i++)if(g[i]){const m=1<<g[i];rw[(i/9)|0]|=m;cl[i%9]|=m;bx[BX[i]]|=m}
  let n=0;function rec(){let bi=-1,bc=10,bm=0;for(let i=0;i<81;i++){if(g[i])continue;const m=~(rw[(i/9)|0]|cl[i%9]|bx[BX[i]])&0x3FE,c=PC[m];if(c<bc){bc=c;bi=i;bm=m;if(c<=1)break}}
   if(bi<0){n++;return n>=cap}if(!bc)return false;const r=(bi/9)|0,c=bi%9,b=BX[bi];
   for(let d=1;d<=9;d++){const m=1<<d;if(!(bm&m))continue;g[bi]=d;rw[r]|=m;cl[c]|=m;bx[b]|=m;const s=rec();rw[r]^=m;cl[c]^=m;bx[b]^=m;g[bi]=0;if(s)return true}return false}
  rec();return n}
 function gen(target){const s=fullGrid(),g=s.slice(),ord=[...Array(81).keys()];for(let k=80;k>0;k--){const j=R(k+1);[ord[k],ord[j]]=[ord[j],ord[k]]}
  let giv=81;for(const i of ord){if(giv<=target)break;const v=g[i];g[i]=0;if(count(g,2)>1)g[i]=v;else giv--}return{s,g}}
 const PEERS=[];for(let i=0;i<81;i++){const r=(i/9)|0,c=i%9,s=new Set;for(let k=0;k<9;k++){s.add(r*9+k);s.add(k*9+c)}const br=r-r%3,bc=c-c%3;for(let a=0;a<3;a++)for(let b=0;b<3;b++)s.add((br+a)*9+bc+b);s.delete(i);PEERS.push([...s])}
 const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
 // ---------- DOM ----------
 const sc=E('div','sc'),pan=E('div'),info=E('div','hint');pan.style.cssText='display:flex;gap:4px;flex-wrap:wrap;justify-content:center;margin:2px 0 4px;max-width:100%';info.style.cssText='min-height:18px;margin:0 0 4px';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(360px,100%);margin:4px auto';
 const bd=E('div','bdr');bd.style.cssText+='grid-template-columns:repeat(9,minmax(0,1fr));gap:0;width:100%;margin:0;border:2px solid var(--tx);border-radius:6px;overflow:hidden;background:var(--card)';
 wrap.append(bd);
 const pad=E('div'),pad2=E('div');pad.style.cssText=pad2.style.cssText='display:flex;gap:4px;width:min(360px,100%);margin:8px auto 0';
 st.append(sc,pan,info,wrap,pad,pad2,E('div','hint','Tik op een vakje en dan op een cijfer · toetsen 1–9, pijltjes, Backspace · H = hint · juiste cijfers krijgen de kleur van de speler'));
 const cells=[];for(let i=0;i<81;i++){const r=(i/9)|0,c=i%9,d=E('div');
  d.style.cssText='font-size:21px;font-weight:600;position:relative;box-sizing:border-box;'+(c<8?`border-right:${c%3===2?'2px solid var(--tx)':'1px solid rgba(128,128,140,.35)'};`:'')+(r<8?`border-bottom:${r%3===2?'2px solid var(--tx)':'1px solid rgba(128,128,140,.35)'};`:'');
  d.onpointerdown=e=>{e.preventDefault();select(i)};cells.push(d);bd.append(d)}
 const digb=[];for(let d=1;d<=9;d++){const b=E('button','btn',d);b.style.cssText='flex:1;min-width:0;padding:9px 0;font-size:19px';b.onpointerdown=e=>{e.preventDefault();put(d)};digb.push(b);pad.append(b)}
 const mk=(t,f)=>{const b=E('button','btn',t);b.style.cssText='flex:1;min-width:0;padding:8px 0;font-size:14px';b.onpointerdown=e=>{e.preventDefault();f()};pad2.append(b);return b};
 mk('✖ Wissen',()=>put(0));const hintb=mk('💡 Hint (3)',()=>act({k:'hint',i:sel}));
 // ---------- toestand ----------
 const p=gen(32),sol=p.s,giv=p.g.map(v=>!!v);
 const S={v:p.g.slice(),w:new Array(81).fill(-1),P:{},sel:{},h:3,won:0};let full=0,t0=performance.now(),sel=-1,gone={},tm,bt=null,st0=0,selT=null,podDone=0;
 const reg=(q,c)=>({n:q.name,c,av:q.av||'🙂',col:q.col||net.pcol(q),ok:0,bad:0});
 net.players.forEach((q,k)=>{S.P[q.id]=reg(q,k%4)});
 const me=net.me.id,colOf=id=>S.P[id]&&S.P[id].col||net.pcol(id),myCol=()=>S.P[me]?colOf(me):'var(--ac)',secs=()=>Math.floor(((S.won?S.won*1000+t0:performance.now())-t0)/1000);
 const seatCol=()=>{const m={};for(const id in S.P)m[S.P[id].c]=S.P[id].col;return m};
 const pack=()=>({k:'s',v:S.v.join(''),w:S.w.map(x=>x<0?'.':x).join(''),P:S.P,sel:S.sel,h:S.h,won:S.won,el:(performance.now()-t0)/1000});
 function bcast(now){if(!net.isHost)return;const dt=performance.now()-st0;if(now||dt>120){clearTimeout(bt);bt=null;st0=performance.now();net.send(pack())}else if(!bt)bt=setTimeout(()=>{bt=null;bcast(1)},120-dt)}
 function unpack(d){S.v=[...d.v].map(Number);S.w=[...d.w].map(x=>x==='.'?-1:+x);S.P=d.P;S.sel=d.sel;S.h=d.h;S.won=d.won;if(!S.won)t0=performance.now()-d.el*1000;draw()}
 // host past acties toe (eigen + van joiners); joiners sturen ze naar de host
 function act(d){if(net.isHost)apply(d,me);else net.send(d)}
 function apply(d,id){if(!d||typeof d!=='object'||!S.P[id])return;const i=d.i|0;
  if(d.k==='sel'){if(i>=-1&&i<81){S.sel[id]=i;draw();bcast()}return}
  if(S.won)return;
  if(d.k==='put'){const v=d.d|0;if(i<0||i>80||v<0||v>9||giv[i]||S.v[i]===sol[i]||S.v[i]===v)return;
   if(!v){S.v[i]=0;S.w[i]=-1}else{S.v[i]=v;S.w[i]=S.P[id].c;if(v===sol[i])S.P[id].ok++;else S.P[id].bad++}}
  else if(d.k==='hint'){if(S.h<=0)return;let j=i;if(j<0||j>80||giv[j]||S.v[j]===sol[j]){const e=[];for(let k=0;k<81;k++)if(S.v[k]!==sol[k])e.push(k);if(!e.length)return;j=e[Math.floor(Math.random()*e.length)]}
   S.v[j]=sol[j];S.w[j]=9;S.h--}
  else return;
  if(S.v.every((v,k)=>v===sol[k]))S.won=Math.max(1,secs());
  draw();bcast(1)}
 function select(i){if(S.won)return;sel=i;draw();clearTimeout(selT);selT=setTimeout(()=>act({k:'sel',i:sel}),net.isHost?0:150)}
 function put(d){if(S.won||sel<0||giv[sel])return;if(S.v[sel]===sol[sel]&&S.v[sel]){beep(300,.05,'sine',.02);return}
  if(d&&d!==sol[sel])beep(180,.12,'sawtooth',.04);else if(d)beep(520,.05,'triangle',.03);act({k:'put',i:sel,d})}
 // ---------- tekenen ----------
 // naam met avatar uit S.P (blijft kloppen als de speler al weg is), anders via net
 const pn=id=>{const q=S.P[id];return q?(q.av||'🙂')+' '+q.n:net.pname(id)};
 function panel(){pan.replaceChildren();for(const id in S.P){const q=S.P[id],live=net.players.some(x=>x.id===id),on=id===me,ch=E('span');
  ch.style.cssText='display:inline-flex;align-items:center;white-space:nowrap;line-height:1.2;padding:1px 7px 1px 1px;border-radius:99px;font-size:12px;font-weight:'+(on?'700':'600')+';color:var(--tx);border:2px solid '+q.col+';background:'+(on?'color-mix(in srgb,'+q.col+' 18%,var(--bg))':'var(--bg)')+(live?'':';opacity:.45');
  const av=E('span','pav s');av.style.setProperty('--c',q.col);av.style.cssText+=';width:20px;height:20px;font-size:12px;margin:0 4px 0 0';av.textContent=q.av||'🙂';const nm=E('span');nm.style.cssText='max-width:76px;overflow:hidden;text-overflow:ellipsis';nm.textContent=q.n+(on?' (jij)':'');
  const ok=E('span','','✓'+q.ok),bad=E('span','','✗'+q.bad);ok.style.marginLeft='4px';bad.style.cssText='color:#e5484d;margin-left:3px';ch.append(av,nm,ok,bad);pan.append(ch)}}
 function draw(){const sv=sel>=0?S.v[sel]:0,pr=sel>=0?new Set(PEERS[sel]):null,others={},PC=seatCol();for(const id in S.sel)if(id!==me&&S.P[id]&&net.players.some(x=>x.id===id)&&S.sel[id]>=0)others[S.sel[id]]=S.P[id].col;
  for(let i=0;i<81;i++){const d=cells[i],v=S.v[i],w=S.w[i];let bg='',col=giv[i]?'var(--tx)':w===9?'var(--ac)':w>=0&&PC[w]?PC[w]:'var(--tx)';
   const wrong=v&&!giv[i]&&v!==sol[i];if(wrong)col='#e5484d';
   if(i===sel&&!S.won){bg=myCol();col=inkOn(bg)}else if(sv&&v===sv)bg='rgba(108,92,231,.3)';else if(pr&&pr.has(i))bg='rgba(108,92,231,.1)';else if(wrong)bg='rgba(229,72,77,.14)';// fout cijfer: rood + lichte rode tint (onderscheid met een rode spelerskleur)
   d.style.background=bg;d.style.color=col;d.style.fontWeight=giv[i]?'800':'700';d.style.boxShadow=others[i]?'inset 0 0 0 3px '+others[i]:'';d.textContent=v||''}
  const cnt=Array(10).fill(0);S.v.forEach((v,k)=>{if(v===sol[k])cnt[v]++});digb.forEach((b,k)=>b.style.opacity=cnt[k+1]>=9?'.35':'1');
  hintb.textContent='💡 Hint ('+S.h+')';hintb.style.opacity=S.h?'1':'.4';
  let bad=0;for(const id in S.P)bad+=S.P[id].bad;sc.textContent=(S.won?'🎉 Opgelost in '+fmt(S.won):'⏱ '+fmt(secs()))+' · Fouten: '+bad+' · Hints: '+S.h;panel();
  if(!S.won&&S.v.every(v=>v)){info.textContent='Rooster vol, maar er staan nog rode fouten: tik erop en kies een ander cijfer of ✖ Wissen';full=1}else if(full){full=0;info.textContent=''}
  // einde: gedeeld podium (coöp -> geen winnaar, ieders bijdrage = juist ingevulde vakjes)
  if(S.won&&!podDone){podDone=1;const scores={};for(const id in S.P)scores[id]=S.P[id].ok;const hu=3-S.h;
   net.result({winner:null,scores,unit:' juist',title:'Gelukt! 🎉',text:'Samen opgelost in '+fmt(S.won)+' · '+bad+' fout'+(bad===1?'':'en')+' · '+hu+' hint'+(hu===1?'':'s')})}}
 // ---------- net ----------
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;if(net.isHost)apply(d,from);else if(d.k==='s')unpack(d)});
 const offP=net.onPlayers(pl=>{for(const id in S.P)if(!pl.some(x=>x.id===id)&&!gone[id]){gone[id]=1;info.textContent='⚠️ '+pn(id)+' heeft het spel verlaten';delete S.sel[id]}
  if(net.isHost){const used=new Set(Object.values(S.P).map(q=>q.c));for(const q of pl)if(!S.P[q.id]){let c=0;while(used.has(c)&&c<4)c++;used.add(c%4);S.P[q.id]=reg(q,c%4);net.sendTo(q.id,pack())}bcast(1)}draw()});
 const inp=input(st,[],k=>{if(k>='1'&&k<='9')put(+k);else if(k==='Backspace'||k==='Delete'||k==='0'||k===' ')put(0);else if(k==='h'||k==='H')act({k:'hint',i:sel});
  else if(k.startsWith('Arrow')){if(S.won)return;let s=sel<0?0:sel;const r=(s/9)|0,c=s%9;if(sel>=0){if(k==='ArrowUp')s=((r+8)%9)*9+c;if(k==='ArrowDown')s=((r+1)%9)*9+c;if(k==='ArrowLeft')s=r*9+(c+8)%9;if(k==='ArrowRight')s=r*9+(c+1)%9}select(s)}});
 tm=setInterval(()=>{if(!S.won)sc.textContent=sc.textContent.replace(/⏱ [\d:]+/,'⏱ '+fmt(secs()))},500);
 window.__dbg={sol:()=>sol.slice(),val:()=>S.v.slice(),giv:()=>giv.slice(),who:()=>S.w.slice(),P:()=>JSON.parse(JSON.stringify(S.P)),sel:()=>Object.assign({},S.sel),state:()=>({won:S.won,h:S.h,sel}),select,put,colOf};
 // ---------- bots (host): elke 6–12 s een vakje — liefst een fout of een vakje met veel ingevulde buren — selecteren en invullen, ~10% fout.
 // Via net.botAct({k:'sel'}/{k:'put'}) zoals een joiner; stoppen zodra het rooster klaar is (window.__botT = tempo voor tests).
 const bTm={};
 function botGo(id){clearTimeout(bTm[id]);bTm[id]=setTimeout(()=>{if(S.won||!net.isBot(id))return;
   const todo=[],bad=[];for(let i=0;i<81;i++)if(!giv[i]&&S.v[i]!==sol[i])(S.v[i]?bad:todo).push(i);
   if(bad.length){const i=bad[Math.floor(Math.random()*bad.length)];net.botAct(id,{k:'sel',i});net.botAct(id,{k:'put',i,d:sol[i]})}// eerst foute cijfers verbeteren
   else if(todo.length){const fil=i=>PEERS[i].filter(j=>S.v[j]).length+(S.v[i]?6:0)+Math.random()*6;todo.sort((a,b)=>fil(b)-fil(a));const i=todo[Math.random()<.7?0:Math.floor(Math.random()*todo.length)];
    let d=sol[i];if(Math.random()<.1){const w=[1,2,3,4,5,6,7,8,9].filter(x=>x!==sol[i]&&x!==S.v[i]);d=w[Math.floor(Math.random()*w.length)]}
    net.botAct(id,{k:'sel',i});net.botAct(id,{k:'put',i,d})}
   botGo(id)},(6000+Math.random()*6000)*(window.__botT>0?window.__botT:1))}
 if(net.isHost)net.bots().forEach(b=>botGo(b.id));
 draw();return()=>{for(const id in bTm)clearTimeout(bTm[id]);clearInterval(tm);clearTimeout(bt);clearTimeout(selT);inp.stop();off();offP();delete window.__dbg}}},
