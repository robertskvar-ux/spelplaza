{id:'pong',n:'Pong duel',e:'🏓',c:'Samen',g:'#373b44,#4286f4',min:2,max:2,bots:true,run(st,net){
 // Pong voor 2: host = linker peddel, joiner = rechter peddel, elk in zijn eigen spelerskleur. Host simuleert, joiner stuurt eigen peddelpositie en voorspelt die lokaal.
 const W=400,H=280,PH=60,PW=8,BR=6,WIN=7,me=net.myIndex(),HOST=net.isHost;
 const COL=['#2f80ed','#e5383b'],names=['…','…'],ids=[null,null];
 const hx=h=>[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0),mix=(h,t)=>'rgb('+hx(h).map(q=>Math.round(q+(255-q)*t)).join(',')+')',rgba=(h,a)=>'rgba('+hx(h).join(',')+','+a+')';
 const sc=E('div','sc'),c=mkCanvas(st,W,H),x=c.getContext('2d');st.prepend(sc);
 st.append(E('div','hint','Sleep op het veld of ▲ ▼ (toetsen/knoppen) · eerste tot 7 wint'));
 const inp=input(st,[['▲','ArrowUp'],['▼','ArrowDown']]);
 const clamp=(v,a,b)=>v<a?a:v>b?b:v;let gone=0,left='',ended=0;
 // S = gezaghebbende toestand (host): p=peddels y, b=bal, s=scores, cd=aftellen, w=winnaar, h=teller peddel-raak
 let S={p:[110,110],b:[W/2,H/2],s:[0,0],cd:3,w:-1,h:0},vx=0,vy=0,spd=0,dir=1;
 let my=110,sentY=-1,sendT=0,acc=0,trail=[],fl=0,last=null,tx=null,drag=0,t=0;
 const sub=()=>HOST?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten';
 function ov(big,small){if(!big){overlay(st,c,'');return}const o=overlay(st,c,' ');o.replaceChildren();const a=E('div');a.textContent=big;const b=E('div');b.style.cssText='font-size:15px;font-weight:600';b.textContent=small||'';o.append(a,b);o.style.pointerEvents='none'}
 function refresh(){if(gone)ov(left?'⚠️ '+left+' heeft het spel verlaten':'Wachten op speler…',sub());else ov('')}
 function line(){sc.replaceChildren();[0,1].forEach(i=>{const s=E('span');s.style.color=COL[i];s.textContent=names[i]+(i===me?' (jij)':'');sc.append(s);if(!i){const m=E('span');m.textContent='  '+S.s[0]+' – '+S.s[1]+'  ';sc.append(m)}});
  if(S.w>=0){const w=E('span');w.style.color='var(--mu)';w.textContent=' · 🏆 '+names[S.w]+' wint';sc.append(w)}}
 function conn(){net.players.forEach((p,i)=>{if(i>1)return;names[i]=net.pname(p);COL[i]=net.pcol(p);ids[i]=p.id});const was=gone;
  if(net.players.length<2){gone=1;if(!was)left=names[1-me]==='…'?'':names[1-me]}else{gone=0;left='';if(HOST&&was&&S.w<0)serve()}refresh();line()}
 function endCheck(){if(S.w<0||ended)return;ended=1;line();net.result({winner:ids[S.w],scores:{[ids[0]]:S.s[0],[ids[1]]:S.s[1]},text:'Eerste tot '+WIN+' punten'})}
 function serve(){S.b=[W/2,H/2];vx=vy=0;S.cd=3}
 function hit(i,by){const rel=clamp((by-(S.p[i]+PH/2))/(PH/2),-1,1),a=rel*1.05;spd=Math.min(640,spd*1.07);vx=Math.cos(a)*spd*(i?-1:1);vy=Math.sin(a)*spd;S.b[0]=i?W-18-BR:18+BR;S.h++}
 function point(i){S.s[i]++;dir=i?-1:1;if(S.s[i]>=WIN){S.w=i;S.b=[W/2,H/2];vx=vy=0}else serve()}
 function step(dt){const b=S.b;
  if(S.cd>0){S.cd-=dt;if(S.cd<=0){S.cd=0;const a=(Math.random()-.5)*.9;spd=230;vx=Math.cos(a)*spd*dir;vy=Math.sin(a)*spd}return}
  b[0]+=vx*dt;b[1]+=vy*dt;
  if(b[1]<BR){b[1]=BR;vy=Math.abs(vy)}else if(b[1]>H-BR){b[1]=H-BR;vy=-Math.abs(vy)}
  if(vx<0&&b[0]-BR<18&&b[0]-BR>4&&b[1]>S.p[0]-BR&&b[1]<S.p[0]+PH+BR)hit(0,b[1]);
  if(vx>0&&b[0]+BR>W-18&&b[0]+BR<W-4&&b[1]>S.p[1]-BR&&b[1]<S.p[1]+PH+BR)hit(1,b[1]);
  if(b[0]<-24)point(1);else if(b[0]>W+24)point(0)}
 const snap=()=>({h:S.h,a:S.s[me],o:S.s[1-me],cd:Math.ceil(S.cd),w:S.w});
 function fx(){const n=snap();if(last){
  if(n.h!==last.h){beep(620,.05,'square',.03);fl=1}
  if(n.a!==last.a){beep(n.w===me?880:660,.25,'triangle',.04);fl=.6;trail=[]}else if(n.o!==last.o){beep(180,.3,'sawtooth',.04);trail=[]}
  if(n.cd!==last.cd&&last.cd>0)beep(n.cd?440:700,n.cd?.06:.15,'square',.03);
  if(n.a!==last.a||n.o!==last.o)line()}last=n;endCheck()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(HOST){if(d.k==='i'&&from===net.players[1]?.id)S.p[1]=clamp(+d.y||0,0,H-PH)}
  else if(d.k==='s'&&Array.isArray(d.d)){const v=d.d;S={p:[v[0],v[1]],b:[v[2],v[3]],s:[v[4],v[5]],cd:v[6],w:v[7],h:v[8]}}});
 const offP=net.onPlayers(conn);
 const py=e=>{const r=c.getBoundingClientRect();return(e.clientY-r.top)*H/r.height-PH/2};
 c.onpointerdown=e=>{e.preventDefault();drag=1;tx=py(e);try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointermove=e=>{if(drag)tx=py(e)};c.onpointerup=c.onpointercancel=()=>{drag=0};
 function rr(px,py2,w,h,r){x.beginPath();x.roundRect(px,py2,w,h,r);x.fill()}
 function draw(){x.fillStyle='#0e1020';x.fillRect(0,0,W,H);
  x.strokeStyle='#262b52';x.lineWidth=3;x.setLineDash([8,10]);x.beginPath();x.moveTo(W/2,6);x.lineTo(W/2,H-6);x.stroke();x.setLineDash([]);
  x.font='bold 72px system-ui,sans-serif';x.textAlign='center';x.fillStyle=rgba(COL[0],.2);x.fillText(S.s[0],W/4,H/2+26);x.fillStyle=rgba(COL[1],.2);x.fillText(S.s[1],3*W/4,H/2+26);
  const yl=me===0?my:S.p[0],yr=me===1?my:S.p[1];
  [[10,yl,0],[W-18,yr,1]].forEach(([px,py2,i])=>{x.shadowColor=mix(COL[i],.25);x.shadowBlur=16;x.fillStyle=COL[i];rr(px,py2,PW,PH,4);x.shadowBlur=0;x.strokeStyle=mix(COL[i],.55);x.lineWidth=1.5;x.beginPath();x.roundRect(px+.75,py2+.75,PW-1.5,PH-1.5,3.5);x.stroke()});
  if(S.cd<=0&&S.w<0){trail.push([S.b[0],S.b[1]]);if(trail.length>9)trail.shift()}
  trail.forEach(([bx,by],i)=>{x.globalAlpha=(i+1)/trail.length*.35;x.fillStyle='#fff';x.beginPath();x.arc(bx,by,BR*(.4+.6*i/trail.length),0,7);x.fill()});x.globalAlpha=1;
  if(S.w<0){x.shadowColor='#fff';x.shadowBlur=10;x.fillStyle='#fff';x.beginPath();x.arc(S.b[0],S.b[1],BR,0,7);x.fill();x.shadowBlur=0}
  if(fl>0){x.fillStyle='rgba(255,255,255,'+(fl*.12)+')';x.fillRect(0,0,W,H)}
  if(S.cd>0&&!gone&&S.w<0){const n=Math.ceil(S.cd),f=S.cd-Math.floor(S.cd);x.fillStyle='#fff';x.font='bold '+(40+f*30)+'px system-ui,sans-serif';x.globalAlpha=.4+f*.6;x.fillText(n,W/2,H/2+20);x.globalAlpha=1;
   const to=dir>0?1:0;x.fillStyle=mix(COL[to],.45);x.font='bold 13px system-ui,sans-serif';x.fillText('Bal naar '+names[to],W/2,H/2+50)}}
 // ---- bot (alleen op de host): rechter peddel volgt de bal met reactietijd, beperkte snelheid en af en toe een misser; stuurt dezelfde {k:'i',y} als een joiner (10×/s) ----
 let bT=0,bY=H/2-PH/2,bDir=0,bWait=0,bAim=0,bSent=-1;
 function botTick(dt){const b=net.players[1];if(!b||!net.isBot(b.id)||gone||S.w>=0)return;bT+=dt;if(bT<.1)return;const st=bT;bT=0;
  const tow=vx>0&&S.cd<=0;if(tow!==bDir){bDir=tow;bWait=.15+Math.random()*.25;const miss=Math.random()<.16;bAim=miss?(Math.random()<.5?-1:1)*(PH*.62+Math.random()*PH*.45):(Math.random()-.5)*PH*.75}
  let ty=bY;if(bWait>0)bWait-=st;
  else if(tow){const tx=W-18-BR,L=H-2*BR;let y=S.b[1]+vy*Math.max(0,(tx-S.b[0])/vx)-BR;y=((y%(2*L))+2*L)%(2*L);if(y>L)y=2*L-y;ty=y+BR-PH/2+bAim}
  else ty=H/2-PH/2+(S.b[1]-H/2)*.3;
  const sp=250*st;bY=clamp(bY+clamp(ty-bY,-sp,sp),0,H-PH);if(Math.abs(bY-bSent)>=.5){bSent=bY;net.botAct(b.id,{k:'i',y:Math.round(bY*10)/10})}}
 const stop=loop(dt=>{t+=dt;if(fl>0)fl-=dt*3;
  const ku=inp.has('ArrowUp')||inp.has('w'),kd=inp.has('ArrowDown')||inp.has('s');if(ku||kd)tx=null;if(ku)my-=280*dt;if(kd)my+=280*dt;
  if(tx!=null){const d=tx-my;my+=Math.sign(d)*Math.min(Math.abs(d),1000*dt)}my=clamp(my,0,H-PH);
  if(HOST){S.p[0]=my;if(!gone&&S.w<0){step(dt);botTick(dt)}acc+=dt;if(acc>=.04){acc=Math.min(acc-.04,.04);net.send({k:'s',d:[Math.round(S.p[0]),Math.round(S.p[1]),Math.round(S.b[0]*10)/10,Math.round(S.b[1]*10)/10,S.s[0],S.s[1],Math.round(S.cd*100)/100,S.w,S.h]})}}
  else{sendT+=dt;if(Math.abs(my-sentY)>=.5&&sendT>=.04){sendT=0;sentY=my;net.send({k:'i',y:Math.round(my*10)/10})}}
  fx();draw()});
 conn();line();window.__dbg={s:()=>JSON.parse(JSON.stringify(S)),my:()=>my};
 return()=>{stop();inp.stop();off();offP();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;delete window.__dbg}}},
