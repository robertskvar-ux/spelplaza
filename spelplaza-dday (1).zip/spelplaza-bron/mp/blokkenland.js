{id:'blokkenland',n:'Blokkenland',e:'⛏️',c:'Samen',g:'#56ab2f,#3a7bd5',min:2,max:8,bots:false,restart:false,run(st,net){
 // Blokkenland online: samen bouwen in dezelfde blokkenwereld (seed van de ronde). De host keurt elke blokwijziging goed en stuurt ze door.
 // ===== engine (zelfde ontwerp als mp/blokkenland.js) =====
 const CS=16,NC=8,WS=CS*NC,WH=48,WL=14,WATER=7,BED=17,HW=.3,PH=1.8,EYE=1.62,TORCH=18,LAMP=19,STAIR=24,DOOR=32;
 const BL=[null,['Gras',[0,1,2],1,.45],['Aarde',[2,2,2],1,.4],['Steen',[3,3,3],1,1],['Zand',[4,4,4],1,.35],['Hout',[6,5,6],1,.7],['Bladeren',[7,7,7],2,.15],['Water',[8,8,8],3,0],['Glas',[9,9,9],2,.25],['Baksteen',[10,10,10],1,1],['Planken',[11,11,11],1,.55],['Sneeuw',[12,13,2],1,.3],['Rode wol',[14,14,14],1,.3],['Blauwe wol',[15,15,15],1,.3],['Gele wol',[16,16,16],1,.3],['Groene wol',[17,17,17],1,.3],['Witte wol',[18,18,18],1,.3],['Grondsteen',[19,19,19],1,1e9],
  ['Fakkel',[20,20,20],4,.05],['Lamp',[21,21,21],1,.3],['Rode bloem',[22,22,22],5,.02],['Gele bloem',[23,23,23],5,.02],['Blauwe bloem',[24,24,24],5,.02],['Witte bloem',[27,27,27],5,.02]];
 for(let o=0;o<4;o++)BL[24+o]=['Trap',[11,11,11],4,.55];for(let k=0;k<16;k++)BL[32+k]=['Deur',k<8?[25,25,25]:[26,26,26],4,.5];for(let l=1;l<=6;l++)BL[47+l]=['Water',[8,8,8],3,0];
 // per-block properties: OPQ hides neighbour faces + blocks light, SOL collides, SHD casts sky shadow, WAT water, LEM light emission, SHP box shapes (stairs/doors/torch)
 const OPQ=new Uint8Array(64),SHD=new Uint8Array(64),SOL=new Uint8Array(64),WAT=new Uint8Array(64),LEM=new Uint8Array(64),SHP=[];
 BL.forEach((b,i)=>{if(!b)return;const k=b[2];OPQ[i]=k===1?1:0;SOL[i]=k===1||k===2||(k===4&&i!==TORCH)?1:0;SHD[i]=(k===1||k===2||k===4)&&i!==8&&i!==TORCH?1:0;WAT[i]=k===3?1:0});LEM[TORCH]=7;LEM[LAMP]=8;
 const T3=3/16,DB=[[0,0,0,1,1,T3],[1-T3,0,0,1,1,1],[0,0,1-T3,1,1,1],[0,0,0,T3,1,1]],SU=[[.5,.5,0,1,1,1],[0,.5,0,.5,1,1],[0,.5,.5,1,1,1],[0,.5,0,1,1,.5]];
 SHP[TORCH]=[[7/16,0,7/16,9/16,10/16,9/16]];for(let o=0;o<4;o++)SHP[24+o]=[[0,0,0,1,.5,1],SU[o]];for(let k=0;k<16;k++)SHP[32+k]=[DB[k&4?((k&3)+1)&3:k&3]];
 const isDoor=b=>b>=32&&b<48,wl=b=>b===WATER?0:b-47,base=b=>b===1?2:b>=24&&b<28?STAIR:isDoor(b)?DOOR:b,LF=[0,.012,.025,.045,.08,.14,.24,.42,.75];
 const V=new Uint8Array(WS*WS*WH),HM=new Uint8Array(WS*WS),HS=new Uint8Array(WS*WS),LT=new Uint8Array(WS*WS*WH),I=(x,y,z)=>x+WS*(z+WS*y);
 const g=(x,y,z)=>x<0||z<0||x>=WS||z>=WS||y<0?BED:y>=WH?0:V[x+WS*(z+WS*y)];
 const mulb=s=>{let a=s>>>0;return()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}};
 // --- texture atlas: 16x16 pixel tiles drawn in code ---
 const AT=document.createElement('canvas');AT.width=256;AT.height=32;
 (()=>{const x=AT.getContext('2d'),im=x.createImageData(256,32),D=im.data,rr=mulb(424242),Q=()=>rr()*16|0;
  const hx=h=>[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];
  const put=(t,px,py,c,j=0,a=255)=>{const o=((((t>>4)*16+py)*256)+(t&15)*16+px)*4,k=(rr()-.5)*j;for(let i=0;i<3;i++)D[o+i]=Math.max(0,Math.min(255,c[i]+k));D[o+3]=a};
  const fill=(t,h,j)=>{const c=hx(h);for(let y=0;y<16;y++)for(let X=0;X<16;X++)put(t,X,y,c,j)};
  const dots=(t,h,n,j=10)=>{const c=hx(h);for(let i=0;i<n;i++)put(t,Q(),Q(),c,j)};
  fill(0,'#5fa83a',30);dots(0,'#467f2a',26);dots(0,'#7cc350',14);
  fill(2,'#8a5a3c',28);dots(2,'#6b4329',18);dots(2,'#a3734f',12);
  for(const t of [1,13]){fill(t,'#8a5a3c',28);dots(t,'#6b4329',14);for(let X=0;X<16;X++){const d=(t===1?3:4)+(rr()<.5)+(rr()<.25);for(let y=0;y<d;y++)put(t,X,y,hx(t===1?'#5fa83a':'#f2f6fb'),t===1?30:10);put(t,X,d,hx(t===1?'#467f2a':'#c9d6e3'),10)}}
  fill(3,'#8b8d90',22);dots(3,'#a6a8ab',16);for(let i=0;i<5;i++){let X=Q(),y=Q();for(let k=0;k<4;k++){put(3,X&15,y&15,hx('#696b6f'),8);X+=rr()<.5?1:0;y+=rr()<.6?1:-1}}
  fill(4,'#e3d39b',16);dots(4,'#c9b57a',22);dots(4,'#f1e5b8',10);
  for(let X=0;X<16;X++){const c=hx(X%5===0?'#4f3519':'#6d4a2a');for(let y=0;y<16;y++)put(5,X,y,c,rr()<.15?40:16)}
  for(let y=0;y<16;y++)for(let X=0;X<16;X++){const d=Math.max(Math.abs(X-7.5),Math.abs(y-7.5));put(6,X,y,hx(d>6.4?'#5a3d22':(d|0)%2?'#b48a57':'#9a7343'),14)}
  fill(7,'#3a8a2c',44);dots(7,'#5bb043',20);for(let i=0;i<26;i++)put(7,Q(),Q(),[0,0,0],0,0);
  fill(8,'#2f6fd2',12);for(let i=0;i<7;i++){const y=Q(),X=Q();for(let k=0;k<5;k++)put(8,(X+k)&15,y,hx('#6aa0ec'),10)}
  for(let y=0;y<16;y++)for(let X=0;X<16;X++){const e=X===0||y===0||X===15||y===15;put(9,X,y,hx(e?'#d3eefc':'#ffffff'),0,e?255:(X===y&&X>2&&X<7)||(X===y+1&&X>3&&X<6)||(X===y+7&&X>9&&X<13)?190:0)}
  for(let y=0;y<16;y++)for(let X=0;X<16;X++){const off=((y>>2)&1)*4,m=y%4===3||(X+off)%8===7;put(10,X,y,hx(m?'#c4b8a8':'#a24b3a'),m?8:24)}
  for(let y=0;y<16;y++)for(let X=0;X<16;X++){const row=y>>2,m=y%4===3||X===(row*5+3)%16;put(11,X,y,hx(m?'#7d5530':'#b8894f'),m?8:14)}
  fill(12,'#f3f7fb',8);dots(12,'#d8e3ee',18,4);
  ['#c8352e','#2f5fc4','#e8c22e','#4c9a32','#e9e9e9'].forEach((h,i)=>{const c=hx(h);for(let y=0;y<16;y++)for(let X=0;X<16;X++)put(14+i,X,y,(X+y*3)%5===0?c.map(v=>v*.86):c,12)});
  fill(19,'#4c4c52',60);dots(19,'#222226',30,10);
  // 20 fakkel (stick + flame in the middle columns; the thin box samples columns 7-8)
  for(let y=10;y<16;y++){put(20,7,y,hx('#86592f'),10);put(20,8,y,hx('#5e3d22'),10)}[['#fff8c4','#fff3a0'],['#ffe36a','#ffd84a'],['#ffb83a','#ffc94d'],['#e8772a','#f0a030']].forEach((r,i)=>{put(20,7,6+i,hx(r[0]),6);put(20,8,6+i,hx(r[1]),6)});
  // 21 lamp: warm glowing panel in a wooden frame
  for(let y=0;y<16;y++)for(let X=0;X<16;X++){const e=X===0||y===0||X===15||y===15,gl=X%5===0||y%5===0,c=Math.abs(X-7.5)+Math.abs(y-7.5);put(21,X,y,hx(e?'#6b4a2a':gl?'#e9a83e':c<5?'#fff8d2':'#ffdc78'),e?10:6)}
  // 22-24, 27 bloemen (cross sprites)
  [[22,'#e8343a','#ffd23d'],[23,'#ffd23d','#e8861e'],[24,'#4f7bea','#f6f6f6'],[27,'#f8f8f8','#f2c230']].forEach(([t,p,cc])=>{for(let y=7;y<16;y++){put(t,7,y,hx('#3f8f2c'),12);put(t,8,y,hx('#357a25'),12)}[[5,11],[6,11],[6,12],[9,12],[10,12],[10,11]].forEach(([X,y])=>put(t,X,y,hx('#4fa83a'),10));
   for(let y=1;y<9;y++)for(let X=3;X<13;X++){const dx=X-7.5,dy=y-4.5,d=Math.hypot(dx,dy);if(d<3.7&&(Math.abs(dx)<1.3||Math.abs(dy)<1.3||d<2.5))put(t,X,y,hx(d<1.2?cc:p),d<1.2?8:24)}});
  // 25/26 deur onder/boven (window = transparent pixels)
  for(const t of [25,26])for(let y=0;y<16;y++)for(let X=0;X<16;X++){const e=X<2||X>13||(t===26?y<2:y>13),win=t===26&&X>3&&X<12&&y>3&&y<11&&X!==7&&X!==8&&y!==7;if(!win)put(t,X,y,hx(e?'#6b4524':X%4===1?'#8d6036':'#ab7a42'),e?10:16)}
  for(let k=3;k<13;k++)put(25,k,15-k,hx('#7a4f2a'),6);put(25,12,1,hx('#f4d35e'));put(25,12,2,hx('#c99d2e'));put(25,11,1,hx('#f4d35e'));
  x.putImageData(im,0,0)})();
 const icon=b=>{const cv=document.createElement('canvas');cv.width=cv.height=36;const x=cv.getContext('2d'),t=BL[b][1],k=BL[b][2];x.imageSmoothingEnabled=false;const tl=(i,dx,dy,w,h)=>x.drawImage(AT,(i&15)*16,(i>>4)*16,16,16,dx,dy,w,h);
  if(k===5||b===TORCH){tl(t[1],2,2,32,32);return cv.toDataURL()}if(isDoor(b)){tl(26,9,0,18,18);tl(25,9,18,18,18);return cv.toDataURL()}
  const f=(i,a,bb,cc,d,e,ff,sh)=>{x.setTransform(a,bb,cc,d,e,ff);x.drawImage(AT,(i&15)*16,(i>>4)*16,16,16,0,0,16,16);if(sh){x.globalCompositeOperation='source-atop';x.fillStyle='rgba(0,0,0,'+sh+')';x.fillRect(0,0,16,16);x.globalCompositeOperation='source-over'}};
  f(t[0],1,-.5,1,.5,2,10,0);f(t[1],1,.5,0,1,2,10,.2);f(t[1],1,-.5,0,1,18,18,.38);if(b>=24&&b<28){x.setTransform(1,0,0,1,0,0);x.globalCompositeOperation='destination-out';x.beginPath();x.moveTo(2,10);x.lineTo(18,2);x.lineTo(34,10);x.lineTo(18,18);x.closePath();x.fillStyle='rgba(0,0,0,.55)';x.fill();x.globalCompositeOperation='source-over'}return cv.toDataURL()};
 const ICON=[],ico=b=>ICON[b]||(ICON[b]=icon(b));
 // --- world generation (seeded value noise + worm caves) ---
 const noise=seed=>{const h=(x,z)=>{let n=Math.imul(x,374761393)+Math.imul(z,668265263)+Math.imul(seed,982451653)|0;n=Math.imul(n^n>>>13,1274126177);return((n^n>>>16)>>>0)/4294967296};
  const v=(x,z)=>{const xi=Math.floor(x),zi=Math.floor(z),xf=x-xi,zf=z-zi,u=xf*xf*(3-2*xf),w=zf*zf*(3-2*zf),a=h(xi,zi),b=h(xi+1,zi),c=h(xi,zi+1),d=h(xi+1,zi+1);return a+(b-a)*u+(c-a)*w+(a-b-c+d)*u*w};
  return(x,z,o)=>{let s=0,a=1,t=0,f=1;for(let i=0;i<o;i++){s+=v(x*f+i*17.3,z*f-i*9.1)*a;t+=a;a*=.5;f*=2}return s/t}};
 function colH(x,z){const c=x+z*WS;let y=WH-1;while(y>0&&!SHD[V[I(x,y,z)]])y--;HM[c]=y;while(y>0&&!OPQ[V[I(x,y,z)]])y--;HS[c]=y}
 function gen(seed){V.fill(0);const n=noise(seed),m=noise(seed+7),r=mulb(seed^0x9e3779b9),H=new Uint8Array(WS*WS);
  for(let z=0;z<WS;z++)for(let x=0;x<WS;x++){const dx=(x-WS/2+.5)/(WS/2),dz=(z-WS/2+.5)/(WS/2),d=Math.max(Math.abs(dx),Math.abs(dz))*.55+Math.hypot(dx,dz)*.45,fall=Math.max(0,(d-.6)/.4);
   const mt=Math.max(0,m(x/70,z/70,3)-.48)*2.2;let h=Math.round(WL+1.5+(n(x/36,z/36,4)-.45)*15+mt*mt*28-fall*fall*22);h=Math.max(3,Math.min(WH-10,h));H[x+z*WS]=h;
   const beach=h<=WL+1,snow=h>=31-(n(x/5,z/5,1)*3|0);
   for(let y=0;y<=h;y++)V[I(x,y,z)]=y===0?BED:y===h?(beach?4:snow?11:1):y>h-4?(beach?4:snow?3:2):3;
   for(let y=h+1;y<=WL;y++)V[I(x,y,z)]=WATER}
  // caves: noise-steered worms; a few start at the surface (entrances). Never carve next to water so the sea stays put.
  const cr=mulb(seed^0x51ed27),cn=noise(seed+31);
  const carve=(cx,cy,cz,rad)=>{const R=Math.ceil(rad),r2=rad*rad;for(let y=Math.max(1,Math.round(cy)-R);y<=Math.min(WH-2,Math.round(cy)+R);y++)for(let z=Math.max(1,Math.round(cz)-R);z<=Math.min(WS-2,Math.round(cz)+R);z++)for(let x=Math.max(1,Math.round(cx)-R);x<=Math.min(WS-2,Math.round(cx)+R);x++){
   if((x-cx)**2+((y-cy)*1.3)**2+(z-cz)**2>r2)continue;const i=I(x,y,z),b=V[i];if(!b||b===WATER||b===BED)continue;if(V[i+1]===WATER||V[i-1]===WATER||V[i+WS]===WATER||V[i-WS]===WATER||V[i+WS*WS]===WATER)continue;V[i]=0}};
  for(let w=0;w<20;w++){let x=10+cr()*(WS-20),z=10+cr()*(WS-20);const surf=w<6,h0=H[(x|0)+(z|0)*WS];if(surf&&h0<=WL+2)continue;let y=surf?h0+1:5+cr()*14,yaw=cr()*6.283,pit=surf?-.6:(cr()-.5)*.3;
   const len=70+cr()*90;for(let s=0;s<len;s++){yaw+=(cn(s*.07,w*5.3,1)-.5)*.9;pit=surf&&s<9?-.6:pit*.85+(cn(w*3.1,s*.09,1)-.5)*.45;if(y<4)pit=Math.abs(pit)+.1;if(y>WH-14)pit=-Math.abs(pit)-.05;
    x+=Math.cos(yaw)*Math.cos(pit);z+=Math.sin(yaw)*Math.cos(pit);y+=Math.sin(pit)*.8;if(x<4||z<4||x>WS-4||z>WS-4)break;carve(x,y,z,1.3+cn(s*.05,w*2.7,2)*1.7)}}
  for(let gz=4;gz<WS-4;gz+=6)for(let gx=4;gx<WS-4;gx+=6){if(r()<.55)continue;const x=gx+(r()*5|0)-2,z=gz+(r()*5|0)-2,h=H[x+z*WS];if(V[I(x,h,z)]!==1||h>27||!V[I(x,h-1,z)])continue;
   const th=4+(r()*2|0),top=h+th;for(let y=h+1;y<=top;y++)V[I(x,y,z)]=5;
   for(let y=top-2;y<=top+1;y++){const rd=y<top?2:1;for(let a=-rd;a<=rd;a++)for(let b=-rd;b<=rd;b++){if(Math.abs(a)===rd&&Math.abs(b)===rd&&(y>=top||r()<.5))continue;const i=I(x+a,y,z+b);if(!V[i])V[i]=6}}}
  const fl=noise(seed+55);for(let z=1;z<WS-1;z++)for(let x=1;x<WS-1;x++){const h=H[x+z*WS],i=I(x,h,z);if(V[i]!==1||V[i+WS*WS])continue;if(fl(x/8,z/8,2)>.6&&r()<.2)V[i+WS*WS]=20+(fl(x/23+50,z/23,1)*7|0)%4}
  for(let z=0;z<WS;z++)for(let x=0;x<WS;x++)colH(x,z);LT.fill(0);LSRC.clear()}
 // --- block light: BFS flood fill (max 8), recomputed only around a change ---
 const LSRC=new Set,LQ=new Int32Array(65536);let lqh=0,lqt=0;
 const lpush=i=>{LQ[lqt&65535]=i;lqt++},lt=(j,l)=>{if(LT[j]<l&&!OPQ[V[j]]){LT[j]=l;lpush(j)}};
 function lflood(){while(lqh<lqt){const i=LQ[lqh&65535];lqh++;const l=LT[i];if(l<=1)continue;const x=i%WS,r=(i-x)/WS,z=r%WS,y=(r-z)/WS,nl=l-1;
  if(x>0)lt(i-1,nl);if(x<WS-1)lt(i+1,nl);if(z>0)lt(i-WS,nl);if(z<WS-1)lt(i+WS,nl);if(y>0)lt(i-WS*WS,nl);if(y<WH-1)lt(i+WS*WS,nl)}lqh=lqt=0}
 function relightAll(){LT.fill(0);for(const s of LSRC){LT[s]=LEM[V[s]];lpush(s)}lflood();lcnt++}
 let lcnt=0,lms=0;
 function relight(x,y,z,force){const t0=performance.now();let near=force;if(!near)for(const s of LSRC){const sx=s%WS,sz=(s/WS|0)%WS,sy=s/(WS*WS)|0;if(Math.abs(sx-x)<=15&&Math.abs(sy-y)<=15&&Math.abs(sz-z)<=15){near=1;break}}if(!near)return;
  const R=8,x0=Math.max(0,x-R),x1=Math.min(WS-1,x+R),y0=Math.max(0,y-R),y1=Math.min(WH-1,y+R),z0=Math.max(0,z-R),z1=Math.min(WS-1,z+R);
  for(let Y=y0;Y<=y1;Y++)for(let Z=z0;Z<=z1;Z++){const o=I(0,Y,Z);LT.fill(0,o+x0,o+x1+1)}
  for(let Y=y0-1;Y<=y1+1;Y++)for(let Z=z0-1;Z<=z1+1;Z++)for(let X=x0-1;X<=x1+1;X++){if(X>=x0&&X<=x1&&Y>=y0&&Y<=y1&&Z>=z0&&Z<=z1){X=x1;continue}if(X<0||Z<0||Y<0||X>=WS||Z>=WS||Y>=WH)continue;const j=I(X,Y,Z);if(LT[j]>1)lpush(j)}
  for(const s of LSRC){const sx=s%WS,sz=(s/WS|0)%WS,sy=s/(WS*WS)|0;if(sx>=x0&&sx<=x1&&sy>=y0&&sy<=y1&&sz>=z0&&sz<=z1){LT[s]=LEM[V[s]];lpush(s)}}lflood();
  for(let cz=Math.max(0,(z0-1)>>4);cz<=Math.min(NC-1,(z1+1)>>4);cz++)for(let cx=Math.max(0,(x0-1)>>4);cx<=Math.min(NC-1,(x1+1)>>4);cx++)DIRTY.add(cx+cz*NC);lcnt++;lms+=performance.now()-t0}
 const lightAt=(x,y,z)=>x<0||z<0||x>=WS||z>=WS||y<0||y>=WH?0:LT[I(x,y,z)];
 // sky access: open sky = 1, under leaves/overhang = .6, under solid ground it fades with depth (caves get dark)
 const skyAt=(x,y,z)=>{if(x<0||z<0||x>=WS||z>=WS||y>=WH)return 1;const c=x+z*WS;if(y>HM[c])return 1;if(y>HS[c])return .6;let d=HS[c]-y;
  if(x>0)d=Math.min(d,HS[c-1]-y);if(x<WS-1)d=Math.min(d,HS[c+1]-y);if(z>0)d=Math.min(d,HS[c-WS]-y);if(z<WS-1)d=Math.min(d,HS[c+WS]-y);return d<0?.5:Math.max(.018,.45-.08*d)};
 // --- chunk meshing: exposed faces, AO + face shade; vertex colour r = sky light, g = block light (combined with the day factor in the shader) ---
 const FN=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],FC=[[1,0,1,1,0,0,1,1,0,1,1,1],[0,0,0,0,0,1,0,1,1,0,1,0],[0,1,1,1,1,1,1,1,0,0,1,0],[0,0,0,1,0,0,1,0,1,0,0,1],[0,0,1,1,0,1,1,1,1,0,1,1],[1,0,0,0,0,0,0,1,0,1,1,0]],FS=[.8,.8,1,.5,.66,.66],AOL=[.48,.66,.83,1];
 const AOF=new Int8Array(216);for(let f=0;f<6;f++){const n=FN[f],na=n[0]?0:n[1]?1:2,ax=[0,1,2].filter(a=>a!==na);for(let k=0;k<4;k++){const su=FC[f][k*3+ax[0]]?1:-1,sv=FC[f][k*3+ax[1]]?1:-1;for(let j=0;j<3;j++){const v=n.slice();if(j!==1)v[ax[0]]+=su;if(j!==0)v[ax[1]]+=sv;AOF.set(v,(f*4+k)*9+j*3)}}}
 const UA=[],VA=[];for(let f=0;f<6;f++)for(let a=0;a<3;a++){const s=[0,1,2,3].map(k=>FC[f][k*3+a]).join('');if(s==='0110')UA[f]=[a,0];if(s==='1001')UA[f]=[a,1];if(s==='0011')VA[f]=[a,0];if(s==='1100')VA[f]=[a,1]}
 const mkS=n=>({p:new Float32Array(n*12),u:new Float32Array(n*8),c:new Float32Array(n*12),i:new Uint32Array(n*6),n:0,cap:n}),SO=mkS(16384),SW=mkS(4096);
 const grow=S=>{const o=mkS(S.cap*2);o.p.set(S.p);o.u.set(S.u);o.c.set(S.c);o.i.set(S.i);o.n=S.n;Object.assign(S,o)};
 function face(S,x,y,z,f,b,wh,emi){if(S.n>=S.cap)grow(S);const t=BL[b][1][f===2?0:f===3?2:1],u0=(t&15)/16+.0008,u1=((t&15)+1)/16-.0008,v1=1-(t>>4)/2-.003,v0=1-((t>>4)+1)/2+.003;
  const nx=x+FN[f][0],ny=y+FN[f][1],nz=z+FN[f][2],sk=skyAt(nx,ny,nz),bl=emi?1:LF[lightAt(nx,ny,nz)],C=FC[f],n=S.n,p=n*12,q=n*8;let a0=3,a1=3,a2=3,a3=3;
  for(let k=0;k<4;k++){let a=3;if(!wh&&!emi){const o=(f*4+k)*9,s1=OPQ[g(x+AOF[o],y+AOF[o+1],z+AOF[o+2])],s2=OPQ[g(x+AOF[o+3],y+AOF[o+4],z+AOF[o+5])],cn=OPQ[g(x+AOF[o+6],y+AOF[o+7],z+AOF[o+8])];a=s1&&s2?0:3-s1-s2-cn}
   const l=emi?1:FS[f]*AOL[a],pk=p+k*3;S.c[pk]=l*sk;S.c[pk+1]=l*bl;S.c[pk+2]=0;S.p[pk]=x+C[k*3];S.p[pk+1]=y+(wh&&C[k*3+1]?wh:C[k*3+1]);S.p[pk+2]=z+C[k*3+2];if(k===0)a0=a;else if(k===1)a1=a;else if(k===2)a2=a;else a3=a}
  S.u[q]=u0;S.u[q+1]=v0;S.u[q+2]=u1;S.u[q+3]=v0;S.u[q+4]=u1;S.u[q+5]=v1;S.u[q+6]=u0;S.u[q+7]=v1;
  const v=n*4,i=n*6,I_=S.i;if(a0+a2<a1+a3){I_[i]=v+1;I_[i+1]=v+2;I_[i+2]=v+3;I_[i+3]=v+1;I_[i+4]=v+3;I_[i+5]=v}else{I_[i]=v;I_[i+1]=v+1;I_[i+2]=v+2;I_[i+3]=v;I_[i+4]=v+2;I_[i+5]=v+3}S.n++}
 const tri=(S,v)=>{const i=S.n*6;S.i[i]=v;S.i[i+1]=v+1;S.i[i+2]=v+2;S.i[i+3]=v;S.i[i+4]=v+2;S.i[i+5]=v+3;S.n++};
 const BL3=[0,0,0];function boxQ(S,x,y,z,f,bx,t,cr,cg){if(S.n>=S.cap)grow(S);const C=FC[f],n=S.n,p=n*12,q=n*8,tu=(t&15)/16,tv=1-((t>>4)+1)/2,ua=UA[f],va=VA[f],L=BL3;
  for(let k=0;k<4;k++){const pk=p+k*3;L[0]=C[k*3]?bx[3]:bx[0];L[1]=C[k*3+1]?bx[4]:bx[1];L[2]=C[k*3+2]?bx[5]:bx[2];S.p[pk]=x+L[0];S.p[pk+1]=y+L[1];S.p[pk+2]=z+L[2];
   const u=ua[1]?1-L[ua[0]]:L[ua[0]],v=va[1]?1-L[va[0]]:L[va[0]];S.u[q+k*2]=tu+(.004+u*.992)/16;S.u[q+k*2+1]=tv+(.004+v*.992)/2;S.c[pk]=cr;S.c[pk+1]=cg;S.c[pk+2]=0}tri(S,n*4)}
 const XD=[[.15,.15,.85,.85],[.85,.15,.15,.85]];
 function crossQ(S,x,y,z,t,cr,cg){const tu=(t&15)/16,tv=1-((t>>4)+1)/2;for(let s=0;s<4;s++){if(S.n>=S.cap)grow(S);const n=S.n,p=n*12,q=n*8,d=XD[s&1],rv=s>1,x0=rv?d[2]:d[0],z0=rv?d[3]:d[1],x1=rv?d[0]:d[2],z1=rv?d[1]:d[3];
  for(let k=0;k<4;k++){const e=k===1||k===2,pk=p+k*3,uu=rv?!e:e;S.p[pk]=x+(e?x1:x0);S.p[pk+1]=y+(k>1?.94:0);S.p[pk+2]=z+(e?z1:z0);S.c[pk]=cr;S.c[pk+1]=cg;S.c[pk+2]=0;S.u[q+k*2]=tu+(uu?.996:.004)/16;S.u[q+k*2+1]=tv+(k>1?.996:.004)/2}tri(S,n*4)}}
 const onEdge=(bx,f)=>f===0?bx[3]===1:f===1?bx[0]===0:f===2?bx[4]===1:f===3?bx[1]===0:f===4?bx[5]===1:bx[2]===0;
 const CK=[];for(let i=0;i<NC*NC;i++)CK.push({o:null,w:null});let bms=0,bcnt=0;const DIRTY=new Set;
 function build(ci){const t0=performance.now(),x0=(ci%NC)*CS,z0=(ci/NC|0)*CS;SO.n=SW.n=0;
  for(let y=0;y<WH;y++)for(let z=z0;z<z0+CS;z++){let idx=x0+WS*(z+WS*y);for(let x=x0;x<x0+CS;x++,idx++){const b=V[idx];if(!b)continue;const k=BL[b][2];
   if(k===4){const sk=skyAt(x,y,z),bl=LEM[b]?1:LF[LT[idx]],tt=BL[b][1];for(const bx of SHP[b])for(let f=0;f<6;f++){if(onEdge(bx,f)&&OPQ[g(x+FN[f][0],y+FN[f][1],z+FN[f][2])])continue;const s=LEM[b]?1:FS[f];boxQ(SO,x,y,z,f,bx,tt[f===2?0:f===3?2:1],s*sk,s*bl)}continue}
   if(k===5){crossQ(SO,x,y,z,BL[b][1][1],.92*skyAt(x,y,z),.92*LF[LT[idx]]);continue}
   for(let f=0;f<6;f++){const nb=g(x+FN[f][0],y+FN[f][1],z+FN[f][2]);
    if(k===3){if(WAT[nb]||OPQ[nb]||(f===3&&nb))continue;face(SW,x,y,z,f,b,y<WH-1&&WAT[V[idx+WS*WS]]?1:.875-wl(b)*.115,0)}
    else{if(OPQ[nb]||(k===2&&nb===b&&b!==6))continue;face(SO,x,y,z,f,b,0,LEM[b])}}}}
  setG(ci,'o',SO,mO);setG(ci,'w',SW,mW);bms+=performance.now()-t0;bcnt++}
 function setG(ci,key,S,mat){const C=CK[ci];let m=C[key];if(!S.n){if(m){m.geometry.dispose();SC.remove(m);C[key]=null}return}
  const gg=new THREE.BufferGeometry(),nv=S.n*4,ni=S.n*6;gg.setAttribute('position',new THREE.BufferAttribute(S.p.slice(0,nv*3),3));gg.setAttribute('uv',new THREE.BufferAttribute(S.u.slice(0,nv*2),2));gg.setAttribute('color',new THREE.BufferAttribute(S.c.slice(0,nv*3),3));
  gg.setIndex(new THREE.BufferAttribute(nv>65535?S.i.slice(0,ni):new Uint16Array(S.i.subarray(0,ni)),1));gg.computeBoundingSphere();
  if(m){m.geometry.dispose();m.geometry=gg}else{m=new THREE.Mesh(gg,mat);m.matrixAutoUpdate=false;m.renderOrder=key==='w'?1:0;SC.add(m);C[key]=m}m.visible=chunkVis(ci)}
 let Q=[];const queueAll=()=>{Q=CK.map((_,i)=>i);sortQ()},sortQ=()=>{const px=cam.position.x/16,pz=cam.position.z/16,d=i=>((i%NC)+.5-px)**2+((i/NC|0)+.5-pz)**2;Q.sort((a,b)=>d(a)-d(b))};
 function rebuildAt(x,z){const cx=x>>4,cz=z>>4,lx=x&15,lz=z&15;for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++){if(dx&&!(dx<0?lx===0:lx===15))continue;if(dz&&!(dz<0?lz===0:lz===15))continue;const X=cx+dx,Z=cz+dz;if(X>=0&&Z>=0&&X<NC&&Z<NC)DIRTY.add(X+Z*NC)}}
 let fms=0,fcnt=0;function flush(){if(!DIRTY.size)return;const t0=performance.now();for(const ci of DIRTY){build(ci);const qi=Q.indexOf(ci);if(qi>=0)Q.splice(qi,1)}DIRTY.clear();fms=performance.now()-t0;fcnt++}
 function setB(x,y,z,b){if(x<0||z<0||x>=WS||z>=WS||y<1||y>=WH)return 0;const i=I(x,y,z),o=V[i];if(o===b)return 0;V[i]=b;colH(x,z);if(LEM[o])LSRC.delete(i);if(LEM[b])LSRC.add(i);
  if(LEM[o]||LEM[b]||OPQ[o]!==OPQ[b])relight(x,y,z,LEM[o]||LEM[b]);rebuildAt(x,z);return 1}
 // primary edit -> all cells it changes (doors are 2 high; torches/flowers fall when their support goes)
 function expand(x,y,z,b){const cu=g(x,y,z),L=[[x,y,z,b]];if(b>=32&&b<40)L.push([x,y+1,z,b+8]);
  else if(!b){if(isDoor(cu)){const oy=cu<40?y+1:y-1;if(isDoor(g(x,oy,z)))L.push([x,oy,z,0])}const up=g(x,y+1,z);if(up===TORCH||(up>=20&&up<24))L.push([x,y+1,z,0])}return L}
 function orient(b,x,y,z){const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),ax=Math.abs(fx)>Math.abs(fz),dn=g(x,y-1,z);
  if(b===STAIR)return 24+(ax?(fx>0?0:1):(fz>0?2:3));if(b===DOOR)return 32+(ax?(fx>0?3:1):(fz>0?0:2));if(b===TORCH||(b>=20&&b<24))return SOL[dn]&&!SHP[dn]?b:-1;return b}
 // --- flowing water: cellular, sources (7) spread up to 6 cells (ids 48..53 = level 1..6), down first ---
 const WQ=new Int32Array(16384),WF=new Uint8Array(WS*WS*WH),D4=[[1,0],[-1,0],[0,1],[0,-1]],N7=[[0,0,0],[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];let wqh=0,wqt=0,onW=null,wcnt=0;
 const wEnq=i=>{if(WF[i]||wqt-wqh>=16000)return;WF[i]=1;WQ[wqt&16383]=i;wqt++};
 function touchW(x,y,z){for(const d of N7){const X=x+d[0],Y=y+d[1],Z=z+d[2];if(X<0||Z<0||X>=WS||Z>=WS||Y<1||Y>=WH)continue;const i=I(X,Y,Z);if(WAT[V[i]])wEnq(i)}}
 function wSet(x,y,z,b){if(setB(x,y,z,b)){wcnt++;if(onW)onW(I(x,y,z),b);touchW(x,y,z)}}
 function wCell(i){const b=V[i];if(!WAT[b])return;const x=i%WS,r=(i-x)/WS,z=r%WS,y=(r-z)/WS,L=wl(b);
  const Lf=Math.max(1,L);if(L){const up=g(x,y+1,z);let e=WAT[up]?Math.max(1,wl(up)):9;for(const d of D4){const nb=g(x+d[0],y,z+d[1]);if(WAT[nb]){const l=wl(nb)+1;if(l<e)e=l}}if(e>6){wSet(x,y,z,0);return}if(e!==L){wSet(x,y,z,47+e);return}}
  const dn=g(x,y-1,z);if(!dn){wSet(x,y-1,z,47+Lf);return}if(WAT[dn]){if(wl(dn)>Lf)wSet(x,y-1,z,47+Lf);return}if(L>=6)return;
  for(const d of D4){const X=x+d[0],Z=z+d[1],nb=g(X,y,Z);if(!nb||(WAT[nb]&&wl(nb)>L+1))wSet(X,y,Z,48+L)}}
 function wTick(n){const end=Math.min(wqt,wqh+n);while(wqh<end){const i=WQ[wqh&16383];wqh++;WF[i]=0;wCell(i)}}
 const wReset=()=>{WF.fill(0);wqh=wqt=0};
 // --- renderer, sky, sun, clouds, ocean ---
 const TOUCH=(navigator.maxTouchPoints||0)>0||matchMedia('(pointer:coarse)').matches,PHONE=TOUCH&&Math.min(innerWidth,innerHeight)<760,VD=PHONE?3:4;
 const AW=Math.max(280,Math.min(980,(st.clientWidth||400)-34)),PORT=innerHeight>innerWidth*1.1,CWd=AW,CHt=Math.round(PORT?Math.min(AW*1.4,Math.max(320,innerHeight-380)):Math.max(320,Math.min(AW*.6,innerHeight-340)));
 const T=three(st,CWd,CHt,{fov:72,far:420}),SC=T.s,cam=T.cam,c=T.c;T.r.setPixelRatio(Math.min(devicePixelRatio||1,PHONE?1.5:2));T.r.setSize(CWd,CHt,false);c.style.width=CWd+'px';c.style.display='block';
 cam.rotation.order='YXZ';SC.add(cam);
 const tex=new THREE.CanvasTexture(AT);tex.magFilter=tex.minFilter=THREE.NearestFilter;tex.generateMipmaps=false;tex.colorSpace=THREE.SRGBColorSpace;
 const LU={value:1},lit=m=>{m.onBeforeCompile=s=>{s.uniforms.uDay=LU;s.fragmentShader='uniform float uDay;\n'+s.fragmentShader.replace('#include <color_fragment>','diffuseColor.rgb*=max(vec3(vColor.r*uDay),vColor.g*vec3(1.,.82,.56));')};return m};
 const mO=lit(new THREE.MeshBasicMaterial({map:tex,vertexColors:true,alphaTest:.5})),mW=lit(new THREE.MeshBasicMaterial({map:tex,vertexColors:true,transparent:true,opacity:.74,depthWrite:false,side:THREE.DoubleSide}));
 const FOGF=VD*16-4;SC.fog=new THREE.Fog(0xbfe3ff,FOGF*.55,FOGF);SC.background=new THREE.Color(0xbfe3ff);
 const domeG=new THREE.SphereGeometry(300,16,10),dc=new Float32Array(domeG.attributes.position.count*3);domeG.setAttribute('color',new THREE.BufferAttribute(dc,3));
 const dome=new THREE.Mesh(domeG,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.BackSide,fog:false,depthWrite:false}));dome.renderOrder=-3;SC.add(dome);
 const orb=(col,s)=>{const m=new THREE.Mesh(new THREE.PlaneGeometry(s,s),new THREE.MeshBasicMaterial({color:col,fog:false,depthWrite:false,transparent:true}));m.renderOrder=-2;SC.add(m);return m},sun=orb(0xfff3b0,34),moon=orb(0xe6edff,22);
 const cc=document.createElement('canvas');cc.width=cc.height=64;{const x=cc.getContext('2d'),n=noise(99);for(let y=0;y<64;y++)for(let X=0;X<64;X++)if(n(X/9,y/9,2)>.6){x.fillStyle='#fff';x.fillRect(X,y,1,1)}}
 const ctex=new THREE.CanvasTexture(cc);ctex.magFilter=ctex.minFilter=THREE.NearestFilter;ctex.generateMipmaps=false;ctex.wrapS=ctex.wrapT=THREE.RepeatWrapping;ctex.repeat.set(5,5);
 const cloudM=new THREE.MeshBasicMaterial({map:ctex,transparent:true,opacity:.82,depthWrite:false,side:THREE.DoubleSide}),clouds=new THREE.Mesh(new THREE.PlaneGeometry(WS*5,WS*5),cloudM);clouds.rotation.x=-Math.PI/2;clouds.position.set(WS/2,WH+18,WS/2);SC.add(clouds);
 const wc=document.createElement('canvas');wc.width=wc.height=16;wc.getContext('2d').drawImage(AT,128,0,16,16,0,0,16,16);const wtex=new THREE.CanvasTexture(wc);wtex.magFilter=wtex.minFilter=THREE.NearestFilter;wtex.generateMipmaps=false;wtex.wrapS=wtex.wrapT=THREE.RepeatWrapping;wtex.colorSpace=THREE.SRGBColorSpace;wtex.repeat.set(WS*2,WS*2);
 const ocean=new THREE.Mesh(new THREE.PlaneGeometry(WS*5,WS*5),new THREE.MeshBasicMaterial({map:wtex,color:0xbfd4ff}));ocean.rotation.x=-Math.PI/2;ocean.position.set(WS/2,WL+.86,WS/2);ocean.renderOrder=-1;
 // hole for the world: 4 strips instead of one plane
 ocean.geometry.dispose();{const L=WS*2,gs=[];for(const [w,d,x,z] of [[WS+2*L,L,WS/2,-L/2],[WS+2*L,L,WS/2,WS+L/2],[L,WS,-L/2,WS/2],[L,WS,WS+L/2,WS/2]]){const p=new THREE.PlaneGeometry(w,d);p.rotateX(-Math.PI/2);p.translate(x,0,z);const uv=p.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*w,uv.getY(i)*d);gs.push(p)}
  const pos=[],uvs=[],idx=[];let o=0;for(const p of gs){pos.push(...p.attributes.position.array);uvs.push(...p.attributes.uv.array);idx.push(...Array.from(p.index.array,i=>i+o));o+=p.attributes.position.count;p.dispose()}
  const og=new THREE.BufferGeometry();og.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));og.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));og.setIndex(idx);ocean.geometry=og;ocean.rotation.x=0;ocean.position.set(0,WL+.86,0);wtex.repeat.set(1,1)}
 SC.add(ocean);
 const amb=new THREE.AmbientLight(0xffffff,.7),dl=new THREE.DirectionalLight(0xffffff,2.2);SC.add(amb,dl,dl.target);
 const sel=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(1.006,1.006,1.006)),new THREE.LineBasicMaterial({color:0x101018,transparent:true,opacity:.6}));sel.visible=false;SC.add(sel);
 const hand=new THREE.Mesh(new THREE.BoxGeometry(.2,.2,.2),new THREE.MeshBasicMaterial({map:tex,vertexColors:true,alphaTest:.5,fog:false}));hand.position.set(.5,-.46,-.85);hand.rotation.set(.15,.7,0);hand.renderOrder=5;cam.add(hand);
 {const hc=new Float32Array(72);[.8,.8,1,.5,.66,.66].forEach((s,f)=>{for(let k=0;k<4;k++)hc.fill(s,f*12+k*3,f*12+k*3+3)});hand.geometry.setAttribute('color',new THREE.BufferAttribute(hc,3))}
 function setHand(b){hand.visible=!!b&&b<64;if(!hand.visible)return;const k=BL[b][2],thin=k===5||b===TORCH;hand.scale.set(thin?.3:1,thin?1.6:isDoor(b)?1.6:1,thin?.3:isDoor(b)?.3:1);const uv=hand.geometry.attributes.uv,t=BL[b][1];for(let f=0;f<6;f++){const ti=t[f===2?0:f===3?2:1],u0=(ti&15)/16,v0=1-((ti>>4)+1)/2;for(let k=0;k<4;k++){const i=f*4+k;uv.setXY(i,u0+(k&1)/16,v0+(k<2?.5:0))}}uv.needsUpdate=true}
 const cTop=new THREE.Color(),cHor=new THREE.Color(),DT=new THREE.Color(0x4f97e6),DH=new THREE.Color(0xc4e6ff),NT=new THREE.Color(0x03060f),NH=new THREE.Color(0x18203c),SH=new THREE.Color(0xf59a5a),sunD=new THREE.Vector3(),tv=new THREE.Vector3();let LIGHT=1;
 function sky(t){const a=t*Math.PI*2,sh=Math.sin(a),k=Math.max(0,Math.min(1,(sh+.1)/.35)),dusk=Math.max(0,1-Math.abs(sh)/.28);cTop.copy(NT).lerp(DT,k);cHor.copy(NH).lerp(DH,k).lerp(SH,dusk*.5);
  const P_=domeG.attributes.position;for(let i=0;i<P_.count;i++){const q=Math.max(0,Math.min(1,P_.getY(i)/300*1.7));dc[i*3]=cHor.r+(cTop.r-cHor.r)*q;dc[i*3+1]=cHor.g+(cTop.g-cHor.g)*q;dc[i*3+2]=cHor.b+(cTop.b-cHor.b)*q}domeG.attributes.color.needsUpdate=true;
  SC.fog.color.copy(cHor);SC.background.copy(cHor);LIGHT=.075+.925*k*k;LU.value=LIGHT;ocean.material.color.setRGB(.75*LIGHT,.83*LIGHT,LIGHT);cloudM.color.setScalar(.3+.7*k);
  sunD.set(Math.cos(a),sh,.3).normalize();amb.intensity=.25+.55*k;dl.intensity=.3+2*k;dl.position.copy(sunD).multiplyScalar(50);sun.material.opacity=Math.max(0,Math.min(1,sh*4+.6));moon.material.opacity=Math.max(0,Math.min(1,-sh*4+.6))}
 // --- player + entity physics (AABB vs block boxes, auto step-up onto half blocks), raycast ---
 const P={x:WS/2,y:30,z:WS/2,vx:0,vy:0,vz:0,yaw:0,pitch:-.2,gr:0,sg:0,fly:0,bob:0,hw:HW,h:PH,cy:30,kb:0};
 const FULL=[[0,0,0,1,1,1]],BX=[0,0,0,0,0,0];
 function ov(e){const x0=Math.floor(e.x-e.hw),x1=Math.floor(e.x+e.hw),y0=Math.floor(e.y),y1=Math.floor(e.y+e.h),z0=Math.floor(e.z-e.hw),z1=Math.floor(e.z+e.hw);
  for(let y=y0;y<=y1;y++)for(let z=z0;z<=z1;z++)for(let x=x0;x<=x1;x++){const b=g(x,y,z);if(!SOL[b])continue;for(const s of SHP[b]||FULL){const a0=x+s[0],b0=y+s[1],c0=z+s[2],a1=x+s[3],b1=y+s[4],c1=z+s[5];
   if(e.x+e.hw>a0&&e.x-e.hw<a1&&e.y+e.h>b0&&e.y<b1&&e.z+e.hw>c0&&e.z-e.hw<c1){BX[0]=a0;BX[1]=b0;BX[2]=c0;BX[3]=a1;BX[4]=b1;BX[5]=c1;return 1}}}return 0}
 function emv(e,ax,d){if(!d)return 0;if(ax===0)e.x+=d;else if(ax===1)e.y+=d;else e.z+=d;if(!ov(e))return 0;
  if(ax!==1&&e.sg&&BX[4]-e.y<=.56&&BX[4]>e.y){const oy=e.y;e.y=BX[4]+1e-3;if(!ov(e))return 0;e.y=oy;ov(e)}
  if(ax===0){e.x=d>0?BX[0]-e.hw-1e-3:BX[3]+e.hw+1e-3;e.vx=0}else if(ax===1)e.y=d>0?BX[1]-e.h-1e-3:BX[4];else{e.z=d>0?BX[2]-e.hw-1e-3:BX[5]+e.hw+1e-3;e.vz=0}return 1}
 const mv=(ax,d)=>emv(P,ax,d);
 const HIT={x:0,y:0,z:0,px:0,py:0,pz:0,b:0,t:0};
 function ray(ox,oy,oz,dx,dy,dz,max){let x=Math.floor(ox),y=Math.floor(oy),z=Math.floor(oz),px=x,py=y,pz=z;const sx=dx>0?1:-1,sy=dy>0?1:-1,sz=dz>0?1:-1,tx=dx?Math.abs(1/dx):1e9,ty=dy?Math.abs(1/dy):1e9,tz=dz?Math.abs(1/dz):1e9;
  let mx=dx?(dx>0?x+1-ox:ox-x)*tx:1e9,my=dy?(dy>0?y+1-oy:oy-y)*ty:1e9,mz=dz?(dz>0?z+1-oz:oz-z)*tz:1e9,t=0;
  while(t<=max){if(x<0||z<0||x>=WS||z>=WS||y<0)return null;const b=y<WH?V[I(x,y,z)]:0;if(b&&!WAT[b]){HIT.x=x;HIT.y=y;HIT.z=z;HIT.px=px;HIT.py=py;HIT.pz=pz;HIT.b=b;HIT.t=t;return HIT}
   px=x;py=y;pz=z;if(mx<my&&mx<mz){x+=sx;t=mx;mx+=tx}else if(my<mz){y+=sy;t=my;my+=ty}else{z+=sz;t=mz;mz+=tz}}return null}
 const inPl=(x,y,z,qx,qy,qz)=>x+1>qx-HW&&x<qx+HW&&y+1>qy&&y<qy+PH&&z+1>qz-HW&&z<qz+HW;
 function spawnPt(cx=WS/2,cz=WS/2){for(let r=0;r<40;r++)for(let a=0;a<8*r+1;a++){const x=Math.max(1,Math.min(WS-2,Math.floor(cx)+Math.round(Math.cos(a/(8*r+1)*6.283)*r))),z=Math.max(1,Math.min(WS-2,Math.floor(cz)+Math.round(Math.sin(a/(8*r+1)*6.283)*r))),h=HM[x+z*WS];if(h>WL&&V[I(x,h,z)]!==6&&!WAT[V[I(x,h,z)]]&&!SHP[V[I(x,h,z)]])return[x+.5,h+1,z+.5]}return[WS/2+.5,WH-2,WS/2+.5]}
 // --- entities: blocky animals (koe, varken, kip) + glowing night slimes; simple AABB physics, sleep when far ---
 const SPC={koe:{hw:.42,h:1.35,sp:1.1,hp:3,drop:102,legY:.62,legs:[[.28,.48],[-.28,.48],[.28,-.48],[-.28,-.48]],
   body:[[.9,.7,1.35,0,.95,0,'#f4f1ea'],[.92,.32,.42,0,1.05,.18,'#2e2a28'],[.92,.26,.3,0,.82,-.36,'#2e2a28'],[.93,.22,.25,0,1.18,-.42,'#2e2a28'],[.6,.55,.5,0,1.18,.86,'#f4f1ea'],[.52,.26,.14,0,1.0,1.13,'#eaa7a2'],[.1,.16,.1,.22,1.5,.8,'#efe3c4'],[.1,.16,.1,-.22,1.5,.8,'#efe3c4'],[.09,.1,.04,.17,1.26,1.115,'#1d1d22'],[.09,.1,.04,-.17,1.26,1.115,'#1d1d22'],[.2,.12,.2,0,.55,-.05,'#f0b8b4'],[.06,.4,.06,0,1.05,-.7,'#2e2a28']],
   leg:[[.22,.5,.22,0,-.25,0,'#f4f1ea'],[.23,.12,.23,0,-.56,0,'#3a302a']]},
  varken:{hw:.38,h:.95,sp:1.2,hp:3,drop:103,legY:.38,legs:[[.22,.34],[-.22,.34],[.22,-.34],[-.22,-.34]],
   body:[[.75,.58,1.05,0,.66,0,'#f3a9b7'],[.56,.5,.45,0,.76,.7,'#f3a9b7'],[.3,.2,.1,0,.68,.97,'#e5869a'],[.06,.07,.02,.07,.68,1.025,'#7a2f42'],[.06,.07,.02,-.07,.68,1.025,'#7a2f42'],[.08,.09,.03,.17,.88,.93,'#1d1d22'],[.08,.09,.03,-.17,.88,.93,'#1d1d22'],[.14,.12,.08,.19,1.03,.62,'#e994a6'],[.14,.12,.08,-.19,1.03,.62,'#e994a6'],[.08,.08,.12,0,.82,-.56,'#e994a6']],leg:[[.2,.38,.2,0,-.19,0,'#ef9fae']]},
  kip:{hw:.24,h:.75,sp:1.35,hp:2,drop:101,legY:.32,legs:[[.1,0],[-.1,0]],
   body:[[.4,.38,.5,0,.5,0,'#f8f6f0'],[.3,.26,.12,0,.66,-.3,'#efece4'],[.28,.32,.28,0,.84,.27,'#f8f6f0'],[.14,.08,.14,0,.81,.47,'#f2a33a'],[.08,.12,.16,0,1.05,.27,'#d8322e'],[.08,.1,.06,0,.7,.43,'#d8322e'],[.03,.06,.06,.145,.9,.33,'#1d1d22'],[.03,.06,.06,-.145,.9,.33,'#1d1d22'],[.06,.24,.34,.22,.52,0,'#e9e5da'],[.06,.24,.34,-.22,.52,0,'#e9e5da']],leg:[[.07,.32,.07,0,-.16,0,'#f2a33a']]},
  slijm:{hw:.4,h:.8,sp:3,hp:2,drop:104,body:[[.46,.42,.46,0,.36,0,'#36c95e'],[.14,.2,.04,.17,.52,.43,'#0f3a1d'],[.14,.2,.04,-.17,.52,.43,'#0f3a1d'],[.05,.07,.045,.13,.57,.445,'#eafff0'],[.05,.07,.045,-.21,.57,.445,'#eafff0'],[.22,.06,.04,0,.3,.43,'#0f3a1d']]}};
 const SPN=['koe','varken','kip','slijm'],EFS=[.8,.8,1,.55,.7,.7],MG={};
 function mdl(parts){const pos=[],col=[],idx=[],cl=new THREE.Color();for(const [w,h,d,x,y,z,hx] of parts){cl.set(hx);for(let f=0;f<6;f++){const C=FC[f],o=pos.length/3;for(let k=0;k<4;k++){pos.push(x+(C[k*3]-.5)*w,y+(C[k*3+1]-.5)*h,z+(C[k*3+2]-.5)*d);col.push(cl.r*EFS[f],cl.g*EFS[f],cl.b*EFS[f])}idx.push(o,o+1,o+2,o,o+2,o+3)}}
  const gg=new THREE.BufferGeometry();gg.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));gg.setAttribute('color',new THREE.Float32BufferAttribute(col,3));gg.setIndex(idx);gg.computeBoundingSphere();return gg}
 const mg=(sp,k)=>MG[sp+k]||(MG[sp+k]=k==='l'?mdl(SPC[sp].leg):mdl(SPC[sp].body));
 const halo=(()=>{const cv=document.createElement('canvas');cv.width=cv.height=64;const x=cv.getContext('2d'),gr=x.createRadialGradient(32,32,2,32,32,32);gr.addColorStop(0,'rgba(150,255,170,.75)');gr.addColorStop(.45,'rgba(90,255,140,.22)');gr.addColorStop(1,'rgba(60,255,120,0)');x.fillStyle=gr;x.fillRect(0,0,64,64);return new THREE.CanvasTexture(cv)})();
 const slimeOG=new THREE.BoxGeometry(.84,.84,.84);slimeOG.translate(0,.42,0);
 const ENT=[];let EID=1;
 function mkEnt(sp,x,y,z){const S=SPC[sp],G=new THREE.Group(),e={id:EID++,sp,x,y,z,vx:0,vy:0,vz:0,yaw:Math.random()*6.283,ry:0,hw:S.hw,h:S.h,gr:0,sg:0,hp:S.hp,t:Math.random()*2,wx:0,wz:0,flee:0,ph:0,G,legs:[],m:null,die:0,hurt:0,sq:1,tx:x,ty:y,tz:z,ta:0};e.ry=e.yaw;e.ta=e.yaw;
  if(sp==='slijm'){const m=new THREE.MeshBasicMaterial({vertexColors:true}),B=new THREE.Group();B.add(new THREE.Mesh(mg(sp,'b'),m));const om=new THREE.MeshBasicMaterial({color:0x8dffb0,transparent:true,opacity:.5,depthWrite:false});B.add(new THREE.Mesh(slimeOG,om));
   const hs=new THREE.Sprite(new THREE.SpriteMaterial({map:halo,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true}));hs.scale.set(2.4,2.4,1);hs.position.y=.45;G.add(B,hs);e.B=B;e.m=m;e.m2=om;e.m3=hs.material}
  else{const m=new THREE.MeshBasicMaterial({vertexColors:true});e.m=m;G.add(new THREE.Mesh(mg(sp,'b'),m));for(const [lx,lz] of S.legs){const q=new THREE.Mesh(mg(sp,'l'),m);q.position.set(lx,S.legY,lz);G.add(q);e.legs.push(q)}}
  G.position.set(x,y,z);SC.add(G);ENT.push(e);return e}
 function rmEnt(e){SC.remove(e.G);e.m&&e.m.dispose();e.m2&&e.m2.dispose();e.m3&&e.m3.dispose();const k=ENT.indexOf(e);if(k>=0)ENT.splice(k,1)}
 const clearEnts=()=>{while(ENT.length)rmEnt(ENT[0])};
 function estep(e,dt){const inW=WAT[g(Math.floor(e.x),Math.floor(e.y+.3),Math.floor(e.z))];e.vy=inW?Math.min(e.vy+9*dt,1.8):Math.max(e.vy-25*dt,-30);
  e.sg=e.gr;e.gr=0;const n=Math.ceil(Math.max(Math.abs(e.vx),Math.abs(e.vy),Math.abs(e.vz))*dt/.3)||1,sd=dt/n;for(let i=0;i<n;i++){emv(e,0,e.vx*sd);emv(e,2,e.vz*sd);if(emv(e,1,e.vy*sd)){if(e.vy<0)e.gr=1;e.vy=0}}}
 function aiAnimal(e,dt,px,pz){const S=SPC[e.sp];let sp=S.sp;e.t-=dt;
  if(e.flee>0){e.flee-=dt;const dx=e.x-px,dz=e.z-pz,l=Math.hypot(dx,dz)||1;if(e.t<=0){e.wx=dx/l;e.wz=dz/l}sp*=2.8}
  else if(e.t<=0){e.t=2+Math.random()*4;if(Math.random()<.35)e.wx=e.wz=0;else{const a=Math.random()*6.283;e.wx=Math.sin(a);e.wz=Math.cos(a)}}
  let tx=e.wx*sp,tz=e.wz*sp;
  if(e.wx||e.wz){const ax=Math.floor(e.x+e.wx*(e.hw+.45)),az=Math.floor(e.z+e.wz*(e.hw+.45)),fy=Math.floor(e.y+.05);
   if(e.gr&&(WAT[g(ax,fy,az)]||WAT[g(ax,fy-1,az)]||(!SOL[g(ax,fy,az)]&&!SOL[g(ax,fy-1,az)]&&!SOL[g(ax,fy-2,az)]))){const a=Math.atan2(e.wx,e.wz)+Math.PI*(.6+Math.random()*.8);e.wx=Math.sin(a);e.wz=Math.cos(a);e.t=e.flee>0?.6:1.5+Math.random()*2;tx=tz=0}
   else if(e.gr&&SOL[g(ax,fy,az)]&&!SHP[g(ax,fy,az)]&&!SOL[g(ax,fy+1,az)]&&!SOL[g(ax,fy+2,az)])e.vy=6.6;e.ta=Math.atan2(e.wx,e.wz)}
  const k=Math.min(1,dt*(e.gr?8:2));e.vx+=(tx-e.vx)*k;e.vz+=(tz-e.vz)*k}
 function aiSlime(e,dt,px,pz){e.t-=dt;if(e.gr){const f=Math.max(0,1-dt*12);e.vx*=f;e.vz*=f;if(e.t<=0){e.t=.7+Math.random()*.9;const dx=px-e.x,dz=pz-e.z,l=Math.hypot(dx,dz),ch=l<22,a=ch?Math.atan2(dx,dz)+(Math.random()-.5)*.5:Math.random()*6.283,s=ch?Math.min(3.4,l*1.6):1.5;e.ta=a;e.vx=Math.sin(a)*s;e.vz=Math.cos(a)*s;e.vy=6.8;e.sq=.7}}}
 function visE(e,dt){const sp=Math.hypot(e.x-(e.lx??e.x),e.z-(e.lz??e.z))/Math.max(dt,1e-3);e.lx=e.x;e.lz=e.z;e.ph+=sp*dt*5;let d=e.ta-e.ry;d=Math.atan2(Math.sin(d),Math.cos(d));e.ry+=d*Math.min(1,dt*9);
  e.G.position.set(e.x,e.y,e.z);e.G.rotation.y=e.ry;if(e.legs.length){const sw=Math.sin(e.ph)*Math.min(1,sp/1.2)*.6;for(let k=0;k<e.legs.length;k++)e.legs[k].rotation.x=k===0||k===3?sw:-sw}
  if(e.B){const tg=e.gr?1:1.12;e.sq+=(tg-e.sq)*Math.min(1,dt*7);const w=1+(1-e.sq)*.6;e.B.scale.set(w,e.sq,w);if(e.hurt>0){e.hurt-=dt;e.m.color.setRGB(1,.5,.5)}else e.m.color.setScalar(1);return}
  const xi=Math.floor(e.x),yi=Math.floor(e.y+.5),zi=Math.floor(e.z),l=Math.max(.12,Math.min(1,Math.max(skyAt(xi,yi,zi)*LIGHT,LF[lightAt(xi,yi,zi)])*1.05));if(e.hurt>0){e.hurt-=dt;e.m.color.setRGB(l,l*.55,l*.55)}else e.m.color.setScalar(l)}
 function hitEnt(e,ax,az,catchable){if(e.die)return 0;e.hp--;e.hurt=.3;const dx=e.x-ax,dz=e.z-az,l=Math.hypot(dx,dz)||1;e.vx=dx/l*4.5;e.vz=dz/l*4.5;e.vy=4.6;e.gr=0;if(e.sp!=='slijm'){e.flee=3.5;e.t=0}else e.t=1;
  if(e.hp<=0){if(catchable){e.die=.45;return 2}e.hp=SPC[e.sp].hp}return 1}
 function rayEnt(ox,oy,oz,dx,dy,dz,max){let best=null,bt=max;for(const e of ENT){if(e.die||!e.G.visible)continue;const m=.08;let t0=0,t1=bt;
   const sl=(o,d,a,b)=>{if(Math.abs(d)<1e-9)return o>=a&&o<=b;let p=(a-o)/d,q=(b-o)/d;if(p>q){const s=p;p=q;q=s}if(p>t0)t0=p;if(q<t1)t1=q;return t0<=t1};
   if(sl(ox,dx,e.x-e.hw-m,e.x+e.hw+m)&&sl(oy,dy,e.y,e.y+e.h+m)&&sl(oz,dz,e.z-e.hw-m,e.z+e.hw+m)&&t0<bt){bt=t0;best=e}}return best}
 const PT=[];{const pg=new THREE.BoxGeometry(.13,.13,.13);for(let i=0;i<24;i++){const m=new THREE.Mesh(pg,new THREE.MeshBasicMaterial({color:0xffffff,transparent:true}));m.visible=false;SC.add(m);PT.push({m,vx:0,vy:0,vz:0,l:0})}}
 function puff(x,y,z,col,n=8){let k=0;for(const p of PT){if(p.l>0)continue;p.l=.5+Math.random()*.4;p.m.visible=true;p.m.position.set(x+(Math.random()-.5)*.5,y+Math.random()*.5,z+(Math.random()-.5)*.5);p.vx=(Math.random()-.5)*3;p.vy=1.5+Math.random()*2.5;p.vz=(Math.random()-.5)*3;p.m.material.color.set(col);if(++k>=n)break}}
 function ptStep(dt){for(const p of PT){if(p.l<=0)continue;p.l-=dt;if(p.l<=0){p.m.visible=false;continue}p.vy-=7*dt;p.m.position.x+=p.vx*dt;p.m.position.y+=p.vy*dt;p.m.position.z+=p.vz*dt;p.m.scale.setScalar(Math.min(1,p.l*2.2));p.m.material.opacity=Math.min(1,p.l*2.5)}}
 function grassSpot(px,pz,r0,r1){for(let k=0;k<30;k++){const a=Math.random()*6.283,r=r0+Math.random()*(r1-r0),x=Math.floor(px+Math.cos(a)*r),z=Math.floor(pz+Math.sin(a)*r);if(x<2||z<2||x>=WS-2||z>=WS-2)continue;const h=HM[x+z*WS];if(V[I(x,h,z)]===1&&HS[x+z*WS]===h&&!SOL[g(x,h+1,z)]&&!g(x,h+2,z))return[x+.5,h+1,z+.5]}return null}
 // --- input ---
 const Kd=new Set();let joy=null,jx=0,jy=0,tUp=0,tDn=0,hB=0,hP=0,lastSp=0,mouse=null,locked=0;
 const GK=['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','KeyW','KeyA','KeyS','KeyD','ShiftLeft','ShiftRight','KeyX','KeyC','KeyF','KeyE'];
 const kd=e=>{if(e.target&&e.target.tagName==='INPUT')return;if(GK.includes(e.code))e.preventDefault();if(e.repeat)return;Kd.add(e.code);press(e.code)},ku=e=>Kd.delete(e.code),blur=()=>{Kd.clear();hB=hP=0};
 addEventListener('keydown',kd);addEventListener('keyup',ku);addEventListener('blur',blur);
 const look=(dx,dy,s)=>{P.yaw-=dx*s;P.pitch=Math.max(-1.55,Math.min(1.55,P.pitch-dy*s))};
 c.oncontextmenu=e=>e.preventDefault();
 c.onpointerdown=e=>{e.preventDefault();if(!playing())return;try{c.setPointerCapture(e.pointerId)}catch(x){}if(locked){if(e.button===2)hP=1;else hB=1;return}
  const r=c.getBoundingClientRect();if(e.pointerType==='touch'){if(e.clientX-r.left<r.width*.45&&!joy){joy={id:e.pointerId,x:e.clientX,y:e.clientY};jx=jy=0;JOY.style.display='block';JOY.style.left=(e.clientX-r.left)+'px';JOY.style.top=(e.clientY-r.top)+'px';KN.style.transform=''}else mouse={id:e.pointerId,x:e.clientX,y:e.clientY,t:performance.now(),look:1,touch:1}}
  else mouse={id:e.pointerId,x:e.clientX,y:e.clientY,x0:e.clientX,y0:e.clientY,t:performance.now(),look:0,btn:e.button}};
 c.onpointermove=e=>{if(joy&&e.pointerId===joy.id){let dx=e.clientX-joy.x,dy=e.clientY-joy.y;const l=Math.hypot(dx,dy);if(l>48){dx*=48/l;dy*=48/l}jx=dx/48;jy=dy/48;KN.style.transform=`translate(${dx}px,${dy}px)`;return}
  if(mouse&&e.pointerId===mouse.id){if(!mouse.look&&Math.hypot(e.clientX-mouse.x0,e.clientY-mouse.y0)>5)mouse.look=1;if(mouse.look)look(e.clientX-mouse.x,e.clientY-mouse.y,mouse.touch?.0075:.0055);mouse.x=e.clientX;mouse.y=e.clientY}};
 c.onpointerup=c.onpointercancel=e=>{if(locked){hB=hP=0;return}if(joy&&e.pointerId===joy.id){joy=null;jx=jy=0;JOY.style.display='none';return}
  if(mouse&&e.pointerId===mouse.id){if(!mouse.look&&!mouse.touch&&performance.now()-mouse.t<220&&e.type==='pointerup'){if(mouse.btn===2)place();else brk(1)}mouse=null}};
 const wheel=e=>{if(!playing())return;e.preventDefault();pick((selI+(e.deltaY>0?1:8))%9)};c.addEventListener('wheel',wheel,{passive:false});
 const plc=()=>{locked=document.pointerLockElement===c;if(!locked)hB=hP=0},pmv=e=>{if(locked)look(e.movementX,e.movementY,.0028)};document.addEventListener('pointerlockchange',plc);document.addEventListener('mousemove',pmv);
 // --- HUD DOM ---
 const css=E('style');css.textContent=`.bk-w{position:relative;display:inline-block;max-width:100%;line-height:0;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}
.bk-x{position:absolute;left:50%;top:50%;width:20px;height:20px;margin:-10px 0 0 -10px;pointer-events:none;opacity:.9}.bk-x:before,.bk-x:after{content:'';position:absolute;background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.35)}.bk-x:before{left:9px;top:0;width:2px;height:20px}.bk-x:after{top:9px;left:0;height:2px;width:20px}.bk-x.en:before,.bk-x.en:after{background:#ffd166}
.bk-pb{position:absolute;left:50%;top:50%;width:48px;height:6px;margin:18px 0 0 -24px;background:rgba(0,0,0,.5);border-radius:3px;overflow:hidden;display:none;pointer-events:none}.bk-pb i{display:block;height:100%;background:#ffd166;width:0}
.bk-tb{position:absolute;right:8px;bottom:8px;display:grid;grid-template-columns:repeat(2,56px);gap:8px;line-height:1}.bk-tb button{width:56px;height:56px;border-radius:50%;border:2px solid rgba(255,255,255,.55);background:rgba(14,16,32,.42);color:#fff;font-size:26px;padding:0;touch-action:none}.bk-tb button.on{background:rgba(255,209,102,.55)}.bk-tb button:active{background:rgba(255,255,255,.35)}
.bk-joy{position:absolute;width:112px;height:112px;margin:-56px 0 0 -56px;border-radius:50%;border:2px solid rgba(255,255,255,.5);background:rgba(255,255,255,.1);pointer-events:none;display:none}.bk-joy i{position:absolute;left:50%;top:50%;width:46px;height:46px;margin:-23px;border-radius:50%;background:rgba(255,255,255,.55)}
.bk-hb{display:flex;gap:4px;justify-content:center;margin:8px auto 0;width:${CWd}px;max-width:100%}.bk-s{position:relative;flex:1 1 0;max-width:50px;aspect-ratio:1;border-radius:9px;border:2px solid var(--ln,#8884);background:var(--bg);padding:3px;cursor:pointer;touch-action:manipulation}
.bk-s.on{border-color:#f5b82e;box-shadow:0 0 0 2px #f5b82e88}.bk-s img{width:100%;height:100%;image-rendering:pixelated;display:block}.bk-s.no img{opacity:.3}.bk-s b{position:absolute;right:3px;bottom:1px;font-size:11px;color:var(--tx)}.bk-s u{position:absolute;left:4px;top:2px;font-size:9px;color:var(--mu);text-decoration:none}
.bk-row{display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-top:8px}.bk-row .btn{font-size:14px;min-height:40px;padding:8px 12px}
.bk-pal{position:absolute;inset:0;background:rgba(14,16,32,.92);border-radius:12px;display:none;flex-direction:column;gap:8px;padding:12px;color:#fff;line-height:1.3;overflow:auto;font-size:14px;text-align:left}.bk-pal h4{margin:2px 0;font-size:15px}
.bk-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(58px,1fr));gap:6px}.bk-g button{position:relative;background:#ffffff14;border:1px solid #ffffff30;border-radius:10px;color:#fff;padding:4px 2px;font-size:10px;cursor:pointer;line-height:1.1}.bk-g button img{width:34px;height:34px;image-rendering:pixelated;display:block;margin:0 auto 2px}.bk-g button:disabled{opacity:.35}.bk-g button em{display:block;font-style:normal;font-size:24px;line-height:34px;height:34px;margin-bottom:2px}
.bk-g.rc{grid-template-columns:repeat(auto-fill,minmax(150px,1fr))}.bk-g.rc button{display:flex;align-items:center;gap:6px;text-align:left;font-size:11px;padding:4px 6px}.bk-g.rc button img{width:28px;height:28px;margin:0;flex:none}
.bk-ov{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:linear-gradient(#0e1020aa,#0e1020dd);color:#fff;border-radius:12px;line-height:1.3;padding:16px;text-align:center}.bk-ov h2{margin:0;font-size:28px}.bk-ov .btn{min-width:220px;font-size:17px}.bk-ov small{opacity:.8;font-weight:600}
.bk-hp{position:absolute;left:8px;top:8px;font-size:17px;line-height:1;letter-spacing:1px;pointer-events:none;filter:drop-shadow(0 1px 1px #000a);display:none}.bk-hp.hit{animation:bkh .35s}@keyframes bkh{50%{transform:scale(1.25)}}
.bk-toast{position:absolute;left:50%;top:13%;transform:translateX(-50%);background:rgba(14,16,32,.8);color:#fff;padding:7px 12px;border-radius:12px;font:600 14px/1.25 system-ui,sans-serif;pointer-events:none;opacity:0;transition:opacity .25s;white-space:nowrap;max-width:92%;overflow:hidden;text-overflow:ellipsis}
.bk-fl{position:absolute;inset:0;border-radius:12px;pointer-events:none;background:radial-gradient(transparent 40%,rgba(235,45,45,.6));opacity:0;transition:opacity .4s}`;st.append(css);
 const sc=E('div','sc');st.prepend(sc);const wrap=E('div','bk-w');c.replaceWith(wrap);wrap.append(c);
 const CR=E('div','bk-x'),PB=E('div','bk-pb','<i></i>'),JOY=E('div','bk-joy','<i></i>'),KN=JOY.firstChild,HPD=E('div','bk-hp'),TOAST=E('div','bk-toast'),FL=E('div','bk-fl');wrap.append(FL,CR,PB,JOY,HPD,TOAST);
 let toastT=0;const toast=s=>{TOAST.textContent=s;TOAST.style.opacity='1';clearTimeout(toastT);toastT=setTimeout(()=>TOAST.style.opacity='0',1800)};
 const TB=E('div','bk-tb'),tbtn=(l,dn,up)=>{const b=E('button','',l);b.onpointerdown=e=>{e.preventDefault();e.stopPropagation();try{b.setPointerCapture(e.pointerId)}catch(x){}dn()};b.onpointerup=b.onpointercancel=()=>up&&up();b.oncontextmenu=e=>e.preventDefault();TB.append(b);return b};
 const bFly=tbtn('🕊️',()=>toggleFly()),bDn=tbtn('⤓',()=>tDn=1,()=>tDn=0);tbtn('🧱',()=>{if(playing()){place();pCool=.28}hP=1},()=>hP=0);tbtn('⛏️',()=>{if(playing()&&(mode==='c'||ehit)){brk();bCool=.25}hB=1},()=>hB=0);tbtn('⤒',()=>{tUp=1;jumpTap()},()=>tUp=0);tbtn('🎒',()=>pal(1));
 if(TOUCH)wrap.append(TB);
 const HB=E('div','bk-hb');st.append(HB);const slots=[];for(let i=0;i<9;i++){const s=E('div','bk-s','<img alt=""><b></b><u>'+(i+1)+'</u>');s.onclick=()=>pick(i);HB.append(s);slots.push(s)}
 const PAL=E('div','bk-pal');wrap.append(PAL);
 // --- movement (shared) ---
 function toggleFly(){if(mode!=='c')return;P.fly=P.fly?0:1;P.vy=0;bFly.className=P.fly?'on':'';beep(P.fly?660:440,.05,'sine',.03)}
 function jumpTap(){const n=performance.now();if(n-lastSp<300)toggleFly();lastSp=n}
 function phys(dt){const kf=(Kd.has('KeyW')||Kd.has('ArrowUp')?1:0)-(Kd.has('KeyS')||Kd.has('ArrowDown')?1:0)-jy,ks=(Kd.has('KeyD')||Kd.has('ArrowRight')?1:0)-(Kd.has('KeyA')||Kd.has('ArrowLeft')?1:0)+jx;
  const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);let wx=fx*kf-fz*ks,wz=fz*kf+fx*ks;const wl_=Math.hypot(wx,wz);if(wl_>1){wx/=wl_;wz/=wl_}
  const sh=Kd.has('ShiftLeft')||Kd.has('ShiftRight'),up=Kd.has('Space')||tUp,dn=(sh&&P.fly)||tDn,inW=WAT[g(Math.floor(P.x),Math.floor(P.y+.4),Math.floor(P.z))];
  if(P.kb>0)P.kb-=dt;
  if(P.fly){const sp=12;P.vx+=(wx*sp-P.vx)*Math.min(1,dt*8);P.vz+=(wz*sp-P.vz)*Math.min(1,dt*8);P.vy+=(((up?1:0)-(dn?1:0))*9-P.vy)*Math.min(1,dt*10)}
  else{const sp=inW?2.6:(sh||wl_>.97&&joy)?5.8:4.3,ac=P.kb>0?1.5:P.gr?18:inW?6:5;P.vx+=(wx*sp-P.vx)*Math.min(1,ac*dt);P.vz+=(wz*sp-P.vz)*Math.min(1,ac*dt);
   if(inW){P.vy=Math.max(P.vy-10*dt,-3);if(up)P.vy=Math.min(P.vy+30*dt,3.4)}else{P.vy=Math.max(P.vy-27*dt,-45);if(up&&P.gr)P.vy=8.4}}
  const n=Math.ceil(Math.max(Math.abs(P.vx),Math.abs(P.vy),Math.abs(P.vz))*dt/.3)||1,sd=dt/n;let hx=0;P.sg=P.gr&&!P.fly;P.gr=0;
  for(let i=0;i<n;i++){hx|=mv(0,P.vx*sd);hx|=mv(2,P.vz*sd);if(mv(1,P.vy*sd)){if(P.vy<0){P.gr=1;if(P.fly&&dn)P.fly=0,bFly.className=''}P.vy=0}}
  if(hx&&wl_>.3&&(P.gr||inW)&&(TOUCH||inW)){const ax=Math.floor(P.x+wx*.6),az=Math.floor(P.z+wz*.6),ay=Math.floor(P.y);if(SOL[g(ax,ay,az)]&&!SOL[g(ax,ay+1,az)]&&!SOL[g(ax,ay+2,az)])P.vy=inW?6:8.4}
  if(P.y>WH+30)P.y=WH+30;P.bob+=P.gr?Math.hypot(P.vx,P.vz)*dt:0;P.cy=Math.abs(P.y-P.cy)>1.2?P.y:P.cy+(P.y-P.cy)*Math.min(1,dt*16)}
 function chunkVis(i){const dx=(i%NC)+.5-cam.position.x/16,dz=(i/NC|0)+.5-cam.position.z/16;return dx*dx+dz*dz<=(VD+.75)**2}
 // ===== game layer (online, host-authoritative block edits, water, animals, chat, saved worlds) =====
 const HOST=net.isHost,MYID=net.me.id,mode='c',PLACE=[1,2,3,4,5,6,10,8,9,11,12,13,14,15,16,7,TORCH,LAMP,20,21,22,23,STAIR,DOOR];
 const OKB=new Uint8Array(64);PLACE.forEach(b=>OKB[b]=1);for(let o=0;o<4;o++)OKB[24+o]=1;for(let k=0;k<8;k++)OKB[32+k]=1;
 const css2=E('style');css2.textContent=`.bk-log{position:absolute;left:8px;top:8px;text-align:left;align-items:flex-start;max-width:min(62%,340px);display:flex;flex-direction:column;gap:3px;pointer-events:none;line-height:1.25;font:600 12px system-ui,sans-serif}.bk-log div{background:rgba(14,16,32,.62);color:#fff;padding:3px 8px;border-radius:9px;transition:opacity .6s;overflow-wrap:anywhere;font-size:11px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.bk-log b{font-weight:800}
.bk-ci{position:absolute;left:8px;right:8px;bottom:8px;display:none;gap:6px;line-height:1}.bk-ci input{flex:1;min-width:0;font-size:16px;padding:9px 12px;border-radius:12px;border:2px solid #f5b82e;background:rgba(14,16,32,.88);color:#fff;outline:none}.bk-ci .btn{min-height:40px;padding:6px 12px;font-size:15px}
.bk-wl{display:flex;flex-direction:column;gap:6px;width:min(100%,430px);max-height:48%;overflow:auto}.bk-wr{display:flex;align-items:center;gap:8px;background:#ffffff14;border:1px solid #ffffff30;border-radius:10px;padding:6px 8px;text-align:left;line-height:1.25}.bk-wr div{flex:1;min-width:0}.bk-wr b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bk-wr small{font-weight:500}.bk-ov .bk-wr .btn{min-width:0;font-size:13px;padding:6px 10px;min-height:34px}
.bk-ov input.bk-nm{font-size:16px;padding:9px 12px;border-radius:12px;border:2px solid #f5b82e;background:#0e1020;color:#fff;width:min(100%,320px)}`;st.append(css2);
 const ROW=E('div','bk-row');st.append(ROW);const btn=(l,f)=>{const b=E('button','btn sec',l);b.onclick=f;ROW.append(b);return b};
 if(!TOUCH){btn('🎒 Blokken',()=>pal(1));btn('🖱️ Muis vast',()=>{try{c.requestPointerLock()}catch(e){}})}btn('💬 Chat',()=>chatOpen());const bSave=HOST?btn('💾 Opslaan',()=>saveUI()):null;const bStop=HOST?btn('🏁 Stoppen',()=>stopGame()):null;if(TOUCH)ROW.style.flexWrap='nowrap';
 st.append(E('div','hint',(TOUCH?'Links slepen = lopen · rechts slepen = kijken · ⛏️ breken/dier aaien · 🧱 plaatsen of deur open/dicht · ⤒ springen (2× = vliegen) · 💬 praten':'WASD lopen · slepen/🖱️ kijken · klik/X breken · rechtsklik/C plaatsen of deur open/dicht · 1–9/wiel kiezen · spatie springen · F vliegen · E blokken · T of Enter = chat')+(HOST?' · 💾 bewaart deze wereld op dit toestel · 🏁 rondt de sessie af':' · de host bewaart en rondt de sessie af')));
 let reqT=0,hot=[1,2,3,10,5,8,TORCH,DOOR,12],selI=0,hit=null,ehit=null,t=0,hudT=0,visT=0,bCool=0,pCool=0,eCool=0,ready=0,ended=0,placed=0,netT=0,wT=0,saveT=0,animT=0,bLog='',dayT=.3,wready=0,slot=null,wname='',uiEl=null,cin=0;
 const SCORE={},EDITS=new Map(),POS=new Map(),RATE=new Map(),AV=new Map(),CHR=new Map(),WB=[];
 const playing=()=>!ended&&wready&&!uiEl&&PAL.style.display!=='flex';
 const r2=v=>Math.round(v*100)/100;
 // same world on every peer from the round seed; the host may swap it for a saved world (message W)
 const seed0=Math.floor(net.rng()()*2**31);let seed=seed0;
 function loadWorld(sd,edits){const t0=performance.now();seed=sd;clearEnts();wReset();gen(sd);EDITS.clear();for(let i=0;i+1<(edits||[]).length;i+=2){const k=edits[i]|0,b=edits[i+1]|0;if(k>=0&&k<V.length&&(b===0||BL[b])){V[k]=b;EDITS.set(k,b);if(LEM[b])LSRC.add(k)}}
  if(EDITS.size)for(let z=0;z<WS;z++)for(let x=0;x<WS;x++)colH(x,z);relightAll();bLog='gen '+Math.round(performance.now()-t0)+'ms';DIRTY.clear();queueAll();ready=0;delete c.dataset.build}
 function toSpawn(){const me=Math.max(0,net.myIndex()),s0=spawnPt(),sp=spawnPt(s0[0]+(me%3-1)*4,s0[2]+((me/3|0)%3-1)*4);[P.x,P.y,P.z]=sp;P.cy=P.y;P.vx=P.vy=P.vz=0;P.yaw=Math.PI*.25+me*.6;P.pitch=-.15;cam.position.set(P.x,P.y+EYE,P.z);sortQ()}
 loadWorld(seed0,[]);toSpawn();for(let i=0;i<9&&Q.length;i++)build(Q.shift());sky(dayT);
 const blocked=(x,y,z)=>{for(const a of AV.values())if(inPl(x,y,z,a.tx,a.ty,a.tz))return 1;return 0};
 function canEdit(x,y,z,b,pp){if(![x,y,z,b].every(Number.isInteger)||x<0||z<0||x>=WS||z>=WS||y<1||y>=WH)return 0;if(b!==0&&!OKB[b])return 0;const cu=V[I(x,y,z)];if(cu===BED)return 0;
  if(pp&&Math.hypot(x+.5-pp.x,y+.5-pp.y-EYE,z+.5-pp.z)>8.5)return 0;if(b===0)return cu&&!WAT[cu]?1:0;
  if(b>=32&&b<40){if(cu>=32&&cu<40)return 1;const up=g(x,y+1,z);if(y+1>=WH||(up&&!WAT[up]))return 0}return !cu||WAT[cu]?1:0}
 function hostEdit(from,x,y,z,b){const pp=from===MYID?P:POS.get(from),now=performance.now(),r=RATE.get(from)||{t:0,n:0};if(now-r.t>1000){r.t=now;r.n=0}RATE.set(from,r);
  const L=Number.isInteger(x)&&Number.isInteger(y)&&Number.isInteger(z)?expand(x,y,z,b):[],tog=b>=32&&b<40&&g(x,y,z)>=32&&g(x,y,z)<40;
  const bad=++r.n>20||!pp||!canEdit(x,y,z,b,pp)||L.some(([a,bb,cc,d])=>d&&SOL[d]&&!tog&&((from!==MYID&&inPl(a,bb,cc,P.x,P.y,P.z))||[...POS].some(([id,q])=>id!==from&&inPl(a,bb,cc,q.x,q.y,q.z))));
  if(bad){if(from!==MYID&&Number.isInteger(x)&&Number.isInteger(y)&&Number.isInteger(z)&&x>=0&&z>=0&&x<WS&&z<WS)for(let k=-1;k<=1;k++)if(y+k>=0&&y+k<WH)net.sendTo(from,{k:'fix',i:I(x,y+k,z),b:V[I(x,y+k,z)]});return 0}
  for(const [a,bb,cc,d] of L)if(setB(a,bb,cc,d)){const i=I(a,bb,cc);EDITS.set(i,d);net.send({k:'set',i,b:d,by:from});touchW(a,bb,cc)}
  if(b&&!tog){SCORE[from]=(SCORE[from]||0)+1;if(from===MYID)placed++}return 1}
 function edit(x,y,z,b){if(ended||!wready)return 0;if(HOST)return hostEdit(MYID,x,y,z,b);if(!canEdit(x,y,z,b,P))return 0;for(const [a,bb,cc,d] of expand(x,y,z,b))setB(a,bb,cc,d);net.send({k:'set',x,y,z,b});return 1}
 onW=HOST?(i,b)=>{EDITS.set(i,b);WB.push(i,b)}:null;
 const at=i=>{const y=Math.floor(i/(WS*WS)),r=i-y*WS*WS;return[r%WS,y,Math.floor(r/WS)]};
 function brk(){if(ehit){hitAnimal();return}if(!hit||hit.b===BED)return;if(edit(hit.x,hit.y,hit.z,0))beep(150+R(60),.05,'square',.03)}
 function place(){if(!hit)return;if(isDoor(hit.b)){const yb=hit.b>=40?hit.y-1:hit.y,bb=g(hit.x,yb,hit.z);if(bb>=32&&bb<40&&edit(hit.x,yb,hit.z,bb^4))beep(bb&4?300:420,.05,'triangle',.03);return}
  const b0=hot[selI];if(!b0)return;const x=hit.px,y=hit.py,z=hit.pz,o=g(x,y,z);if(o&&!WAT[o])return;const b=orient(b0,x,y,z);if(b<0){beep(120,.06,'sine',.03);toast('Zet dit op een blok');return}
  if(SOL[b]&&(inPl(x,y,z,P.x,P.y,P.z)||blocked(x,y,z)))return;if(b0===DOOR&&(inPl(x,y+1,z,P.x,P.y,P.z)||blocked(x,y+1,z)))return;if(edit(x,y,z,b))beep(330,.04,'triangle',.03)}
 function hitAnimal(){if(eCool>0||!ehit)return;eCool=.35;const e=ehit;beep(520,.05,'sine',.035);if(HOST)hitEnt(e,P.x,P.z,false);else{e.hurt=.3;net.send({k:'hit',id:e.id})}}
 function pick(i){selI=i;hotUI();beep(700,.02,'sine',.02)}
 function hotUI(){slots.forEach((s,i)=>{const b=hot[i];s.className='bk-s'+(i===selI?' on':'');const im=s.firstChild;if(b){if(im.dataset.b!=b){im.src=ico(b);im.dataset.b=b}im.style.visibility=''}else im.style.visibility='hidden';s.children[1].textContent='';s.title=b?BL[b][0]:''});setHand(hot[selI])}
 function pal(on){TB.style.opacity=on?'0':'';TB.style.pointerEvents=on?'none':'';if(!on){PAL.style.display='none';return}PAL.replaceChildren();PAL.style.display='flex';const top=E('div');top.style.cssText='display:flex;justify-content:space-between;align-items:center';const h=E('h4');h.textContent='🎨 Kies een blok voor vakje '+(selI+1);const x=E('button','btn','✕');x.onclick=()=>pal(0);top.append(h,x);PAL.append(top);
  const gr=E('div','bk-g');PAL.append(gr);PLACE.forEach(b=>{const k=E('button');k.innerHTML='<img src="'+ico(b)+'">';k.append(BL[b][0]);k.onclick=()=>{const j=hot.indexOf(b);if(j>=0&&j!==selI)hot[j]=hot[selI];hot[selI]=b;hotUI();pal(0)};gr.append(k)})}
 function press(k){if(ended)return;if((k==='KeyT'||k==='Enter')&&!uiEl){chatOpen();return}if(k==='KeyE'){pal(PAL.style.display==='flex'?0:1);return}if(!playing())return;
  if(/^Digit[1-9]$/.test(k))pick(+k[5]-1);else if(k==='KeyF')toggleFly();else if(k==='Space')jumpTap();else if(k==='KeyX'){brk();bCool=.25}else if(k==='KeyC'){place();pCool=.28}}
 // --- other players: blocky figures in their colour, avatar emoji on the head, name tag, chat bubble ---
 const BOX=new THREE.BoxGeometry(1,1,1);
 const rr_=(x,X,Y,w,h,r)=>{x.beginPath();if(x.roundRect)x.roundRect(X,Y,w,h,r);else x.rect(X,Y,w,h)};
 function tagTex(p){const cv=document.createElement('canvas');cv.width=256;cv.height=64;const x=cv.getContext('2d'),s=net.pname(p);x.font='bold 28px system-ui,sans-serif';const w=Math.min(250,x.measureText(s).width+30);x.fillStyle='rgba(14,16,32,.75)';rr_(x,(256-w)/2,6,w,52,16);x.fill();x.strokeStyle=net.pcol(p);x.lineWidth=4;x.stroke();x.fillStyle='#fff';x.textAlign='center';x.textBaseline='middle';x.fillText(s,128,33,236);const tt=new THREE.CanvasTexture(cv);tt.colorSpace=THREE.SRGBColorSpace;return tt}
 function headTex(p,tint){const cv=document.createElement('canvas');cv.width=cv.height=128;const x=cv.getContext('2d');x.fillStyle='#'+tint.getHexString();x.fillRect(0,0,128,128);x.fillStyle='rgba(0,0,0,.2)';x.fillRect(0,0,128,6);x.fillRect(0,122,128,6);x.fillRect(0,0,6,128);x.fillRect(122,0,6,128);
  x.font='100px "Noto Color Emoji","Apple Color Emoji","Segoe UI Emoji",sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(String(p.av||'🙂').slice(0,8),64,72,116);const tt=new THREE.CanvasTexture(cv);tt.colorSpace=THREE.SRGBColorSpace;return tt}
 function bubTex(s){const cv=document.createElement('canvas');cv.width=320;cv.height=128;const x=cv.getContext('2d');x.font='600 24px system-ui,sans-serif';const words=s.split(/\s+/),lines=[];let ln='';
  for(const w of words){const tt=ln?ln+' '+w:w;if(x.measureText(tt).width>280&&ln){lines.push(ln);ln=w}else ln=tt;if(lines.length>=3)break}if(ln&&lines.length<3)lines.push(ln);
  const h=lines.length*28+18,w=Math.min(310,Math.max(...lines.map(l=>x.measureText(l).width))+30);x.fillStyle='rgba(255,255,255,.95)';rr_(x,(320-w)/2,104-h,w,h,16);x.fill();x.beginPath();x.moveTo(150,104);x.lineTo(160,122);x.lineTo(170,104);x.fill();
  x.fillStyle='#1d2030';x.textAlign='center';x.textBaseline='middle';lines.forEach((l,i)=>x.fillText(l,160,104-h+23+i*28,290));const tt=new THREE.CanvasTexture(cv);tt.colorSpace=THREE.SRGBColorSpace;return tt}
 function mkAv(p){const col=new THREE.Color(net.pcol(p)),tint=col.clone().lerp(new THREE.Color(0xffffff),.6),G=new THREE.Group(),M=cl=>new THREE.MeshLambertMaterial({color:cl}),body=M(col),dark=M(col.clone().multiplyScalar(.45)),skin=M(tint),top=M(col.clone().lerp(tint,.4)),ht=headTex(p,tint),face=new THREE.MeshBasicMaterial({map:ht}),mats=[body,dark,skin,top,face];
  const part=(par,m,w,h,d,x,y,z)=>{const o=new THREE.Mesh(BOX,m);o.scale.set(w,h,d);o.position.set(x,y,z);par.add(o);return o},piv=(x,y)=>{const q=new THREE.Group();q.position.set(x,y,0);G.add(q);return q};
  const lL=piv(-.13,.75),lR=piv(.13,.75),aL=piv(-.37,1.45),aR=piv(.37,1.45);part(lL,dark,.25,.75,.27,0,-.375,0);part(lR,dark,.25,.75,.27,0,-.375,0);part(aL,body,.22,.72,.24,0,-.33,0);part(aR,body,.22,.72,.24,0,-.33,0);part(aL,skin,.2,.12,.22,0,-.72,0);part(aR,skin,.2,.12,.22,0,-.72,0);
  part(G,body,.5,.72,.28,0,1.11,0);const head=new THREE.Mesh(BOX,[skin,skin,top,skin,skin,face]);head.scale.setScalar(.52);head.position.y=1.74;G.add(head);
  const tag=new THREE.Sprite(new THREE.SpriteMaterial({map:tagTex(p),depthWrite:false}));tag.scale.set(1.7,.425,1);tag.position.y=2.32;G.add(tag);SC.add(G);
  return{G,lL,lR,aL,aR,head,tag,mats,ht,face,x:0,y:-99,z:0,a:0,tx:0,ty:-99,tz:0,ta:0,tp:0,ph:0,id:p.id,nm:net.pname(p),av:p.av||'',bub:null,bubT:0,bubS:''}}
 function avTarget(id,x,y,z,a,pt){if(id===MYID)return;let v=AV.get(id);if(!v){const p=net.players.find(q=>q.id===id);if(!p)return;v=mkAv(p);AV.set(id,v);v.x=x;v.y=y;v.z=z;v.a=a}v.tx=x;v.ty=y;v.tz=z;v.ta=a;v.tp=pt||0}
 function dropBub(v){if(!v.bub)return;v.G.remove(v.bub);v.bub.material.map.dispose();v.bub.material.dispose();v.bub=null;v.bubS=''}
 function dropAv(id){const v=AV.get(id);if(!v)return;dropBub(v);SC.remove(v.G);v.mats.forEach(m=>m.dispose());v.ht.dispose();v.tag.material.map.dispose();v.tag.material.dispose();AV.delete(id)}
 function avStep(dt){const k=1-Math.exp(-12*dt);for(const v of AV.values()){const ox=v.x,oz=v.z;v.x+=(v.tx-v.x)*k;v.y+=(v.ty-v.y)*k;v.z+=(v.tz-v.z)*k;let d=v.ta-v.a;d=Math.atan2(Math.sin(d),Math.cos(d));v.a+=d*k;
  const sp=Math.hypot(v.x-ox,v.z-oz)/Math.max(dt,1e-3);v.ph+=sp*dt*3.2;const sw=Math.sin(v.ph)*Math.min(1,sp/3)*.7;v.lL.rotation.x=sw;v.lR.rotation.x=-sw;v.aL.rotation.x=-sw;v.aR.rotation.x=sw;v.head.rotation.x=-v.tp*.6;v.G.position.set(v.x,v.y,v.z);v.G.rotation.y=v.a;v.face.color.setScalar(Math.max(.62,Math.sqrt(LIGHT)));
  if(v.bub){v.bubT-=dt;if(v.bubT<=0)dropBub(v);else v.bub.material.opacity=Math.min(1,v.bubT*2)}}}
 // --- chat: 💬 opens an input; host rate-limits, masks bad words, relays; bubbles above heads + small log (all via textContent / canvas) ---
 const BADS=['fuck','kanker','shit','cunt','motherf'],BADP=['kut','klote','tering','tyfus','tiefus','godver','hoer','kloot','neuk','flikker','fck','fuk','sh1t','bitch','whore','slut','bastard','asshole','wanker','kech','klootzak','sukkel'],BADX=['lul','pik','eikel','mongool','debiel','ass','dick','cock','fag','piss','tit','tits','idioot'];
 const RXS=new RegExp('(?:'+BADS.join('|')+')[a-z]*','gi'),RXP=new RegExp('\\b(?:'+BADP.join('|')+')[a-z]*','gi'),RXX=new RegExp('\\b(?:'+BADX.join('|')+')\\b','gi'),star=w=>w[0]+'*'.repeat(w.length-1);
 const mask=s=>s.replace(RXS,star).replace(RXP,star).replace(RXX,star),clean=s=>String(s==null?'':s).replace(/[\u0000-\u001f\u007f\u2028\u2029]/g,' ').replace(/\s+/g,' ').trim().slice(0,80);
 const LOG=E('div','bk-log'),CI=E('div','bk-ci'),CIN=E('input'),CSB=E('button','btn','Stuur'),CX=E('button','btn sec','✕');CIN.maxLength=80;CIN.placeholder='Zeg iets… (max 80)';CIN.enterKeyHint='send';CI.append(CIN,CSB,CX);wrap.append(LOG,CI);const LT_=new Set;
 function chatOpen(){if(ended)return;CI.style.display='flex';cin=1;Kd.clear();setTimeout(()=>{try{CIN.focus()}catch(e){}},0)}
 function chatClose(){CI.style.display='none';cin=0;CIN.value='';try{CIN.blur()}catch(e){}}
 CIN.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();sendChat(CIN.value);chatClose()}else if(e.key==='Escape')chatClose()};CSB.onclick=()=>{sendChat(CIN.value);chatClose()};CX.onclick=chatClose;
 function sendChat(m){m=clean(m);if(!m||ended)return;if(HOST)hostChat(MYID,m);else net.send({k:'chat',m})}
 function hostChat(from,m){m=clean(m);if(!m||!net.players.some(p=>p.id===from))return;const now=performance.now(),r=CHR.get(from)||{last:-9e9,ts:[]};r.ts=r.ts.filter(x=>now-x<15000);
  if(now-r.last<1200||r.ts.length>=5){if(from===MYID)toast('⏳ Even wachten met de volgende chat');else net.sendTo(from,{k:'chatno'});CHR.set(from,r);return}r.last=now;r.ts.push(now);CHR.set(from,r);m=mask(m);net.send({k:'chat',id:from,m});showChat(from,m)}
 function showChat(id,m){const p=net.players.find(q=>q.id===id);if(!p)return;const d=E('div'),b=E('b');b.textContent=net.pname(p)+(id===MYID?' (jij)':'')+': ';b.style.color=net.pcol(p);d.append(b,document.createTextNode(m));LOG.append(d);while(LOG.children.length>3)LOG.firstChild.remove();
  const t1=setTimeout(()=>{d.style.opacity='0';LT_.delete(t1);const t2=setTimeout(()=>{d.remove();LT_.delete(t2)},650);LT_.add(t2)},8000);LT_.add(t1);
  const v=AV.get(id);if(v){dropBub(v);const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:bubTex(m),depthWrite:false,transparent:true}));sp.scale.set(2.3,.92,1);sp.position.y=3.08;sp.renderOrder=6;v.G.add(sp);v.bub=sp;v.bubT=8;v.bubS=m}beep(880,.04,'sine',.025)}
 // --- saved worlds (host only, in this browser's localStorage): seed + edit list + time of day ---
 const WKEY='blokkenland_mp_worlds',lw=()=>{try{const a=JSON.parse(localStorage.getItem(WKEY));return Array.isArray(a)?a.filter(w=>w&&w.id&&Array.isArray(w.e)):[]}catch(e){return[]}},sw=a=>{try{localStorage.setItem(WKEY,JSON.stringify(a));return 1}catch(e){return 0}};
 const nBlocks=()=>{let n=0;EDITS.forEach(b=>{if(b&&!WAT[b])n++});return n},defName=()=>'Wereld van '+new Date().toLocaleString('nl-BE',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
 function saveWorld(name,quiet){if(!HOST||!wready)return 0;const a=lw(),e=[];EDITS.forEach((b,i)=>e.push(i,b));let w=a.find(x=>x.id===slot);if(!w){w={id:'w'+Date.now().toString(36)+R(1e4)};a.unshift(w);slot=w.id}w.name=clean(name||wname||w.name||defName()).slice(0,40)||defName();wname=w.name;
  Object.assign(w,{v:1,seed,e,t:r2(dayT),d:Date.now(),n:nBlocks()});a.sort((p,q)=>q.d-p.d);const ok=sw(a.slice(0,10));if(!quiet)toast(ok?'💾 Bewaard: '+w.name:'⚠️ Bewaren mislukt (geheugen vol?)');saveT=0;return ok}
 function closeUI(){if(uiEl){uiEl.remove();uiEl=null}}
 function saveUI(){if(!HOST||!wready||ended)return;closeUI();uiEl=E('div','bk-ov');const h=E('h2');h.textContent='💾 Wereld bewaren';const s=E('small');s.textContent='De wereld wordt op dit toestel bewaard; volgende keer kan je hem weer laden.';const inp=E('input','bk-nm');inp.maxLength=40;inp.value=wname||defName();
  const ok=E('button','btn','💾 Bewaar'),no=E('button','btn sec','Annuleer');ok.onclick=()=>{saveWorld(inp.value);closeUI()};no.onclick=closeUI;inp.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter')ok.click();if(e.key==='Escape')closeUI()};uiEl.append(h,s,inp,ok,no);wrap.append(uiEl)}
 function picker(){closeUI();const a=lw().sort((p,q)=>q.d-p.d);if(!a.length){hostBegin(null);return}uiEl=E('div','bk-ov');const h=E('h2');h.textContent='🌍 Kies een wereld';const s=E('small');s.textContent='Je bewaarde werelden staan op dit toestel. Iedereen in de kamer speelt mee in de gekozen wereld.';
  const nb=E('button','btn','🌱 Nieuwe wereld');nb.onclick=()=>{closeUI();hostBegin(null)};const L=E('div','bk-wl');
  a.forEach(w=>{const r=E('div','bk-wr'),d=E('div'),b=E('b'),m=E('small');b.textContent=w.name||'Wereld';m.textContent=new Date(w.d||0).toLocaleString('nl-BE',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})+' · 🧱 '+(w.n|0)+' blokken';d.append(b,m);
   const lb=E('button','btn','▶ Laden'),db=E('button','btn sec','🗑️');lb.onclick=()=>{closeUI();hostBegin(w)};let arm=0;db.onclick=()=>{if(!arm){arm=1;db.textContent='Zeker?';setTimeout(()=>{arm=0;db.textContent='🗑️'},2500);return}sw(lw().filter(x=>x.id!==w.id));r.remove();if(!L.children.length){closeUI();hostBegin(null)}};r.append(d,lb,db);L.append(r)});
  uiEl.append(h,s,nb,L);wrap.append(uiEl)}
 const sendAll=to=>{const a=[];EDITS.forEach((b,i)=>a.push(i,b));for(let k=0;k<a.length||k===0;k+=600){const m={k:'all',e:a.slice(k,k+600)};if(to)net.sendTo(to,m);else net.send(m)}};
 function hostBegin(w){if(w){loadWorld(w.seed|0,w.e);dayT=+w.t>=0&&+w.t<1?+w.t:.3;slot=w.id;wname=w.name||''}else{loadWorld(seed0,[]);dayT=.3;slot=null;wname=''}wready=1;toSpawn();sky(dayT);
  for(let k=0;k<8;k++){const q=grassSpot(P.x,P.z,5,40);if(q)mkEnt(SPN[k%3],q[0],q[1],q[2])}net.send({k:'W',seed,t:dayT});sendAll(null);if(w)toast('🌍 '+(w.name||'Wereld')+' geladen')}
 const WAIT=HOST?null:E('div','bk-ov','<h2>⏳</h2><small>De host kiest een wereld…</small>');if(WAIT)wrap.append(WAIT);
 // --- network ---
 const num=(v,a,b)=>{v=+v;return isFinite(v)?Math.max(a,Math.min(b,v)):a};
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(HOST){if(d.k==='p'){const q={x:num(d.x,-2,WS+2),y:num(d.y,-2,WH+40),z:num(d.z,-2,WS+2),a:num(d.a,-1e3,1e3),t:num(d.t,-2,2)};POS.set(from,q);avTarget(from,q.x,q.y,q.z,q.a,q.t)}
   else if(d.k==='set'){if(wready)hostEdit(from,d.x,d.y,d.z,d.b)}
   else if(d.k==='chat')hostChat(from,d.m);
   else if(d.k==='hit'){const e=ENT.find(q=>q.id===d.id),q=POS.get(from);if(e&&q&&Math.hypot(e.x-q.x,e.z-q.z)<7)hitEnt(e,q.x,q.z,false)}
   else if(d.k==='req'){if(wready){net.sendTo(from,{k:'W',seed,t:dayT});sendAll(from);if(ended)net.sendTo(from,{k:'end',s:scores()})}}return}
  if(d.k==='P'&&Array.isArray(d.a)){for(const e of d.a)if(Array.isArray(e))avTarget(String(e[0]),+e[1],+e[2],+e[3],+e[4],+e[5]);if(isFinite(d.t))dayT=num(d.t,0,1);if(Array.isArray(d.n))syncAnimals(d.n)}
  else if(d.k==='W'){EMAP.clear();loadWorld(d.seed|0,[]);dayT=num(d.t,0,1);sky(dayT);if(!wready){wready=1;toSpawn();if(WAIT)WAIT.remove()}}
  else if(d.k==='set'||d.k==='fix'){const i=d.i|0;const b=d.b|0;if(i<0||i>=V.length||(b&&!BL[b]))return;const [x,y,z]=at(i);setB(x,y,z,b);if(d.k==='set'&&d.by===MYID&&d.b&&!isDoor(d.b))placed++}
  else if(d.k==='S'&&Array.isArray(d.a)){for(let k=0;k+1<d.a.length;k+=2){const i=d.a[k]|0,b=d.a[k+1]|0;if(i<0||i>=V.length||(b&&!WAT[b]))continue;const [x,y,z]=at(i);setB(x,y,z,b)}}
  else if(d.k==='all'&&Array.isArray(d.e)){const cols=new Set;for(let k=0;k+1<d.e.length;k+=2){const i=d.e[k]|0,b=d.e[k+1]|0;if(i<0||i>=V.length||(b&&!BL[b]))continue;if(LEM[V[i]])LSRC.delete(i);V[i]=b;if(LEM[b])LSRC.add(i);const [x,,z]=at(i);cols.add(x+z*WS)}cols.forEach(h=>colH(h%WS,h/WS|0));if(cols.size){relightAll();queueAll()}}
  else if(d.k==='chat'&&typeof d.m==='string')showChat(String(d.id),clean(d.m));
  else if(d.k==='chatno')toast('⏳ Even wachten met de volgende chat');
  else if(d.k==='end'&&d.s&&typeof d.s==='object')finish(d.s)});
 const EMAP=new Map;
 function syncAnimals(a){const seen=new Set;for(const r of a){if(!Array.isArray(r))continue;const id=r[0]|0,sp=SPN[r[1]|0];if(!sp||sp==='slijm')continue;seen.add(id);let e=EMAP.get(id);if(!e){e=mkEnt(sp,+r[2],+r[3],+r[4]);e.id=id;EMAP.set(id,e)}e.tx=num(r[2],0,WS);e.ty=num(r[3],0,WH+5);e.tz=num(r[4],0,WS);e.ta=+r[5]||0}
  for(const [id,e] of EMAP)if(!seen.has(id)){rmEnt(e);EMAP.delete(id)}}
 const offP=net.onPlayers(ps=>{for(const id of [...AV.keys()])if(!ps.some(p=>p.id===id)){dropAv(id);POS.delete(id);RATE.delete(id);CHR.delete(id)}});
 if(!HOST)net.send({k:'req'});
 const scores=()=>{const s={};net.players.forEach(p=>s[p.id]=HOST?SCORE[p.id]||0:0);return s};
 function stopGame(){if(!HOST||ended)return;if(slot||EDITS.size)saveWorld('',1);const s=scores();net.send({k:'end',s});finish(s)}
 function finish(s){if(ended)return;ended=1;pal(0);chatClose();closeUI();hB=hP=0;try{if(document.pointerLockElement===c)document.exitPointerLock()}catch(e){}if(bStop)bStop.disabled=true;if(bSave)bSave.disabled=true;net.result({winner:null,title:'Mooi gebouwd! 🏗️',scores:s,unit:' blokken',text:'Blokken geplaatst in deze bouwsessie'+(HOST&&wname?' · bewaard als “'+wname+'”':'')})}
 // --- main loop ---
 const dir=new THREE.Vector3();
 const stopLoop=loop(dt=>{t+=dt;if(playing())phys(dt);cam.position.set(P.x,P.cy+EYE+Math.sin(P.bob*2.2)*.04,P.z);cam.rotation.set(P.pitch,P.yaw,0);
  dir.set(-Math.sin(P.yaw)*Math.cos(P.pitch),Math.sin(P.pitch),-Math.cos(P.yaw)*Math.cos(P.pitch));hit=playing()?ray(cam.position.x,cam.position.y,cam.position.z,dir.x,dir.y,dir.z,6):null;
  ehit=playing()?rayEnt(cam.position.x,cam.position.y,cam.position.z,dir.x,dir.y,dir.z,Math.min(4.5,hit?hit.t+.01:4.5)):null;CR.className='bk-x'+(ehit?' en':'');sel.visible=!!hit&&!ehit;if(hit)sel.position.set(hit.x+.5,hit.y+.5,hit.z+.5);eCool-=dt;
  const mh=mouse&&!mouse.look&&!mouse.touch&&performance.now()-mouse.t>220,bh=hB||Kd.has('KeyX')||(mh&&mouse.btn!==2),ph=hP||Kd.has('KeyC')||(mh&&mouse.btn===2);
  if(bh&&ehit)hitAnimal();else if(bh&&hit){bCool-=dt;if(bCool<=0){brk();bCool=.25}}else bCool=0;if(ph){pCool-=dt;if(pCool<=0){place();pCool=.28}}else pCool=0;hand.position.y=-.46+Math.sin(P.bob*2.2)*.015;
  if(HOST&&wready&&!ended){dayT=(dayT+dt/600)%1;wT+=dt;if(wT>.15){wT=0;wTick(24)}
   for(const e of ENT){if(e.y<1){e.die=.01}nearP(e);aiAnimal(e,dt,NP[0],NP[1]);estep(e,dt);visE(e,dt)}for(let k=ENT.length-1;k>=0;k--)if(ENT[k].die)rmEnt(ENT[k]);
   animT+=dt;if(animT>12){animT=0;if(ENT.length<8){const q=grassSpot(P.x,P.z,10,40);if(q)mkEnt(SPN[R(3)],q[0],q[1],q[2])}}saveT+=dt;if(saveT>120&&(slot||EDITS.size))saveWorld('',1)}
  else if(!HOST){if(!wready){reqT+=dt;if(reqT>1.5){reqT=0;net.send({k:'req'})}}for(const e of ENT){const k=1-Math.exp(-10*dt);e.x+=(e.tx-e.x)*k;e.y+=(e.ty-e.y)*k;e.z+=(e.tz-e.z)*k;visE(e,dt)}}
  netT+=dt;if(netT>=.1){netT=0;if(HOST){const a=[[MYID,r2(P.x),r2(P.y),r2(P.z),r2(P.yaw),r2(P.pitch)]];POS.forEach((q,id)=>{if(net.players.some(p=>p.id===id))a.push([id,r2(q.x),r2(q.y),r2(q.z),r2(q.a),r2(q.t)])});
    net.send({k:'P',a,t:Math.round(dayT*1e4)/1e4,n:wready?ENT.map(e=>[e.id,SPN.indexOf(e.sp),r2(e.x),r2(e.y),r2(e.z),r2(e.ta)]):undefined});while(WB.length)net.send({k:'S',a:WB.splice(0,600)})}
   else if(wready)net.send({k:'p',x:r2(P.x),y:r2(P.y),z:r2(P.z),a:r2(P.yaw),t:r2(P.pitch)})}
  avStep(dt);ptStep(dt);flush();{const hx_=Math.floor(cam.position.x),hy_=Math.floor(cam.position.y),hz_=Math.floor(cam.position.z);hand.material.color.setScalar(Math.max(.18,Math.min(1,Math.sqrt(Math.max(skyAt(hx_,hy_,hz_)*LIGHT,LF[lightAt(hx_,hy_,hz_)])))))}
  const t0=performance.now();while(Q.length&&performance.now()-t0<(ready?6:12))build(Q.shift());if(!Q.length&&!ready){ready=1;c.dataset.build=bLog+' · '+bcnt+' chunks '+Math.round(bms)+'ms'}
  visT+=dt;if(visT>.3){visT=0;for(let i=0;i<CK.length;i++){const v=chunkVis(i),C=CK[i];if(C.o)C.o.visible=v;if(C.w)C.w.visible=v}sky(dayT)}
  ctex.offset.x=(t*.004)%1;dome.position.copy(cam.position);tv.copy(sunD).multiplyScalar(250);sun.position.copy(cam.position).add(tv);sun.lookAt(cam.position);moon.position.copy(cam.position).sub(tv);moon.lookAt(cam.position);
  hudT+=dt;if(hudT>.2){hudT=0;hud()}T.r.render(SC,cam)});
 const NP=[0,0];function nearP(e){let bx=P.x,bz=P.z,bd=(e.x-P.x)**2+(e.z-P.z)**2;POS.forEach(q=>{const d=(e.x-q.x)**2+(e.z-q.z)**2;if(d<bd){bd=d;bx=q.x;bz=q.z}});NP[0]=bx;NP[1]=bz;return NP}
 function hud(){const b=hot[selI],h=(dayT*24+6)%24;sc.textContent=net.pname(net.me.id)+(PHONE?'':' (jij)')+' · '+(b?'🧱 '+BL[b][0]:'✋')+' · '+(h>=6&&h<19?'☀️':'🌙')+(PHONE?'':' '+String(h|0).padStart(2,'0')+':'+String((h%1)*60|0).padStart(2,'0'))+' · 📍 '+(P.x|0)+','+(P.y|0)+','+(P.z|0)+' · 🏗️ '+placed+(PHONE?'':' · 👥 '+net.players.length)+(P.fly?' · 🕊️':'')+(ended?' · klaar!':'')}
 st.bl={get:(x,y,z)=>g(x,y,z),P,hit:()=>hit&&{...hit},av:()=>[...AV.values()].map(v=>({id:v.id,x:v.x,y:v.y,z:v.z,nm:v.nm,av:v.av,face:!!(v.head.material[5].map&&v.head.material[5].map.image),bub:v.bubS})),edits:()=>EDITS.size,placed:()=>placed,score:()=>({...SCORE}),build:()=>c.dataset.build,stop:()=>stopGame(),
  ready:()=>wready,seed:()=>seed,worlds:()=>lw().map(w=>({id:w.id,name:w.name,n:w.n,t:w.t})),save:n=>saveWorld(n),ui:()=>uiEl?uiEl.innerText:'',chat:m=>sendChat(m),log:()=>[...LOG.children].map(d=>d.textContent),mask:s=>mask(s),
  ents:()=>ENT.map(e=>({id:e.id,sp:e.sp,x:e.x,z:e.z})),day:v=>{dayT=v;sky(v)},dayT:()=>dayT,light:(x,y,z)=>lightAt(x,y,z),edit:(x,y,z,b)=>edit(x,y,z,b),hash:()=>{let h=0;for(let i=0;i<V.length;i++)h=(Math.imul(h,31)+V[i])|0;return h},perf:()=>({bms,bcnt,fms,fcnt,lcnt,lms})};
 hotUI();hud();if(HOST)picker();
 return()=>{if(HOST&&wready&&!ended&&(slot||EDITS.size))saveWorld('',1);stopLoop();off();offP();LT_.forEach(x=>clearTimeout(x));clearTimeout(toastT);removeEventListener('keydown',kd);removeEventListener('keyup',ku);removeEventListener('blur',blur);c.removeEventListener('wheel',wheel);document.removeEventListener('pointerlockchange',plc);document.removeEventListener('mousemove',pmv);
  try{if(document.pointerLockElement===c)document.exitPointerLock()}catch(e){}c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=c.oncontextmenu=null;delete st.bl;[...AV.keys()].forEach(dropAv);clearEnts();Object.values(MG).forEach(x=>x.dispose());slimeOG.dispose();halo.dispose();BOX.dispose();[wtex,ctex].forEach(x=>x.dispose());T.dispose()}}},
