{id:'quiz',n:'Quiz met buzzers',e:'❓',c:'Samen',g:'#4568dc,#b06ab3',min:2,max:8,bots:true,run(st,net){
 // Partyquiz (host-authoritatief): 10 vragen, iedereen antwoordt op zijn eigen toestel, snelste juiste antwoord = 100 punten.
 const CAT={A:'Aardrijkskunde',D:'Dieren & natuur',W:'Wetenschap',G:'Geschiedenis',T:'Taal & cultuur',S:'Sport',E:'Eten & drinken',M:'Muziek & film'};
 // [categorie, vraag, 'JUIST|fout|fout|fout'] — het eerste antwoord is het juiste (wordt geschud)
 const Q=[
  ['A','Wat is de hoofdstad van Australië?','Canberra|Sydney|Melbourne|Perth'],['A','Wat is de langste rivier van Afrika?','De Nijl|De Congo|De Niger|De Zambezi'],
  ['A','Welk land is het grootste ter wereld in oppervlakte?','Rusland|Canada|China|Verenigde Staten'],['A','Wat is de hoofdstad van Canada?','Ottawa|Toronto|Vancouver|Montreal'],
  ['A','Wat is de hoogste berg ter wereld?','Mount Everest|K2|Kilimanjaro|Mont Blanc'],['A','Welke oceaan is de grootste?','Grote (Stille) Oceaan|Atlantische Oceaan|Indische Oceaan|Noordelijke IJszee'],
  ['A','Wat is de hoofdstad van Brazilië?','Brasília|Rio de Janeiro|São Paulo|Salvador'],['A','Wat is het kleinste land ter wereld?','Vaticaanstad|Monaco|San Marino|Liechtenstein'],
  ['A','Welke rivier stroomt door Parijs?','De Seine|De Loire|De Rhône|De Theems'],['A','Hoeveel provincies heeft België?','10|9|11|12'],
  ['A','Wat is de hoofdstad van Noorwegen?','Oslo|Stockholm|Helsinki|Bergen'],['A','In welk land ligt de stad Marrakech?','Marokko|Egypte|Tunesië|Turkije'],
  ['A','Welke zee ligt tussen Europa en Afrika?','De Middellandse Zee|De Noordzee|De Zwarte Zee|De Rode Zee'],['A','Wat is de hoofdstad van Japan?','Tokio|Kioto|Osaka|Seoel'],
  ['D','Hoeveel poten heeft een spin?','8|6|10|4'],['D','Wat is het grootste dier dat ooit op aarde heeft geleefd?','Blauwe vinvis|Afrikaanse olifant|Tyrannosaurus rex|Witte haai'],
  ['D','Welk dier is het snelste landdier?','Jachtluipaard|Leeuw|Paard|Antilope'],['D','Hoeveel harten heeft een octopus?','3|1|2|4'],
  ['D','Welke vogel kan niet vliegen?','Pinguïn|Duif|Zwaluw|Ooievaar'],['D','Wat is het grootste landdier?','Afrikaanse olifant|Neushoorn|Nijlpaard|Giraf'],
  ['D','Hoeveel poten heeft een insect?','6|8|4|10'],['D','Wat eet een reuzenpanda vooral?','Bamboe|Vis|Vlees|Fruit'],
  ['D','Welk van deze dieren is een zoogdier?','Dolfijn|Haai|Krokodil|Kikker'],['D','Wat is de grootste levende vogel?','Struisvogel|Adelaar|Albatros|Condor'],
  ['D','Hoeveel magen heeft een koe?','4|1|2|3'],['D','Welk dier verandert van kleur om zich te verbergen?','Kameleon|Gekko|Leguaan|Schildpad'],
  ['D','Hoe heet het jong van een schaap?','Lam|Veulen|Kalf|Big'],['D','Welke boom verliest in de winter zijn naalden?','Lariks|Den|Spar|Taxus'],
  ['W','Wat is het chemisch symbool voor goud?','Au|Ag|Go|Gd'],['W','Welke planeet staat het dichtst bij de zon?','Mercurius|Venus|Aarde|Mars'],
  ['W','Hoeveel planeten telt ons zonnestelsel?','8|9|7|10'],['W','Wat is de chemische formule van water?','H₂O|CO₂|O₂|NaCl'],
  ['W','Welke planeet wordt de rode planeet genoemd?','Mars|Jupiter|Venus|Saturnus'],['W','Wat is het grootste orgaan van het menselijk lichaam?','De huid|De lever|De longen|De hersenen'],
  ['W','Bij hoeveel graden Celsius kookt water op zeeniveau?','100|90|110|80'],['W','Wat is het chemisch symbool voor ijzer?','Fe|Ir|Ij|Fr'],
  ['W','Welke planeet is de grootste van ons zonnestelsel?','Jupiter|Saturnus|Neptunus|Aarde'],['W','Welk element heeft atoomnummer 1?','Waterstof|Helium|Zuurstof|Koolstof'],
  ['W','Hoeveel botten heeft een volwassen mens ongeveer?','206|180|250|320'],['W','Welk gas ademen planten vooral in?','Koolstofdioxide|Zuurstof|Stikstof|Waterstof'],
  ['W','Hoe snel is het licht ongeveer?','300.000 km/s|30.000 km/s|3.000.000 km/s|3.000 km/s'],['W','Wat meet een thermometer?','Temperatuur|Luchtdruk|Vochtigheid|Windkracht'],
  ['G','In welk jaar begon de Eerste Wereldoorlog?','1914|1918|1939|1912'],['G','In welk jaar eindigde de Tweede Wereldoorlog?','1945|1944|1946|1939'],
  ['G','Wie zette als eerste mens voet op de maan?','Neil Armstrong|Buzz Aldrin|Joeri Gagarin|Michael Collins'],['G','In welk jaar viel de Berlijnse Muur?','1989|1991|1985|1979'],
  ['G','In welk jaar bereikte Columbus Amerika?','1492|1500|1452|1512'],['G','In welk jaar werd België onafhankelijk?','1830|1815|1848|1900'],
  ['G','Welke beschaving bouwde de piramiden van Gizeh?','De Egyptenaren|De Romeinen|De Grieken|De Maya’s'],['G','Wie was de eerste president van de Verenigde Staten?','George Washington|Abraham Lincoln|Thomas Jefferson|John Adams'],
  ['G','In welk jaar zonk de Titanic?','1912|1905|1920|1898'],['G','Welke Romeinse stad werd in 79 n.Chr. bedolven door de Vesuvius?','Pompeï|Rome|Athene|Carthago'],
  ['G','Wie was de eerste koning van België?','Leopold I|Albert I|Boudewijn|Willem I'],['G','Welke muur werd gebouwd om China te beschermen?','De Chinese Muur|De Berlijnse Muur|De Muur van Hadrianus|De Klaagmuur'],
  ['G','Wie was de Franse keizer die in 1815 bij Waterloo verloor?','Napoleon|Lodewijk XIV|Karel de Grote|De Gaulle'],
  ['T','Wie schreef ‘Romeo en Julia’?','William Shakespeare|Charles Dickens|Jane Austen|Oscar Wilde'],['T','Wie schilderde de Mona Lisa?','Leonardo da Vinci|Michelangelo|Rembrandt|Pablo Picasso'],
  ['T','Wie schreef het dagboek ‘Het Achterhuis’?','Anne Frank|Annie M.G. Schmidt|Hella Haasse|Harry Mulisch'],['T','Welke componist schreef de ‘Ode aan de vreugde’?','Ludwig van Beethoven|Wolfgang Amadeus Mozart|Johann Sebastian Bach|Frédéric Chopin'],
  ['T','Wie schreef de Harry Potter-boeken?','J.K. Rowling|J.R.R. Tolkien|Roald Dahl|Stephen King'],['T','Wie schilderde ‘De Nachtwacht’?','Rembrandt van Rijn|Vincent van Gogh|Johannes Vermeer|Frans Hals'],
  ['T','Wie schreef ‘In de ban van de ring’?','J.R.R. Tolkien|C.S. Lewis|George R.R. Martin|Terry Pratchett'],['T','Welke taal is de officiële taal van Brazilië?','Portugees|Spaans|Braziliaans|Italiaans'],
  ['T','Wie schilderde ‘De Sterrennacht’?','Vincent van Gogh|Claude Monet|Salvador Dalí|Rembrandt van Rijn'],['T','Welke Belgische striptekenaar bedacht de Smurfen?','Peyo|Hergé|Willy Vandersteen|Marc Sleen'],
  ['T','Hoeveel letters telt het Nederlandse alfabet?','26|24|25|28'],['T','Wie bedacht Kuifje?','Hergé|Peyo|Marc Sleen|Jef Nys'],
  ['S','Hoeveel spelers staan er per ploeg op het veld bij voetbal?','11|10|12|9'],['S','Om de hoeveel jaar worden de Olympische Zomerspelen gehouden?','4|2|3|5'],
  ['S','Hoeveel ringen heeft het olympische logo?','5|4|6|7'],['S','Welke sport wordt op Wimbledon gespeeld?','Tennis|Golf|Cricket|Hockey'],
  ['S','Hoe lang is een marathon ongeveer?','42 km|21 km|50 km|30 km'],['S','Welke kleur heeft de leiderstrui in de Ronde van Frankrijk?','Geel|Groen|Wit|Rood'],
  ['S','Hoeveel spelers staan er per ploeg op het veld bij basketbal?','5|6|7|4'],['S','In welk land werden in 1896 de eerste moderne Olympische Spelen gehouden?','Griekenland|Frankrijk|Italië|Engeland'],
  ['S','Hoeveel holes heeft een standaard golfbaan?','18|9|12|20'],['S','Bij welke sport speel je met een shuttle?','Badminton|Tennis|Squash|Tafeltennis'],
  ['S','Hoeveel punten is een touchdown waard bij American football?','6|3|7|5'],['S','Hoe heet de voetbalploeg uit Brugge in de hoogste klasse?','Club Brugge|Anderlecht|Genk|Standard'],
  ['E','Van welke plant wordt chocolade gemaakt?','Cacaoboom|Koffieplant|Vanilleorchidee|Suikerriet'],['E','Welk ingrediënt laat brood rijzen?','Gist|Zout|Suiker|Boter'],
  ['E','Uit welk land komt de pizza oorspronkelijk?','Italië|Griekenland|Spanje|Frankrijk'],['E','Wat is het hoofdingrediënt van guacamole?','Avocado|Tomaat|Komkommer|Erwten'],
  ['E','Welke groente zit er in stoemp met wortelen?','Aardappel|Rijst|Pasta|Kool'],['E','Van welk graan wordt sushi-rijst gemaakt?','Rijst|Tarwe|Gerst|Haver'],
  ['E','Wat is tofu?','Gestremde sojamelk|Gefermenteerde kool|Gedroogd zeewier|Geroosterde kikkererwten'],['E','Hoe heet het Belgische biertje met een kersensmaak?','Kriek|Tripel|Geuze|Witbier'],
  ['M','Hoeveel snaren heeft een standaardgitaar?','6|4|5|8'],['M','Welke band zong ‘Yellow Submarine’?','The Beatles|The Rolling Stones|Queen|ABBA'],
  ['M','Hoeveel toetsen heeft een piano?','88|76|100|64'],['M','Wie is de tovenaar in ‘In de ban van de ring’?','Gandalf|Dumbledore|Merlijn|Saruman'],
  ['M','Welk instrument heeft toetsen, pedalen en pijpen?','Orgel|Harp|Accordeon|Trompet'],['M','In welke film zegt een robot ‘I’ll be back’?','The Terminator|RoboCop|Star Wars|Alien'],
  ['M','Welke Belgische zanger zong ‘Ne me quitte pas’?','Jacques Brel|Stromae|Arno|Will Tura'],['M','Hoe heet de sneeuwman in de film ‘Frozen’?','Olaf|Sven|Kristoff|Hans']];
 const PER=10,TL=15000,PTS=[100,80,65,50,40,32,26,20],isH=net.isHost,me=net.me.id;
 const sc=E('div','sc'),note=E('div','hint'),board=E('div');board.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:4px 0 10px';
 const card=E('div');card.style.cssText='background:var(--bg);border-radius:14px;padding:14px;max-width:460px;margin:0 auto;text-align:left';
 const cat=E('div');cat.style.cssText='font-size:12px;font-weight:700;color:var(--ac);text-transform:uppercase;letter-spacing:.5px';
 const qt=E('div');qt.style.cssText='font-size:19px;font-weight:700;margin:6px 0 10px;min-height:52px;line-height:1.3';
 const barW=E('div');barW.style.cssText='height:8px;border-radius:99px;background:var(--card);overflow:hidden;margin-bottom:12px';
 const bar=E('div');bar.style.cssText='height:100%;width:100%;border-radius:99px;background:#38d9a9';barW.append(bar);
 const ans=E('div');ans.style.cssText='display:grid;gap:8px';const fb=E('div');fb.style.cssText='min-height:24px;margin-top:10px;font-weight:700;font-size:15px';
 const res=E('div');res.style.cssText='margin-top:8px;font-size:14px';card.append(cat,qt,barW,ans,fb,res);
 st.append(sc,note,board,card,E('div','hint','Tik op een antwoord of druk op 1–4 · snelste juiste antwoord = 100 punten'));
 let S=null,btns=[],lEnd=0,lQi=-1,myA=-1,notes=[],known={},lastPh='',podDone=0;
 net.players.forEach(p=>known[p.id]=net.pname(p));
 const mine=()=>S&&S.pl.find(p=>p.id===me);
 const rank=()=>S.pl.slice().sort((a,b)=>b.sc-a.sc);
 // naam met avatar; valt terug op de naam uit de toestand als de speler al weg is
 const pn=(id,n)=>{const q=net.players.find(x=>x.id===id);return q?net.pname(q):(n||'?')};
 // leaderboard-chip: avatar-bolletje + tekst, rand in de kleur van de speler, eigen chip licht ingekleurd
 function chip(p,txt){const q=net.players.find(x=>x.id===p.id),col=q&&q.col||'var(--mu)',on=p.id===me,d=E('div');
  d.style.cssText='display:inline-flex;align-items:center;padding:2px 9px 2px 2px;border-radius:99px;font-size:13px;font-weight:'+(on?'700':'600')+';color:var(--tx);border:2px solid '+col+';background:'+(on?'color-mix(in srgb,'+col+' 18%,var(--bg))':'var(--bg)');
  const av=E('span','pav s');av.style.setProperty('--c',col);av.textContent=q&&q.av||'🙂';const t=E('span');t.textContent=txt;d.append(av,t);return d}
 function render(){if(!S)return;const m=mine();
  sc.textContent=(S.ph==='end'?'Quiz klaar!':'Vraag '+(S.qi+1)+'/'+PER)+(m?' · Jij: '+m.sc+' pt':'');
  board.replaceChildren(...rank().map((p,i)=>chip(p,(i===0&&p.sc>0?'🏆 ':'')+p.n+(p.id===me?' (jij)':'')+' · '+p.sc+(S.ph==='q'&&(p.d||p.a!=null)?' ✓':''))));
  note.textContent=notes.slice(-3).join(' · ');note.style.display=notes.length?'':'none';
  if(S.ph==='end'){cat.textContent='Eindstand';barW.style.display='none';ans.replaceChildren();fb.textContent='';qt.textContent='De quiz is klaar!';res.textContent='';
   if(!podDone){podDone=1;const r=rank(),scores={};r.forEach(p=>scores[p.id]=p.sc);const tie=r.length>1&&r[0].sc===r[1].sc;
    net.result({winner:!tie&&r[0]?r[0].id:null,scores,unit:' pt',title:tie?'Gelijkspel 🤝':undefined})}return}
  barW.style.display='';cat.textContent=CAT[S.cat];qt.textContent=S.q;
  if(S.qi!==lQi){lQi=S.qi;myA=-1;lEnd=performance.now()+S.tl;btns=[];ans.replaceChildren();
   S.opts.forEach((o,k)=>{const b=E('button','btn',(k+1)+'. '+o);b.style.cssText='width:100%;text-align:left;padding:12px 14px;font-size:16px;background:var(--card);color:var(--tx);border:2px solid transparent;transition:background .15s';b.onpointerdown=e=>{e.preventDefault();answer(k)};btns.push(b);ans.append(b)})}
  const a=m?m.a:null;if(a!=null&&a>=0)myA=a;
  if(S.ph==='q'){btns.forEach((b,i)=>{b.style.borderColor=i===myA?'var(--ac)':'transparent';b.style.pointerEvents=myA>=0||!m?'none':'';b.style.opacity=myA>=0&&i!==myA?'.6':'1'});
   fb.style.color='var(--mu)';fb.textContent=!m?'Je doet mee vanaf de volgende vraag':myA>=0?'Antwoord verstuurd · wachten op de anderen…':'';res.textContent='';return}
  btns.forEach((b,i)=>{b.style.pointerEvents='none';b.style.opacity='1';b.style.borderColor='transparent';if(i===S.cor){b.style.background='#2ecc71';b.style.color='#fff'}else if(i===myA){b.style.background='#e74c3c';b.style.color='#fff'}else b.style.opacity='.55'});
  bar.style.width='0%';if(m){const ok=myA===S.cor;fb.style.color=ok?'#2ecc71':'#e74c3c';fb.textContent=ok?'✅ Juist! +'+m.p:myA<0?'⏰ Geen antwoord. Juist was: '+S.opts[S.cor]:'❌ Fout. Juist was: '+S.opts[S.cor]}
  const good=S.pl.filter(p=>p.p>0).sort((a,b)=>b.p-a.p);res.textContent=good.length?'Goed: '+good.map(p=>pn(p.id,p.n)+' +'+p.p).join(', '):'Niemand had het juist 😅'}
 function answer(k){const m=mine();if(!S||S.ph!=='q'||!m||myA>=0)return;myA=k;beep(520,.05,'triangle',.03);if(isH)hAns(me,k);else net.send({k:'a',a:k});render()}
 // ---- host ----
 let round,ansN,t0,tm=0,nt=0;
 const snap=()=>{const out=Object.assign({},S);if(S.ph==='q'){delete out.cor;out.tl=Math.max(0,TL-(Date.now()-t0));out.pl=S.pl.map(p=>({id:p.id,n:p.n,sc:p.sc,d:p.a!=null?1:0}))}return out};
 function pub(){net.send(snap());render()}
 function startQ(){const q=round[S.qi];S.ph='q';S.cat=q[0];S.q=q[1];S.opts=q.ord.map(i=>q.o[i]);S.cor=q.ord.indexOf(0);S.tl=TL;S.pl.forEach(p=>{p.a=null;p.p=0});ansN=0;t0=Date.now();lEnd=performance.now()+TL;pub();botsQ()}
 // bots (host): antwoorden na 2–9 s, ~60% juist; één timer per bot, gewist bij een nieuwe vraag/einde (window.__botT = tempo voor tests)
 let bTm=[];function botsQ(){bTm.forEach(clearTimeout);bTm=[];const qi=S.qi,f=window.__botT>0?window.__botT:1;
  S.pl.forEach(p=>{if(!net.isBot(p.id))return;bTm.push(setTimeout(()=>{if(S.ph!=='q'||S.qi!==qi)return;const wr=[0,1,2,3].filter(i=>i!==S.cor);
   net.botAct(p.id,{k:'a',a:Math.random()<.6?S.cor:wr[Math.floor(Math.random()*3)]})},(2000+Math.random()*7000)*f))})}
 function hAns(id,k){const p=S.pl.find(x=>x.id===id);if(!p||S.ph!=='q'||p.a!=null||!(k>=0&&k<4))return;p.a=k|0;if(p.a===S.cor){p.p=PTS[Math.min(ansN,PTS.length-1)];ansN++}
  if(S.pl.every(x=>x.a!=null))reveal();else pub()}
 function reveal(){if(S.ph!=='q')return;S.ph='r';S.pl.forEach(p=>{if(p.a==null)p.a=-1;p.sc+=p.p});pub();const ok=mine()&&mine().p>0;beep(ok?880:200,.15,ok?'triangle':'sawtooth',.04);
  nt=setTimeout(()=>{S.qi++;if(S.qi>=PER){S.ph='end';pub();[0,1,2].forEach(i=>setTimeout(()=>beep(523*Math.pow(1.26,i),.12,'triangle',.05),i*120))}else startQ()},4500)}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(isH){if(d.k==='a')hAns(from,d.a);else if(d.k==='hi'&&S)net.sendTo(from,snap())}
  else if(d.k==='s'){S=d;if(S.ph==='r'&&lastPh!=='r'){const m=mine();beep(m&&m.p>0?880:200,.15,m&&m.p>0?'triangle':'sawtooth',.04)}lastPh=S.ph;render()}});
 const offP=net.onPlayers(ps=>{const ids=new Set(ps.map(p=>p.id));
  Object.keys(known).forEach(id=>{if(!ids.has(id)){notes.push('⚠️ '+known[id]+' heeft het spel verlaten');delete known[id];if(isH&&S){S.pl=S.pl.filter(p=>p.id!==id);if(S.ph==='q'&&S.pl.length&&S.pl.every(x=>x.a!=null))reveal()}}});
  ps.forEach(p=>{if(!known[p.id]){known[p.id]=net.pname(p);if(isH&&S&&!S.pl.some(x=>x.id===p.id)){S.pl.push({id:p.id,n:p.name,sc:0,a:null,p:0})}}});
  if(isH&&S)pub();else render()});
 const inp=input(st,[],k=>{if(k>='1'&&k<='4')answer(+k-1)});
 const stopLoop=loop(()=>{if(!S||S.ph!=='q')return;const f=Math.max(0,(lEnd-performance.now())/TL);bar.style.width=f*100+'%';bar.style.background=`hsl(${Math.round(f*120)},70%,50%)`});
 st.qz=()=>S;
 if(isH){const rng=net.rng(),sh=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
  round=sh(Q.slice()).slice(0,PER).map(q=>({0:q[0],1:q[1],o:q[2].split('|'),ord:sh([0,1,2,3])}));
  S={k:'s',ph:'q',qi:0,pl:net.players.map(p=>({id:p.id,n:p.name,sc:0,a:null,p:0}))};
  tm=setInterval(()=>{if(S.ph==='q'&&Date.now()-t0>=TL)reveal()},100);startQ()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{off();offP();inp.stop();stopLoop();clearInterval(tm);clearTimeout(nt);bTm.forEach(clearTimeout)}}},
