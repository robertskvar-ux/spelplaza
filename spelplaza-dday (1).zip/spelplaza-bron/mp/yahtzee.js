{id:'yahtzee',n:'Yahtzee met z’n allen',e:'🎲',c:'Samen',g:'#f12711,#f5af19',min:2,max:6,bots:true,run(st,net){
 // tekstkleur op een effen spelerskleur: zwart of wit, wat het meeste contrast geeft (altijd ≥ 4.5:1)
 const inkOn=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(String(h||'').trim());if(!m)return'#fff';const n=parseInt(m[1],16),L=[n>>16,n>>8&255,n&255].map(v=>{v/=255;return v<=.03928?v/12.92:((v+.055)/1.055)**2.4}),l=.2126*L[0]+.7152*L[1]+.0722*L[2];return (l+.05)/.05>1.05/(l+.05)?'#000':'#fff'};
 // Yahtzee om de beurt (host-authoritatief): 13 beurten per speler, max 3 worpen, gedeelde scorekaart met een kolom per speler.
 const PIPS=[[],[4],[2,6],[2,4,6],[0,2,6,8],[0,2,4,6,8],[0,2,3,5,6,8]];
 const CATS=[['Enen',1],['Tweeën',2],['Drieën',3],['Vieren',4],['Vijven',5],['Zessen',6],['3 gelijk','3k'],['4 gelijk','4k'],['Full house','fh'],['Kl. straat','ss'],['Gr. straat','ls'],['Yahtzee','y'],['Kans','ch']];
 const isH=net.isHost,me=net.me.id;
 function calc(k,d,Sc){const cnt=[0,0,0,0,0,0,0];d.forEach(v=>cnt[v]++);const sum=d.reduce((a,b)=>a+b,0),mx=Math.max(...cnt),yz=mx===5,joker=yz&&Sc.y===50;
  if(typeof k==='number')return cnt[k]*k;if(k==='3k')return mx>=3?sum:0;if(k==='4k')return mx>=4?sum:0;if(k==='ch')return sum;if(k==='y')return yz?50:0;
  if(k==='fh')return(mx===3&&cnt.includes(2))||joker?25:0;const has=a=>a.every(v=>cnt[v]);
  if(k==='ss')return has([1,2,3,4])||has([2,3,4,5])||has([3,4,5,6])||joker?30:0;if(k==='ls')return has([1,2,3,4,5])||has([2,3,4,5,6])||joker?40:0;return 0}
 const upper=p=>[1,2,3,4,5,6].reduce((a,k)=>a+(p.S[k]||0),0),bonus=p=>upper(p)>=63?35:0,lower=p=>['3k','4k','fh','ss','ls','y','ch'].reduce((a,k)=>a+(p.S[k]||0),0)+p.yb,total=p=>upper(p)+bonus(p)+lower(p),filled=p=>CATS.filter(([n,k])=>p.S[k]!=null).length;
 // ---- UI ----
 const sc=E('div','sc'),note=E('div','hint'),who=E('div');who.style.cssText='font-weight:700;min-height:22px';
 const diceRow=E('div');diceRow.style.cssText='display:flex;gap:10px;justify-content:center;margin:8px 0 10px';
 const dice=[],faces=[];for(let i=0;i<5;i++){const d=E('div');d.style.cssText='width:54px;height:54px;border-radius:12px;background:#fff;border:2px solid #ddd;box-shadow:0 3px 8px rgba(0,0,0,.3);display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(3,1fr);padding:7px;gap:2px;cursor:pointer;transition:transform .2s,box-shadow .2s;position:relative;user-select:none;-webkit-user-select:none;touch-action:manipulation';
  const pips=[];for(let k=0;k<9;k++){const p=E('span');p.style.cssText='border-radius:50%;background:#1b1d2a;visibility:hidden';d.append(p);pips.push(p)}
  const tag=E('span','','vast');tag.style.cssText='position:absolute;left:0;right:0;bottom:-19px;font-size:11px;font-weight:800;color:#f5af19;display:none';d.append(tag);d._tag=tag;
  d.onpointerdown=e=>{e.preventDefault();hold(i)};diceRow.append(d);dice.push(d);faces.push(pips)}
 const bRoll=E('button','btn','🎲 Gooi');bRoll.style.cssText='font-size:16px;padding:11px 22px;margin:14px 0 10px;background:linear-gradient(135deg,#f12711,#f5af19)';bRoll.onclick=()=>roll();
 const tw=E('div');tw.style.cssText='overflow-x:auto;margin:0 auto;max-width:520px';const tb=E('table');tb.style.cssText='border-collapse:collapse;width:100%;font-size:13px;text-align:center';tw.append(tb);
 st.append(sc,note,who,diceRow,bRoll,tw,E('div','hint','Tik op een dobbelsteen om hem vast te houden · tik op een rij in je kolom om te scoren · spatie = gooien · 1–5 = vasthouden'));
 let S=null,notes=[],known={},disp={},left=new Set,cells={},colIds='',lastRid=-1,anim=0,shown=[1,2,3,4,5],busy=0,podDone=0;
 net.players.forEach(p=>{known[p.id]=p.name;disp[p.id]=net.pname(p)});
 const cur=()=>S&&S.pl[S.t],myTurn=()=>S&&S.ph==='play'&&cur()&&cur().id===me;
 // naam met avatar (valt terug op de naam uit de toestand als de speler weg is) en kleur/avatar van een speler
 const pn=(id,n)=>{const q=net.players.find(x=>x.id===id);return q?net.pname(q):(n||'?')},pinfo=id=>net.players.find(x=>x.id===id)||{};
 function showDie(i,v){faces[i].forEach((p,k)=>p.style.visibility=PIPS[v].includes(k)?'visible':'hidden')}
 function buildTable(){cells={};tb.replaceChildren();const ids=S.pl.map(p=>p.id).join(',');colIds=ids;tw.style.maxWidth=Math.min(760,130+100*Math.max(3,S.pl.length))+'px';
  const mkRow=(label,key,isCat,head)=>{const tr=E('tr');const th=E(head?'th':'td');th.textContent=label;th.style.cssText='text-align:left;padding:5px 6px;white-space:nowrap;border-bottom:1px solid var(--ln,#ddd);'+(isCat?'font-weight:600':'color:var(--mu);font-size:12px');tr.append(th);
   S.pl.forEach(p=>{const td=E(head?'th':'td');td.style.cssText='padding:5px 4px;min-width:40px;border-bottom:1px solid var(--ln,#ddd);font-weight:'+(isCat?'400':'800');if(isCat)td.onpointerdown=e=>{e.preventDefault();pick(p.id,key)};(cells[p.id]=cells[p.id]||{})[key]=td;tr.append(td)});tb.append(tr);return tr};
  mkRow('',  'name',0,1);CATS.slice(0,6).forEach(([n,k])=>mkRow(n,k,1));mkRow('Bonus (63+)','bonus');mkRow('Boven','utot');CATS.slice(6).forEach(([n,k])=>mkRow(n,k,1));mkRow('Yahtzee-bonus','ybonus');mkRow('Totaal','tot')}
 function render(){if(!S)return;if(S.pl.map(p=>p.id).join(',')!==colIds)buildTable();const c=cur(),mt=myTurn(),m=S.pl.find(p=>p.id===me);
  note.textContent=notes.slice(-3).join(' · ');note.style.display=notes.length?'':'none';
  if(S.rid!==lastRid){const first=lastRid<0;lastRid=S.rid;if(!first&&S.rolls>0)animate();else{shown=S.d.slice()}}
  for(let i=0;i<5;i++){if(!anim)showDie(i,shown[i]);const h=S.h[i];dice[i].style.transform=h?'translateY(8px)':anim?dice[i].style.transform:'none';dice[i].style.boxShadow=h?'0 0 0 3px #f5af19,0 3px 8px rgba(0,0,0,.3)':'0 3px 8px rgba(0,0,0,.3)';dice[i].style.opacity=S.rolls===0||S.ph!=='play'?'.6':'1';dice[i]._tag.style.display=h?'block':'none';dice[i].style.cursor=mt&&S.rolls>0&&S.rolls<3?'pointer':'default'}
  S.pl.forEach(p=>{const C=cells[p.id],isC=c&&c.id===p.id,mine=p.id===me,q=pinfo(p.id),col=q.col||'var(--mu)';
   // kolomkop: avatar-bolletje + naam, bovenrand in de kleur van de speler, gevuld in die kleur als hij aan zet is
   C.name.replaceChildren();const av=E('span','pav s');av.style.cssText='--c:'+col+';width:22px;height:22px;font-size:13px;margin-right:4px';av.textContent=q.av||'🙂';const nmEl=E('span');nmEl.textContent=p.n+(mine?' (jij)':'');C.name.append(av,nmEl);
   C.name.style.cssText='padding:4px 4px;max-width:96px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;border-radius:8px 8px 0 0;border-top:3px solid '+col+';'+(isC&&S.ph==='play'?'background:'+col+';color:'+inkOn(col):'background:color-mix(in srgb,'+col+' 12%,var(--bg))');
   if(isC&&S.ph==='play')av.style.background='rgba(255,255,255,.85)';
   for(const[n,k]of CATS){const td=C[k],done=p.S[k]!=null,pot=mine&&mt&&S.rolls>0&&!done;td.textContent=done?p.S[k]:pot?calc(k,S.d,p.S):'';td.style.color=done?'var(--tx)':'var(--mu)';td.style.fontWeight=done?'700':'400';td.style.cursor=pot?'pointer':'default';td.style.background=pot?'color-mix(in srgb,'+col+' 22%,transparent)':isC&&S.ph==='play'?'color-mix(in srgb,'+col+' 9%,transparent)':'transparent'}
   C.bonus.textContent=bonus(p)||(upper(p)+'/63');C.utot.textContent=upper(p)+bonus(p);C.ybonus.textContent=p.yb||'';C.tot.textContent=total(p);C.tot.style.fontWeight='800';C.tot.style.color=col;C.bonus.style.fontSize=C.utot.style.fontSize=C.ybonus.style.fontSize='12px'});
  if(S.ph==='fin'){const r=S.pl.slice().sort((a,b)=>total(b)-total(a)),tie=r.length>1&&total(r[0])===total(r[1]);sc.textContent=r.length?(tie?'Klaar! Gelijkspel met '+total(r[0])+' punten':'Klaar! 🏆 '+pn(r[0].id,r[0].n)+' wint met '+total(r[0])+' punten'):'Klaar!';who.textContent='';bRoll.style.display='none';diceRow.style.display='none';
   if(!podDone){podDone=1;const scores={};r.forEach(p=>scores[p.id]=total(p));net.result({winner:!tie&&r[0]?r[0].id:null,scores,unit:' pt',title:tie?'Gelijkspel 🤝':undefined})}return}
  bRoll.style.display='';diceRow.style.display='flex';
  sc.textContent='Beurt '+Math.min(13,(c?filled(c):0)+1)+'/13'+(m?' · Jij: '+total(m):' · Je kijkt mee');
  who.textContent=c?(mt?'Jij bent aan zet':pn(c.id,c.n)+' is aan zet')+' · worp '+S.rolls+'/3'+(mt&&S.rolls===3?' · kies een rij':''):'';
  bRoll.textContent=mt?(S.rolls===3?'Kies een rij':'🎲 Gooi ('+(3-S.rolls)+' over)'):c?'⏳ '+pn(c.id,c.n)+' is bezig…':'…';bRoll.disabled=!mt||S.rolls>=3||anim;bRoll.style.opacity=mt&&S.rolls<3&&!anim?'1':'.5'}
 function animate(){if(anim)clearInterval(anim);let n=0;beep(300,.05,'triangle',.03);busy=1;
  anim=setInterval(()=>{n++;for(let i=0;i<5;i++)if(!S.h[i]){showDie(i,1+R(6));dice[i].style.transform='rotate('+(R(2)?-1:1)*(6+R(14))+'deg) scale(1.06)'}
   if(n>=7){clearInterval(anim);anim=0;busy=0;shown=S.d.slice();const cnt=[0,0,0,0,0,0,0];S.d.forEach(v=>cnt[v]++);beep(Math.max(...cnt)===5?880:520,Math.max(...cnt)===5?.4:.06,'triangle',.04);render()}},70)}
 function roll(){if(!myTurn()||S.rolls>=3||anim)return;send({k:'roll'})}
 function hold(i){if(!myTurn()||S.rolls===0||S.rolls>=3||anim)return;send({k:'hold',i})}
 function pick(pid,k){if(pid!==me||!myTurn()||S.rolls===0||anim)return;const p=S.pl.find(p=>p.id===me);if(!p||p.S[k]!=null)return;send({k:'pick',c:k})}
 function send(d){if(isH)act(me,d);else net.send(d)}
 // ---- host ----
 let gone={};
 function pub(){net.send(S);render();botSched()}
 function act(id,d){if(!S||S.ph!=='play')return;const p=cur();if(!p||p.id!==id)return;
  if(d.k==='roll'){if(S.rolls>=3)return;for(let i=0;i<5;i++)if(!S.h[i])S.d[i]=1+R(6);S.rolls++;S.rid++;pub();return true}
  else if(d.k==='hold'){const i=d.i|0;if(S.rolls===0||S.rolls>=3||i<0||i>4)return;S.h[i]=S.h[i]?0:1;pub();return true}
  else if(d.k==='pick'){const k=d.c;if(S.rolls===0||!CATS.some(x=>x[1]===k)||p.S[k]!=null)return;const cnt=[0,0,0,0,0,0,0];S.d.forEach(v=>cnt[v]++);
   if(Math.max(...cnt)===5&&p.S.y===50)p.yb+=100;p.S[k]=calc(k,S.d,p.S);next();return true}}
 function next(){S.rolls=0;S.h=[0,0,0,0,0];if(S.pl.length&&S.pl.every(p=>filled(p)===13)){S.ph='fin';pub();return}
  let g=0;do{S.t=(S.t+1)%S.pl.length}while(filled(S.pl[S.t])===13&&g++<S.pl.length);pub()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(isH){if(d.k==='hi'){if(S)net.sendTo(from,S)}else{const ok=act(from,d);if(net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}}}
  else if(d.k==='s'){S=d;render()}});
 const offP=net.onPlayers(ps=>{const ids=new Set(ps.map(p=>p.id));
  Object.keys(known).forEach(id=>{if(!ids.has(id)){notes.push('⚠️ '+(disp[id]||known[id])+' heeft het spel verlaten');left.add(known[id]);delete known[id];delete disp[id];
   if(isH&&S){const i=S.pl.findIndex(p=>p.id===id);if(i>=0){gone[S.pl[i].n]=S.pl[i];S.pl.splice(i,1);if(S.ph==='play'){if(i<S.t)S.t--;else if(i===S.t){S.t=(S.t-1+Math.max(1,S.pl.length))%Math.max(1,S.pl.length);next();return}}}}}});
  ps.forEach(p=>{if(!known[p.id]){known[p.id]=p.name;disp[p.id]=net.pname(p);if(left.has(p.name)){left.delete(p.name);notes.push('🔁 '+net.pname(p)+' is terug')}if(isH&&S&&!S.pl.some(x=>x.id===p.id)){const old=gone[p.name];const fresh=S.pl.every(x=>filled(x)===0);
   if(old&&S.ph==='play'){delete gone[p.name];S.pl.push(Object.assign(old,{id:p.id}))}else if(fresh&&S.ph==='play')S.pl.push({id:p.id,n:p.name,S:{},yb:0})}}});
  if(isH&&S)pub();else render()});
 const inp=input(st,[],k=>{if(k===' '||k==='Enter')roll();else if(k>='1'&&k<='5')hold(+k-1)});
 // ---- bots (alleen host): houden het meest voorkomende getal vast (of een straat), stoppen bij yahtzee/grote straat/full house, en kiezen de vrije rij met de beste waarde ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]}),bT={};
 const botKey=id=>S&&S.ph==='play'&&cur()&&cur().id===id?'Y|'+S.t+'|'+filled(cur())+'|'+S.rolls+'|'+S.h.join(''):null;
 function botSched(){if(!isH)return;net.bots().forEach(b=>{const k=botKey(b.id),o=bT[b.id];if(o&&o.k===k)return;if(o)clearTimeout(o.tm);delete bT[b.id];if(!k)return;
  bT[b.id]={k,tm:setTimeout(()=>{delete bT[b.id];if(botKey(b.id)!==k){botSched();return}botDo(b.id)},BT.fast?30+R(50):S.rolls?500+R(700):800+R(900))}})}
 function botUtil(k,d,P){const v=calc(k,d,P.S),cnt=[0,0,0,0,0,0,0];d.forEach(x=>cnt[x]++);const sum=d.reduce((a,b)=>a+b,0);
  if(typeof k==='number')return v-k*3+(cnt[k]>=4?6:0);// boven: "par" is 3 stuks (bonus 63)
  if(k==='ch')return v-22;if(k==='3k'||k==='4k')return v?v-(k==='3k'?16:12):-(k==='3k'?6:10);if(k==='y')return v?60:-12;if(k==='fh')return v?25:-14;if(k==='ss')return v?28:-12;if(k==='ls')return v?40:-16;return v}
 function botPlan(P){const d=S.d,cnt=[0,0,0,0,0,0,0];d.forEach(x=>cnt[x]++);const mx=Math.max(...cnt),free=k=>P.S[k]==null,has=a=>a.every(v=>cnt[v]);
  if(mx===5&&(free('y')||P.S.y===50))return{stop:1};if(free('ls')&&(has([1,2,3,4,5])||has([2,3,4,5,6])))return{stop:1};
  if(free('fh')&&mx===3&&cnt.includes(2)&&!(free(cnt.indexOf(3))&&cnt.indexOf(3)>=5))return{stop:1};
  const runs=[[1,2,3,4],[2,3,4,5],[3,4,5,6]].filter(has);if(runs.length&&(free('ls')||free('ss'))&&mx<3){if(!free('ls'))return{stop:1};const want=runs[0];const keep=[0,0,0,0,0],used={};d.forEach((v,i)=>{if(want.includes(v)&&!used[v]){used[v]=1;keep[i]=1}});return{keep}}
  // meest voorkomende waarde (bij gelijkstand de hoogste); 3-op-een-rij straat-aanzet als er niets dubbel is
  let f=0;for(let v=6;v>=1;v--)if(cnt[v]>cnt[f]||!f)f=v;if(mx===1&&(free('ls')||free('ss'))){const keep=d.map(v=>v>=2&&v<=5?1:0);const seen={};d.forEach((v,i)=>{if(keep[i]){if(seen[v])keep[i]=0;seen[v]=1}});return{keep}}
  return{keep:d.map(v=>v===f?1:0)}}
 function botDo(id){const P=cur();if(!P||P.id!==id)return;const say=d=>{BT.sent++;net.botAct(id,d)};
  if(S.rolls===0){say({k:'roll'});return}
  const plan=S.rolls<3?botPlan(P):{stop:1};
  if(!plan.stop){const i=S.h.findIndex((h,i)=>!!h!==!!plan.keep[i]);if(i>=0){say({k:'hold',i});return}if(plan.keep.some(v=>!v)){say({k:'roll'});return}}
  let best=null,bv=-1e9;for(const[n,k]of CATS){if(P.S[k]!=null)continue;const v=botUtil(k,S.d,P)+Math.random()*.5;if(v>bv){bv=v;best=k}}if(best!=null)say({k:'pick',c:best})}
 st.yz={get S(){return S},total,filled};
 if(isH){S={k:'s',ph:'play',t:0,d:[1,2,3,4,5],h:[0,0,0,0,0],rolls:0,rid:0,pl:net.players.map(p=>({id:p.id,n:p.name,S:{},yb:0}))};pub()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{off();offP();inp.stop();clearInterval(anim);Object.values(bT).forEach(o=>clearTimeout(o.tm))}}},
