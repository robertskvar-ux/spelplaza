{id:'hockey',n:'Airhockey',e:'🏒',c:'Samen',g:'#1d4350,#a43931',min:2,max:2,bots:true,run(st,net){
 // Airhockey op een staande tafel. Hostcoördinaten: host verdedigt onderaan, joiner bovenaan; de joiner ziet alles 180° gedraaid zodat zijn doel onderaan staat. Schijven en doelen in de spelerskleur.
 const W=300,H=480,MR=22,PR=11,GW=100,WIN=5,me=net.myIndex(),HOST=net.isHost,FLIP=me===1;
 const COL=['#2f80ed','#e5383b'],names=['…','…'],ids=[null,null];
 const hx=h=>[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0),mix=(h,t)=>'rgb('+hx(h).map(q=>Math.round(q+(255-q)*t)).join(',')+')',rgba=(h,a)=>'rgba('+hx(h).join(',')+','+a+')';
 const sc=E('div','sc'),c=mkCanvas(st,W,H),x=c.getContext('2d');st.prepend(sc);
 st.append(E('div','hint','Sleep je schijf (onderste helft) met vinger of muis · pijltjes werken ook · eerste tot 5 goals wint'));
 const inp=input(st,[]),clamp=(v,a,b)=>v<a?a:v>b?b:v;let gone=0,left='',last=null,fl=0,acc=0,sendT=0,sx=-1,sy=-1,trail=[],t=0,ended=0;
 // S: m = malletposities [x0,y0,x1,y1], p = puck, v = pucksnelheid (alleen host), s = scores, pz = pauze na goal, w = winnaar, h/b/g = tellers (slag, band, goal)
 let S={m:[W/2,H-70,W/2,70],p:[W/2,H/2],s:[0,0],pz:1,w:-1,h:0,b:0,g:0},v=[0,0],mv=[[0,0],[0,0]],pm=[[W/2,H-70],[W/2,70]];
 let mx=FLIP?W/2:W/2,my=FLIP?70:H-70,tx=null,ty=null,drag=0;
 const lim=(i,px,py)=>[clamp(px,MR,W-MR),i?clamp(py,MR,H/2-MR):clamp(py,H/2+MR,H-MR)];
 const sub=()=>HOST?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten';
 function ov(big,small){if(!big){overlay(st,c,'');return}const o=overlay(st,c,' ');o.replaceChildren();const a=E('div');a.textContent=big;const b=E('div');b.style.cssText='font-size:15px;font-weight:600';b.textContent=small||'';o.append(a,b);o.style.pointerEvents='none'}
 function refresh(){if(gone)ov(left?'⚠️ '+left+' heeft het spel verlaten':'Wachten op speler…',sub());else ov('')}
 function line(){sc.replaceChildren();[0,1].forEach(i=>{const s=E('span');s.style.color=COL[i];s.textContent=names[i]+(i===me?' (jij)':'');sc.append(s);if(!i){const m=E('span');m.textContent='  '+S.s[0]+' – '+S.s[1]+'  ';sc.append(m)}});
  if(S.w>=0){const w=E('span');w.style.color='var(--mu)';w.textContent=' · 🏆 '+names[S.w]+' wint';sc.append(w)}}
 function conn(){net.players.forEach((p,i)=>{if(i>1)return;names[i]=net.pname(p);COL[i]=net.pcol(p);ids[i]=p.id});const was=gone;if(net.players.length<2){gone=1;if(!was)left=names[1-me]==='…'?'':names[1-me]}else{gone=0;left='';if(HOST&&was&&S.w<0)reset(-1)}refresh();line()}
 function endCheck(){if(S.w<0||ended)return;ended=1;line();net.result({winner:ids[S.w],scores:{[ids[0]]:S.s[0],[ids[1]]:S.s[1]},unit:' goals',text:'Eerste tot '+WIN+' goals'})}
 function reset(who){S.p=[W/2,who<0?H/2:who?H*.3:H*.7];v=[0,0];S.pz=1.2;trail=[]}
 function goal(i){S.s[i]++;S.g++;if(S.s[i]>=WIN){S.w=i;S.p=[W/2,H/2];v=[0,0]}else reset(1-i)}
 function step(dt){for(let i=0;i<2;i++){const px=S.m[i*2],py=S.m[i*2+1];mv[i]=[mv[i][0]*.6+(px-pm[i][0])/dt*.4,mv[i][1]*.6+(py-pm[i][1])/dt*.4];pm[i]=[px,py]}
  if(S.pz>0){S.pz-=dt;return}const p=S.p;
  const f=Math.max(0,1-.45*dt);v[0]*=f;v[1]*=f;p[0]+=v[0]*dt;p[1]+=v[1]*dt;
  if(p[0]<PR){p[0]=PR;v[0]=Math.abs(v[0])*.85;S.b++}else if(p[0]>W-PR){p[0]=W-PR;v[0]=-Math.abs(v[0])*.85;S.b++}
  const inG=Math.abs(p[0]-W/2)<GW/2-2;
  if(p[1]<PR&&!inG){p[1]=PR;v[1]=Math.abs(v[1])*.85;S.b++}else if(p[1]>H-PR&&!inG){p[1]=H-PR;v[1]=-Math.abs(v[1])*.85;S.b++}
  if(p[1]<-PR){goal(0);return}if(p[1]>H+PR){goal(1);return}
  for(let i=0;i<2;i++){const dx=p[0]-S.m[i*2],dy=p[1]-S.m[i*2+1],d=Math.hypot(dx,dy)||.001;if(d<MR+PR){const nx=dx/d,ny=dy/d;p[0]=S.m[i*2]+nx*(MR+PR);p[1]=S.m[i*2+1]+ny*(MR+PR);
   const rv=(v[0]-mv[i][0])*nx+(v[1]-mv[i][1])*ny;if(rv<0){v[0]-=1.75*rv*nx;v[1]-=1.75*rv*ny;S.h++}}}
  const sp=Math.hypot(v[0],v[1]);if(sp>900){v[0]*=900/sp;v[1]*=900/sp}}
 const snap=()=>({h:S.h,b:S.b,g:S.g,w:S.w,a:S.s[me],o:S.s[1-me]});
 function fx(){const n=snap();if(last){if(n.h!==last.h){beep(700,.05,'square',.03);fl=.5}if(n.b!==last.b)beep(300,.03,'square',.02);
  if(n.g!==last.g){fl=1;trail=[];beep(n.a!==last.a?880:200,.35,n.a!==last.a?'triangle':'sawtooth',.05);line()}}last=n;endCheck()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(HOST){if(d.k==='i'&&from===net.players[1]?.id){const q=lim(1,+d.x||0,+d.y||0);S.m[2]=q[0];S.m[3]=q[1]}}
  else if(d.k==='s'&&Array.isArray(d.d)){const q=d.d;S={m:q.slice(0,4),p:[q[4],q[5]],s:[q[6],q[7]],pz:q[8],w:q[9],h:q[10],b:q[11],g:q[12]}}});
 const offP=net.onPlayers(conn);
 const pos=e=>{const r=c.getBoundingClientRect();let px=(e.clientX-r.left)*W/r.width,py=(e.clientY-r.top)*H/r.height;return FLIP?[W-px,H-py]:[px,py]};
 c.onpointerdown=e=>{e.preventDefault();drag=1;[tx,ty]=pos(e);try{c.setPointerCapture(e.pointerId)}catch(_){}};
 c.onpointermove=e=>{if(drag)[tx,ty]=pos(e)};c.onpointerup=c.onpointercancel=()=>{drag=0};
 function circ(px,py,r,col){const g=x.createRadialGradient(px-r*.3,py-r*.3,r*.1,px,py,r);g.addColorStop(0,'#fff');g.addColorStop(.25,col);g.addColorStop(1,'#000');x.fillStyle=g;x.beginPath();x.arc(px,py,r,0,7);x.fill()}
 function mallet(px,py,i){const col=COL[i];x.shadowColor=mix(col,.2);x.shadowBlur=14;circ(px,py,MR,col);x.shadowBlur=0;x.strokeStyle=mix(col,.55);x.lineWidth=2;x.beginPath();x.arc(px,py,MR-1,0,7);x.stroke();x.fillStyle=mix(col,.3);x.beginPath();x.arc(px,py,MR*.42,0,7);x.fill();x.fillStyle='rgba(255,255,255,.35)';x.beginPath();x.arc(px-3,py-3,MR*.18,0,7);x.fill()}
 function draw(dt){x.setTransform(1,0,0,1,0,0);x.fillStyle='#0e1020';x.fillRect(0,0,W,H);if(FLIP){x.translate(W,H);x.rotate(Math.PI)}
  x.fillStyle='#131838';x.beginPath();x.roundRect(4,4,W-8,H-8,14);x.fill();x.strokeStyle='#2a2f55';x.lineWidth=2;x.beginPath();x.moveTo(4,H/2);x.lineTo(W-4,H/2);x.stroke();x.beginPath();x.arc(W/2,H/2,40,0,7);x.stroke();
  [[0,1],[H,0]].forEach(([gy,i])=>{x.strokeStyle=rgba(COL[i],.35);x.beginPath();x.arc(W/2,gy,70,0,7);x.stroke();x.shadowColor=mix(COL[i],.3);x.shadowBlur=18;x.fillStyle=COL[i];x.fillRect(W/2-GW/2,gy-(i?0:6),GW,6);x.shadowBlur=0;x.fillStyle=mix(COL[i],.5);x.fillRect(W/2-GW/2,gy-(i?0:6)+(i?0:4),GW,2)});
  x.strokeStyle='#3a4075';x.lineWidth=4;x.beginPath();x.roundRect(4,4,W-8,H-8,14);x.stroke();
  const m=S.m.slice();if(!HOST){m[2]=mx;m[3]=my}else{m[0]=mx;m[1]=my}
  if(S.pz<=0&&S.w<0){trail.push([S.p[0],S.p[1]]);if(trail.length>8)trail.shift()}
  trail.forEach(([px,py],i)=>{x.globalAlpha=(i+1)/trail.length*.3;x.fillStyle='#fff';x.beginPath();x.arc(px,py,PR*(.5+.5*i/trail.length),0,7);x.fill()});x.globalAlpha=1;
  mallet(m[0],m[1],0);mallet(m[2],m[3],1);
  if(S.w<0){x.shadowColor='#fff';x.shadowBlur=8;circ(S.p[0],S.p[1],PR,'#555');x.shadowBlur=0}
  x.setTransform(1,0,0,1,0,0);x.textAlign='center';x.font='bold 90px system-ui,sans-serif';x.fillStyle=rgba(COL[1-me],.12);x.fillText(S.s[1-me],W/2,H/4+32);x.fillStyle=rgba(COL[me],.12);x.fillText(S.s[me],W/2,3*H/4+32);
  x.font='bold 12px system-ui,sans-serif';x.textAlign='left';x.shadowColor='#000';x.shadowBlur=4;x.fillStyle=mix(COL[1-me],.4);x.fillText(names[1-me],14,24);x.fillStyle=mix(COL[me],.4);x.fillText(names[me],14,H-14);x.shadowBlur=0;x.textAlign='center';
  if(fl>0){x.fillStyle='rgba(255,255,255,'+(fl*.15)+')';x.fillRect(0,0,W,H);fl-=dt*3}
  if(S.pz>0&&S.g>0&&S.w<0&&!gone){x.fillStyle='#fff';x.shadowColor='#000';x.shadowBlur=10;x.font='bold '+(36+Math.sin(t*12)*3)+'px system-ui,sans-serif';x.fillText('GOAL!',W/2,H/2+12);x.shadowBlur=0}}
 // ---- bot (alleen op de host, bovenste helft): ziet de puck met ~0,2 s vertraging, verdedigt tussen puck en eigen doel en valt aan
 // door achter de puck te gaan en er richting het doel van de host (met een mikfout) doorheen te duwen. Max. 300 px/s, stuurt {k:'i',x,y} 10×/s.
 let bT=0,bX=W/2,bY=70,bAim=0,bHist=[],bSx=-1,bSy=-1,bAtt=0;
 function botTick(dt){const b=net.players[1];if(!b||!net.isBot(b.id)||gone||S.w>=0)return;
  bHist.push([S.p[0],S.p[1],v[0],v[1]]);if(bHist.length>12)bHist.shift();bT+=dt;if(bT<.1)return;const st=bT;bT=0;
  const[px,py,vx,vy]=bHist[0];let tx,ty;
  if(S.pz>0){tx=W/2;ty=70;bAtt=0}
  else if(py<H/2+MR&&vy<160){if(!bAtt){bAtt=1;bAim=(Math.random()-.5)*(Math.random()<.2?GW*1.6:GW*.8)}
   const gx=W/2+bAim,gy=H+30,ax=gx-px,ay=gy-py,al=Math.hypot(ax,ay)||1,ux=ax/al,uy=ay/al;
   const[cx,cy]=lim(1,px-ux*(MR+PR+8),py-uy*(MR+PR+8)),front=(bX-px)*ux+(bY-py)*uy;
   if(front>-4){tx=px+(bX<px?-1:1)*(MR+PR+14);ty=py-MR}// verkeerde kant: om de puck heen
   else if(Math.hypot(bX-cx,bY-cy)<16){tx=px+ux*40;ty=py+uy*40}// erdoor!
   else{tx=cx;ty=cy}}
  else{bAtt=0;const ly=py<H/2?py:H/2;tx=W/2+(px-W/2)*.55+(vx*.05);ty=Math.min(90,ly-MR-PR)}
  const dx=tx-bX,dy=ty-bY,d=Math.hypot(dx,dy),sp=Math.min(d,300*st);if(d>0){bX+=dx/d*sp;bY+=dy/d*sp}[bX,bY]=lim(1,bX,bY);
  if(Math.abs(bX-bSx)>=.5||Math.abs(bY-bSy)>=.5){bSx=bX;bSy=bY;net.botAct(b.id,{k:'i',x:Math.round(bX*10)/10,y:Math.round(bY*10)/10})}}
 const stop=loop(dt=>{t+=dt;const i=me;let kx=(inp.has('ArrowRight')||inp.has('d')?1:0)-(inp.has('ArrowLeft')||inp.has('a')?1:0),ky=(inp.has('ArrowDown')||inp.has('s')?1:0)-(inp.has('ArrowUp')||inp.has('w')?1:0);
  if(kx||ky){tx=ty=null;if(FLIP){kx=-kx;ky=-ky}mx+=kx*360*dt;my+=ky*360*dt}
  if(tx!=null){const dx=tx-mx,dy=ty-my,d=Math.hypot(dx,dy),s=Math.min(d,1600*dt);if(d>0){mx+=dx/d*s;my+=dy/d*s}}
  [mx,my]=lim(i,mx,my);
  if(HOST){S.m[0]=mx;S.m[1]=my;if(!gone&&S.w<0){step(dt);botTick(dt)}acc+=dt;if(acc>=.04){acc=Math.min(acc-.04,.04);const r1=q=>Math.round(q*10)/10;net.send({k:'s',d:[...S.m.map(r1),r1(S.p[0]),r1(S.p[1]),S.s[0],S.s[1],r1(S.pz),S.w,S.h,S.b,S.g]})}}
  else{sendT+=dt;if((Math.abs(mx-sx)>=.5||Math.abs(my-sy)>=.5)&&sendT>=.04){sendT=0;sx=mx;sy=my;net.send({k:'i',x:Math.round(mx*10)/10,y:Math.round(my*10)/10})}}
  fx();draw(dt)});
 conn();line();window.__dbg={s:()=>JSON.parse(JSON.stringify(S)),my:()=>[mx,my],v:()=>v.slice()};
 return()=>{stop();inp.stop();off();offP();c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null;delete window.__dbg}}},
