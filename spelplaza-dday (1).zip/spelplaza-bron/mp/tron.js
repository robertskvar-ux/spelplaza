{id:'tron',n:'Tron lichtcycli',e:'🏍️',c:'Samen',g:'#0f2027,#2c5364',min:2,max:4,bots:true,run(st,net){
 // Tron voor 2–4 spelers. 2 spelers: 60×60 rooster, links/rechts. 3–4 spelers: 72×72 met een draaimolen-opstelling langs de randen.
 // Host simuleert; sporen reizen als hoekpunten-lijsten (polylines), toestand 25×/s. Laatste overlevende wint de ronde, eerste tot 3 wint.
 const HOST=net.isHost,DX=[1,0,-1,0],DY=[0,1,0,-1],WIN=3,SPD=15;
 const seat0=net.players.slice(0,4),P=Math.max(2,seat0.length),N=P>2?72:60,CS=360/N,W=N*CS;
 const SP=P>2?[[12,30,0],[59,41,2],[41,12,1],[30,59,3]]:[[14,30,0],[45,30,2]];
 const COL=seat0.map(p=>net.pcol(p)),names=seat0.map(p=>net.pname(p)),avs=seat0.map(p=>p.av||'🙂');while(COL.length<P){COL.push('#888');names.push('…');avs.push('🙂')}
 const hx=h=>[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0),mix=(h,t)=>'rgb('+hx(h).map(q=>Math.round(q+(255-q)*t)).join(',')+')';
 const sc=E('div','sc'),note=E('div','hint'),c=mkCanvas(st,W,W),x=c.getContext('2d');st.prepend(sc);c.before(note);note.style.cssText='margin:2px 0;min-height:'+(P>2?'18px':'0');
 st.append(E('div','hint','Pijltjes, WASD, veeg op het veld of de knoppen = afslaan · bots nergens tegenaan · laatste die rijdt wint de ronde · 3 rondes wint'));
 let gone=0,left='',last=null,fl=0,parts=[],acc=0,tick=0,occ,ended=0,noteT=0;
 // S.ids = spelers per stoel, S.q = stoel verlaten
 let S={ids:seat0.map(p=>p.id),q:Array(P).fill(0),p:[],d:[],a:[],s:Array(P).fill(0),cd:3,w:-1,r:1,rw:-1,rt:0,c:0},want=Array(P).fill(-1);
 const myS=()=>S.ids.indexOf(net.me.id),K2D={ArrowRight:0,d:0,ArrowDown:1,s:1,ArrowLeft:2,a:2,ArrowUp:3,w:3};
 function turn(d){const me=myS();if(me<0||S.w>=0||gone)return;if(HOST)want[me]=d;else net.send({k:'i',d})}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight']],k=>{if(K2D[k]!=null)turn(K2D[k])});
 let sx,sy;c.onpointerdown=e=>{e.preventDefault();sx=e.clientX;sy=e.clientY};
 c.onpointerup=e=>{if(sx==null)return;const dx=e.clientX-sx,dy=e.clientY-sy;sx=null;if(Math.max(Math.abs(dx),Math.abs(dy))<14)return;turn(Math.abs(dx)>Math.abs(dy)?(dx>0?0:2):(dy>0?1:3))};
 const sub=()=>HOST?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten';
 function ov(big,small){if(!big){overlay(st,c,'');return}const o=overlay(st,c,' ');o.replaceChildren();const a=E('div');a.textContent=big;const b=E('div');b.style.cssText='font-size:15px;font-weight:600';b.textContent=small||'';o.append(a,b);o.style.pointerEvents='none'}
 function refresh(){if(gone)ov(left?'⚠️ '+left+' heeft het spel verlaten':'Wachten op speler…',sub());else ov('')}
 function say(t){note.textContent=t;clearTimeout(noteT);noteT=setTimeout(()=>{note.textContent=''},4000)}
 function line(){sc.replaceChildren();const me=myS();
  if(P===2){[0,1].forEach(i=>{const s=E('span');s.style.color=COL[i];s.textContent=names[i]+(i===me?' (jij)':'');sc.append(s);if(!i){const m=E('span');m.textContent='  '+S.s[0]+' – '+S.s[1]+'  ';sc.append(m)}})}
  else for(let i=0;i<P;i++){const s=E('span');s.style.cssText='color:'+COL[i]+';margin:0 5px;white-space:nowrap;'+(S.q[i]?'opacity:.35;text-decoration:line-through;':!S.a[i]&&S.cd<=0?'opacity:.5;':'')+(i===me?'text-decoration:underline;':'');s.textContent=avs[i]+' '+S.s[i]+(i===me?' (jij)':'');sc.append(s)}
  const r=E('span');r.style.color='var(--mu)';r.textContent=S.w>=0?' · 🏆 '+names[S.w]+' wint':' · ronde '+S.r;sc.append(r)}
 function conn(){const ps=net.players,ids=new Set(ps.map(p=>p.id));
  for(let i=0;i<P;i++){const p=ps.find(q=>q.id===S.ids[i]);if(p){names[i]=net.pname(p);COL[i]=net.pcol(p);avs[i]=p.av||'🙂'}}
  if(HOST){let ch=0;for(let i=0;i<P;i++)if(!S.q[i]&&!ids.has(S.ids[i])){S.q[i]=1;ch=1;say('⚠️ '+names[i]+' heeft het spel verlaten');if(S.a[i]){S.a[i]=0;if(S.q.filter(q=>!q).length>=2)settle()}}
   const act=()=>S.q.filter(q=>!q).length;
   if(act()<2){// stoel vrij → nieuwe speler mag hem overnemen (zoals bij 2 spelers)
    ps.forEach(p=>{if(S.ids.includes(p.id))return;const i=S.q.indexOf(1);if(i<0)return;S.ids[i]=p.id;S.q[i]=0;names[i]=net.pname(p);COL[i]=net.pcol(p);avs[i]=p.av||'🙂'})}
   const was=gone;if(act()<2){gone=1;if(!was){const i=S.q.indexOf(1);left=i>=0&&names[i]!=='…'?names[i]:''}}else{gone=0;left='';if(was&&S.w<0)newRound()}}
  else{const act=S.q.filter(q=>!q).length,was=gone;gone=ps.length<2||act<2?1:0;if(gone&&!was){const o=S.ids.findIndex(id=>id!==net.me.id&&!ids.has(id)),i=S.q.indexOf(1);left=o>=0?names[o]:i>=0?names[i]:''}if(!gone)left=''}
  refresh();line()}
 function endCheck(){if(S.w<0||ended)return;ended=1;line();const scores={};S.ids.forEach((id,i)=>scores[id]=S.s[i]);net.result({winner:S.ids[S.w],scores,unit:' rondes',text:'Beslist na '+S.r+' rondes · eerste tot '+WIN})}
 function newRound(){occ=new Uint8Array(N*N);S.p=[];S.d=[];S.a=[];for(let i=0;i<P;i++){const[a,b,d]=SP[i];S.p.push([a,b,a,b]);S.d.push(d);S.a.push(S.q[i]?0:1);if(!S.q[i])occ[b*N+a]=i+1}
  S.cd=3;S.rw=-1;S.rt=0;want=Array(P).fill(-1);acc=0}
 // ronde beslist zodra er hoogstens één rijder over is; tegelijk de laatste crashes = gelijkspel (rw=-2)
 function settle(){if(S.rt>0||S.w>=0)return;const al=[];S.a.forEach((a,i)=>{if(a)al.push(i)});if(al.length>1)return;
  S.rw=al.length?al[0]:-2;S.rt=1.8;if(S.rw>=0){S.s[S.rw]++;if(S.s[S.rw]>=WIN)S.w=S.rw}}
 function step(){stepN++;const nh=[],cr=Array(P).fill(0);let any=0;
  for(let i=0;i<P;i++){if(!S.a[i]){nh.push(null);continue}const p=S.p[i],w=want[i];
   if(w>=0&&w!==S.d[i]&&(w+2)%4!==S.d[i]){S.d[i]=w;p.push(p[p.length-2],p[p.length-1])}want[i]=-1;
   const hx=p[p.length-2]+DX[S.d[i]],hy=p[p.length-1]+DY[S.d[i]];nh.push([hx,hy]);
   if(hx<0||hy<0||hx>=N||hy>=N||occ[hy*N+hx])cr[i]=1}
  for(let i=0;i<P;i++)for(let j=i+1;j<P;j++)if(nh[i]&&nh[j]&&nh[i][0]===nh[j][0]&&nh[i][1]===nh[j][1])cr[i]=cr[j]=1;
  for(let i=0;i<P;i++)if(nh[i]){const p=S.p[i];p[p.length-2]=nh[i][0];p[p.length-1]=nh[i][1];if(cr[i]){S.a[i]=0;S.c++;any=1}else occ[nh[i][1]*N+nh[i][0]]=i+1}
  if(any)settle()}
 // ---- bots (alleen op de host): na elke stap kiest elke bot met een flood-fill-vooruitblik de richting met de meeste vrije ruimte
 // (rechtdoor bij gelijkstand, kans op een kop-aan-kop telt mee), soms een iets slechtere keuze; stuurt {k:'i',d} zoals een joiner, max. 10×/s.
 const bSent={},bStep={};let stepN=0;
 function flood(sx,sy,cap){if(sx<0||sy<0||sx>=N||sy>=N||occ[sy*N+sx])return 0;const seen=new Uint8Array(N*N),q=[sy*N+sx];seen[q[0]]=1;let n=0;
  while(q.length&&n<cap){const c=q.pop();n++;const cx=c%N,cy=(c/N)|0;for(let d=0;d<4;d++){const X=cx+DX[d],Y=cy+DY[d];if(X<0||Y<0||X>=N||Y>=N)continue;const j=Y*N+X;if(!seen[j]&&!occ[j]){seen[j]=1;q.push(j)}}}return n}
 function botThink(){const cap=P>2?500:350;
  for(let i=1;i<P;i++){const id=S.ids[i];if(!S.a[i]||S.q[i]||!net.isBot(id))continue;if(bStep[id]===stepN||stepN-(bSent[id]||-9)<2)continue;bStep[id]=stepN;
   const p=S.p[i],hx=p[p.length-2],hy=p[p.length-1],cd=S.d[i],opts=[];
   for(const d of [cd,(cd+1)%4,(cd+3)%4]){const nx=hx+DX[d],ny=hy+DY[d];let v=flood(nx,ny,cap);
    if(v>0){for(let j=0;j<P;j++){if(j===i||!S.a[j])continue;const q=S.p[j],ox=q[q.length-2]+DX[S.d[j]],oy=q[q.length-1]+DY[S.d[j]];if(ox===nx&&oy===ny)v*=.3}
     if(d===cd)v+=1.5;v+=Math.random()*.8}opts.push([v,d])}
   opts.sort((a,b)=>b[0]-a[0]);let pick=opts[0];
   if(opts[1][0]>0&&opts[1][0]>=opts[0][0]*.8&&Math.random()<.12)pick=opts[1];// af en toe een menselijke, minder goede keuze
   else if(pick[1]===cd&&opts[1][0]>=cap*.9&&Math.random()<.04)pick=opts[1];// en soms gewoon een bocht op open terrein
   if(pick[1]!==cd&&pick[0]>0){bSent[id]=stepN;net.botAct(id,{k:'i',d:pick[1]})}}}
 function sim(dt){if(S.rt>0){S.rt-=dt;if(S.rt<=0&&S.w<0){S.r++;newRound()}return}
  if(S.cd>0){S.cd-=dt;if(S.cd<0)S.cd=0;return}acc+=dt*(window.__tronFast||1);while(acc>=1/SPD){acc-=1/SPD;if(S.rt<=0)step()}if(S.rt<=0&&S.w<0)botThink()}
 const snap=()=>({c:S.c,cd:Math.ceil(S.cd),w:S.w,s:S.s.join(),r:S.r,a:S.a.slice(),q:S.q.join(),ids:S.ids.join()});
 function fx(){const n=snap(),me=myS();if(last){
  if(n.c!==last.c){fl=1;n.a.forEach((a,i)=>{if(!a&&last.a[i]&&S.p[i]){const p=S.p[i],hx=p[p.length-2]*CS+CS/2,hy=p[p.length-1]*CS+CS/2;beep(i===me?120:300,.35,'sawtooth',.05);
   for(let k=0;k<30;k++){const an=Math.random()*7,v=30+Math.random()*150;parts.push({x:hx,y:hy,vx:Math.cos(an)*v,vy:Math.sin(an)*v,l:.5+Math.random()*.7,c:k%3?(k%2?COL[i]:mix(COL[i],.4)):'#fff'})}}})}
  if(n.cd!==last.cd&&last.cd>0)beep(n.cd?440:700,n.cd?.06:.15,'square',.03);
  if(n.ids!==last.ids)conn();
  if(n.s!==last.s||n.r!==last.r||n.q!==last.q||n.a.join()!==last.a.join()||(n.cd===0)!==(last.cd===0))line();
  if(!HOST&&n.q!==last.q){const qa=last.q.split(',');S.q.forEach((q,i)=>{if(q&&qa[i]==='0')say('⚠️ '+names[i]+' heeft het spel verlaten')});conn()}
  if(n.w!==last.w)beep(n.w===me?880:220,.4,'triangle',.05)}last=n;endCheck()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(HOST){if(d.k==='i'&&d.d>=0&&d.d<4){const i=S.ids.indexOf(from);if(i>0&&!S.q[i])want[i]=d.d|0}}
  else if(d.k==='s'&&Array.isArray(d.p)&&d.p.length===P){S={ids:d.ids,q:d.q,p:d.p,d:d.d,a:d.a,s:d.s,cd:d.cd,w:d.w,r:d.r,rw:d.rw,rt:d.rt,c:d.c}}});
 const offP=net.onPlayers(conn);
 function trail(i){const p=S.p[i];if(!p||p.length<2)return;x.lineCap=x.lineJoin='round';x.globalAlpha=1;
  [[CS+6,.2,COL[i]],[CS-1.5,1,COL[i]],[Math.max(1,CS-4),.8,mix(COL[i],.55)]].forEach(([lw,al,col])=>{x.strokeStyle=col;x.globalAlpha=al*(S.q[i]?.4:1);x.lineWidth=lw;x.beginPath();x.moveTo(p[0]*CS+CS/2,p[1]*CS+CS/2);for(let k=2;k<p.length;k+=2)x.lineTo(p[k]*CS+CS/2,p[k+1]*CS+CS/2);x.stroke()});x.globalAlpha=1;
  if(S.a[i]){x.shadowColor=mix(COL[i],.5);x.shadowBlur=14;x.fillStyle='#fff';x.fillRect(p[p.length-2]*CS,p[p.length-1]*CS,CS,CS);x.shadowBlur=0}}
 function draw(dt){const me=myS();x.fillStyle='#0e1020';x.fillRect(0,0,W,W);x.strokeStyle='#171c3a';x.lineWidth=1;x.beginPath();for(let i=CS*(P>2?6:5);i<W;i+=CS*(P>2?6:5)){x.moveTo(i+.5,0);x.lineTo(i+.5,W);x.moveTo(0,i+.5);x.lineTo(W,i+.5)}x.stroke();
  x.strokeStyle='#2a2f55';x.lineWidth=3;x.strokeRect(1.5,1.5,W-3,W-3);
  for(let i=0;i<P;i++)trail(i);
  // tijdens het aftellen: pijltje bij elke start en een label "jij" bij je eigen cyclus
  if(S.cd>0&&S.rt<=0&&S.p.length)for(let i=0;i<P;i++){if(!S.a[i])continue;const p=S.p[i],hx=p[p.length-2]*CS+CS/2,hy=p[p.length-1]*CS+CS/2,d=S.d[i];
   x.fillStyle=mix(COL[i],.3);x.beginPath();x.moveTo(hx+DX[d]*16,hy+DY[d]*16);x.lineTo(hx+DX[d]*8-DY[d]*5,hy+DY[d]*8+DX[d]*5);x.lineTo(hx+DX[d]*8+DY[d]*5,hy+DY[d]*8-DX[d]*5);x.fill();
   if(i===me){x.font='bold 11px system-ui,sans-serif';x.textAlign='center';x.fillStyle='#fff';x.fillText('jij',hx-DX[d]*14,hy-DY[d]*14+4)}}
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.95;p.vy*=.95;p.l-=dt;x.globalAlpha=Math.min(1,p.l*2);x.fillStyle=p.c;x.fillRect(p.x-2,p.y-2,4,4)}x.globalAlpha=1;parts=parts.filter(p=>p.l>0);
  if(fl>0){x.fillStyle='rgba(255,255,255,'+(fl*.15)+')';x.fillRect(0,0,W,W);fl-=dt*3}
  x.textAlign='center';x.fillStyle='#fff';
  if(S.cd>0&&!gone&&S.w<0&&S.rt<=0){const n=Math.ceil(S.cd),f=S.cd-Math.floor(S.cd);x.font='bold '+(44+f*30)+'px system-ui,sans-serif';x.globalAlpha=.4+f*.6;x.fillText(n,W/2,W/2+18);x.globalAlpha=1;x.fillStyle='#8a90b8';x.font='bold 14px system-ui,sans-serif';x.fillText('Ronde '+S.r+' · eerste tot '+WIN,W/2,W/2+46)}
  if(S.rt>0&&S.w<0){x.font='bold 24px system-ui,sans-serif';x.shadowColor='#000';x.shadowBlur=8;x.fillStyle=S.rw<0?'#fff':mix(COL[S.rw],.45);x.fillText(S.rw<0?'Gelijk! Niemand scoort':S.rw===me?'Jij wint de ronde!':names[S.rw]+' wint de ronde',W/2,W/2-60);x.shadowBlur=0}}
 const stop=loop(dt=>{if(HOST){if(!gone&&S.w<0)sim(dt);tick+=dt;if(tick>=.04){tick=Math.min(tick-.04,.04);net.send({k:'s',ids:S.ids,q:S.q,p:S.p,d:S.d,a:S.a,s:S.s,cd:Math.round(S.cd*100)/100,w:S.w,r:S.r,rw:S.rw,rt:Math.round(S.rt*100)/100,c:S.c})}}fx();draw(dt)});
 newRound();conn();line();window.__dbg={s:()=>JSON.parse(JSON.stringify(S))};
 return()=>{stop();inp.stop();off();offP();clearTimeout(noteT);c.onpointerdown=c.onpointerup=null;delete window.__dbg}}},
