{id:'checkers',n:'Dammen',e:'⚫',c:'Samen',g:'#8e9eab,#eef2f3',min:2,max:2,bots:true,run(st,net){
 // Dammen 10×10 (Nederlandse regels) voor 2 spelers: host = wit (begint), joiner = zwart (bord gespiegeld). Slaan verplicht, meerslag telt, dammen vliegen. Spelerchips (avatar + kleur) in de statusregel, podium aan het einde.
 const me=net.myIndex(),MY=me===0?1:-1,SYM=s=>s===1?'⚪':'⚫',FLIP=MY===-1,D2B=d=>FLIP?99-d:d;
 let opp=null;const P=s=>net.players[s===1?0:1]||(s===MY?net.me:opp),nm=s=>{const p=P(s);return p?net.pname(p):'…'},cl=s=>{const p=P(s);return p&&p.col||'#888'},pid=s=>{const p=P(s);return p?p.id:null};
 const tint=(h,a)=>{const v=[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0);return'rgba('+v.join(',')+','+a+')'};
 const sc=E('div','sc'),who=E('div','hint');who.style.cssText='min-height:26px;line-height:2;font-weight:600;color:var(--tx);margin:0 auto';
 const info=E('div','hint');info.style.cssText='min-height:18px;margin:2px auto';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(380px,100%);margin:4px auto';
 const bd=E('div','bdr');bd.style.cssText+='grid-template-columns:repeat(10,1fr);width:100%;gap:0;border-radius:8px;overflow:hidden;box-shadow:0 4px 14px rgba(0,0,0,.35);margin:0';
 const ov=E('div','ov');ov.style.display='none';wrap.append(bd,ov);
 const hint=E('div','hint','Tik op een schijf en dan op een vakje · slaan is verplicht (meeste stukken) · dammen vliegen');
 st.append(sc,who,info,wrap,hint);
 const sq=[],pc=[];
 for(let d=0;d<100;d++){const el=E('div');el.style.position='relative';
  const p=E('span');p.style.cssText='display:none;width:76%;height:76%;border-radius:50%;align-items:center;justify-content:center;font-size:min(20px,4.8vw);line-height:1;pointer-events:none;box-shadow:0 2px 4px rgba(0,0,0,.55)';el.append(p);pc.push(p);
  el.onpointerdown=e=>{e.preventDefault();tap(D2B(d))};sq.push(el);bd.append(el)}
 // ---------- spelerchips ----------
 function chip(s,on){const k=cl(s),c=E('span');c.style.cssText='display:inline-flex;align-items:center;gap:5px;padding:1px 9px;border-radius:99px;border:1.5px solid '+k+';background:'+tint(k,.14)+';white-space:nowrap;vertical-align:middle;line-height:1.5;'+(on===1?'box-shadow:0 0 0 3px '+tint(k,.3)+';font-weight:800':on===-1?'opacity:.55':'');
  c.append(document.createTextNode(SYM(s)+' '+nm(s)+(s===MY?' (jij)':'')));return c}
 function setWho(t,msg){who.replaceChildren();[1,-1].forEach((s,i)=>{if(i)who.append(document.createTextNode(' · '));who.append(chip(s,t?(t===s?1:-1):0));if(t===s&&!msg)who.append(document.createTextNode(s===MY?' bent aan zet':' is aan zet'))});if(msg)who.append(document.createTextNode(' · '+msg))}
 // ---------- regels ----------
 const DR=[[-1,-1],[-1,1],[1,-1],[1,1]],inB=(r,c)=>r>=0&&r<10&&c>=0&&c<10;
 function capsFrom(b,r,c,p,side,capt,path,out){let any=0;
  for(const[dr,dc]of DR){
   if(p===1){const r1=r+dr,c1=c+dc,r2=r+2*dr,c2=c+2*dc;if(!inB(r2,c2))continue;const i1=r1*10+c1;
    if(b[i1]*side<0&&!capt.includes(i1)&&!b[r2*10+c2]){capt.push(i1);path.push(r2*10+c2);any=1;capsFrom(b,r2,c2,p,side,capt,path,out);capt.pop();path.pop()}}
   else{let r1=r+dr,c1=c+dc;while(inB(r1,c1)&&!b[r1*10+c1]){r1+=dr;c1+=dc}
    if(!inB(r1,c1))continue;const i1=r1*10+c1;if(b[i1]*side>=0||capt.includes(i1))continue;
    let r2=r1+dr,c2=c1+dc;
    while(inB(r2,c2)&&!b[r2*10+c2]){capt.push(i1);path.push(r2*10+c2);any=1;capsFrom(b,r2,c2,p,side,capt,path,out);capt.pop();path.pop();r2+=dr;c2+=dc}}}
  if(!any&&capt.length)out.push({path:path.slice(),caps:capt.slice()})}
 function moves(b,side){let best=[],mx=0;
  for(let i=0;i<100;i++){const v=b[i];if(v*side<=0)continue;const p=Math.abs(v),out=[];b[i]=0;capsFrom(b,(i/10)|0,i%10,p,side,[],[],out);b[i]=v;
   for(const m of out){if(m.caps.length>mx){mx=m.caps.length;best=[]}if(m.caps.length===mx){m.f=i;m.t=m.path[m.path.length-1];best.push(m)}}}
  if(mx)return best;
  const ms=[];
  for(let i=0;i<100;i++){const v=b[i];if(v*side<=0)continue;const r=(i/10)|0,c=i%10;
   if(Math.abs(v)===1){const r1=r-side;for(const dc of[-1,1]){const c1=c+dc;if(inB(r1,c1)&&!b[r1*10+c1])ms.push({f:i,t:r1*10+c1,path:[r1*10+c1],caps:[]})}}
   else for(const[dr,dc]of DR){let r1=r+dr,c1=c+dc;while(inB(r1,c1)&&!b[r1*10+c1]){ms.push({f:i,t:r1*10+c1,path:[r1*10+c1],caps:[]});r1+=dr;c1+=dc}}}
  return ms}
 function apply(b,m,side){const nb=b.slice();let v=nb[m.f];nb[m.f]=0;for(const c of m.caps)nb[c]=0;if(Math.abs(v)===1&&((m.t/10)|0)===(side===1?0:9))v=2*side;nb[m.t]=v;return nb}
 // ---------- toestand ----------
 let b,t,over,sel,cand,step,dispB,dim,tg,lastP,busy,quiet,tms=[],gone=0,shown=0;
 function showOv(big,small){ov.replaceChildren();const x=E('div');x.textContent=big;const s=E('div');s.style.cssText='font-size:15px;font-weight:600';s.textContent=small||'';ov.append(x,s);ov.style.textShadow='0 1px 4px #000';ov.style.display='flex'}
 function refresh(){if(gone)showOv(opp?'⚠️ '+nm(-MY)+' heeft het spel verlaten':'Wachten op speler…',net.isHost?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten');else ov.style.display='none';draw();
  if(over&&!shown){shown=1;net.result({winner:over===3?null:pid(over),text:over===3?'25 zetten zonder slag of schijfzet':count(1)+' – '+count(-1)+' schijven · '+nm(-over)+' kan niet meer zetten'})}botTick()}
 function status(){over=0;const ms=moves(b,t);if(!ms.length)over=-t;else if(quiet>=50)over=3;
  if(over)beep(over===MY?880:over===3?330:160,.35,over===MY?'triangle':'sawtooth',.05);return ms}
 function count(v){let n=0;for(const x of b)if(x*v>0)n++;return n}
 function draw(){const B=dispB||b;
  for(let d=0;d<100;d++){const i=D2B(d),el=sq[d],v=B[i],dark=(((i/10)|0)+i%10)%2===1;let bg=dark?'#7a5a3c':'#ead9b8';
   if(dark&&lastP&&lastP.includes(i))bg='#9c7d3c';if(i===sel)bg='#c2a23a';el.style.backgroundColor=bg;
   el.style.backgroundImage=tg&&tg.has(i)?'radial-gradient(circle,rgba(255,225,110,.85) 0 19%,transparent 21%)':'none';
   const p=pc[d];if(!v){p.style.display='none';continue}p.style.display='flex';
   p.style.background=v>0?'radial-gradient(circle at 35% 35%,#fff,#dedede 55%,#9a9a9a)':'radial-gradient(circle at 35% 35%,#6a6a6a,#2a2a2a 55%,#000)';
   p.style.opacity=dim&&dim.includes(i)?'.3':'1';p.style.outline=i===sel?'3px solid #ffd54a':'none';p.style.outlineOffset='-1px';
   p.textContent=Math.abs(v)===2?'♛':'';p.style.color=v>0?'#c9a227':'#ffd54a'}
  sc.textContent='⚪ '+nm(1)+(MY===1?' (jij)':'')+' '+count(1)+' – '+count(-1)+' '+nm(-1)+(MY===-1?' (jij)':'')+' ⚫'+(over?over===3?' · 🤝 gelijkspel':over===MY?' · 🎉 jij wint!':' · 🏆 '+nm(over)+' wint!':'');
  setWho(over?0:t,over?'spel voorbij':busy?nm(-MY)+' slaat…':t===MY&&step?'ga verder met slaan…':'')}
 function tap(i){if(gone||over||busy||t!==MY)return;
  if(step){const nx=cand.filter(m=>m.path[step]===i);if(nx.length){advance(nx,i)}return}
  if(sel>=0&&cand){const nx=cand.filter(m=>m.path[0]===i);if(nx.length){advance(nx,i);return}}
  const all=moves(b,MY);if(b[i]*MY>0&&all.some(m=>m.f===i)){sel=i;cand=all.filter(m=>m.f===i);step=0;tg=new Set(cand.map(m=>m.path[0]));info.textContent=all[0].caps.length?'Slaan is verplicht'+(cand[0].caps.length>1?' · '+cand[0].caps.length+' stukken':''):''}
  else{sel=-1;cand=null;tg=null;info.textContent=b[i]*MY>0&&all.length&&all[0].caps.length?'Je moet slaan met een andere schijf':''}
  draw()}
 function advance(nx,i){cand=nx;step++;const m=nx[0];
  if(nx.every(x=>x.path.length===step)){play(m);return}
  dispB=b.slice();dispB[sel]=0;dispB[i]=b[sel];dim=m.caps.slice(0,step);tg=new Set(nx.map(x=>x.path[step]));lastP=[sel,...m.path.slice(0,step)];beep(300,.05,'square',.03);draw()}
 function commit(m,side){const mv=Math.abs(b[m.f])===1||m.caps.length;b=apply(b,m,side);quiet=mv?0:quiet+1;lastP=[m.f,...m.path];sel=-1;cand=null;step=0;dispB=null;dim=null;tg=null;t=-side;beep(m.caps.length?260:520,.06,'square',.03)}
 function play(m){commit(m,MY);status();info.textContent='';refresh();net.send({k:'mv',f:m.f,path:m.path})}
 function remote(d){if(over||busy||t!==MY*-1||!Array.isArray(d.path))return;const m=moves(b,-MY).find(x=>x.f===d.f&&x.path.length===d.path.length&&x.path.every((v,j)=>v===d.path[j]));if(!m)return;
  sel=-1;cand=null;step=0;tg=null;info.textContent='';if(m.path.length===1){commit(m,-MY);status();refresh();return true}
  busy=1;let k=0;const stepFn=()=>{if(k<m.path.length){dispB=(dispB||b).slice();dispB[k?m.path[k-1]:m.f]=0;dispB[m.path[k]]=b[m.f];dim=m.caps.slice(0,k+1);lastP=[m.f,...m.path.slice(0,k+1)];draw();k++;if(k<m.path.length){tms.push(setTimeout(stepFn,260));return}}
   tms.push(setTimeout(()=>{busy=0;commit(m,-MY);status();refresh()},240))};
  stepFn();return true}
 const pack=()=>({k:'st',b,t,over,quiet,lastP});
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='mv'){const ok=remote(d);botRes(from,ok,d)}
  else if(d.k==='st'&&!net.isHost){tms.forEach(clearTimeout);tms=[];b=d.b;t=d.t;over=d.over;quiet=d.quiet;lastP=d.lastP;busy=0;sel=-1;cand=null;step=0;dispB=null;dim=null;tg=null;shown=0;refresh()}});
 function conn(){const o=net.players.find(p=>p.id!==net.me.id);const was=gone;if(o){opp=Object.assign({},o);gone=0;if(net.isHost&&was)net.sendTo(o.id,pack())}else gone=1;refresh()}
 const offP=net.onPlayers(conn);
 // ---------- bot (alleen op de host): materiaal na de zet minus de beste terugslag, plus opmars/dam, met toeval ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]});let botT=0;
 const botId=()=>{const p=net.isHost&&net.players[1];return p&&p.bot?p.id:null};
 const botRes=(from,ok,d)=>{if(net.isHost&&net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}};
 const mat=(bb,side)=>bb.reduce((a,v)=>a+(v*side>0?(Math.abs(v)===2?3:1):v*side<0?-(Math.abs(v)===2?3:1):0),0);
 function aiMove(side){const ms=moves(b,side);if(!ms.length)return null;let best=-1e9,bm=ms[0];
  for(const m of ms){const nb=apply(b,m,side);let v=mat(nb,side)*10;const rep=moves(nb,-side);if(rep.length&&rep[0].caps.length){let worst=0;for(const r of rep){const x=mat(apply(nb,r,-side),side)*10;if(x-v<worst)worst=x-v}v+=worst*.9}
   if(!rep.length)v+=1000;const r=(m.t/10)|0;if(Math.abs(b[m.f])===1)v+=(side===1?9-r:r)*.4;if(Math.abs(nb[m.t])===2&&Math.abs(b[m.f])===1)v+=15;const c=m.t%10;if(c===0||c===9)v+=1;v+=Math.random()*4;if(v>best){best=v;bm=m}}return bm}
 function botTick(){clearTimeout(botT);botT=0;const id=botId();if(!id||gone||over||busy||t!==-1)return;const k=b.join('');
  botT=setTimeout(()=>{botT=0;if(gone||over||busy||t!==-1||b.join('')!==k||botId()!==id)return;const m=aiMove(-1);if(!m)return;BT.sent++;net.botAct(id,{k:'mv',f:m.f,path:m.path})},BT.fast?25+R(40):600+R(900))}
 b=Array(100).fill(0);for(let i=0;i<100;i++){const r=(i/10)|0;if((r+i%10)%2===1){if(r<4)b[i]=-1;else if(r>5)b[i]=1}}
 t=1;over=0;sel=-1;cand=null;step=0;dispB=null;dim=null;tg=null;lastP=null;busy=0;quiet=0;conn();
 window._dam={board:()=>b.slice(),moves:()=>moves(b,t),state:()=>({over,turn:t,busy,step}),tap};
 return()=>{clearTimeout(botT);tms.forEach(clearTimeout);tms=[];off();offP();delete window._dam}}},
