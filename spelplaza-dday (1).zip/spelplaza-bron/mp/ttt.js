{id:'ttt',n:'Boter-kaas-eieren',e:'❌',c:'Samen',g:'#fa709a,#fee140',min:2,max:2,bots:true,run(st,net){
 // tekstkleur op een effen spelerskleur: zwart of wit, wat het meeste contrast geeft (altijd ≥ 4.5:1)
 const inkOn=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(String(h||'').trim());if(!m)return'#fff';const n=parseInt(m[1],16),L=[n>>16,n>>8&255,n&255].map(v=>{v/=255;return v<=.03928?v/12.92:((v+.055)/1.055)**2.4}),l=.2126*L[0]+.7152*L[1]+.0722*L[2];return (l+.05)/.05>1.05/(l+.05)?'#000':'#fff'};
 // Boter-kaas-eieren voor 2 spelers: host = ✕ (begint ronde 1), joiner = ◯, elk in zijn eigen kleur. Reeks met lopende score; de verliezer begint de volgende ronde. Na elke ronde het podium met de reeksstand.
 const me=net.myIndex(),MY=me===0?1:-1,SYM=s=>s===1?'✕':'◯';
 let opp=null;const P=s=>net.players[s===1?0:1]||(s===MY?net.me:opp),nm=s=>{const p=P(s);return p?net.pname(p):'…'},cl=s=>{const p=P(s);return p&&p.col||'#888'},pid=s=>{const p=P(s);return p?p.id:null};
 const tint=(h,a)=>{const v=[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0);return'rgba('+v.join(',')+','+a+')'};
 const sc=E('div','sc'),who=E('div','hint');who.style.cssText='min-height:26px;line-height:2;font-weight:600;color:var(--tx);margin:0 auto 4px';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(300px,90%);margin:10px auto';
 const bd=E('div','ttt');bd.style.cssText='width:100%;margin:0';
 const ov=E('div','ov');ov.style.display='none';wrap.append(bd,ov);
 const hint=E('div','hint','Tik op een vakje · drie op een rij wint · de verliezer begint de volgende ronde');
 st.append(sc,who,wrap,hint);
 const cells=[];for(let i=0;i<9;i++){const d=E('div');d.style.cssText='background:var(--bg);border:2px solid var(--ln);transition:background .2s';d.onpointerdown=e=>{e.preventDefault();tap(i)};cells.push(d);bd.append(d)}
 const L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
 const winLine=a=>L.find(l=>a[l[0]]&&a[l[0]]===a[l[1]]&&a[l[0]]===a[l[2]]);
 // ---------- spelerchips ----------
 function chip(s,on){const k=cl(s),c=E('span');c.style.cssText='display:inline-flex;align-items:center;gap:5px;padding:1px 9px;border-radius:99px;border:1.5px solid '+k+';background:'+tint(k,.14)+';white-space:nowrap;vertical-align:middle;line-height:1.5;'+(on===1?'box-shadow:0 0 0 3px '+tint(k,.3)+';font-weight:800':on===-1?'opacity:.55':'');
  const d=E('span','',SYM(s));d.style.cssText='font-weight:900;color:'+k;c.append(d,document.createTextNode(nm(s)+(s===MY?' (jij)':'')));return c}
 function setWho(t,msg){who.replaceChildren();[1,-1].forEach((s,i)=>{if(i)who.append(document.createTextNode(' · '));who.append(chip(s,t?(t===s?1:-1):0));if(t===s)who.append(document.createTextNode(s===MY?' bent aan zet':' is aan zet'))});if(msg)who.append(document.createTextNode(' · '+msg))}
 // ---------- toestand ----------
 let a,t,round,starter,score,over,wl,gone=0,shown=0;
 function showOv(big,small){ov.replaceChildren();const b=E('div');b.textContent=big;const s=E('div');s.style.cssText='font-size:15px;font-weight:600';s.textContent=small||'';ov.append(b,s);ov.style.background='';ov.style.textShadow='0 1px 4px #000';ov.style.display='flex'}
 function refresh(){if(gone)showOv(opp?'⚠️ '+nm(-MY)+' heeft het spel verlaten':'Wachten op speler…',net.isHost?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten');else ov.style.display='none';draw();
  if(over&&!shown){shown=1;const sc_={};[1,-1].forEach(s=>{const id=pid(s);if(id)sc_[id]=score[s]});
   net.result({winner:over===3?null:pid(over),scores:sc_,title:over===3?'Gelijkspel 🤝':undefined,text:'Stand in de reeks na ronde '+round,buttons:[{label:'▶ Volgende ronde',fn:()=>next(1)}]})}botTick()}
 function draw(){for(let i=0;i<9;i++){const d=cells[i],v=a[i],w=wl&&wl.includes(i);d.textContent=v?SYM(v):'';d.style.color=v?(w?inkOn(cl(v)):cl(v)):'';d.style.background=w?cl(v):'var(--bg)';d.style.borderColor=w?cl(v):'var(--ln)';d.style.opacity=over&&wl&&!w?'.5':'1';d.style.cursor=!over&&!v&&t===MY?'pointer':'default'}
  sc.replaceChildren();const dot=s=>{const e=E('span','',SYM(s));e.style.cssText='color:'+cl(s)+';font-weight:900';return e};
  sc.append(document.createTextNode('Ronde '+round+' · '),dot(1),document.createTextNode(' '+nm(1)+(MY===1?' (jij)':'')+' '+score[1]+' – '+score[-1]+' '+nm(-1)+(MY===-1?' (jij)':'')+' '),dot(-1));
  if(score[3])sc.append(document.createTextNode(' · '+score[3]+'× gelijk'));
  if(over)sc.append(document.createTextNode(over===3?' · 🤝 gelijkspel':over===MY?' · 🎉 jij wint deze ronde':' · 🏆 '+nm(over)+' wint deze ronde'));
  setWho(over?0:t,over?'ronde voorbij':'')}
 function place(i,side){if(over||t!==side||a[i])return false;a[i]=side;beep(side===1?520:400,.06,'square',.03);
  const l=winLine(a);if(l){wl=l;over=side;score[side]++;beep(side===MY?880:220,.35,side===MY?'triangle':'sawtooth',.05)}
  else if(a.every(Boolean)){over=3;score[3]++;beep(330,.3,'sine',.04)}
  t=-side;refresh();return true}
 function tap(i){if(gone||over||t!==MY||a[i])return;if(place(i,MY))net.send({k:'mv',i,r:round})}
 function reset(){a=Array(9).fill(0);t=starter;over=0;wl=null;shown=0;const p=st.querySelector('.podium');if(p)p.remove()}
 function next(send){if(!over)return;const r=round;round++;starter=over===3?-starter:-over;reset();beep(600,.06,'triangle',.03);refresh();if(send)net.send({k:'next',r})}
 const pack=()=>({k:'st',a,t,round,starter,score,over,wl});
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='mv'){const ok=d.r===round&&typeof d.i==='number'&&d.i>=0&&d.i<=8&&place(d.i,-MY);botRes(from,ok,d)}
  else if(d.k==='next'){if(d.r===round)next(0)}
  else if(d.k==='st'&&!net.isHost){a=d.a;t=d.t;round=d.round;starter=d.starter;score=d.score;over=d.over;wl=d.wl;shown=0;refresh()}});
 function conn(){const o=net.players.find(p=>p.id!==net.me.id);const was=gone;if(o){opp=Object.assign({},o);gone=0;if(net.isHost&&was)net.sendTo(o.id,pack())}else gone=1;refresh()}
 const offP=net.onPlayers(conn);
 // ---------- bot (alleen op de host): minimax, maar ~25% van de zetten willekeurig ("normaal") ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]});let botT=0;
 const botId=()=>{const p=net.isHost&&net.players[1];return p&&p.bot?p.id:null};
 const botRes=(from,ok,d)=>{if(net.isHost&&net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}};
 function mm(b,s){const w=winLine(b);if(w)return b[w[0]]===s?1:-1;if(b.every(Boolean))return 0;let best=-2;for(let i=0;i<9;i++)if(!b[i]){b[i]=s;const v=-mm(b,-s);b[i]=0;if(v>best)best=v}return best}
 function aiMove(s){const free=[];for(let i=0;i<9;i++)if(!a[i])free.push(i);if(!free.length)return-1;const b=a.slice();
  for(const i of free){b[i]=s;const w=winLine(b);b[i]=0;if(w)return i}// winnen kan altijd
  if(Math.random()<.25)return free[R(free.length)];
  let best=-3,opts=[];for(const i of free){b[i]=s;const v=-mm(b,-s);b[i]=0;if(v>best){best=v;opts=[i]}else if(v===best)opts.push(i)}return opts[R(opts.length)]}
 function botTick(){clearTimeout(botT);botT=0;const id=botId();if(!id||gone||over||t!==-1)return;const r=round;
  botT=setTimeout(()=>{botT=0;if(gone||over||t!==-1||round!==r||botId()!==id)return;const i=aiMove(-1);if(i<0)return;BT.sent++;net.botAct(id,{k:'mv',i,r})},BT.fast?25+R(40):600+R(900))}
 window._ttt={board:()=>a.slice(),state:()=>({over,t,round,score})};
 round=1;starter=1;score={1:0,[-1]:0,3:0};reset();conn();
 return()=>{clearTimeout(botT);off();offP();delete window._ttt}}},
