{id:'snakeduel',n:'Slangenduel',e:'🐍',c:'Samen',g:'#11998e,#38ef7d',min:2,max:4,bots:true,run(st,net){
 // Slangen voor 2–4 spelers, 8 ticks/s. 2 spelers: 24×24, links/rechts. 3–4 spelers: 28×28 met een draaimolen-start.
 // Host simuleert en kiest de appels (aantal = aantal spelers). Laatste slang die leeft wint de ronde, eerste tot 3 wint.
 const HOST=net.isHost,DX=[1,0,-1,0],DY=[0,1,0,-1],WIN=3,TPS=8;
 const seat0=net.players.slice(0,4),P=Math.max(2,seat0.length),N=P>2?28:24,CS=P>2?13:15,W=N*CS,AP=P;
 const SP=P>2?[[[5,9,4,9,3,9],0],[[22,18,23,18,24,18],2],[[18,5,18,4,18,3],1],[[9,22,9,23,9,24],3]]:[[[4,12,3,12,2,12],0],[[19,12,20,12,21,12],2]];
 const COL=seat0.map(p=>net.pcol(p)),names=seat0.map(p=>net.pname(p)),avs=seat0.map(p=>p.av||'🙂'),LT=[];while(COL.length<P){COL.push('#888');names.push('…');avs.push('🙂')}
 const hx=h=>[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0),mix=(h,t)=>'rgb('+hx(h).map(q=>Math.round(q+(255-q)*t)).join(',')+')';
 COL.forEach((c,i)=>LT[i]=mix(c,.3));
 const sc=E('div','sc'),note=E('div','hint'),c=mkCanvas(st,W,W),x=c.getContext('2d');st.prepend(sc);c.before(note);note.style.cssText='margin:2px 0;min-height:'+(P>2?'18px':'0');
 st.append(E('div','hint','Pijltjes, WASD, veeg op het bord of de knoppen · eet 🍎 om te groeien · bots nergens tegen · laatste slang wint de ronde · 3 rondes wint'));
 let gone=0,left='',last=null,fl=0,parts=[],acc=0,tick=0,ended=0,noteT=0;
 let S={ids:seat0.map(p=>p.id),q:Array(P).fill(0),a:[],d:[],al:[],ap:[],s:Array(P).fill(0),cd:3,w:-1,r:1,rw:-1,rt:0,c:0,e:0},q=[];
 const myS=()=>S.ids.indexOf(net.me.id),K2D={ArrowRight:0,d:0,ArrowDown:1,s:1,ArrowLeft:2,a:2,ArrowUp:3,w:3};
 function turn(d){const me=myS();if(me<0||S.w>=0||gone)return;if(HOST){if(q[me].length<2)q[me].push(d)}else net.send({k:'i',d})}
 const inp=input(st,[['◀','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['▶','ArrowRight']],k=>{if(K2D[k]!=null)turn(K2D[k])});
 let sx,sy;c.onpointerdown=e=>{e.preventDefault();sx=e.clientX;sy=e.clientY};
 c.onpointerup=e=>{if(sx==null)return;const dx=e.clientX-sx,dy=e.clientY-sy;sx=null;if(Math.max(Math.abs(dx),Math.abs(dy))<14)return;turn(Math.abs(dx)>Math.abs(dy)?(dx>0?0:2):(dy>0?1:3))};
 const sub=()=>HOST?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten';
 function ov(big,small){if(!big){overlay(st,c,'');return}const o=overlay(st,c,' ');o.replaceChildren();const a=E('div');a.textContent=big;const b=E('div');b.style.cssText='font-size:15px;font-weight:600';b.textContent=small||'';o.append(a,b);o.style.pointerEvents='none'}
 function refresh(){if(gone)ov(left?'⚠️ '+left+' heeft het spel verlaten':'Wachten op speler…',sub());else ov('')}
 function say(t){note.textContent=t;clearTimeout(noteT);noteT=setTimeout(()=>{note.textContent=''},4000)}
 function line(){sc.replaceChildren();const me=myS();
  if(P===2){[0,1].forEach(i=>{const s=E('span');s.style.color=COL[i];s.textContent=names[i]+(i===me?' (jij)':'');sc.append(s);if(!i){const m=E('span');m.textContent='  '+S.s[0]+' – '+S.s[1]+'  ';sc.append(m)}})}
  else for(let i=0;i<P;i++){const s=E('span');s.style.cssText='color:'+COL[i]+';margin:0 5px;white-space:nowrap;'+(S.q[i]?'opacity:.35;text-decoration:line-through;':!S.al[i]&&S.cd<=0?'opacity:.5;':'')+(i===me?'text-decoration:underline;':'');s.textContent=avs[i]+' '+S.s[i]+(i===me?' (jij)':'');sc.append(s)}
  const r=E('span');r.style.color='var(--mu)';r.textContent=S.w>=0?' · 🏆 '+names[S.w]+' wint':' · ronde '+S.r;sc.append(r)}
 function conn(){const ps=net.players,ids=new Set(ps.map(p=>p.id));
  for(let i=0;i<P;i++){const p=ps.find(z=>z.id===S.ids[i]);if(p){names[i]=net.pname(p);COL[i]=net.pcol(p);LT[i]=mix(COL[i],.3);avs[i]=p.av||'🙂'}}
  const act=()=>S.q.filter(z=>!z).length;
  if(HOST){for(let i=0;i<P;i++)if(!S.q[i]&&!ids.has(S.ids[i])){S.q[i]=1;say('⚠️ '+names[i]+' heeft het spel verlaten');if(S.al[i]){S.al[i]=0;if(act()>=2)settle()}}
   if(act()<2)ps.forEach(p=>{if(S.ids.includes(p.id))return;const i=S.q.indexOf(1);if(i<0)return;S.ids[i]=p.id;S.q[i]=0;names[i]=net.pname(p);COL[i]=net.pcol(p);LT[i]=mix(COL[i],.3);avs[i]=p.av||'🙂'});
   const was=gone;if(act()<2){gone=1;if(!was){const i=S.q.indexOf(1);left=i>=0&&names[i]!=='…'?names[i]:''}}else{gone=0;left='';if(was&&S.w<0)newRound()}}
  else{const was=gone;gone=ps.length<2||act()<2?1:0;if(gone&&!was){const o=S.ids.findIndex(id=>id!==net.me.id&&!ids.has(id)),i=S.q.indexOf(1);left=o>=0?names[o]:i>=0?names[i]:''}if(!gone)left=''}
  refresh();line()}
 function endCheck(){if(S.w<0||ended)return;ended=1;line();const scores={};S.ids.forEach((id,i)=>scores[id]=S.s[i]);net.result({winner:S.ids[S.w],scores,unit:' rondes',text:'Beslist na '+S.r+' rondes · eerste tot '+WIN})}
 const occ=(cx,cy)=>S.a.some(a=>{for(let k=0;k<a.length;k+=2)if(a[k]===cx&&a[k+1]===cy)return 1})||S.ap.some((v,k)=>k%2===0&&v===cx&&S.ap[k+1]===cy);
 function spawn(){for(let t=0;t<300;t++){const cx=R(N),cy=R(N);if(!occ(cx,cy)){S.ap.push(cx,cy);return}}}
 function newRound(){S.a=[];S.d=[];S.al=[];for(let i=0;i<P;i++){S.a.push(S.q[i]?[]:SP[i][0].slice());S.d.push(SP[i][1]);S.al.push(S.q[i]?0:1)}
  S.ap=[];S.cd=3;S.rw=-1;S.rt=0;q=Array.from({length:P},()=>[]);acc=0;for(let k=0;k<AP;k++)spawn()}
 // ronde beslist zodra er hoogstens één slang leeft; sterven de laatsten tegelijk = gelijkspel (rw=-2)
 function settle(){if(S.rt>0||S.w>=0)return;const al=[];S.al.forEach((a,i)=>{if(a)al.push(i)});if(al.length>1)return;
  S.rw=al.length?al[0]:-2;S.rt=1.8;if(S.rw>=0){S.s[S.rw]++;if(S.s[S.rw]>=WIN)S.w=S.rw}}
 function step(){stepN++;const nh=[],grow=Array(P).fill(0),cr=Array(P).fill(0);let any=0;
  for(let i=0;i<P;i++){if(!S.al[i]){nh.push(null);continue}while(q[i].length){const d=q[i].shift();if(d!==S.d[i]&&(d+2)%4!==S.d[i]){S.d[i]=d;break}}
   const a=S.a[i],hx=a[0]+DX[S.d[i]],hy=a[1]+DY[S.d[i]];nh.push([hx,hy]);
   for(let k=0;k<S.ap.length;k+=2)if(S.ap[k]===hx&&S.ap[k+1]===hy){grow[i]=1;S.ap.splice(k,2);S.e++;break}}
  for(let i=0;i<P;i++){if(!nh[i])continue;const[hx,hy]=nh[i];if(hx<0||hy<0||hx>=N||hy>=N){cr[i]=1;continue}
   for(let j=0;j<P;j++){const a=S.a[j],end=a.length-(grow[j]||!S.al[j]?0:2);for(let k=0;k<end;k+=2)if(a[k]===hx&&a[k+1]===hy)cr[i]=1}
   for(let j=0;j<P;j++)if(j!==i&&nh[j]&&nh[j][0]===hx&&nh[j][1]===hy)cr[i]=1}
  for(let i=0;i<P;i++){if(!nh[i])continue;if(cr[i]){S.al[i]=0;S.c++;any=1;continue}const a=S.a[i];a.unshift(nh[i][0],nh[i][1]);if(!grow[i])a.length-=2}
  for(let g=0;g<AP&&S.ap.length<AP*2;g++)spawn();
  if(any)settle()}
 // ---- bots (alleen op de host): na elke stap flood-fill-vooruitblik per richting; met genoeg ruimte (≥ eigen lengte) gaat de bot naar de
 // dichtstbijzijnde appel, anders naar de meeste ruimte; kop-aan-kop-vakjes zijn verdacht; soms een minder goede keuze. Stuurt {k:'i',d} (≤ 8×/s).
 let stepN=0;const bStep={};
 function botThink(){const g=new Uint8Array(N*N);
  for(let j=0;j<P;j++){const a=S.a[j];if(!a)continue;const end=S.al[j]?a.length-2:a.length;for(let k=0;k<end;k+=2)g[a[k+1]*N+a[k]]=1}
  const flood=(sx,sy,cap)=>{if(sx<0||sy<0||sx>=N||sy>=N||g[sy*N+sx])return 0;const seen=new Uint8Array(N*N),st2=[sy*N+sx];seen[st2[0]]=1;let n=0;
   while(st2.length&&n<cap){const c=st2.pop();n++;const cx=c%N,cy=(c/N)|0;for(let d=0;d<4;d++){const X=cx+DX[d],Y=cy+DY[d];if(X<0||Y<0||X>=N||Y>=N)continue;const j=Y*N+X;if(!seen[j]&&!g[j]){seen[j]=1;st2.push(j)}}}return n};
  for(let i=1;i<P;i++){const id=S.ids[i];if(!S.al[i]||S.q[i]||!net.isBot(id)||bStep[id]===stepN)continue;bStep[id]=stepN;
   const a=S.a[i],hx=a[0],hy=a[1],cd=S.d[i],len=a.length/2,opts=[];
   for(const d of [cd,(cd+1)%4,(cd+3)%4]){const nx=hx+DX[d],ny=hy+DY[d],room=flood(nx,ny,len*3+10);let v;
    if(!room)v=-1e6;else{let ad=99;for(let k=0;k<S.ap.length;k+=2)ad=Math.min(ad,Math.abs(S.ap[k]-nx)+Math.abs(S.ap[k+1]-ny));
     v=room>=len+2?1000-ad*10:room*5;if(d===cd)v+=3;v+=Math.random()*4;
     for(let j=0;j<P;j++){if(j===i||!S.al[j]||!S.a[j].length)continue;if(Math.abs(S.a[j][0]-nx)+Math.abs(S.a[j][1]-ny)===1)v-=400}}
    opts.push([v,d])}
   opts.sort((x,y)=>y[0]-x[0]);let pick=opts[0];if(opts[1][0]>500&&Math.random()<.07)pick=opts[1];// af en toe een omweg
   if(pick[1]!==cd&&pick[0]>-1e6)net.botAct(id,{k:'i',d:pick[1]})}}
 function sim(dt){if(S.rt>0){S.rt-=dt;if(S.rt<=0&&S.w<0){S.r++;newRound()}return}
  if(S.cd>0){S.cd-=dt;if(S.cd<0)S.cd=0;return}acc+=dt*(window.__snakeFast||1);while(acc>=1/TPS){acc-=1/TPS;if(S.rt<=0)step()}if(S.rt<=0&&S.w<0)botThink()}
 const snap=()=>({c:S.c,e:S.e,cd:Math.ceil(S.cd),w:S.w,s:S.s.join(),r:S.r,al:S.al.slice(),q:S.q.join(),ids:S.ids.join()});
 function fx(){const n=snap(),me=myS();if(last){
  if(n.e!==last.e)beep(760,.06,'square',.03);
  if(n.c!==last.c){fl=1;n.al.forEach((a,i)=>{if(!a&&last.al[i]&&S.a[i]&&S.a[i].length){const h=S.a[i],hx=h[0]*CS+CS/2,hy=h[1]*CS+CS/2;beep(i===me?120:300,.35,'sawtooth',.05);
   for(let k=0;k<26;k++){const an=Math.random()*7,v=30+Math.random()*140;parts.push({x:hx,y:hy,vx:Math.cos(an)*v,vy:Math.sin(an)*v,l:.5+Math.random()*.6,c:k%3?(k%2?COL[i]:LT[i]):'#fff'})}}})}
  if(n.cd!==last.cd&&last.cd>0)beep(n.cd?440:700,n.cd?.06:.15,'square',.03);
  if(n.ids!==last.ids)conn();
  if(n.s!==last.s||n.r!==last.r||n.q!==last.q||n.al.join()!==last.al.join()||(n.cd===0)!==(last.cd===0))line();
  if(!HOST&&n.q!==last.q){const qa=last.q.split(',');S.q.forEach((z,i)=>{if(z&&qa[i]==='0')say('⚠️ '+names[i]+' heeft het spel verlaten')});conn()}
  if(n.w!==last.w)beep(n.w===me?880:220,.4,'triangle',.05)}last=n;endCheck()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(HOST){if(d.k==='i'&&d.d>=0&&d.d<4){const i=S.ids.indexOf(from);if(i>0&&!S.q[i]&&q[i].length<2)q[i].push(d.d|0)}}
  else if(d.k==='s'&&Array.isArray(d.a)&&d.a.length===P){S={ids:d.ids,q:d.q,a:d.a,d:d.d,al:d.al,ap:d.ap,s:d.s,cd:d.cd,w:d.w,r:d.r,rw:d.rw,rt:d.rt,c:d.c,e:d.e}}});
 const offP=net.onPlayers(conn);
 function snake(i){const a=S.a[i];if(!a||!a.length)return;const col=COL[i],lt=LT[i]||mix(col,.3),r1=CS>13?6:5,r2=CS>13?4:3.5;x.globalAlpha=S.al[i]?1:.35;
  for(let k=a.length-2;k>=0;k-=2){const h=k===0;x.fillStyle=h?lt:k%4?col:lt;x.beginPath();x.roundRect(a[k]*CS+1,a[k+1]*CS+1,CS-2,CS-2,h?r1:r2);x.fill()}
  x.strokeStyle=mix(col,.6);x.lineWidth=1.5;x.beginPath();x.roundRect(a[0]*CS+1.5,a[1]*CS+1.5,CS-3,CS-3,r1-.5);x.stroke();
  x.globalAlpha=1;if(!S.al[i])return;const d=S.d[i],hx=a[0]*CS+CS/2,hy=a[1]*CS+CS/2,f=CS/15,ex=DY[d]*3.5*f,ey=DX[d]*3.5*f,fx2=DX[d]*2.5*f,fy=DY[d]*2.5*f;
  x.fillStyle='#0e1020';[[hx+ex+fx2,hy-ey+fy],[hx-ex+fx2,hy+ey+fy]].forEach(([px,py])=>{x.beginPath();x.arc(px,py,2*f,0,7);x.fill()})}
 // vooraf getekend: geblokt bord + gloeiende appel (shadowBlur per frame is duur op trage toestellen)
 const bg=document.createElement('canvas');bg.width=bg.height=W;{const g=bg.getContext('2d');g.fillStyle='#0e1020';g.fillRect(0,0,W,W);g.fillStyle='#12162e';for(let i=0;i<N;i++)for(let j=(i&1);j<N;j+=2)g.fillRect(i*CS,j*CS,CS,CS)}
 const ar=CS>13?5.5:4.8,AS=CS*2,apl=document.createElement('canvas');apl.width=apl.height=AS;{const g=apl.getContext('2d'),m=AS/2;g.fillStyle='#ff4d5a';g.shadowColor='#ff4d5a';g.shadowBlur=8;g.beginPath();g.arc(m,m+1,ar,0,7);g.fill();g.shadowBlur=0;g.fillStyle='#5ef28a';g.beginPath();g.ellipse(m+2,m-ar+.5,3,1.6,-.6,0,7);g.fill()}
 function draw(dt){const me=myS();x.drawImage(bg,0,0);
  for(let k=0;k<S.ap.length;k+=2)x.drawImage(apl,S.ap[k]*CS+CS/2-AS/2,S.ap[k+1]*CS+CS/2-AS/2);
  for(let i=0;i<P;i++)snake(i);
  if(S.cd>0&&S.rt<=0&&me>=0&&S.a[me]&&S.a[me].length){const a=S.a[me],d=S.d[me];x.font='bold 11px system-ui,sans-serif';x.textAlign='center';x.fillStyle='#fff';x.fillText('jij',a[0]*CS+CS/2+DX[d]*CS*1.4,a[1]*CS+CS/2+DY[d]*CS*1.4+4)}
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.95;p.vy*=.95;p.l-=dt;x.globalAlpha=Math.min(1,p.l*2);x.fillStyle=p.c;x.fillRect(p.x-2,p.y-2,4,4)}x.globalAlpha=1;parts=parts.filter(p=>p.l>0);
  if(fl>0){x.fillStyle='rgba(255,255,255,'+(fl*.15)+')';x.fillRect(0,0,W,W);fl-=dt*3}
  x.font='bold 12px system-ui,sans-serif';x.shadowColor='#000';x.shadowBlur=4;const len=i=>(S.a[i]||[]).length/2;
  if(P===2){x.fillStyle=mix(COL[0],.4);x.textAlign='left';x.fillText(names[0]+' · '+len(0),8,W-8);x.fillStyle=mix(COL[1],.4);x.textAlign='right';x.fillText(len(1)+' · '+names[1],W-8,W-8)}
  else{x.textAlign='center';for(let i=0;i<P;i++){x.globalAlpha=S.al[i]?1:.45;x.fillStyle=mix(COL[i],.4);x.fillText(avs[i]+' '+len(i),W*(i+.5)/P,W-8)}x.globalAlpha=1}x.shadowBlur=0;
  x.textAlign='center';x.fillStyle='#fff';
  if(S.cd>0&&!gone&&S.w<0&&S.rt<=0){const n=Math.ceil(S.cd),f=S.cd-Math.floor(S.cd);x.font='bold '+(44+f*30)+'px system-ui,sans-serif';x.globalAlpha=.4+f*.6;x.fillText(n,W/2,W/2-20);x.globalAlpha=1;x.fillStyle='#8a90b8';x.font='bold 14px system-ui,sans-serif';x.fillText('Ronde '+S.r+' · eerste tot '+WIN,W/2,W/2+10)}
  if(S.rt>0&&S.w<0){x.font='bold 24px system-ui,sans-serif';x.shadowColor='#000';x.shadowBlur=8;x.fillStyle=S.rw<0?'#fff':mix(COL[S.rw],.45);x.fillText(S.rw<0?'Gelijk! Niemand scoort':S.rw===me?'Jij wint de ronde!':names[S.rw]+' wint de ronde',W/2,W/2-60);x.shadowBlur=0}}
 const stop=loop(dt=>{if(HOST){if(!gone&&S.w<0)sim(dt);tick+=dt;if(tick>=.04){tick=Math.min(tick-.04,.04);net.send({k:'s',ids:S.ids,q:S.q,a:S.a,d:S.d,al:S.al,ap:S.ap,s:S.s,cd:Math.round(S.cd*100)/100,w:S.w,r:S.r,rw:S.rw,rt:Math.round(S.rt*100)/100,c:S.c,e:S.e})}}fx();draw(dt)});
 newRound();conn();line();window.__dbg={s:()=>JSON.parse(JSON.stringify(S))};
 return()=>{stop();inp.stop();off();offP();clearTimeout(noteT);c.onpointerdown=c.onpointerup=null;delete window.__dbg}}},
