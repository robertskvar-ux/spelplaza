{id:'weerwolven',n:'Weerwolven van Wakkerdam',e:'🐺',c:'Samen',g:'#141e30,#8e2de2',min:3,max:8,run(st,net){
 // Weerwolven (host-authoritatief). De host kent alle rollen; elke speler krijgt met sendTo ALLEEN zijn eigen beeld (eigen rol,
 // en voor wolven/ziener/heks hun geheime info). Doden en het einde zien alle rollen. Laatkomers kijken mee met publieke info.
 const isH=net.isHost,me=net.me.id;
 const RO={W:['🐺','Weerwolf','Elke nacht kies je samen met de andere wolven een slachtoffer. Overdag doe je alsof je een gewone burger bent.'],
  Z:['🔮','Ziener','Elke nacht kies je één speler en zie je in het geheim zijn of haar rol.'],
  H:['🧪','Heks','Je ziet wie de wolven aanvallen. Je hebt één drankje om te redden en één gifdrankje, elk maar één keer.'],
  B:['🧑‍🌾','Burger','Geen speciale kracht. Praat, let goed op en stem overdag de wolven weg!']};
 const rt=r=>RO[r]?RO[r][0]+' '+RO[r][1]:'';
 const T={wolf:60000,heks:30000,day:90000,vote:60000};
 const css=E('style','',`.ww-ban{border-radius:16px;padding:12px 14px;margin:-4px 0 10px;display:flex;align-items:center;justify-content:space-between;gap:8px;text-align:left}
 .ww-ban b{font-size:22px;display:block}.ww-ban small{font-size:13px;opacity:.85}.ww-ban .tm{font-size:22px;font-weight:800;font-variant-numeric:tabular-nums}
 .ww-n{background:linear-gradient(135deg,#141e30,#3a2a6b);color:#fff}.ww-d{background:linear-gradient(135deg,#f6d365,#fda085);color:#2b1a05}.ww-e{background:linear-gradient(135deg,#2a9d8f,#5b4cf5);color:#fff}
 .ww-card{display:flex;gap:12px;align-items:center;text-align:left;border:2px solid var(--ac);border-radius:16px;padding:10px 12px;margin:0 0 10px;background:color-mix(in srgb,var(--ac) 10%,var(--card));cursor:pointer}
 .ww-card .re{font-size:52px;line-height:1}.ww-card b{font-size:19px}.ww-card p{margin:3px 0 0;font-size:13px;color:var(--mu)}
 .ww-msg{font-weight:700;margin:6px 0;min-height:20px}.ww-do{font-weight:700;margin:8px 0;color:var(--ac)}
 .ww-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin:8px 0}
 .ww-p{display:flex;align-items:center;gap:8px;min-height:56px;padding:6px 8px;border-radius:14px;border:2px solid var(--c);background:var(--bg);color:var(--tx);font:inherit;text-align:left;cursor:pointer}
 .ww-p:disabled{cursor:default}.ww-p.off{opacity:.45}.ww-p.sel{background:color-mix(in srgb,var(--c) 28%,var(--bg));box-shadow:0 0 0 3px var(--ac)}
 .ww-p .nm{font-weight:700;font-size:14px;line-height:1.2;word-break:break-word}.ww-p .sub{font-size:12px;color:var(--mu)}.ww-p .vb{margin-left:auto;font-size:13px;white-space:nowrap}
 .ww-act{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:8px 0}.ww-log{font-size:13px;color:var(--mu);text-align:left;line-height:1.5;max-width:420px;margin:8px auto 0}`);
 const ban=E('div','ww-ban'),sc=E('div','sc'),card=E('div','ww-card'),msg=E('div','ww-msg'),todo=E('div','ww-do'),grid=E('div','ww-g'),act=E('div','ww-act'),log=E('div','ww-log');
 st.append(css,ban,sc,card,msg,todo,grid,act,log,E('div','hint','Tik op een speler om te kiezen · tik op je rolkaart om ze te verbergen'));
 let V=null,lEnd=0,hide=0,podDone=0,hkHeal=0,hkPois=null,lastPh='';
 card.onclick=()=>{hide=!hide;render()};
 const nm=q=>(q.av||'🙂')+' '+q.n;
 // ---------- render (zelfde code voor host en joiners, op basis van het eigen beeld V) ----------
 function pbtn(q,o){const b=E('button','ww-p');b.type='button';b.style.setProperty('--c',q.col||'#888');const av=E('span','pav s');av.style.setProperty('--c',q.col||'#888');av.textContent=q.al?q.av:'💀';
  const tx=E('div'),n=E('div','nm'),s=E('div','sub');n.textContent=q.n+(q.id===me?' (jij)':'');s.textContent=(q.r?rt(q.r):'')+(q.al?'':(q.r?' · ':'')+(q.left?'vertrokken':'dood'));tx.append(n,s);b.append(av,tx);
  if(o.badge){const vb=E('span','vb');vb.textContent=o.badge;b.append(vb)}if(o.sel)b.classList.add('sel');if(!q.al)b.classList.add('off');b.disabled=!o.fn;if(o.fn)b.onclick=o.fn;return b}
 function render(){if(!V)return;const v=V,mine=v.pl.find(q=>q.id===me),alive=mine&&mine.al,r=v.me&&v.me.r,night=v.ph==='night';
  if(v.ph+v.step+v.n!==lastPh){lastPh=v.ph+v.step+v.n;hkHeal=0;hkPois=null;beep(night?220:v.ph==='end'?660:520,.12,'triangle',.04)}
  ban.className='ww-ban '+(v.ph==='end'?'ww-e':night?'ww-n':'ww-d');
  const sub={wolf:'De wolven zoeken een slachtoffer…',heks:'De heks is aan zet…'}[v.step];
  ban.innerHTML='<div><b></b><small></small></div><span class="tm"></span>';ban.querySelector('b').textContent=v.ph==='end'?(v.win==='W'?'🐺 Wolven winnen':'🏡 Dorp wint'):night?'🌙 Nacht '+v.n:'☀️ Dag '+v.n;
  ban.querySelector('small').textContent=v.ph==='end'?'Alle rollen zijn bekend':night?sub:v.ph==='day'?'Bespreek: wie is de wolf?':'Stem iemand weg';
  sc.textContent=mine?'Jij bent '+nm(mine)+(alive?'':' · 💀 dood — je ziet alle rollen'):'👀 Je kijkt mee (je doet volgende ronde mee)';
  card.style.display=r?'':'none';if(r){card.innerHTML='<span class="re"></span><div><b></b><p></p></div>';card.querySelector('.re').textContent=hide?'🂠':RO[r][0];card.querySelector('b').textContent=hide?'Je rol (verborgen)':'Jij bent '+RO[r][1];
   card.querySelector('p').textContent=hide?'Tik om te tonen':RO[r][2]+(r==='W'&&v.mates&&v.mates.length?' Je mede-wolven: '+v.mates.map(id=>nm(v.pl.find(q=>q.id===id))).join(', ')+'.':'')+(r==='H'?' Nog: '+(v.heal?'💚':'')+(v.poison?'☠️':'')+(!v.heal&&!v.poison?'geen drankjes':''):'')}
  msg.textContent=v.msg||'';
  // wat mag ik nu doen?
  let mode=null,t='';const tally={};
  if(night&&alive){if(v.step==='wolf'&&r==='W'){mode='wv';t=v.wv&&v.wv[me]?'Wachten tot alle wolven hetzelfde kiezen…':'🐺 Kies jullie slachtoffer';Object.values(v.wv||{}).forEach(id=>tally[id]=(tally[id]||'')+'🐺')}
   else if(v.step==='wolf'&&r==='Z'){mode=v.zt?null:'zs';t=v.zt?'🔮 '+nm(v.pl.find(q=>q.id===v.zt))+' is '+rt(v.seen[v.zt]):'🔮 Kies wie je wilt bekijken'}
   else if(v.step==='heks'&&r==='H'){mode=v.poison?'hp':null;t=v.victim?'🐺 De wolven vallen '+nm(v.pl.find(q=>q.id===v.victim))+' aan.':'De wolven hebben niemand gekozen.';if(v.poison)t+=' Tik op een speler om te vergiftigen.'}
   else t='😴 Ogen dicht… wacht tot het dag wordt';if(r==='Z'&&v.zt&&v.step!=='wolf')t='🔮 '+nm(v.pl.find(q=>q.id===v.zt))+' is '+rt(v.seen[v.zt])+' · '+t}
  else if(v.ph==='vote'){Object.entries(v.votes||{}).forEach(([a,b])=>{const q=v.pl.find(x=>x.id===a);tally[b]=(tally[b]||'')+(q?q.av:'?')});if(alive){mode='vt';t=v.votes[me]?'Je hebt gestemd (je mag nog wisselen)':'🗳️ Stem: wie moet het dorp verlaten?'}else t='Het dorp stemt…'}
  else if(v.ph==='day')t=alive?'💬 Overleg samen. Daarna wordt er gestemd.':'💬 Het dorp overlegt…';
  else if(!alive&&v.ph!=='end')t='👻 Je kijkt mee';
  todo.textContent=t;
  grid.replaceChildren(...v.pl.map(q=>{let fn=null,sel=0;const ok=q.al&&q.id!==me;
   if(mode==='wv'&&ok&&!(v.mates||[]).includes(q.id)){fn=()=>send({k:'wv',t:q.id});sel=v.wv&&v.wv[me]===q.id}
   else if(mode==='zs'&&ok)fn=()=>send({k:'zs',t:q.id});
   else if(mode==='hp'&&q.al){fn=()=>{hkPois=hkPois===q.id?null:q.id;render()};sel=hkPois===q.id}
   else if(mode==='vt'&&ok){fn=()=>send({k:'vt',t:q.id});sel=v.votes[me]===q.id}
   if(v.zt===q.id&&r==='Z'&&night)sel=1;return pbtn(q,{fn,sel,badge:tally[q.id]||''})}));
  act.replaceChildren();
  if(night&&alive&&v.step==='heks'&&r==='H'){if(v.heal&&v.victim){const h=E('button','btn',hkHeal?'💚 Redden ✓':'💚 Redden');h.onclick=()=>{hkHeal=!hkHeal;render()};if(!hkHeal)h.classList.add('sec');act.append(h)}
   const ok=E('button','btn','✔ Klaar'+(hkPois?' (☠️ '+v.pl.find(q=>q.id===hkPois).n+')':''));ok.onclick=()=>send({k:'hk',heal:hkHeal?1:0,p:hkPois});act.append(ok)}
  if(isH&&v.ph==='day'){const s=E('button','btn','⏭ Naar de stemming');s.onclick=()=>send({k:'skip'});act.append(s)}
  log.replaceChildren(...(v.log||[]).slice().reverse().map(x=>{const d=E('div');d.textContent=x;return d}));
  if(v.ph==='end'&&!podDone){podDone=1;const sc2={};v.pl.forEach(q=>sc2[q.id]=(v.win==='W')===(q.r==='W')?1:0);
   const grp=k=>v.pl.filter(q=>q.r===k).map(q=>q.n).join(', ');const text=['W','Z','H','B'].filter(k=>grp(k)).map(k=>rt(k)+': '+grp(k)).join(' · ');
   net.result({winner:null,title:v.win==='W'?'🐺 De weerwolven winnen!':'🏡 Het dorp wint!',scores:sc2,text,unit:' pt'})}
  tick()}
 function tick(){const tm=ban.querySelector('.tm');if(!tm||!V)return;if(V.ph==='end'){tm.textContent='';return}const s=Math.max(0,Math.ceil((lEnd-performance.now())/1000));tm.textContent='⏱ '+Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
 function send(d){if(isH)act2(me,d);else net.send(d)}
 function recv(v){V=v;lEnd=performance.now()+(v.tl||0);render()}
 // ---------- host ----------
 let H=null,tm=0;
 const al=()=>H.pl.filter(q=>q.al),by=id=>H.pl.find(q=>q.id===id),alR=r=>al().filter(q=>q.r===r);
 function view(id){const p=by(id),all=H.ph==='end'||(p&&!p.al),seer=p&&p.al&&p.r==='Z',wolf=p&&p.al&&p.r==='W';
  const v={k:'s',ph:H.ph,step:H.ph==='night'?H.step:'',n:H.n,tl:Math.max(0,H.end-Date.now()),msg:H.msg,log:H.log.slice(-10),win:H.win,
   pl:H.pl.map(q=>{const o={id:q.id,n:q.n,av:q.av,col:q.col,al:q.al,left:q.left};if(all||!q.al||q.id===id||(wolf&&q.r==='W')||(seer&&H.seen[q.id]))o.r=q.r;return o})};
  if(H.ph==='vote')v.votes=H.votes;
  if(p){v.me={r:p.r};if(wolf){v.mates=H.pl.filter(q=>q.r==='W'&&q.id!==id).map(q=>q.id);if(H.ph==='night')v.wv=H.wv}
   if(seer){v.seen=H.seen;if(H.ph==='night')v.zt=H.zt}
   if(p.al&&p.r==='H'){v.heal=H.heal;v.poison=H.poison;if(H.ph==='night'&&H.step==='heks')v.victim=H.victim}}
  return v}
 function pub(){net.players.forEach(p=>{if(p.id===me)recv(view(me));else net.sendTo(p.id,view(p.id))})}
 function winner(){const w=alR('W').length,o=al().length-w;return w===0?'B':w>=o?'W':null}
 function end(w){H.ph='end';H.win=w;H.log.push(w==='W'?'🐺 De weerwolven hebben gewonnen.':'🏡 Alle wolven zijn ontmaskerd!');clearInterval(tm);pub()}
 function night(){H.ph='night';H.step='wolf';H.wv={};H.zt=null;H.victim=null;H.hk={heal:0,p:null};H.end=Date.now()+T.wolf;H.msg=(H.n>1&&H.msg?H.msg+'. ':'')+'🌙 Het wordt nacht in Wakkerdam…';nightCheck()||pub()}
 function nightCheck(){if(H.ph!=='night')return 0;
  if(H.step==='wolf'){const wl=alR('W'),t=wl.map(w=>H.wv[w.id]),agreed=wl.length>0&&t.every(x=>x&&x===t[0]),z=alR('Z')[0];
   if(agreed&&(!z||H.zt)){toHeks(t[0]);return 1}}
  else if(H.step==='heks'&&(!alR('H')[0]||H.hk.done)){dawn();return 1}return 0}
 function toHeks(victim){H.victim=victim&&by(victim)&&by(victim).al?victim:null;if(alR('H')[0]&&(H.heal||H.poison)){H.step='heks';H.end=Date.now()+T.heks;pub()}else dawn()}
 function kill(q,why){q.al=0;H.log.push(why+' '+nm(q)+' — '+rt(q.r))}
 function dawn(){const d=[];if(H.victim&&!H.hk.heal)d.push(H.victim);if(H.hk.p&&!d.includes(H.hk.p))d.push(H.hk.p);
  const qs=d.map(by).filter(q=>q&&q.al);qs.forEach(q=>kill(q,'☠️ Nacht '+H.n+':'));
  H.msg=qs.length?'Vannacht gestorven: '+qs.map(q=>nm(q)+' ('+rt(q.r)+')').join(', '):'Niemand is gestorven vannacht 🎉';if(!qs.length)H.log.push('🌅 Nacht '+H.n+': niemand gestorven');
  const w=winner();if(w)return end(w);H.ph='day';H.end=Date.now()+T.day;H.votes={};pub()}
 function vote(){H.ph='vote';H.votes={};H.end=Date.now()+T.vote;H.msg=H.msg||'';pub()}
 function resolve(){const c={};Object.entries(H.votes).forEach(([a,b])=>{if(by(a)&&by(a).al&&by(b)&&by(b).al)c[b]=(c[b]||0)+1});
  const mx=Math.max(0,...Object.values(c)),top=Object.keys(c).filter(k=>c[k]===mx);
  if(mx>0&&top.length===1){const q=by(top[0]);kill(q,'🗳️ Dag '+H.n+': weggestemd');H.msg='Het dorp stemde '+nm(q)+' weg — '+rt(q.r)}
  else{H.msg=mx?'Gelijke stemmen — niemand verlaat het dorp':'Niemand heeft gestemd — niemand verlaat het dorp';H.log.push('🗳️ Dag '+H.n+': niemand weggestemd')}
  const w=winner();if(w)return end(w);H.n++;night()}
 function act2(from,d){if(!H||!d||H.ph==='end')return;const p=by(from);
  if(d.k==='skip'){if(from===me&&H.ph==='day')vote();return}
  if(!p||!p.al)return;const t=by(d.t),tok=t&&t.al&&t.id!==from;
  if(H.ph==='night'&&H.step==='wolf'){if(d.k==='wv'&&p.r==='W'&&tok&&t.r!=='W'){H.wv[from]=t.id;nightCheck()||pub()}
   else if(d.k==='zs'&&p.r==='Z'&&tok&&!H.zt){H.zt=t.id;H.seen[t.id]=t.r;nightCheck()||pub()}}
  else if(H.ph==='night'&&H.step==='heks'&&d.k==='hk'&&p.r==='H'&&!H.hk.done){const pt=by(d.p);
   H.hk={done:1,heal:d.heal&&H.heal&&H.victim?1:0,p:H.poison&&pt&&pt.al?pt.id:null};if(H.hk.heal)H.heal=0;if(H.hk.p)H.poison=0;dawn()}
  else if(H.ph==='vote'&&d.k==='vt'&&tok){H.votes[from]=t.id;if(al().every(q=>H.votes[q.id]))resolve();else pub()}}
 function hTick(){if(!H||H.ph==='end'||Date.now()<H.end)return;
  if(H.ph==='night'&&H.step==='wolf'){const c={};alR('W').forEach(w=>{const x=H.wv[w.id];if(x)c[x]=(c[x]||0)+1});const mx=Math.max(0,...Object.values(c));
   H.log.push('⏰ De nacht duurde te lang');toHeks(mx?Object.keys(c).find(k=>c[k]===mx):null)}
  else if(H.ph==='night'&&H.step==='heks'){H.hk.done=1;dawn()}else if(H.ph==='day')vote();else if(H.ph==='vote')resolve()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;if(isH){if(d.k==='hi'){if(H)net.sendTo(from,view(from))}else act2(from,d)}else if(d.k==='s')recv(d)});
 const offP=net.onPlayers(ps=>{if(!isH||!H)return;const ids=new Set(ps.map(p=>p.id));
  H.pl.forEach(q=>{if(q.al&&!ids.has(q.id)){q.left=1;kill(q,'🚪 Vertrokken:');delete H.wv[q.id];delete H.votes[q.id];H.msg=nm(q)+' heeft het spel verlaten ('+rt(q.r)+')'}});
  if(H.ph==='end')return pub();const w=winner();if(w)return end(w);
  if(H.ph==='night'&&H.step==='heks'&&!alR('H')[0])return dawn();if(H.ph==='night'&&nightCheck())return;
  if(H.ph==='vote'&&al().every(q=>H.votes[q.id]))return resolve();pub()});
 const ti=setInterval(tick,250);
 if(isH){const rnd=net.rng(),n=net.players.length,nw=n>=6?2:1,roles=[];for(let i=0;i<nw;i++)roles.push('W');roles.push('Z','H');while(roles.length<n)roles.push('B');roles.length=n;
  for(let i=roles.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[roles[i],roles[j]]=[roles[j],roles[i]]}
  H={ph:'night',step:'wolf',n:1,pl:net.players.map((p,i)=>({id:p.id,n:p.name,av:p.av,col:p.col,r:roles[i],al:1})),seen:{},heal:1,poison:1,votes:{},wv:{},log:[],end:0,msg:''};
  if(n<4)H.log.push('🧪 Oefenpotje met '+n+' spelers — vanaf 4 spelers wordt het echt spannend');
  if(window.SPZ_PEER)window.__dbg={get H(){return H},view};tm=setInterval(hTick,250);night()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{off();offP();clearInterval(ti);clearInterval(tm);if(window.__dbg)delete window.__dbg}}},
