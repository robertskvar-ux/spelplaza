{id:'spionnen',n:'Spionnen',e:'🕵️',c:'Samen',g:'#c31432,#240b36',min:2,max:8,run(st,net){
 // Spionnen (Codenames-stijl, host-authoritatief). De sleutelkaart staat alleen op de host en gaat met sendTo
 // uitsluitend naar de twee spionmeesters (en naar iedereen zodra de partij voorbij is).
 const WL='aarde,adelaar,agent,anker,ananas,appel,arm,arts,auto,baard,baby,bad,bakker,bal,ballon,bamboe,banaan,band,bank,bed,beer,bel,berg,bezem,bier,bij,blad,bliksem,bloem,boek,boom,boot,bord,bos,boter,brief,bril,broek,brood,brug,bus,cactus,circus,dak,dans,deken,deur,diamant,dokter,doos,dorp,douche,draak,duif,duim,dwerg,eend,egel,ei,emmer,engel,ezel,fabriek,feest,fiets,film,fles,fontein,gans,geest,geit,geld,gitaar,glas,goud,graf,gras,haai,haar,hamer,hand,hart,haven,heks,hek,hemel,hert,hoed,hond,hoorn,hotel,huis,hut,ijs,inkt,jager,jas,jungle,kaars,kaas,kabel,kameel,kanon,kapitein,kasteel,kat,kerk,kers,ketting,kever,kikker,kip,kist,klei,klok,knie,knoop,koe,koffer,kok,kom,kompas,koning,konijn,koord,korf,kous,krab,kraan,krant,kreeft,krijt,kroon,kruis,kussen,kust,laars,ladder,lam,lamp,land,leeuw,leger,lente,lepel,licht,lift,lijm,lint,lucht,maan,mand,mantel,markt,masker,matras,meer,meeuw,melk,mes,metro,mier,mijn,minuut,mist,molen,mond,mug,muis,munt,muts,muur,naald,nacht,nest,net,neus,noot,olifant,oog,oven,paal,paard,pak,paleis,pan,papier,parel,park,peer,pen,peper,piano,pijl,piloot,piraat,pizza,plant,plein,ploeg,politie,pomp,pop,post,pot,prins,radio,raket,regen,reus,riet,rijst,ring,robot,rok,rook,roos,rots,rug,schaap,schaar,schaduw,schip,schoen,school,schotel,sjaal,slak,slang,sleutel,slot,sneeuw,soep,sok,spiegel,spin,spons,spook,staart,stad,steen,ster,stier,stoel,storm,straat,strand,stroom,suiker,taart,tafel,tak,tand,tank,tas,taxi,tent,thee,tijd,tijger,toets,tomaat,tong,toren,trap,trein,trommel,trui,tuin,tunnel,uil,vaas,varken,veer,veld,vest,vinger,vis,vlag,vlek,vlinder,vloer,voet,vogel,vork,vos,vulkaan,vuur,wafel,wagen,walvis,water,web,wiel,wijn,wind,winkel,winter,wolf,wolk,worst,wortel,zaag,zak,zand,zebra,zee,zeep,zeil,zilver,zolder,zomer,zon,zout,zwaan,zwaard,zwembad'.split(',');
 const isH=net.isHost,me=net.me.id,TC=['#e5383b','#2f80ed','#c9b98f','#1b1b1f'],TN=['🔴 Team rood','🔵 Team blauw'],TS=['rood','blauw'];
 const norm=s=>String(s||'').toLowerCase().trim();
 const css=E('style','',`.sp-tm{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:0 auto 8px;max-width:520px}.sp-t{border-radius:14px;padding:6px 8px;border:2px solid var(--c);background:color-mix(in srgb,var(--c) 10%,var(--card));text-align:left}
 .sp-t h4{margin:0 0 4px;font-size:15px;display:flex;justify-content:space-between}.sp-t.on{box-shadow:0 0 0 3px var(--c)}.sp-c{display:flex;align-items:center;font-size:13px;font-weight:600;margin:2px 0;word-break:break-word}
 .sp-st{font-weight:700;margin:6px 0;min-height:22px}.sp-clue{font-size:22px;font-weight:800;letter-spacing:.04em;margin:4px 0}
 .sp-g{display:grid;grid-template-columns:repeat(5,1fr);gap:5px;max-width:520px;margin:8px auto}
 .sp-w{min-height:58px;padding:2px;border-radius:10px;border:2px solid var(--ln);background:var(--bg);color:var(--tx);font:inherit;font-weight:700;font-size:12.5px;word-break:break-word;hyphens:auto;cursor:pointer;line-height:1.1}
 .sp-w:disabled{cursor:default}.sp-w.k{border-color:var(--k);background:color-mix(in srgb,var(--k) 22%,var(--bg))}.sp-w.r{background:var(--k);border-color:var(--k);color:#fff;opacity:.92}.sp-w.r.n{color:#3a2f12}
 .sp-row{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:8px 0}.sp-row input,.sp-row select{padding:10px 12px;border:1px solid var(--ln);border-radius:12px;background:var(--bg);color:var(--tx);font:inherit;font-size:16px;min-height:46px}
 .sp-row input{flex:1;min-width:0;max-width:200px}.sp-log{font-size:13px;color:var(--mu);text-align:left;line-height:1.5;max-width:520px;margin:6px auto 0}.sp-err{color:#e5383b;font-weight:700;min-height:18px}`);
 const sc=E('div','sc'),teams=E('div','sp-tm'),stat=E('div','sp-st'),clue=E('div','sp-clue'),grid=E('div','sp-g'),row=E('div','sp-row'),err=E('div','sp-err'),log=E('div','sp-log');
 st.append(css,sc,teams,stat,clue,grid,row,err,log,E('div','hint','Spionmeesters zien de kleuren en geven een hint (één woord + aantal) · hun team tikt woorden aan'));
 const cIn=E('input');cIn.maxLength=20;cIn.placeholder='Hint (één woord)';cIn.autocomplete='off';const cN=E('select');for(let i=0;i<=9;i++){const o=E('option','',i===0?'0 (∞)':String(i));o.value=i;cN.append(o)}cN.value='1';
 const cB=E('button','btn','Geef hint');cB.onclick=()=>{send({k:'clue',w:cIn.value,n:+cN.value})};cIn.onkeydown=e=>{if(e.key==='Enter')cB.click()};
 let V=null,podDone=0;
 const chipEl=q=>{const d=E('div','sp-c'),a=E('span','pav s');a.style.setProperty('--c',q.col);a.textContent=q.av;const t=E('span');t.textContent=(V.sm.includes(q.id)?'🕵️ ':'')+q.n+(q.id===me?' (jij)':'');d.append(a,t);return d};
 function btn(l,fn,sec){const b=E('button','btn'+(sec?' sec':''),l);b.onclick=fn;return b}
 function render(){if(!V)return;const v=V,mine=v.pl.find(q=>q.id===me),myT=mine?mine.t:-1,amSm=v.sm.includes(me),onT=myT===v.turn,solo=mine&&v.pl.filter(q=>q.t===myT).length===1;
  const canTap=v.ph==='guess'&&onT&&(!amSm||solo);
  sc.textContent=mine?'Jij: '+net.pname(me)+' · '+TN[myT]+(amSm?' · 🕵️ Spionmeester':' · agent'):'👀 Je kijkt mee';
  teams.replaceChildren(...[0,1].map(t=>{const d=E('div','sp-t'+(v.ph!=='setup'&&v.ph!=='end'&&v.turn===t?' on':''));d.style.setProperty('--c',TC[t]);const h=E('h4');const a=E('span'),b=E('span');a.textContent=['🔴 Rood','🔵 Blauw'][t];b.textContent=v.ph==='setup'?'':'nog '+v.cnt[t];b.style.cssText='font-size:13px;color:var(--mu);font-weight:700;align-self:center';h.append(a,b);d.append(h,...v.pl.filter(q=>q.t===t).map(chipEl));return d}));
  const smOf=t=>v.pl.find(q=>q.id===v.sm[t]);
  if(v.ph==='setup'){stat.textContent=isH?'Verdeel de teams en start het spel':'De host verdeelt de teams…';clue.textContent=''}
  else if(v.ph==='clue'){const s=smOf(v.turn);stat.textContent=TN[v.turn]+' is aan zet — '+(s&&s.id===me?'jij geeft een hint':(s?net.pname(s.id)||s.n:'?')+' bedenkt een hint…');clue.textContent='🤔'}
  else if(v.ph==='guess'){stat.textContent=TN[v.turn]+' raadt'+(canTap?' — tik op een woord':'')+' · nog '+(v.left>50?'∞':v.left)+' '+(v.left===1?'gok':'gokken');clue.textContent='💬 '+v.clue.w.toUpperCase()+' · '+(v.clue.n||'∞')}
  else{stat.textContent=v.why||'';clue.textContent=TN[v.win]+' wint! 🎉'}
  grid.style.display=v.ph==='setup'?'none':'';
  grid.replaceChildren(...v.words.map((w,i)=>{const b=E('button','sp-w');b.type='button';b.textContent=w;const rv=v.rev[i],k=rv>=0?rv:v.key?v.key[i]:-1;
   if(k>=0){b.style.setProperty('--k',TC[k]);b.classList.add(rv>=0?'r':'k');if(k===2&&rv>=0)b.classList.add('n');if(k===3){b.textContent='💀 '+w;b.style.borderColor='#8a8a95'}}
   b.disabled=!(canTap&&rv<0);if(!b.disabled)b.onclick=()=>send({k:'tap',i});return b}));
  row.replaceChildren();
  if(v.ph==='setup'){if(mine)row.append(btn('⇄ Wissel van team',()=>send({k:'sw'}),1));if(isH)row.append(btn('🔀 Teams schudden',()=>send({k:'shuf'}),1),btn('▶ Start',()=>send({k:'go'})))}
  else if(v.ph==='clue'&&v.sm[v.turn]===me){row.append(cIn,cN,cB)}
  else if(canTap)row.append(btn('✋ Stoppen met raden',()=>send({k:'stop'}),1));
  log.replaceChildren(...(v.log||[]).slice().reverse().map(x=>{const d=E('div');d.textContent=x;return d}));
  if(v.ph==='end'&&!podDone){podDone=1;const s={};v.pl.forEach(q=>s[q.id]=q.t===v.win?1:0);net.result({winner:null,title:v.win?'🔵 Team blauw wint!':'🔴 Team rood wint!',scores:s,text:v.why,unit:' pt'})}}
 function send(d){err.textContent='';if(isH)act(me,d);else net.send(d)}
 // ---------- host ----------
 let H=null;const by=id=>H.pl.find(q=>q.id===id);
 function view(id){const sm=H.sm.includes(id)||H.ph==='end';const v={k:'s',ph:H.ph,pl:H.pl,sm:H.sm,words:H.words,rev:H.rev,turn:H.turn,clue:H.clue,left:H.left,log:H.log.slice(-10),win:H.win,why:H.why,
   cnt:[0,1].map(t=>H.key.filter((k,i)=>k===t&&H.rev[i]<0).length)};if(sm&&H.ph!=='setup')v.key=H.key;return v}
 function pub(){net.players.forEach(p=>{if(p.id===me){V=view(me);render()}else net.sendTo(p.id,view(p.id))})}
 function pickSm(){H.sm=[0,1].map(t=>{const m=H.pl.filter(q=>q.t===t);return m.length?m[((net._round||1)-1)%m.length].id:null})}
 function fail(id,m){if(id===me)err.textContent=m;else net.sendTo(id,{k:'err',m})}
 const wLog=(q,s)=>H.log.push((q?(q.av+' '+q.n):'')+' '+s);
 function finish(t,why){H.ph='end';H.win=t;H.why=why;H.log.push('🏁 '+why);pub()}
 function next(){H.turn=1-H.turn;H.ph='clue';H.clue=null;H.left=0;pub()}
 function act(from,d){if(!H||!d)return;const p=by(from);
  if(H.ph==='setup'){if(d.k==='sw'&&p){p.t=1-p.t;pickSm();pub()}
   else if(from===me&&d.k==='shuf'){const ids=H.pl.map(q=>q.id);for(let i=ids.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[ids[i],ids[j]]=[ids[j],ids[i]]}ids.forEach((id,i)=>by(id).t=i%2);pickSm();pub()}
   else if(from===me&&d.k==='go'){if(!H.pl.some(q=>q.t===0)||!H.pl.some(q=>q.t===1))return fail(me,'Elk team heeft minstens één speler nodig');pickSm();H.ph='clue';H.turn=H.start;H.log.push(TN[H.start]+' begint (9 woorden)');pub()}return}
  if(!p||H.ph==='end')return;
  if(d.k==='clue'&&H.ph==='clue'&&H.sm[H.turn]===from){const w=norm(d.w),n=Math.max(0,Math.min(9,d.n|0));
   if(!/^[a-zà-ÿ'-]{2,20}$/.test(w))return fail(from,'Geef één woord (alleen letters)');
   if(H.words.some(x=>x===w||(w.length>=3&&x.includes(w))||(x.length>=3&&w.includes(x))))return fail(from,'Dat woord (of een deel ervan) ligt op het bord');
   H.clue={w,n};H.left=n===0?99:n+1;H.ph='guess';wLog(p,'geeft de hint “'+w+'” · '+(n||'∞'));pub();return}
  const team=H.pl.filter(q=>q.t===H.turn),guesser=p.t===H.turn&&(!H.sm.includes(from)||team.length===1);
  if(H.ph!=='guess'||!guesser)return;
  if(d.k==='stop'){wLog(p,'stopt met raden');return next()}
  const i=d.i|0;if(d.k!=='tap'||i<0||i>24||H.rev[i]>=0)return;const k=H.key[i];H.rev[i]=k;
  wLog(p,'tikt “'+H.words[i]+'” → '+['rood','blauw','neutraal','💀 moordenaar'][k]);
  if(k===3)return finish(1-H.turn,TN[H.turn]+' raakte de moordenaar 💀');
  for(const t of[H.turn,1-H.turn])if(!H.key.some((x,j)=>x===t&&H.rev[j]<0))return finish(t,TN[t]+' vond al zijn woorden');
  if(k===H.turn){H.left--;if(H.left<=0)return next();pub()}else next()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;if(isH){if(d.k==='hi'){if(H)net.sendTo(from,view(from))}else act(from,d)}
  else if(d.k==='s'){V=d;render()}else if(d.k==='err')err.textContent=String(d.m||'')});
 const offP=net.onPlayers(ps=>{if(!isH||!H)return;const ids=new Set(ps.map(p=>p.id));
  H.pl.filter(q=>!ids.has(q.id)).forEach(q=>H.log.push('🚪 '+q.av+' '+q.n+' heeft het spel verlaten'));H.pl=H.pl.filter(q=>ids.has(q.id));
  if(H.ph==='setup')ps.forEach(p=>{if(!by(p.id)){const c=[0,1].map(t=>H.pl.filter(q=>q.t===t).length);H.pl.push({id:p.id,n:p.name,av:p.av,col:p.col,t:c[0]<=c[1]?0:1})}});
  const old=H.sm.slice();H.sm=H.sm.map((id,t)=>by(id)?id:((H.pl.find(q=>q.t===t)||{}).id||null));
  if(H.ph!=='setup'&&H.ph!=='end'){const empty=[0,1].find(t=>!H.pl.some(q=>q.t===t));if(empty!=null)return finish(1-empty,TN[empty]+' heeft geen spelers meer');
   H.sm.forEach((id,t)=>{if(id!==old[t]){wLog(by(id),'is de nieuwe spionmeester van '+TN[t])}})}
  else if(H.ph==='setup')pickSm();pub()});
 if(isH){const rnd=net.rng(),start=rnd()<.5?0:1,pool=WL.slice(),words=[];for(let i=0;i<25;i++)words.push(pool.splice(Math.floor(rnd()*pool.length),1)[0]);
  const key=[...Array(9).fill(start),...Array(8).fill(1-start),...Array(7).fill(2),3];for(let i=24;i>0;i--){const j=Math.floor(rnd()*(i+1));[key[i],key[j]]=[key[j],key[i]]}
  H={ph:'setup',pl:net.players.map((p,i)=>({id:p.id,n:p.name,av:p.av,col:p.col,t:i%2})),sm:[],words,key,rev:Array(25).fill(-1),turn:start,start,clue:null,left:0,log:[],win:null,why:''};pickSm();
  if(net.players.length<4)H.log.push('🧪 Oefenpotje: met minder dan 4 spelers is een spionmeester ook agent');
  if(window.SPZ_PEER)window.__dbg={get H(){return H}};pub()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{off();offP();if(window.__dbg)delete window.__dbg}}},
