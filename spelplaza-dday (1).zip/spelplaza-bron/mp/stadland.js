{id:'stadland',n:'Stad-land-rivier',e:'🌍',c:'Samen',g:'#f7971e,#ffd200',min:2,max:8,run(st,net){
 // Stad-land-rivier (host-authoritatief). Antwoorden blijven op elk toestel tot de invoer sluit; pas in de beoordeling deelt de host ze met iedereen.
 const isH=net.isHost,me=net.me.id,DEF=['Stad','Land','Rivier','Dier','Naam','Beroep','Eten','Merk'],LET='ABCDEFGHIJKLMNOPRSTUVWZ',PLAY=90000,CD=5000,SPIN=1600;
 const norm=s=>String(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
 const pinfo=id=>net.players.find(x=>x.id===id),pn=(id,n)=>{const q=pinfo(id);return q?net.pname(q):(n||'?')},pcol=id=>{const q=pinfo(id);return q&&q.col||'var(--mu)'};
 // beoordeling: per speler per categorie {st,p}; st = ok | dubbel | af (weggestemd) | letter | leeg
 function score(S){const ids=Object.keys(S.ans||{}),R={},nO=ids.length-1,L=(S.L||'').toLowerCase();
  ids.forEach(id=>R[id]=S.cats.map((c,ci)=>{const a=norm(S.ans[id][ci]);if(!a)return{st:'leeg',p:0,v:0};if(a[0]!==L)return{st:'letter',p:0,v:0};
   const v=((S.v[id]||{})[ci]||[]).length;if(nO>0&&v*2>nO)return{st:'af',p:0,v};return{st:'ok',p:10,v,a}}));
  S.cats.forEach((c,ci)=>{const cnt={};ids.forEach(id=>{const x=R[id][ci];if(x.st==='ok')cnt[x.a]=(cnt[x.a]||0)+1});ids.forEach(id=>{const x=R[id][ci];if(x.st==='ok'&&cnt[x.a]>1){x.st='dubbel';x.p=5}})});
  return R}
 const rsum=(R,id)=>(R[id]||[]).reduce((a,x)=>a+x.p,0);
 // ---- UI ----
 const sc=E('div','sc'),note=E('div','hint'),board=E('div'),msg=E('div'),setup=E('div'),letter=E('div'),barW=E('div'),bar=E('div'),form=E('div'),bStop=E('button','btn','✋ STOP!'),rev=E('div'),bNext=E('button','btn','Volgende ronde ▶');
 board.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:6px 0 8px';msg.style.cssText='min-height:22px;font-weight:700;font-size:15px;margin:4px 0';
 letter.style.cssText='display:none;width:96px;height:96px;margin:6px auto 10px;border-radius:22px;background:linear-gradient(135deg,#f7971e,#ffd200);color:#1b1d2a;font:900 64px/96px system-ui,sans-serif;box-shadow:0 6px 18px rgba(0,0,0,.25);transition:transform .15s';
 barW.style.cssText='height:6px;border-radius:99px;background:var(--bg);overflow:hidden;max-width:380px;margin:0 auto 10px';bar.style.cssText='height:100%;width:100%;border-radius:99px;background:#38d9a9';barW.append(bar);
 form.style.cssText='display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;max-width:560px;margin:0 auto 10px;text-align:left';
 bStop.style.cssText='font-size:20px;padding:12px 34px;background:linear-gradient(135deg,#e5383b,#f77f00);display:none;margin:4px auto 10px';
 rev.style.cssText='overflow-x:auto;max-width:600px;margin:0 auto';bNext.style.cssText='display:none;margin:2px auto 8px;font-size:16px';
 st.append(sc,note,board,msg,setup,letter,barW,form,bStop,bNext,rev,E('div','hint','Vul per categorie een woord in dat met de letter begint · STOP! zodra alles ingevuld is · stem ✗ op foute antwoorden · uniek 10 pt, dubbel 5 pt'));
 let S=null,notes=[],known={},inputs=[],formKey='',spinT=0,lPhR='',lEnd=0,podDone=0,lastF=-1,sentLock='';
 net.players.forEach(p=>known[p.id]=net.pname(p));
 const myVals=()=>inputs.map(i=>i.value.slice(0,30));
 const inRound=()=>S&&S.pl.some(p=>p.id===me);
 function chip(id,n,txt,on){const col=pcol(id),d=E('div'),q=pinfo(id);
  d.style.cssText='display:inline-flex;align-items:center;padding:2px 9px 2px 2px;border-radius:99px;font-size:13px;font-weight:'+(on?'800':'600')+';color:var(--tx);border:2px solid '+col+';background:'+(on?'color-mix(in srgb,'+col+' 20%,var(--bg))':'var(--bg)');
  const av=E('span','pav s');av.style.setProperty('--c',col);av.textContent=q&&q.av||'🙂';const t=E('span');t.textContent=txt;d.append(av,t);return d}
 function pill(txt,on,fn){const b=E('button','btn');b.textContent=txt;b.style.cssText='min-height:44px;padding:8px 14px;font-size:15px;border-radius:99px;'+(on?'':'background:var(--bg);color:var(--tx);border:1px solid var(--ln,#ccc)');if(fn)b.onclick=fn;else b.disabled=true;return b}
 function buildForm(){formKey=S.r+'|'+S.cats.join(',');inputs=S.cats.map((c,ci)=>{const w=E('label');w.style.cssText='display:flex;flex-direction:column;gap:3px;font-size:13px;font-weight:700;color:var(--mu)';const t=E('span');t.textContent=c;
   const i=E('input');i.maxLength=30;i.autocomplete='off';i.spellcheck=false;i.autocapitalize='words';i.style.cssText='padding:10px 12px;border:1px solid var(--ln,#ccc);border-radius:12px;background:var(--bg);color:var(--tx);font:inherit;font-size:16px;min-height:44px;font-weight:600';
   i.oninput=changed;i.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();const n=inputs[ci+1];if(n)n.focus();else if(!bStop.disabled)stop()}};w.append(t,i);return w});
  form.replaceChildren(...inputs);inputs=inputs.map(w=>w.querySelector('input'));lastF=-1}
 function changed(){if(!S)return;const f=myVals().filter(v=>norm(v)).length;bStop.disabled=!(S.ph==='play'&&f===S.cats.length);bStop.style.opacity=bStop.disabled?'.45':'1';
  if(f!==lastF){lastF=f;if(isH)hFill(me,f);else net.send({k:'f',r:S.r,n:f})}}
 function stop(){if(!S||S.ph!=='play')return;changed();if(bStop.disabled)return;if(isH)hStop(me);else net.send({k:'stop',r:S.r})}
 bStop.onclick=stop;
 function spin(){clearInterval(spinT);let n=0;letter.style.transform='scale(.85) rotate(-8deg)';spinT=setInterval(()=>{n++;letter.textContent=LET[R(LET.length)];letter.style.transform='scale('+(.85+n*.008)+') rotate('+(n%2?6:-6)+'deg)';if(n%3===0)beep(300+n*20,.03,'triangle',.02);
  if(n>=Math.floor((SPIN-150)/70)){clearInterval(spinT);spinT=0;letter.textContent=S.L;letter.style.transform='scale(1.08)';beep(880,.15,'triangle',.04);setTimeout(()=>letter.style.transform='none',180)}},70)}
 function renderSetup(){setup.replaceChildren();if(S.ph!=='setup'){setup.style.display='none';return}setup.style.display='';
  const h=E('div','');h.style.cssText='font-weight:800;margin:6px 0';h.textContent=isH?'Kies 5–8 categorieën ('+S.cats.length+' gekozen)':'De host kiest de categorieën…';
  const g=E('div');g.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;max-width:520px;margin:0 auto 10px';
  S.opts.forEach(o=>{const on=S.cats.includes(o);g.append(pill((on?'✓ ':'')+o,on,isH?()=>{if(on){if(S.cats.length>5)S.cats=S.cats.filter(x=>x!==o)}else if(S.cats.length<8)S.cats=S.opts.filter(x=>x===o||S.cats.includes(x));pub()}:null))});setup.append(h,g);
  if(isH){const row=E('div');row.style.cssText='display:flex;gap:6px;max-width:340px;margin:0 auto 10px';const ci=E('input');ci.maxLength=16;ci.placeholder='Eigen categorie…';ci.style.cssText='flex:1;min-width:0;padding:10px 12px;border:1px solid var(--ln,#ccc);border-radius:12px;background:var(--bg);color:var(--tx);font:inherit;font-size:16px';
   const add=()=>{const v=ci.value.trim().replace(/\s+/g,' ').slice(0,16);if(!v||S.opts.some(x=>norm(x)===norm(v))||S.opts.length>=14)return;S.opts.push(v);if(S.cats.length<8)S.cats.push(v);pub()};
   const ab=E('button','btn','+ Voeg toe');ab.onclick=add;ci.onkeydown=e=>{if(e.key==='Enter')add()};row.append(ci,ab);setup.append(row)}
  const rr=E('div');rr.style.cssText='display:flex;gap:6px;justify-content:center;align-items:center;margin:4px 0 10px;font-weight:700';const rl=E('span');rl.textContent='Rondes:';rr.append(rl);
  [3,5].forEach(n=>rr.append(pill(n+'',S.nR===n,isH?()=>{S.nR=n;pub()}:null)));setup.append(rr);
  if(isH){const b=E('button','btn','▶ Start');b.style.cssText='font-size:18px;padding:12px 34px';b.disabled=S.cats.length<5||S.cats.length>8;b.onclick=()=>startRound();setup.append(b)}}
 function renderRev(){rev.replaceChildren();if(S.ph!=='rev'){rev.style.display='none';return}rev.style.display='';const R=score(S),ids=Object.keys(S.ans);
  const tb=E('table');tb.style.cssText='border-collapse:collapse;width:100%;font-size:14px;text-align:left';
  S.cats.forEach((c,ci)=>{const hr=E('tr'),th=E('th');th.colSpan=3;th.textContent=c;th.style.cssText='padding:10px 6px 4px;font-size:13px;text-transform:uppercase;letter-spacing:.06em;color:var(--mu);border-bottom:2px solid var(--ln,#ddd)';hr.append(th);tb.append(hr);
   ids.forEach(id=>{const x=R[id][ci],tr=E('tr'),a=E('td'),b=E('td'),d=E('td'),q=pinfo(id);tr.style.borderBottom='1px solid var(--ln,#eee)';
    a.style.cssText='padding:4px;width:30px';const av=E('span','pav s');av.style.cssText='--c:'+pcol(id)+';margin:0';av.textContent=q&&q.av||'🙂';av.title=pn(id);a.append(av);
    b.style.cssText='padding:4px 6px;font-weight:600;word-break:break-word;'+(x.p?'':'color:var(--mu);text-decoration:'+(x.st==='leeg'?'none':'line-through'));b.textContent=(S.ans[id][ci]||'').trim()||'—';
    if(x.st==='letter'){const s=E('small');s.textContent=' (geen '+S.L+')';s.style.textDecoration='none';b.append(s)}
    d.style.cssText='padding:4px;text-align:right;white-space:nowrap';const p=E('b');p.textContent=x.p?'+'+x.p:'0';p.style.cssText='display:inline-block;min-width:30px;color:'+(x.p===10?'#27ae60':x.p?'#e9a100':'var(--mu)');d.append(p);
    if(x.st==='ok'||x.st==='dubbel'||x.st==='af'){const mine=((S.v[id]||{})[ci]||[]).includes(me),can=id!==me&&inRound(),vb=E('button','btn');vb.textContent='✗'+(x.v?' '+x.v:'');
     vb.style.cssText='min-height:40px;min-width:48px;padding:4px 8px;margin-left:6px;font-size:15px;'+(mine?'background:#e5383b':'background:var(--bg);color:var(--tx);border:1px solid var(--ln,#ccc)')+(can?'':';opacity:.45');vb.disabled=!can;
     vb.onclick=()=>{if(isH)hVote(me,id,ci);else net.send({k:'v',p:id,c:ci,r:S.r})};d.append(vb)}
    tr.append(a,b,d);tb.append(tr)})});rev.append(tb);return R}
 function render(){if(!S)return;note.textContent=notes.slice(-3).join(' · ');note.style.display=notes.length?'':'none';const m=S.pl.find(p=>p.id===me),ph=S.ph;
  const live=ph==='spin'||ph==='play'||ph==='cd'||ph==='lock';
  if(live&&formKey!==S.r+'|'+S.cats.join(','))buildForm();
  if(S.r+ph!==lPhR){const prev=lPhR;lPhR=S.r+ph;if(ph==='spin')spin();if(ph==='play'||ph==='cd')lEnd=performance.now()+(S.left||0);
   if(ph==='play'&&prev.endsWith('spin')&&inputs[0]&&m&&matchMedia('(pointer:fine)').matches)inputs[0].focus();if(ph==='cd')beep(660,.12,'square',.04)}
  if(ph==='play'||ph==='cd')lEnd=Math.min(lEnd,performance.now()+(S.left||0)+250);
  if(ph==='lock'&&m&&sentLock!==S.r+''){sentLock=S.r+'';if(isH)setTimeout(()=>hAns(me,myVals()),0);else net.send({k:'a',r:S.r,a:myVals()})}
  renderSetup();letter.style.display=live||ph==='rev'?'':'none';const sm=ph==='rev';letter.style.width=letter.style.height=sm?'56px':'96px';letter.style.fontSize=sm?'38px':'64px';letter.style.lineHeight=sm?'56px':'96px';letter.style.borderRadius=sm?'14px':'22px';st.style.minHeight=ph==='fin'?(300+64*S.pl.length)+'px':'';if(!spinT&&S.L)letter.textContent=S.L;
  barW.style.visibility=ph==='play'||ph==='cd'?'visible':'hidden';barW.style.display=live?'':'none';
  form.style.display=live&&m?'grid':'none';inputs.forEach(i=>{i.disabled=!(ph==='play'||ph==='cd')});
  bStop.style.display=live&&m?'':'none';if(ph!=='play'){bStop.disabled=true;bStop.style.opacity='.45'}else changed();
  const R=renderRev();
  board.replaceChildren(...S.pl.slice().sort((a,b)=>b.sc-a.sc).map(p=>chip(p.id,p.n,p.n+(p.id===me?' (jij)':'')+' · '+p.sc+(live&&ph!=='spin'?' · '+p.f+'/'+S.cats.length:ph==='rev'?' (+'+rsum(R,p.id)+')':''),p.id===me)));
  sc.textContent=ph==='setup'?'Stad-land-rivier · '+S.pl.length+' spelers':ph==='fin'?'Spel klaar!':'Ronde '+(S.r+1)+'/'+S.nR+' · letter '+S.L+(m?' · Jij: '+m.sc+' pt':' · Je kijkt mee');
  bNext.style.display=isH&&ph==='rev'?'':'none';bNext.textContent=S.r+1>=S.nR?'Uitslag 🏆':'Volgende ronde ▶';
  msg.style.color='var(--tx)';
  msg.textContent=ph==='spin'?'De letter wordt gekozen…':ph==='play'?(m?'Alles met de letter '+S.L+'!':'Je doet mee vanaf de volgende ronde'):ph==='cd'?'✋ '+pn(S.stopBy)+' riep STOP!':ph==='lock'?'Pennen neer! Antwoorden verzamelen…':ph==='rev'?(isH?'Stem ✗ op foute antwoorden en ga dan verder':'Stem ✗ op foute antwoorden · de host gaat verder'):'';
  if(ph==='fin'){const r=S.pl.slice().sort((a,b)=>b.sc-a.sc),tie=r.length>1&&r[0].sc===r[1].sc;msg.textContent=r.length&&!tie?'🏆 '+pn(r[0].id,r[0].n)+' wint met '+r[0].sc+' punten!':'Gelijkspel!';
   if(!podDone){podDone=1;const scores={};r.forEach(p=>scores[p.id]=p.sc);net.result({winner:!tie&&r[0]?r[0].id:null,scores,unit:' pt',title:tie?'Gelijkspel 🤝':undefined})}}}
 // ---- host ----
 let A={},tm=0,tPh=0,rng=null;
 function pub(){if(S.ph==='play')S.left=Math.max(0,PLAY-(Date.now()-tPh));else if(S.ph==='cd')S.left=Math.max(0,CD-(Date.now()-tPh));else S.left=0;net.send(S);render()}
 function startRound(){if(S.ph!=='setup'&&S.ph!=='rev')return;if(S.ph==='setup'&&(S.cats.length<5||S.cats.length>8))return;
  S.pend.forEach(p=>{if(!S.pl.some(x=>x.id===p.id))S.pl.push(p)});S.pend=[];
  const left=LET.split('').filter(l=>!S.used.includes(l)),pool=left.length?left:LET.split('');S.L=pool[Math.floor(rng()*pool.length)];S.used.push(S.L);
  S.ph='spin';S.ans={};S.v={};S.stopBy=null;A={};S.pl.forEach(p=>p.f=0);tPh=Date.now();pub()}
 function hFill(id,n){const p=S.pl.find(p=>p.id===id);if(!p||!['play','cd'].includes(S.ph))return;p.f=Math.max(0,Math.min(S.cats.length,n|0));pub()}
 function hStop(id){const p=S.pl.find(p=>p.id===id);if(S.ph!=='play'||!p||p.f<S.cats.length)return;S.ph='cd';S.stopBy=id;tPh=Date.now();pub()}
 function lock(){S.ph='lock';tPh=Date.now();pub()}
 function hAns(id,a){if(S.ph!=='lock'||!S.pl.some(p=>p.id===id)||!Array.isArray(a))return;A[id]=S.cats.map((c,i)=>String(a[i]||'').slice(0,30));if(S.pl.every(p=>A[p.id]))toRev()}
 function toRev(){if(S.ph!=='lock')return;S.ph='rev';S.ans={};S.pl.forEach(p=>S.ans[p.id]=A[p.id]||S.cats.map(()=>''));S.v={};pub();beep(523,.12,'triangle',.04)}
 function hVote(from,id,ci){if(S.ph!=='rev'||from===id||!S.ans[id]||!S.ans[from]||!(ci>=0&&ci<S.cats.length))return;const v=(S.v[id]=S.v[id]||{}),l=v[ci]=v[ci]||[];const i=l.indexOf(from);if(i>=0)l.splice(i,1);else l.push(from);pub()}
 function next(){if(S.ph!=='rev')return;const R=score(S);S.pl.forEach(p=>p.sc+=rsum(R,p.id));S.r++;if(S.r>=S.nR){S.ph='fin';S.ans={};pub();[0,1,2].forEach(i=>setTimeout(()=>beep(523*Math.pow(1.26,i),.12,'triangle',.05),i*120))}else{S.ph='rev';startRound()}}
 bNext.onclick=()=>{if(isH)next()};
 function tick(){if(!S)return;const t=Date.now()-tPh;if(S.ph==='spin'&&t>=SPIN){S.ph='play';tPh=Date.now();pub()}else if(S.ph==='play'&&t>=PLAY)lock();else if(S.ph==='cd'&&t>=CD)lock();else if(S.ph==='lock'&&t>=2500)toRev()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(isH){if(!S)return;if(d.k==='hi')net.sendTo(from,S);else if(d.r!==S.r&&d.k!=='hi')return;else if(d.k==='f')hFill(from,d.n);else if(d.k==='stop')hStop(from);else if(d.k==='a')hAns(from,d.a);else if(d.k==='v')hVote(from,String(d.p),d.c|0)}
  else if(d.k==='s'){S=d;render()}});
 const offP=net.onPlayers(ps=>{const ids=new Set(ps.map(p=>p.id));
  Object.keys(known).forEach(id=>{if(!ids.has(id)){notes.push('⚠️ '+known[id]+' heeft het spel verlaten');delete known[id];
   if(isH&&S){S.pl=S.pl.filter(p=>p.id!==id);S.pend=S.pend.filter(p=>p.id!==id);delete A[id];delete S.ans[id];delete S.v[id];Object.values(S.v).forEach(o=>Object.values(o).forEach(l=>{const i=l.indexOf(id);if(i>=0)l.splice(i,1)}));if(S.stopBy===id&&S.ph==='cd')S.stopBy=null}}});
  ps.forEach(p=>{if(!known[p.id]){known[p.id]=net.pname(p);notes.push('👋 '+net.pname(p)+' kijkt mee');if(isH&&S&&!S.pl.some(x=>x.id===p.id)&&!S.pend.some(x=>x.id===p.id)){const np={id:p.id,n:p.name,sc:0,f:0};if(S.ph==='setup')S.pl.push(np);else S.pend.push(np)}}});
  if(isH&&S){if(S.ph==='lock'&&S.pl.every(p=>A[p.id]))toRev();else pub()}else render()});
 const stopLoop=loop(()=>{if(!S||(S.ph!=='play'&&S.ph!=='cd'))return;const tot=S.ph==='cd'?CD:PLAY,left=Math.max(0,lEnd-performance.now()),f=left/tot;bar.style.width=f*100+'%';bar.style.background=S.ph==='cd'?'#e5383b':`hsl(${Math.round(f*120)},70%,50%)`;
  const s=Math.ceil(left/1000),base=sc.textContent.replace(/ · ⏱.*$/,'');sc.textContent=base+' · ⏱ '+s+' s';if(S.ph==='cd'){letter.style.transform='scale('+(1+.06*Math.sin(performance.now()/90))+')'}});
 window.__dbg={get S(){return S},score,norm,get A(){return isH?A:null},force:()=>{if(isH&&S&&(S.ph==='play'||S.ph==='cd'))lock()}};
 if(isH){rng=net.rng();S={k:'s',ph:'setup',r:0,nR:3,L:'',used:[],opts:DEF.slice(),cats:DEF.slice(),pl:net.players.map(p=>({id:p.id,n:p.name,sc:0,f:0})),pend:[],ans:{},v:{},stopBy:null,left:0};tm=setInterval(tick,150);pub()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{st.style.minHeight='';off();offP();stopLoop();clearInterval(tm);clearInterval(spinT);if(window.__dbg&&window.__dbg.norm===norm)delete window.__dbg}}},
