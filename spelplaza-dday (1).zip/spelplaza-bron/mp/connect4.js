{id:'connect4',n:'Vier op een rij',e:'🔴',c:'Samen',g:'#ff416c,#ff4b2b',min:2,max:2,bots:true,run(st,net){
 // Vier op een rij 7×6 voor 2 spelers: host begint. Schijven in de eigen spelerskleur (donkere rand voor contrast); het bord wordt leisteen als een speler blauw heeft. Lockstep: elke speler valideert en past de zet toe, daarna wordt hij verstuurd.
 const me=net.myIndex(),MY=me===0?1:-1;
 let opp=null;const P=s=>net.players[s===1?0:1]||(s===MY?net.me:opp),nm=s=>{const p=P(s);return p?net.pname(p):'…'},cl=s=>{const p=P(s);return p&&p.col||(s===1?'#e5383b':'#f4a261')},pid=s=>{const p=P(s);return p?p.id:null};
 const hx=h=>[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0),tint=(h,a)=>'rgba('+hx(h).join(',')+','+a+')',mix=(a,b,f)=>{const A=hx(a),B=hx(b);return'rgb('+A.map((v,i)=>Math.round(v+(B[i]-v)*f)).join(',')+')'};
 const hue=h=>{const[r,g,b]=hx(h).map(v=>v/255),M=Math.max(r,g,b),m=Math.min(r,g,b),d=M-m;if(!d)return-999;const x=M===r?((g-b)/d)%6:M===g?(b-r)/d+2:(r-g)/d+4;return(x*60+360)%360};
 const DISC=s=>{const k=cl(s);return'radial-gradient(circle at 35% 35%,'+mix(k,'#ffffff',.5)+','+k+' 55%,'+mix(k,'#000000',.4)+')'};
 const sc=E('div','sc'),who=E('div','hint');who.style.cssText='min-height:26px;line-height:2;font-weight:600;color:var(--tx);margin:0 auto 2px';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(380px,100%);margin:4px auto';
 const top=E('div','bdr');top.style.cssText+='grid-template-columns:repeat(7,minmax(0,1fr));width:100%;gap:6px;padding:0 8px;margin:0';
 const bd=E('div','bdr');bd.style.cssText+='grid-template-columns:repeat(7,minmax(0,1fr));width:100%;gap:6px;padding:8px;border-radius:14px;box-shadow:0 6px 16px rgba(20,50,140,.45);margin:2px 0 0';
 const ov=E('div','ov');ov.style.display='none';wrap.append(top,bd,ov);
 const hint=E('div','hint','Tik op een kolom · toetsen 1–7 of ◀ ▶ en spatie · vier op een rij wint');
 st.append(sc,who,wrap,hint);
 const tops=[],cells=[],discs=[];
 for(let c=0;c<7;c++){const d=E('div');d.style.cssText='aspect-ratio:auto;height:26px;position:relative';const s=E('span');s.style.cssText='display:none;width:24px;height:24px;border-radius:50%;opacity:.7;box-shadow:0 0 0 1.5px rgba(0,0,0,.45)';d.append(s);tops.push(s);d.onpointerdown=e=>{e.preventDefault();human(c)};top.append(d)}
 for(let i=0;i<42;i++){const d=E('div');d.style.cssText='border-radius:50%;background:var(--bg);box-shadow:inset 0 2px 5px rgba(0,0,0,.35);position:relative';
  const s=E('span');s.style.cssText='display:none;position:absolute;inset:6%;border-radius:50%';d.append(s);discs.push(s);
  d.onpointerdown=e=>{e.preventDefault();human(i%7)};cells.push(d);bd.append(d)}
 // ---------- spelerchips ----------
 function chip(s,on){const k=cl(s),c=E('span');c.style.cssText='display:inline-flex;align-items:center;gap:5px;padding:1px 9px;border-radius:99px;border:1.5px solid '+k+';background:'+tint(k,.14)+';white-space:nowrap;vertical-align:middle;line-height:1.5;'+(on===1?'box-shadow:0 0 0 3px '+tint(k,.3)+';font-weight:800':on===-1?'opacity:.55':'');
  const d=E('i');d.style.cssText='width:11px;height:11px;border-radius:50%;flex:none;background:'+DISC(s)+';box-shadow:0 0 0 1px rgba(0,0,0,.4)';c.append(d,document.createTextNode(nm(s)+(s===MY?' (jij)':'')));return c}
 function setWho(t,msg){who.replaceChildren();[1,-1].forEach((s,i)=>{if(i)who.append(document.createTextNode(' · '));who.append(chip(s,t?(t===s?1:-1):0));if(t===s)who.append(document.createTextNode(s===MY?' bent aan zet':' is aan zet'))});if(msg)who.append(document.createTextNode(' · '+msg))}
 function boardSkin(){const blue=[1,-1].some(s=>{const h=hue(cl(s));return h>160&&h<270});bd.style.background=blue?'linear-gradient(160deg,#3b4a63,#1f2838)':'linear-gradient(160deg,#2f6fe4,#1b47b8)'}
 // ---------- regels ----------
 function drop(b,c,p){for(let r=5;r>=0;r--){const i=r*7+c;if(!b[i]){b[i]=p;return i}}return-1}
 function winLine(b,i){const p=b[i],r=(i/7)|0,c=i%7,out=[];
  for(const[dr,dc]of[[0,1],[1,0],[1,1],[1,-1]]){const line=[i];for(const s of[1,-1]){let R=r+dr*s,C=c+dc*s;while(R>=0&&R<6&&C>=0&&C<7&&b[R*7+C]===p){line.push(R*7+C);R+=dr*s;C+=dc*s}}if(line.length>=4)out.push(...line)}
  return out.length?[...new Set(out)]:null}
 // ---------- toestand ----------
 let b,t,over,win,cur_c,n,gone=0,shown=0;
 function showOv(big,small){ov.replaceChildren();const x=E('div');x.textContent=big;const s=E('div');s.style.cssText='font-size:15px;font-weight:600';s.textContent=small||'';ov.append(x,s);ov.style.textShadow='0 1px 4px #000';ov.style.display='flex'}
 function refresh(){if(gone)showOv(opp?'⚠️ '+nm(-MY)+' heeft het spel verlaten':'Wachten op speler…',net.isHost?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten');else ov.style.display='none';draw();
  if(over&&!shown){shown=1;net.result({winner:over===3?null:pid(over),text:over===3?'Het bord is vol':'Vier op een rij na '+n+' zetten'})}botTick()}
 function draw(){boardSkin();
  for(let i=0;i<42;i++){const v=b[i],s=discs[i];if(!v){s.style.display='none';continue}
   s.style.display='block';s.style.background=DISC(v);s.dataset.p=v;
   if(win){const w=win.includes(i);s.style.opacity=w?'1':'.45';s.style.boxShadow=w?'0 0 0 3px #fff,0 0 14px 4px rgba(255,255,255,.7)':'0 0 0 1.5px rgba(0,0,0,.5)'}else{s.style.opacity='1';s.style.boxShadow='0 0 0 1.5px rgba(0,0,0,.5),0 2px 4px rgba(0,0,0,.45),inset 0 -3px 6px rgba(0,0,0,.25)'}}
  for(let c=0;c<7;c++){const s=tops[c];const show=!over&&!gone&&t===MY&&c===cur_c&&b[c]===0;s.style.display=show?'block':'none';s.style.background=DISC(MY)}
  sc.replaceChildren();const dot=s=>{const e=E('span');e.style.cssText='display:inline-block;width:12px;height:12px;border-radius:50%;vertical-align:-1px;margin:0 4px;background:'+DISC(s)+';box-shadow:0 0 0 1px rgba(0,0,0,.4)';return e};
  sc.append(dot(1),document.createTextNode(' '+nm(1)+(MY===1?' (jij)':'')+' tegen '+nm(-1)+(MY===-1?' (jij)':'')+' '),dot(-1),document.createTextNode(' · zet '+(over?n:n+1)));
  if(over)sc.append(document.createTextNode(over===3?' · 🤝 gelijkspel':over===MY?' · 🎉 jij wint!':' · 🏆 '+nm(over)+' wint!'));
  setWho(over?0:t,over?'spel voorbij':'')}
 function animate(i){const s=discs[i],r=(i/7)|0,h=cells[i].getBoundingClientRect().height||44;
  try{s.animate([{transform:'translateY(-'+((r+1)*(h+6))+'px)'},{transform:'none'}],{duration:120+r*55,easing:'cubic-bezier(.3,.6,.5,1.25)'})}catch(e){}}
 function place(c,side){if(over||t!==side||c<0||c>6)return false;const i=drop(b,c,side);if(i<0)return false;n++;draw();animate(i);beep(side===1?440:330,.06,'triangle',.04);
  const wl=winLine(b,i);if(wl){win=wl;over=side;beep(side===MY?880:160,.4,side===MY?'triangle':'sawtooth',.05)}
  else if(n===42){over=3;beep(330,.3,'sine',.04)}
  t=-side;refresh();return true}
 function human(c){if(gone||over||t!==MY)return;cur_c=c;if(b[c]){draw();return}if(place(c,MY))net.send({k:'mv',c})}
 const inp=input(st,[],k=>{if(gone||over||t!==MY)return;
  if(k>='1'&&k<='7')human(+k-1);else if(k==='ArrowLeft'){cur_c=(cur_c+6)%7;draw()}else if(k==='ArrowRight'){cur_c=(cur_c+1)%7;draw()}else if(k===' '||k==='Enter'||k==='ArrowDown')human(cur_c)});
 const pack=()=>({k:'st',b,t,over,win,n});
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='mv'){const ok=typeof d.c==='number'&&place(d.c,-MY);botRes(from,ok,d)}
  else if(d.k==='st'&&!net.isHost){b=d.b;t=d.t;over=d.over;win=d.win;n=d.n;shown=0;refresh()}});
 function conn(){const o=net.players.find(p=>p.id!==net.me.id);const was=gone;if(o){opp=Object.assign({},o);gone=0;if(net.isHost&&was)net.sendTo(o.id,pack())}else gone=1;refresh()}
 const offP=net.onPlayers(conn);
 // ---------- bot (alleen op de host): winnen > blokkeren > geen winst weggeven > midden + dreigingen, met wat toeval ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]});let botT=0;
 const botId=()=>{const p=net.isHost&&net.players[1];return p&&p.bot?p.id:null};
 const botRes=(from,ok,d)=>{if(net.isHost&&net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}};
 const winsAt=(bb,c,p)=>{const x=bb.slice(),i=drop(x,c,p);return i>=0&&!!winLine(x,i)};
 function lines3(bb,p){let v=0;for(let i=0;i<42;i++){if(bb[i])continue;const r=(i/7)|0,c=i%7;for(const[dr,dc]of[[0,1],[1,0],[1,1],[1,-1]]){let k=1;for(const sg of[1,-1]){let R=r+dr*sg,C=c+dc*sg;while(R>=0&&R<6&&C>=0&&C<7&&bb[R*7+C]===p){k++;R+=dr*sg;C+=dc*sg}}if(k>=4)v++}}return v}
 function aiMove(p){const cols=[0,1,2,3,4,5,6].filter(c=>!b[c]);if(!cols.length)return-1;
  for(const c of cols)if(winsAt(b,c,p))return c;for(const c of cols)if(winsAt(b,c,-p))return c;
  const safe=cols.filter(c=>{const x=b.slice();drop(x,c,p);return!(x[c]===0&&winsAt(x,c,-p))});const pool=safe.length?safe:cols;
  if(Math.random()<.15)return pool[R(pool.length)];
  let best=-1e9,opt=[];for(const c of pool){const x=b.slice();drop(x,c,p);const v=(3-Math.abs(3-c))*2+lines3(x,p)*3-lines3(x,-p)*2+Math.random()*3;if(v>best){best=v;opt=[c]}}return opt[0]}
 function botTick(){clearTimeout(botT);botT=0;const id=botId();if(!id||gone||over||t!==-1)return;const k=n;
  botT=setTimeout(()=>{botT=0;if(gone||over||t!==-1||n!==k||botId()!==id)return;const c=aiMove(-1);if(c<0)return;BT.sent++;net.botAct(id,{k:'mv',c})},BT.fast?25+R(40):600+R(900))}
 window._c4={board:()=>b.slice(),state:()=>({over,t,n})};
 b=Array(42).fill(0);t=1;over=0;win=null;cur_c=3;n=0;conn();
 return()=>{clearTimeout(botT);inp.stop();off();offP();delete window._c4}}},
