{id:'battleship',n:'Zeeslag',e:'🚢',c:'Samen',g:'#1e3c72,#2a5298',min:2,max:2,bots:true,run(st,net){
 // Zeeslag voor 2 spelers. Iedere speler legt zijn vloot lokaal (verborgen!) en drukt op Klaar. Schoten gaan als bericht; het doelwit antwoordt raak/mis/gezonken. Host schiet eerst. Schepen in je eigen kleur, treffers met een ring in de kleur van de schutter, podium aan het einde.
 const N=10,FLEET=[[5,'vliegdekschip'],[4,'slagschip'],[3,'kruiser'],[3,'onderzeeër'],[2,'patrouilleboot']];
 const me=net.myIndex(),MY=me===0?1:-1;
 let opp=null;const P=s=>net.players[s===1?0:1]||(s===MY?net.me:opp),nm=s=>{const p=P(s);return p?net.pname(p):'…'},cl=s=>{const p=P(s);return p&&p.col||'#888'},pid=s=>{const p=P(s);return p?p.id:null};
 const hx=h=>[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0),tint=(h,a)=>'rgba('+hx(h).join(',')+','+a+')',mix=(a,b,f)=>{const A=hx(a),B=hx(b);return'rgb('+A.map((v,i)=>Math.round(v+(B[i]-v)*f)).join(',')+')'};
 const WATER='linear-gradient(160deg,#2f78d8,#1f58b0)',SHIP=()=>{const k=cl(MY);return'linear-gradient(160deg,'+mix(k,'#dfe5ee',.62)+','+mix(k,'#5e6878',.5)+')'},HIT='radial-gradient(circle,#ffd1c4 0 28%,#e0432a 38%)',SUNK='#5c1616',MISS='radial-gradient(circle,#eaf2ff 0 15%,transparent 18%),linear-gradient(160deg,#2f78d8,#1f58b0)';
 const sc=E('div','sc'),who=E('div','hint');who.style.cssText='min-height:26px;line-height:2;font-weight:600;color:var(--tx);margin:0 auto';
 const info=E('div');info.style.cssText='min-height:40px;font-weight:700;font-size:15px;line-height:1.4';
 const row=E('div');row.style.cssText='position:relative;display:flex;flex-wrap:wrap;justify-content:center;align-items:flex-start;gap:14px';
 function mkBoard(){const b=E('div','bdr');b.style.cssText+='grid-template-columns:repeat(10,1fr);width:100%;gap:2px;padding:4px;background:#0b2a5c;border-radius:10px;margin:4px 0 0;box-shadow:0 4px 14px rgba(0,0,0,.3)';const cells=[];
  for(let i=0;i<100;i++){const d=E('div');d.style.cssText='border-radius:3px;font-size:18px;line-height:1;transition:background .15s';cells.push(d);b.append(d)}return[b,cells]}
 const[ob,oc]=mkBoard(),[eb,ec]=mkBoard();
 const ow=E('div'),ew=E('div');ow.style.cssText='width:min(380px,100%)';ew.style.cssText='width:min(380px,100%)';
 const ol=E('div','hint','Jouw vloot'),el=E('div','hint');ol.style.margin=el.style.margin='0 auto';
 const ov=E('div','ov');ov.style.display='none';ov.style.zIndex='2';
 ow.append(ol,ob);ew.append(el,eb);row.append(ew,ow,ov);
 const bar=E('div');bar.style.cssText='display:flex;gap:10px;justify-content:center;margin:10px 0 4px;flex-wrap:wrap';
 const bShuf=E('button','btn','🔀 Schud'),bRot=E('button','btn sec','🔁 Draaien'),bReady=E('button','btn','✅ Klaar');bar.append(bShuf,bRot,bReady);
 const hint=E('div','hint');st.append(sc,who,info,row,bar,hint);
 // ---------- spelerchips ----------
 const dot=(s,sz)=>{const d=E('i');d.style.cssText='display:inline-block;width:'+sz+'px;height:'+sz+'px;border-radius:50%;flex:none;vertical-align:-1px;margin:0 2px;background:'+cl(s)+';box-shadow:0 0 0 1px rgba(0,0,0,.35)';return d};
 function chip(s,on){const k=cl(s),c=E('span');c.style.cssText='display:inline-flex;align-items:center;gap:5px;padding:1px 9px;border-radius:99px;border:1.5px solid '+k+';background:'+tint(k,.14)+';white-space:nowrap;vertical-align:middle;line-height:1.5;'+(on===1?'box-shadow:0 0 0 3px '+tint(k,.3)+';font-weight:800':on===-1?'opacity:.55':'');
  c.append(dot(s,11),document.createTextNode(nm(s)+(s===MY?' (jij)':'')));return c}
 function setWho(t,msg){who.replaceChildren();[1,-1].forEach((s,i)=>{if(i)who.append(document.createTextNode(' · '));who.append(chip(s,t?(t===s?1:-1):0))});if(msg)who.append(document.createTextNode(' · '+msg))}
 // ---------- vloot ----------
 function setCells(f,s){const id=f.ships.indexOf(s)+1;s.cells.forEach((i,j)=>{f.grid[i]=id;f.rad[i]=j===0?(s.dir?'45% 45% 3px 3px':'45% 3px 3px 45%'):j===s.len-1?(s.dir?'3px 3px 45% 45%':'3px 45% 45% 3px'):'3px'})}
 function fleet(){const f={grid:new Int8Array(100),shots:new Uint8Array(100),ships:[],rad:[]};
  for(const[len,name]of FLEET){for(;;){const dir=R(2),r=R(dir?N-len+1:N),c=R(dir?N:N-len+1),cells=[];for(let j=0;j<len;j++)cells.push(dir?(r+j)*N+c:r*N+c+j);
   if(cells.every(i=>!f.grid[i])){const s={len,name,dir,cells,hits:0,sunk:0};f.ships.push(s);setCells(f,s);break}}}
  return f}
 function relocate(f,s,anchor,dir){const r=(anchor/N)|0,c=anchor%N,id=f.ships.indexOf(s)+1;if(dir?r+s.len>N:c+s.len>N)return false;const cells=[];for(let j=0;j<s.len;j++)cells.push(dir?(r+j)*N+c:r*N+c+j);
  if(!cells.every(i=>!f.grid[i]||f.grid[i]===id))return false;s.cells.forEach(i=>{f.grid[i]=0});s.cells=cells;s.dir=dir;setCells(f,s);return true}
 function rotate(f,s){const r=(s.cells[0]/N)|0,c=s.cells[0]%N,dir=1-s.dir;
  for(let off=0;off<s.len;off++){const r0=dir?Math.min(Math.max(r-off,0),N-s.len):r,c0=dir?c:Math.min(Math.max(c-off,0),N-s.len);if(relocate(f,s,r0*N+c0,dir))return true}return false}
 function fire(f,i){const v=f.grid[i];if(!v){f.shots[i]=1;return{hit:0}}f.shots[i]=2;const s=f.ships[v-1];s.hits++;if(s.hits===s.len)s.sunk=1;return{hit:1,s,sunk:s.sunk}}
 // ---------- toestand ----------
 let my,en,enSunk,enHitsOnShips,shots,phase,turn,busy,sel,lastIn,lastOut,over,myReady,oppReady,gone=0,shown=0;
 function showOv(big,small){ov.replaceChildren();const x=E('div');x.textContent=big;const s=E('div');s.style.cssText='font-size:15px;font-weight:600';s.textContent=small||'';ov.append(x,s);ov.style.background=gone?'':'rgba(14,16,32,.55)';ov.style.display='flex'}
 function refresh(){if(gone)showOv(opp?'⚠️ '+nm(-MY)+' heeft het spel verlaten':'Wachten op speler…',net.isHost?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten');
  else if(phase==='wait'&&!over)showOv('⏳ Wachten tot '+nm(-MY)+' klaar is…','Je vloot ligt klaar');else ov.style.display='none';layout();draw();
  if(over&&!shown){shown=1;net.result({winner:pid(over),text:'De vloot van '+nm(-over)+' is gezonken · '+shots+' schoten'})}botTick()}
 const sunkN=f=>f.ships.filter(s=>s.sunk).length;
 function draw(){
  const ship=SHIP(),myRing='inset 0 0 0 2px '+tint(cl(MY),.9),opRing='inset 0 0 0 2px '+tint(cl(-MY),.9);
  for(let i=0;i<100;i++){const v=my.grid[i],s=my.shots[i],d=oc[i];
   d.style.background=s===2?(my.ships[v-1].sunk?SUNK:HIT):s===1?MISS:v?ship:WATER;d.style.borderRadius=v?my.rad[i]:'3px';d.style.boxShadow=i===lastIn?'0 0 0 2px #ffd54a,'+opRing:sel&&my.grid[i]===my.ships.indexOf(sel)+1?'inset 0 0 0 3px #ffd54a':s===2?opRing:'none';d.style.cursor=phase==='setup'?'pointer':'default';
   const s2=en[i],e=ec[i],sk=s2===3;
   e.style.background=sk?SUNK:s2===2?HIT:s2===1?MISS:WATER;e.style.borderRadius=sk?enSunk[i]||'3px':'3px';e.textContent=s2>=2?'💥':'';e.style.boxShadow=i===lastOut?'0 0 0 2px #ffd54a,'+myRing:s2>=2?myRing:'none';e.style.cursor=phase==='play'&&turn===MY&&!busy&&!s2?'crosshair':'default'}
  sc.replaceChildren(document.createTextNode('🚢 '),dot(MY,12),document.createTextNode(' '+nm(MY)+' (jij) '+(5-sunkN(my))+' – '+(5-enHitsOnShips)+' '+nm(-MY)+' '),dot(-MY,12),document.createTextNode(' · schoten: '+shots+(over?over===MY?' · 🎉 jij wint!':' · 💀 '+nm(-MY)+' wint':'')));
  setWho(phase==='play'&&!over?turn:0,phase==='setup'?'leg je vloot klaar en druk op Klaar':phase==='wait'?'wachten op '+nm(-MY)+'…':over?'spel voorbij':turn===MY?(busy?'schot onderweg…':'jij bent aan de beurt · vuur!'):nm(-MY)+' richt…')}
 function layout(){const s=phase==='setup';ew.style.display=s?'none':'';info.style.minHeight=s?'0':'40px';bar.style.display=s?'flex':'none';ow.style.width=s?'min(380px,100%)':'min(190px,100%)';
  ol.replaceChildren(dot(MY,10),document.createTextNode(' '+nm(MY)+' · jouw vloot'+(s?' · tik op een schip, dan op een vak om het te verplaatsen':'')));el.replaceChildren(dot(-MY,10),document.createTextNode(' Wateren van '+nm(-MY)+(phase==='play'&&turn===MY?' · tik om te vuren':'')));
  hint.textContent=s?'Tik op een schip en dan op een leeg vak om het te verplaatsen · 🔁 of nogmaals tikken draait het · 🔀 Schud legt alles opnieuw · ✅ Klaar als je tevreden bent':'Om de beurt één schot · 💥 raak · • mis · gezonken schepen worden donkerrood'}
 function tapOwn(i){if(phase!=='setup'||gone)return;const v=my.grid[i];
  if(v){const s=my.ships[v-1];if(sel===s){if(rotate(my,s))beep(500,.05,'triangle',.03);else beep(200,.08,'square',.03)}else{sel=s;beep(420,.04,'triangle',.03)}}
  else if(sel){if(relocate(my,sel,i,sel.dir))beep(460,.05,'triangle',.03);else{beep(200,.08,'square',.03);info.textContent='Daar past het schip niet.'}}
  draw()}
 function tapEnemy(i){if(phase!=='play'||gone||over||turn!==MY||busy||en[i])return;busy=1;lastOut=i;shots++;send({k:'shot',i});beep(360,.05,'square',.03);draw()}
 function ready(){if(phase!=='setup'||gone)return;myReady=1;sel=null;send({k:'ready'});beep(440,.08,'triangle',.04);startIfBoth()}
 function startIfBoth(){if(myReady&&oppReady){phase='play';turn=1;info.textContent=turn===MY?'Jij schiet eerst 🎯':nm(-MY)+' schiet eerst';refresh()}else if(myReady){phase='wait';refresh()}}
 function onShot(i){if(phase!=='play'||over||turn!==MY*-1||typeof i!=='number'||i<0||i>99||my.shots[i])return;const r=fire(my,i);lastIn=i;
  const all=my.ships.every(s=>s.sunk);const res={k:'res',i,hit:r.hit,sunk:r.sunk?{cells:r.s.cells,rad:r.s.cells.map(c=>my.rad[c]),name:r.s.name}:null,over:all?1:0};
  if(r.hit){beep(240,.1,'square',.04);info.textContent=r.sunk?'😱 '+nm(-MY)+' heeft je '+r.s.name+' tot zinken gebracht!':'💢 '+nm(-MY)+' raakt je '+r.s.name+'!'}else{beep(300,.06,'sine',.03);info.textContent=nm(-MY)+' mist 🌊'}
  send(res);if(all){over=-MY;beep(140,.4,'sawtooth',.05)}else turn=MY;refresh();return true}
 function onRes(d){if(phase!=='play'||over||!busy||d.i!==lastOut)return;busy=0;en[d.i]=d.hit?2:1;
  if(d.hit){enHitsOnShips+=d.sunk?1:0;if(d.sunk&&Array.isArray(d.sunk.cells)){d.sunk.cells.forEach((c,j)=>{if(c>=0&&c<100){en[c]=3;enSunk[c]=String(d.sunk.rad&&d.sunk.rad[j]||'3px')}});info.textContent='💥 Je hebt de '+String(d.sunk.name).slice(0,20)+' van '+nm(-MY)+' tot zinken gebracht!';beep(180,.35,'sawtooth',.05)}else{info.textContent='🎯 Geraakt!';beep(720,.08,'square',.05)}}
  else{info.textContent='🌊 Mis';beep(300,.06,'sine',.03)}
  if(d.over){over=MY;beep(880,.4,'triangle',.05)}else turn=-MY;refresh();return true}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='ready'){const ok=!oppReady&&phase!=='play';oppReady=1;botRes(from,ok,d);if(myReady)startIfBoth();else{info.textContent=nm(-MY)+' is klaar en wacht op jou';draw()}}
  else if(d.k==='shot')botRes(from,onShot(d.i),d);else if(d.k==='res')botRes(from,onRes(d),d)});
 function conn(){const o=net.players.find(p=>p.id!==net.me.id);if(o){opp=Object.assign({},o);gone=0}else gone=1;refresh()}
 const offP=net.onPlayers(conn);
 oc.forEach((d,i)=>d.onpointerdown=e=>{e.preventDefault();tapOwn(i)});ec.forEach((d,i)=>d.onpointerdown=e=>{e.preventDefault();tapEnemy(i)});
 bShuf.onclick=()=>{if(phase!=='setup')return;my=fleet();sel=null;info.textContent='';beep(380,.05,'triangle',.03);draw()};
 bRot.onclick=()=>{if(phase!=='setup'||!sel)return;if(rotate(my,sel))beep(500,.05,'triangle',.03);else beep(200,.08,'square',.03);draw()};
 bReady.onclick=ready;
 const inp=input(st,[],k=>{if(k==='Enter'&&phase==='setup')ready()});
 // ---------- bot (alleen op de host): eigen willekeurige vloot, beantwoordt schoten zelf; schiet met jagen (dambordpatroon) / doelen (rond treffers, langs de lijn) ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]});let botT=0,bf=null,bk=null,bPend=0;
 const botId=()=>{const p=net.isHost&&net.players[1];return p&&p.bot?p.id:null};
 const botRes=(from,ok,d)=>{if(net.isHost&&net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}};
 const bTm=new Set,bAct=(id,d,ms)=>{const tk=setTimeout(()=>{bTm.delete(tk);if(botId()!==id)return;BT.sent++;net.botAct(id,d)},ms);bTm.add(tk)};
 const bDelay=(a,b)=>BT.fast?20+R(40):a+R(b-a);
 function send(d){net.send(d);const id=botId();if(!id)return;
  if(d.k==='shot'){const i=d.i;   const tk=setTimeout(()=>{bTm.delete(tk);if(botId()!==id||!bf||bf.shots[i])return;const r=fire(bf,i),all=bf.ships.every(s=>s.sunk);BT.sent++;
    net.botAct(id,{k:'res',i,hit:r.hit,sunk:r.sunk?{cells:r.s.cells,rad:r.s.cells.map(c=>bf.rad[c]),name:r.s.name}:null,over:all?1:0})},bDelay(300,700));bTm.add(tk)}
  else if(d.k==='res'&&bk){bk[d.i]=d.hit?2:1;if(d.sunk)d.sunk.cells.forEach(c=>bk[c]=3)}}
 function aiShot(){const nb=i=>{const r=(i/N)|0,c=i%N,o=[];if(r>0)o.push(i-N);if(r<N-1)o.push(i+N);if(c>0)o.push(i-1);if(c<N-1)o.push(i+1);return o};
  const hits=[];for(let i=0;i<100;i++)if(bk[i]===2)hits.push(i);
  if(hits.length){let line=[];for(const h of hits){const r=(h/N)|0,c=h%N;for(const[dr,dc]of[[0,1],[1,0]]){if(!hits.includes(h+dr*N+dc)||(dc&&c===N-1))continue;
     for(const sg of[1,-1]){let R_=r,C=c;while(R_>=0&&R_<N&&C>=0&&C<N&&bk[R_*N+C]===2){R_+=dr*sg;C+=dc*sg}if(R_>=0&&R_<N&&C>=0&&C<N&&!bk[R_*N+C])line.push(R_*N+C)}}}
   if(line.length)return line[R(line.length)];const around=[...new Set(hits.flatMap(nb))].filter(i=>!bk[i]);if(around.length)return around[R(around.length)]}
  const par=[],any=[];for(let i=0;i<100;i++)if(!bk[i]){any.push(i);if((((i/N)|0)+i%N)%2===0)par.push(i)}const pool=par.length?par:any;return pool.length?pool[R(pool.length)]:-1}
 function botTick(){const id=botId();if(!id)return;
  if(!bf){bf=fleet();bk=new Uint8Array(100);bAct(id,{k:'ready'},bDelay(400,900))}
  clearTimeout(botT);botT=0;if(gone||over||phase!=='play'||turn!==-MY)return;const k=shots+'|'+lastIn;
  botT=setTimeout(()=>{botT=0;if(gone||over||phase!=='play'||turn!==-MY||shots+'|'+lastIn!==k||botId()!==id)return;const i=aiShot();if(i<0)return;BT.sent++;net.botAct(id,{k:'shot',i})},bDelay(600,1500))}
 window._bsBot={fleet:()=>bf&&[...bf.grid],know:()=>bk&&[...bk]};
 my=fleet();en=new Uint8Array(100);enSunk={};enHitsOnShips=0;shots=0;phase='setup';turn=1;busy=0;sel=null;lastIn=-1;lastOut=-1;over=0;myReady=0;oppReady=0;info.textContent='';conn();
 window._bs={state:()=>({phase,turn,busy,over,shots,shipsLeft:5-sunkN(my),enemySunk:enHitsOnShips}),grid:()=>[...my.grid],en:()=>[...en]};
 return()=>{clearTimeout(botT);bTm.forEach(clearTimeout);inp.stop();off();offP();delete window._bs;delete window._bsBot}}},
