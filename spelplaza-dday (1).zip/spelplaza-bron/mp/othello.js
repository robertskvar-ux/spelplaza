{id:'othello',n:'Othello',e:'⚪',c:'Samen',g:'#134e5e,#71b280',min:2,max:2,bots:true,run(st,net){
 // Othello / Reversi 8×8 voor 2 spelers: host = zwart (begint), joiner = wit. Stippen tonen je legale zetten; wie niet kan zetten, past automatisch. Spelerchips (avatar + kleur) in de statusregel, podium met eindstand.
 const me=net.myIndex(),MY=me===0?1:-1,SYM=s=>s===1?'⚫':'⚪';
 let opp=null;const P=s=>net.players[s===1?0:1]||(s===MY?net.me:opp),nm=s=>{const p=P(s);return p?net.pname(p):'…'},cl=s=>{const p=P(s);return p&&p.col||'#888'},pid=s=>{const p=P(s);return p?p.id:null};
 const tint=(h,a)=>{const v=[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0);return'rgba('+v.join(',')+','+a+')'};
 const sc=E('div','sc'),who=E('div','hint');who.style.cssText='min-height:26px;line-height:2;font-weight:600;color:var(--tx);margin:0 auto';
 const info=E('div','hint');info.style.cssText='min-height:18px;margin:2px auto';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(380px,100%);margin:4px auto';
 const bd=E('div','bdr');bd.style.cssText+='grid-template-columns:repeat(8,1fr);width:100%;gap:3px;padding:5px;background:#0f5a33;border-radius:10px;box-shadow:0 4px 14px rgba(0,0,0,.35);margin:0';
 const ov=E('div','ov');ov.style.display='none';wrap.append(bd,ov);
 const hint=E('div','hint','Tik op een stip om een schijf te leggen · wie de meeste schijven heeft, wint');
 st.append(sc,who,info,wrap,hint);
 const sq=[],disc=[],dot=[];
 for(let i=0;i<64;i++){const d=E('div');d.style.cssText='background:#2a9d5c;border-radius:4px;position:relative';
  const p=E('span');p.style.cssText='display:none;width:84%;height:84%;border-radius:50%;box-shadow:0 2px 4px rgba(0,0,0,.5);transition:transform .45s ease,background .4s;pointer-events:none;will-change:transform';
  const o=E('span');o.style.cssText='display:none;width:26%;height:26%;border-radius:50%;background:rgba(0,0,0,.35);pointer-events:none';
  d.append(p,o);disc.push(p);dot.push(o);d.onpointerdown=e=>{e.preventDefault();tap(i)};sq.push(d);bd.append(d)}
 // ---------- spelerchips ----------
 function chip(s,on){const k=cl(s),c=E('span');c.style.cssText='display:inline-flex;align-items:center;gap:5px;padding:1px 9px;border-radius:99px;border:1.5px solid '+k+';background:'+tint(k,.14)+';white-space:nowrap;vertical-align:middle;line-height:1.5;'+(on===1?'box-shadow:0 0 0 3px '+tint(k,.3)+';font-weight:800':on===-1?'opacity:.55':'');
  c.append(document.createTextNode(SYM(s)+' '+nm(s)+(s===MY?' (jij)':'')));return c}
 function setWho(t,msg){who.replaceChildren();[1,-1].forEach((s,i)=>{if(i)who.append(document.createTextNode(' · '));who.append(chip(s,t?(t===s?1:-1):0));if(t===s&&!msg)who.append(document.createTextNode(s===MY?' bent aan zet':' is aan zet'))});if(msg)who.append(document.createTextNode(' · '+msg))}
 // ---------- regels ----------
 const DIRS=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,1],[1,0]];
 function flips(b,i,p){if(b[i])return[];const r=i>>3,c=i&7,out=[];
  for(const[dr,dc]of DIRS){let R=r+dr,C=c+dc,n=0;while(R>=0&&R<8&&C>=0&&C<8&&b[R*8+C]===-p){R+=dr;C+=dc;n++}
   if(n&&R>=0&&R<8&&C>=0&&C<8&&b[R*8+C]===p){R-=dr;C-=dc;while(n--){out.push(R*8+C);R-=dr;C-=dc}}}
  return out}
 function legal(b,p){const m=[];for(let i=0;i<64;i++)if(!b[i]&&flips(b,i,p).length)m.push(i);return m}
 function play(b,i,p){const nb=b.slice(),f=flips(b,i,p);nb[i]=p;for(const j of f)nb[j]=p;return nb}
 // ---------- toestand ----------
 let b,t,over,lastI,flipN,gone=0,shown=0;
 const cnt=p=>b.reduce((n,v)=>n+(v===p),0);
 function showOv(big,small){ov.replaceChildren();const x=E('div');x.textContent=big;const s=E('div');s.style.cssText='font-size:15px;font-weight:600';s.textContent=small||'';ov.append(x,s);ov.style.textShadow='0 1px 4px #000';ov.style.display='flex'}
 function refresh(){if(gone)showOv(opp?'⚠️ '+nm(-MY)+' heeft het spel verlaten':'Wachten op speler…',net.isHost?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten');else ov.style.display='none';draw();
  if(over&&!shown){shown=1;net.result({winner:over===3?null:pid(over),text:cnt(1)+' – '+cnt(-1)+' schijven'})}botTick()}
 function draw(){const lg=t===MY&&!over&&!gone?legal(b,MY):[];
  for(let i=0;i<64;i++){const v=b[i],p=disc[i];sq[i].style.boxShadow=i===lastI?'inset 0 0 0 3px #ffd54a':'none';
   if(!v){p.style.display='none';p.dataset.v='';dot[i].style.display=lg.includes(i)?'block':'none';continue}
   dot[i].style.display='none';
   const was=p.dataset.v;p.dataset.v=v;const bg=v===1?'radial-gradient(circle at 35% 35%,#555,#1a1a1a 60%,#000)':'radial-gradient(circle at 35% 35%,#fff,#e4e4e4 60%,#a8a8a8)';
   if(!was){p.style.display='block';p.style.transition='none';p.style.transform='scale(0)';p.style.background=bg;void p.offsetWidth;p.style.transition='transform .3s ease,background .4s';p.style.transform='scale(1)'}
   else if(+was!==v){flipN[i]=(flipN[i]||0)+1;p.style.transform='rotateY('+flipN[i]*180+'deg)';p.style.background=bg}}
  sc.textContent='⚫ '+nm(1)+(MY===1?' (jij)':'')+' '+cnt(1)+' – '+cnt(-1)+' '+nm(-1)+(MY===-1?' (jij)':'')+' ⚪'+(over?over===3?' · 🤝 gelijkspel':over===MY?' · 🎉 jij wint!':' · 🏆 '+nm(over)+' wint!':'');
  setWho(over?0:t,over?'spel voorbij':'')}
 function move(i,side){if(over||t!==side||typeof i!=='number'||b[i]||!flips(b,i,side).length)return false;b=play(b,i,side);lastI=i;beep(side===1?520:400,.05,'square',.03);t=-side;next();return true}
 function next(){const my=legal(b,t).length,th=legal(b,-t).length;info.textContent='';
  if(!my&&!th){const B=cnt(1),W=cnt(-1);over=B>W?1:W>B?-1:3;beep(over===MY?880:over===3?330:160,.35,over===MY?'triangle':'sawtooth',.05);info.textContent='Eindstand '+B+' – '+W;refresh();return}
  if(!my){info.textContent=(t===MY?'Je kunt niet zetten en moet passen.':nm(t)+' kan niet zetten en past.');t=-t;beep(240,.12,'sine',.03)}
  refresh()}
 function tap(i){if(gone||over||t!==MY)return;if(move(i,MY))net.send({k:'mv',i})}
 const pack=()=>({k:'st',b,t,over,lastI});
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='mv'){const ok=move(d.i,-MY);botRes(from,ok,d)}
  else if(d.k==='st'&&!net.isHost){b=d.b;t=d.t;over=d.over;lastI=d.lastI;shown=0;refresh()}});
 function conn(){const o=net.players.find(p=>p.id!==net.me.id);const was=gone;if(o){opp=Object.assign({},o);gone=0;if(net.isHost&&was)net.sendTo(o.id,pack())}else gone=1;refresh()}
 const offP=net.onPlayers(conn);
 // ---------- bot (alleen op de host): positietabel (hoeken!) + mobiliteit, 1 zet diep met toeval ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]});let botT=0;
 const botId=()=>{const p=net.isHost&&net.players[1];return p&&p.bot?p.id:null};
 const botRes=(from,ok,d)=>{if(net.isHost&&net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}};
 const WT=[100,-20,10,5,5,10,-20,100,-20,-40,-2,-2,-2,-2,-40,-20,10,-2,1,1,1,1,-2,10,5,-2,1,0,0,1,-2,5,5,-2,1,0,0,1,-2,5,10,-2,1,1,1,1,-2,10,-20,-40,-2,-2,-2,-2,-40,-20,100,-20,10,5,5,10,-20,100];
 function aiMove(p){const ms=legal(b,p);if(!ms.length)return-1;let best=-1e9,bi=ms[0];
  for(const i of ms){const nb=play(b,i,p);let v=WT[i]+flips(b,i,p).length*.5-legal(nb,-p).length*2;if(legal(nb,-p).some(j=>WT[j]===100))v-=30;v+=Math.random()*14;if(v>best){best=v;bi=i}}return bi}
 function botTick(){clearTimeout(botT);botT=0;const id=botId();if(!id||gone||over||t!==-1)return;const k=b.join('');
  botT=setTimeout(()=>{botT=0;if(gone||over||t!==-1||b.join('')!==k||botId()!==id)return;const i=aiMove(-1);if(i<0)return;BT.sent++;net.botAct(id,{k:'mv',i})},BT.fast?25+R(40):600+R(900))}
 b=Array(64).fill(0);b[27]=-1;b[36]=-1;b[28]=1;b[35]=1;t=1;over=0;lastI=-1;flipN={};conn();
 window._oth={board:()=>b.slice(),legal:()=>legal(b,t),state:()=>({over,turn:t})};
 return()=>{clearTimeout(botT);off();offP();delete window._oth}}},
