{id:'dots',n:'Kamertje verhuren',e:'✏️',c:'Samen',g:'#7f00ff,#e100ff',min:2,max:2,bots:true,run(st,net){
 // Kamertje verhuren (dots & boxes) voor 2 spelers: host begint en kiest vóór de eerste zet 4×4 / 5×5 / 6×6. Lijnen, hokjes en initialen in de eigen spelerskleur. Hokje dicht = nog een beurt. Podium met de hokjesstand aan het einde.
 const NS='http://www.w3.org/2000/svg',SV=(t,a)=>{const e=document.createElementNS(NS,t);for(const k in a)e.setAttribute(k,a[k]);return e};
 const me=net.myIndex(),MY=me===0?1:2,OP=3-MY;
 let opp=null;const P=s=>net.players[s-1]||(s===MY?net.me:opp),nm=s=>{const p=P(s);return p?net.pname(p):'…'},cl=s=>{const p=P(s);return p&&p.col||(s===1?'#8f3dff':'#ff9100')},pid=s=>{const p=P(s);return p?p.id:null};
 const tint=(h,a)=>{const v=[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0);return'rgba('+v.join(',')+','+a+')'};
 const COL=s=>cl(s),TINT=s=>tint(cl(s),.22);
 const ini=s=>{const p=P(s);return(p&&p.name||'').trim().charAt(0).toUpperCase()||'?'},mark=s=>{const a=ini(1),b=ini(2);if(a!==b)return ini(s);const p1=P(1),p2=P(2),x=p1&&p1.av,y=p2&&p2.av;if(x&&y&&x!==y)return P(s).av;return s===1?'①':'②'};
 const sc=E('div','sc'),who=E('div','hint');who.style.cssText='min-height:26px;line-height:2;font-weight:600;color:var(--tx);margin:0 auto 4px';
 const sizes=E('div');sizes.style.cssText='display:flex;gap:6px;justify-content:center;align-items:center;margin:2px 0 8px;flex-wrap:wrap';
 const szl=E('span','hint','Bordgrootte:');szl.style.margin='0';sizes.append(szl);
 const sbtn=[4,5,6].map(k=>{const b=E('button','btn',k+'×'+k);b.style.cssText='padding:6px 12px;font-size:13px';b.onclick=()=>{if(!net.isHost||moved||gone||over)return;n=k;build();init();net.send({k:'size',n});beep(500,.05,'triangle',.03)};sizes.append(b);return b});
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(380px,100%);margin:0 auto';
 const svg=SV('svg',{});svg.style.cssText='width:100%;height:auto;display:block;background:var(--bg);border-radius:14px;touch-action:manipulation;user-select:none;-webkit-user-select:none';
 const ov=E('div','ov');ov.style.display='none';wrap.append(svg,ov);
 const hint=E('div','hint','Tik tussen twee stippen om een lijn te trekken · wie een hokje sluit, krijgt het en mag nog eens · de meeste hokjes winnen');
 st.append(sc,who,sizes,wrap,hint);
 // ---------- spelerchips ----------
 const dot=(s,sz)=>{const d=E('i');d.style.cssText='display:inline-block;width:'+sz+'px;height:'+sz+'px;border-radius:50%;flex:none;vertical-align:-1px;margin:0 2px;background:'+cl(s)+';box-shadow:0 0 0 1px rgba(0,0,0,.25)';return d};
 function chip(s,on){const k=cl(s),c=E('span');c.style.cssText='display:inline-flex;align-items:center;gap:5px;padding:1px 9px;border-radius:99px;border:1.5px solid '+k+';background:'+tint(k,.14)+';white-space:nowrap;vertical-align:middle;line-height:1.5;'+(on===1?'box-shadow:0 0 0 3px '+tint(k,.3)+';font-weight:800':on===-1?'opacity:.55':'');
  c.append(dot(s,11),document.createTextNode(nm(s)+(s===MY?' (jij)':'')));return c}
 function setWho(t,msg){who.replaceChildren();[1,2].forEach((s,i)=>{if(i)who.append(document.createTextNode(' · '));who.append(chip(s,t?(t===s?1:-1):0));if(t===s)who.append(document.createTextNode(s===MY?' bent aan zet':' is aan zet'))});if(msg)who.append(document.createTextNode(' · '+msg))}
 // ---------- bord ----------
 let n=5,NE,NB,H,lines=[],hits=[],boxes=[],letters=[],halo,E_,B_,turn,over,moved,lastE=-1,gone=0,shown=0;
 const hIdx=(r,c)=>r*(n-1)+c,vIdx=(r,c)=>H+r*n+c,bIdx=(r,c)=>r*(n-1)+c;
 const boxEdges=b=>{const r=(b/(n-1))|0,c=b%(n-1);return[hIdx(r,c),hIdx(r+1,c),vIdx(r,c),vIdx(r,c+1)]};
 function edgeBoxes(e){const out=[];if(e<H){const r=(e/(n-1))|0,c=e%(n-1);if(r>0)out.push(bIdx(r-1,c));if(r<n-1)out.push(bIdx(r,c))}else{const k=e-H,r=(k/n)|0,c=k%n;if(c>0)out.push(bIdx(r,c-1));if(c<n-1)out.push(bIdx(r,c))}return out}
 const sides=(E,b)=>boxEdges(b).reduce((s,e)=>s+(E[e]?1:0),0);
 function build(){H=n*(n-1);NE=2*H;NB=(n-1)*(n-1);const W=(n-1)*100+100;svg.setAttribute('viewBox','0 0 '+W+' '+W);svg.innerHTML='';lines=[];hits=[];boxes=[];letters=[];
  const P=(r,c)=>[50+c*100,50+r*100];
  for(let b=0;b<NB;b++){const r=(b/(n-1))|0,c=b%(n-1),[x,y]=P(r,c);const rc=SV('rect',{x:x+7,y:y+7,width:86,height:86,rx:10,fill:'transparent'});const t=SV('text',{x:x+50,y:y+66,'text-anchor':'middle','font-size':'46','font-weight':'800','font-family':'system-ui,Arial,sans-serif'});svg.append(rc,t);boxes.push(rc);letters.push(t)}
  halo=SV('line',{stroke:'rgba(255,213,74,.55)','stroke-width':'24','stroke-linecap':'round',visibility:'hidden'});svg.append(halo);
  for(let e=0;e<NE;e++){let x1,y1,x2,y2;if(e<H){const r=(e/(n-1))|0,c=e%(n-1);[x1,y1]=P(r,c);[x2,y2]=P(r,c+1)}else{const k=e-H,r=(k/n)|0,c=k%n;[x1,y1]=P(r,c);[x2,y2]=P(r+1,c)}
   const l=SV('line',{x1,y1,x2,y2,'stroke-width':'10','stroke-linecap':'round','pointer-events':'none'});lines.push(l);svg.append(l)}
  for(let e=0;e<NE;e++){const l=lines[e],x1=+l.getAttribute('x1'),y1=+l.getAttribute('y1'),hz=e<H;
   const h=SV('rect',hz?{x:x1+10,y:y1-24,width:80,height:48}:{x:x1-24,y:y1+10,width:48,height:80});h.setAttribute('fill','transparent');h.style.cursor='pointer';
   h.onpointerenter=()=>{if(!E_[e]&&turn===MY&&!over&&!gone){l.setAttribute('stroke',COL(MY));l.setAttribute('stroke-opacity','.45')}};h.onpointerleave=()=>{if(!E_[e])paintEdge(e)};
   h.onpointerdown=ev=>{ev.preventDefault();human(e)};hits.push(h);svg.append(h)}
  for(let r=0;r<n;r++)for(let c=0;c<n;c++){const[x,y]=P(r,c);svg.append(SV('circle',{cx:x,cy:y,r:9,fill:'var(--tx)','pointer-events':'none'}))}
  sbtn.forEach((b,i)=>b.style.opacity=[4,5,6][i]===n?'1':'.5')}
 function paintEdge(e){const l=lines[e],o=E_[e];l.setAttribute('stroke',o?COL(o):'var(--mu)');l.setAttribute('stroke-opacity',o?'1':'.22');l.setAttribute('stroke-width',o?(e===lastE?'13':'10'):'8');l.setAttribute('stroke-dasharray',o?'':'1 16')}
 function showOv(big,small){ov.replaceChildren();const x=E('div');x.textContent=big;const s=E('div');s.style.cssText='font-size:15px;font-weight:600';s.textContent=small||'';ov.append(x,s);ov.style.textShadow='0 1px 4px #000';ov.style.display='flex'}
 const score=p=>B_.reduce((s,v)=>s+(v===p),0);
 function refresh(){if(gone)showOv(opp?'⚠️ '+nm(OP)+' heeft het spel verlaten':'Wachten op speler…',net.isHost?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten');else ov.style.display='none';
  sizes.style.display=net.isHost&&!moved&&!over?'flex':'none';draw();
  if(over&&!shown){shown=1;net.result({winner:over===3?null:pid(over),text:score(1)+' – '+score(2)+' hokjes'})}botTick()}
 function draw(){for(let e=0;e<NE;e++)paintEdge(e);
  for(let b=0;b<NB;b++){const o=B_[b];boxes[b].setAttribute('fill',o?TINT(o):'transparent');letters[b].textContent=o?mark(o):'';letters[b].setAttribute('fill',o?COL(o):'')}
  if(lastE>=0){const l=lines[lastE];['x1','y1','x2','y2'].forEach(k=>halo.setAttribute(k,l.getAttribute(k)));halo.setAttribute('visibility','visible')}else halo.setAttribute('visibility','hidden');
  sc.replaceChildren(dot(1,12),document.createTextNode(' '+nm(1)+(MY===1?' (jij)':'')+' '+score(1)+' – '+score(2)+' '+nm(2)+(MY===2?' (jij)':'')+' '),dot(2,12),document.createTextNode(' · '+n+'×'+n+(over?over===3?' · 🤝 gelijkspel':over===MY?' · 🎉 jij wint!':' · 🏆 '+nm(over)+' wint!':'')));
  setWho(over?0:turn,over?'spel voorbij':'')}
 // ---------- regels ----------
 function play(e,p){if(over||turn!==p||typeof e!=='number'||e<0||e>=NE||E_[e])return false;E_[e]=p;lastE=e;moved=1;let got=0;for(const b of edgeBoxes(e))if(!B_[b]&&sides(E_,b)===4){B_[b]=p;got++}
  if(got)beep(p===MY?760:520,.1,'triangle',.05);else beep(p===MY?440:360,.04,'square',.03);
  if(B_.every(Boolean)){const a=score(1),b=NB-a;over=a>b?1:b>a?2:3;beep(over===MY?880:over===3?330:160,.4,over===MY?'triangle':'sawtooth',.05)}
  else if(!got)turn=3-p;refresh();return true}
 function human(e){if(gone||over||turn!==MY||E_[e])return;if(play(e,MY))net.send({k:'mv',e})}
 function init(){E_=new Uint8Array(NE);B_=new Uint8Array(NB);turn=1;over=0;moved=0;lastE=-1;shown=0;refresh()}
 const pack=()=>({k:'st',n,E:[...E_],B:[...B_],turn,over,moved,lastE});
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='mv'){const ok=play(d.e,OP);botRes(from,ok,d)}
  else if(d.k==='size'&&!net.isHost){if([4,5,6].includes(d.n)&&!moved){n=d.n;build();init()}}
  else if(d.k==='st'&&!net.isHost){if([4,5,6].includes(d.n)){if(d.n!==n){n=d.n;build()}E_=Uint8Array.from(d.E);B_=Uint8Array.from(d.B);turn=d.turn;over=d.over;moved=d.moved;lastE=d.lastE;shown=0;refresh()}}});
 function conn(){const o=net.players.find(p=>p.id!==net.me.id);const was=gone;if(o){opp=Object.assign({},o);gone=0;if(net.isHost&&was)net.sendTo(o.id,pack())}else gone=1;refresh()}
 const offP=net.onPlayers(conn);
 // ---------- bot (alleen op de host): hokje dichtmaken > veilige lijn (geen 3e zijde) > zo weinig mogelijk weggeven ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]});let botT=0;
 const botId=()=>{const p=net.isHost&&net.players[1];return p&&p.bot?p.id:null};
 const botRes=(from,ok,d)=>{if(net.isHost&&net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}};
 function aiMove(){const free=[];for(let e=0;e<NE;e++)if(!E_[e])free.push(e);if(!free.length)return-1;
  const take=free.filter(e=>edgeBoxes(e).some(b=>!B_[b]&&sides(E_,b)===3));if(take.length&&Math.random()<.95)return take[R(take.length)];
  const give=e=>edgeBoxes(e).filter(b=>!B_[b]&&sides(E_,b)===2).length;const safe=free.filter(e=>!give(e));if(safe.length)return safe[R(safe.length)];
  // geen veilige lijn: tel hoeveel hokjes de tegenstander daarna in een keten kan pakken en kies de kleinste
  const chain=e=>{const x=Uint8Array.from(E_);x[e]=9;let n=0,go=1;while(go){go=0;for(let b=0;b<NB;b++){if(B_[b]||x.length&&boxEdges(b).every(k=>x[k]))continue;const miss=boxEdges(b).filter(k=>!x[k]);if(miss.length===1){x[miss[0]]=9;n++;go=1}}}return n};
  let best=1e9,opt=[];for(const e of free){const c=chain(e);if(c<best){best=c;opt=[e]}else if(c===best)opt.push(e)}return opt[R(opt.length)]}
 function botTick(){clearTimeout(botT);botT=0;const id=botId();if(!id||gone||over||turn!==2)return;const k=E_.join('');
  botT=setTimeout(()=>{botT=0;if(gone||over||turn!==2||E_.join('')!==k||botId()!==id)return;const e=aiMove();if(e<0)return;BT.sent++;net.botAct(id,{k:'mv',e})},BT.fast?25+R(40):600+R(900))}
 build();init();conn();
 window._dots={state:()=>({n,turn,over,moved,E:[...E_],B:[...B_]}),hit:e=>{const h=hits[e].getBoundingClientRect();return{x:h.x+h.width/2,y:h.y+h.height/2}},edgeBoxes,sides:b=>sides(E_,b)};
 return()=>{clearTimeout(botT);off();offP();delete window._dots}}},
