{id:'bluf',n:'Bluffpoker',e:'🎲',c:'Samen',g:'#8e2de2,#4a00e0',min:2,max:6,bots:true,run(st,net){
 // tekstkleur op een effen spelerskleur: zwart of wit, wat het meeste contrast geeft (altijd ≥ 4.5:1)
 const inkOn=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(String(h||'').trim());if(!m)return'#fff';const n=parseInt(m[1],16),L=[n>>16,n>>8&255,n&255].map(v=>{v/=255;return v<=.03928?v/12.92:((v+.055)/1.055)**2.4}),l=.2126*L[0]+.7152*L[1]+.0722*L[2];return (l+.05)/.05>1.05/(l+.05)?'#000':'#fff'};
 // Bluffpoker / Perudo (host-authoritatief). De host gooit met echte willekeur (niet de gedeelde seed) en stuurt elke speler alleen zijn eigen stenen (sendTo).
 const isH=net.isHost,me=net.me.id,TURN=30000,PIPS=[[],[4],[2,6],[2,4,6],[0,2,6,8],[0,2,4,6,8],[0,2,3,5,6,8]];
 const pinfo=id=>net.players.find(x=>x.id===id),pn=(id,n)=>{const q=pinfo(id);return q?net.pname(q):(n||'?')},pcol=id=>{const q=pinfo(id);return q&&q.col||'var(--mu)'};
 const tot=S=>S.pl.reduce((a,p)=>a+p.c,0),act=S=>S.pl.filter(p=>p.c>0);
 // geldig bod? 1 = joker (Paco). Openen met enen mag niet. Naar enen: aantal ≥ helft (naar boven). Van enen af: aantal ≥ 2×+1.
 function legal(b,n,f,T){if(!(n>=1&&n<=T&&f>=1&&f<=6))return false;if(!b)return f!==1;
  if(b.f===1)return f===1?n>b.n:n>=b.n*2+1;return f===1?n>=Math.ceil(b.n/2):(n>b.n||(n===b.n&&f>b.f))}
 function minRaise(b,T){for(let n=1;n<=T;n++)for(let f=2;f<=6;f++)if(legal(b,n,f,T))return{n,f};for(let n=1;n<=T;n++)if(legal(b,n,1,T))return{n,f:1};return null}
 const count=(dice,f)=>Object.values(dice).flat().filter(v=>v===f||(f!==1&&v===1)).length;
 // ---- UI ----
 function die(v,sz){const d=E('div');d.style.cssText=`width:${sz}px;height:${sz}px;border-radius:${sz*.2}px;background:#fff;border:2px solid #d8d8e0;box-shadow:0 2px 6px rgba(0,0,0,.25);display:inline-grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(3,1fr);padding:${sz*.13}px;gap:1px;box-sizing:border-box;transition:transform .2s,opacity .2s,box-shadow .2s;flex:none`;
  for(let k=0;k<9;k++){const p=E('span');p.style.cssText='border-radius:50%;background:'+(v===1?'#e5383b':'#1b1d2a');p.style.visibility=(PIPS[v]||[]).includes(k)?'visible':'hidden';d.append(p)}return d}
 const sc=E('div','sc'),note=E('div','hint'),plist=E('div'),who=E('div'),mineW=E('div'),pick=E('div'),hist=E('div'),revW=E('div'),bNext=E('button','btn','Volgende ronde ▶');
 plist.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:6px 0 8px';who.style.cssText='font-weight:800;font-size:16px;min-height:24px;margin:4px 0';
 mineW.style.cssText='margin:6px auto 10px;padding:10px;border-radius:16px;background:var(--bg);max-width:400px';pick.style.cssText='display:none;max-width:400px;margin:0 auto 10px';
 hist.style.cssText='display:flex;gap:5px;flex-wrap:wrap;justify-content:center;margin:6px auto;max-width:420px;min-height:30px';revW.style.cssText='display:none;max-width:440px;margin:6px auto;text-align:left';bNext.style.cssText='display:none;margin:8px auto';
 st.append(sc,note,plist,who,mineW,pick,revW,bNext,hist,E('div','hint','Bied hoeveel stenen met een waarde er in totaal liggen (enen = joker) of roep Bluf! · ↑↓ aantal · 1–6 waarde · Enter bieden · B = bluf'));
 let S=null,notes=[],known={},myD={rnd:-1,d:[]},lEnd=0,pk='',selN=1,selF=2,revR=-1,revT=0,rollT=0,lastRnd=-1,podDone=0;
 net.players.forEach(p=>known[p.id]=net.pname(p));
 const myTurn=()=>S&&S.ph==='bid'&&S.pl[S.t]&&S.pl[S.t].id===me,meP=()=>S&&S.pl.find(p=>p.id===me);
 function chip(p){const col=pcol(p.id),q=pinfo(p.id),on=S.ph==='bid'&&S.pl[S.t]&&S.pl[S.t].id===p.id,d=E('div');
  d.style.cssText='display:inline-flex;align-items:center;padding:2px 10px 2px 2px;border-radius:99px;font-size:13px;font-weight:700;border:2px solid '+col+';'+(on?'background:'+col+';color:'+inkOn(col):'background:var(--bg);color:var(--tx)')+(p.c?'':';opacity:.45');
  const av=E('span','pav s');av.style.setProperty('--c',col);av.textContent=q&&q.av||'🙂';if(on)av.style.background='rgba(255,255,255,.85)';const t=E('span');t.textContent=p.n+(p.id===me?' (jij)':'')+' · '+(p.c?'🎲'+p.c:'uit');d.append(av,t);return d}
 function bidTag(b,big){const d=E('span');d.style.cssText='display:inline-flex;align-items:center;gap:4px;font-weight:800;font-size:'+(big?18:13)+'px;padding:'+(big?'4px 10px':'2px 7px')+';border-radius:10px;background:var(--bg);color:var(--tx);border-left:4px solid '+pcol(b.by);
  const t=E('span');t.textContent=b.n+' ×';d.append(t,die(b.f,big?28:22));if(b.auto){const a=E('small');a.textContent='⏱';d.append(a)}return d}
 function renderMine(){mineW.replaceChildren();const m=meP();if(!m||!m.c){const t=E('div','hint');t.textContent=m?'Je bent uit · je kijkt mee':'Je kijkt mee';t.style.fontSize='14px';mineW.append(t);mineW.style.display=S.ph==='fin'?'none':'';return}mineW.style.display='';
  const h=E('div');h.style.cssText='font-size:12px;font-weight:700;color:var(--mu);margin-bottom:6px';h.textContent='Jouw stenen (alleen jij ziet ze)';const row=E('div');row.style.cssText='display:flex;gap:8px;justify-content:center;flex-wrap:wrap';
  if(myD.rnd!==S.rnd){for(let i=0;i<m.c;i++){const d=die(0,52);d.style.background='var(--card)';row.append(d)}}else{const f=S.ph==='rev'&&S.rev?S.rev.bid.f:0;myD.d.forEach(v=>{const d=die(rollT?1+R(6):v,52);if(f&&!(v===f||(f!==1&&v===1)))d.style.opacity='.4';row.append(d)})}mineW.append(h,row)}
 function renderPick(){pick.style.display=myTurn()?'':'none';if(!myTurn())return;const T=tot(S),key=S.rnd+'|'+S.hist.length;
  if(pk!==key){pk=key;const m=minRaise(S.bid,T)||{n:T,f:2};selN=m.n;selF=m.f}pick.replaceChildren();
  const row=E('div');row.style.cssText='display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:8px';
  const mb=E('button','btn','−'),pb=E('button','btn','+'),nv=E('b');[mb,pb].forEach(b=>b.style.cssText='min-width:52px;min-height:52px;font-size:24px;padding:0;background:var(--bg);color:var(--tx);border:1px solid var(--ln,#ccc)');
  nv.style.cssText='font-size:30px;min-width:64px';nv.textContent=selN+' ×';mb.disabled=selN<=1;pb.disabled=selN>=T;mb.onclick=()=>step(-1);pb.onclick=()=>step(1);row.append(mb,nv,pb);
  const fr=E('div');fr.style.cssText='display:grid;grid-template-columns:repeat(6,1fr);gap:6px;margin-bottom:10px';
  for(let f=1;f<=6;f++){const ok=legal(S.bid,selN,f,T),b=E('button');b.type='button';b.style.cssText='min-height:56px;border-radius:12px;border:3px solid '+(selF===f?'var(--ac)':'transparent')+';background:'+(selF===f?'color-mix(in srgb,var(--ac) 25%,var(--card))':'transparent')+';display:flex;align-items:center;justify-content:center;cursor:pointer;padding:2px;opacity:'+(ok?1:.25);
   b.disabled=!ok;b.dataset.f=f;b.append(die(f,38));b.onclick=()=>{selF=f;renderPick()};fr.append(b)}
  const br=E('div');br.style.cssText='display:flex;gap:8px;justify-content:center';const bb=E('button','btn','Bied '+selN+' × '+(selF?'':'?'));if(selF){const dd=die(selF,24);dd.style.marginLeft='6px';bb.append(dd)}bb.style.cssText='flex:1;font-size:17px;max-width:220px;display:inline-flex;align-items:center;justify-content:center';bb.disabled=!legal(S.bid,selN,selF,T);bb.style.opacity=bb.disabled?'.5':'1';bb.onclick=doBid;
  br.append(bb);if(S.bid){const bl=E('button','btn','Bluf! 🤥');bl.style.cssText='flex:1;font-size:17px;max-width:160px;background:linear-gradient(135deg,#e5383b,#f77f00)';bl.onclick=doBluf;br.append(bl)}
  const h=E('div','hint',selN>0&&S.bid&&S.bid.f!==1?'Naar enen (joker): minstens '+Math.ceil(S.bid.n/2)+' · '+T+' stenen in het spel':S.bid?'Van enen af: minstens '+(S.bid.n*2+1)+' · '+T+' stenen in het spel':'Openen met enen mag niet · '+T+' stenen in het spel');pick.append(row,fr,br,h)}
 function step(d){if(!myTurn())return;selN=Math.max(1,Math.min(tot(S),selN+d));if(selF&&!legal(S.bid,selN,selF,tot(S)))selF=[2,3,4,5,6,1].find(f=>legal(S.bid,selN,f,tot(S)))||0;renderPick()}
 function doBid(){if(!myTurn()||!legal(S.bid,selN,selF,tot(S)))return;send({k:'bid',n:selN,f:selF,rnd:S.rnd})}
 function doBluf(){if(!myTurn()||!S.bid)return;send({k:'bluf',rnd:S.rnd})}
 function send(d){if(isH)hAct(me,d);else net.send(d)}
 function renderRev(){if(S.ph!=='rev'||!S.rev){revW.style.display='none';clearInterval(revT);revT=0;return}revW.style.display='';if(revR===S.rnd)return;revR=S.rnd;
  const R0=S.rev,f=R0.bid.f,hits=[],cnt=E('div');revW.replaceChildren();cnt.style.cssText='text-align:center;font-size:18px;font-weight:800;margin:4px 0 8px';
  const h=E('div');h.style.cssText='text-align:center;font-weight:700;margin-bottom:6px';h.textContent=pn(R0.caller)+' roept Bluf! op ';h.append(bidTag(R0.bid,1));revW.append(h,cnt);
  Object.keys(R0.dice).forEach(id=>{const ds=R0.dice[id];if(!ds.length)return;const r=E('div');r.style.cssText='display:flex;align-items:center;gap:6px;padding:5px 6px;border-radius:12px;margin-bottom:4px;background:var(--bg);border-left:4px solid '+pcol(id);
   const av=E('span','pav s');av.style.cssText='--c:'+pcol(id)+';margin:0';av.textContent=(pinfo(id)||{}).av||'🙂';av.title=pn(id);r.append(av);
   ds.forEach(v=>{const d=die(v,32);d.style.opacity='.55';r.append(d);if(v===f||(f!==1&&v===1))hits.push(d)});revW.append(r)});
  const verdict=E('div');verdict.style.cssText='text-align:center;font-weight:800;font-size:16px;margin-top:8px;min-height:24px';revW.append(verdict);
  let i=0;cnt.textContent='Geteld: 0';const fin=()=>{clearInterval(revT);revT=0;cnt.textContent='Geteld: '+R0.cnt+' (geboden: '+R0.bid.n+')';const lp=S.pl.find(p=>p.id===R0.loser);
   verdict.textContent=(R0.cnt>=R0.bid.n?'Het bod klopte! ':'Gebluft! ')+pn(R0.loser)+' verliest een steen'+(lp&&!lp.c?' en ligt eruit 💀':'');verdict.style.color=pcol(R0.loser);beep(R0.loser===me?180:520,.2,'triangle',.05)};
  clearInterval(revT);revT=setInterval(()=>{if(i>=hits.length)return fin();const d=hits[i++];d.style.opacity='1';d.style.transform='scale(1.15)';d.style.boxShadow='0 0 0 3px #ffd200';cnt.textContent='Geteld: '+i;beep(400+i*30,.04,'triangle',.02)},hits.length>12?110:180)}
 function render(){if(!S)return;note.textContent=notes.slice(-3).join(' · ');note.style.display=notes.length?'':'none';const m=meP(),T=tot(S);
  if(S.rnd!==lastRnd&&S.ph==='bid'){lastRnd=S.rnd;lEnd=performance.now()+S.left}if(S.ph==='bid')lEnd=Math.min(lEnd,performance.now()+S.left+250);
  plist.replaceChildren(...S.pl.map(chip));
  sc.textContent=S.ph==='fin'?'Spel klaar!':'Ronde '+(S.rnd+1)+' · '+T+' stenen in het spel'+(m&&m.c?' · jij: '+m.c:'');
  const c=S.pl[S.t];who.style.color='var(--tx)';
  who.textContent=S.ph==='bid'?(myTurn()?'Jij bent aan zet':c?pn(c.id,c.n)+' is aan zet':''):S.ph==='rev'?'Onthulling!':S.ph==='fin'?'🏆 '+pn(S.win)+' wint!':'';who.dataset.base=who.textContent;
  renderMine();renderPick();renderRev();bNext.style.display=isH&&S.ph==='rev'?'':'none';
  hist.replaceChildren(...S.hist.slice(-8).reverse().map((b,i)=>{const t=bidTag(b,i===0);if(i)t.style.opacity='.7';return t}));hist.style.display=S.ph==='bid'&&S.hist.length?'flex':'none';
  if(S.ph==='bid'&&!S.hist.length){const s=E('div','hint');s.textContent=(c?pn(c.id,c.n):'?')+' opent het bieden';hist.replaceChildren(s);hist.style.display='flex'}
  if(S.ph==='fin'){st.style.minHeight=(300+64*S.pl.length)+'px';if(!podDone){podDone=1;// score = aantal rondes overleefd: zo volgt het podium de volgorde van uitschakelen; de winnaar overleefde alle rondes
   const scores={},wc=(S.pl.find(p=>p.id===S.win)||{}).c||0;S.pl.forEach(p=>{const o=S.out.find(x=>x.id===p.id);scores[p.id]=o?o.r-1:S.rnd+1});const order=S.out.map((o,i)=>(i+1)+'. '+pn(o.id,o.n)+' (ronde '+o.r+')').join(' · ');
   net.result({winner:S.win,scores,unit:' rondes',text:pn(S.win)+' wint met nog '+wc+(wc===1?' steen':' stenen')+(order?' · eruit: '+order:'')})}}}
 // ---- host ----
 let D={},tm=0,tT=0,tR=0;
 const nxt=i=>{for(let k=1;k<=S.pl.length;k++){const j=(i+k)%S.pl.length;if(S.pl[j].c>0)return j}return i};
 function pub(){S.left=S.ph==='bid'?Math.max(0,TURN-(Date.now()-tT)):0;net.send(S);render();botSched()}
 function roll(){D={};S.pl.forEach(p=>D[p.id]=Array.from({length:p.c},()=>1+R(6)).sort((a,b)=>a-b));myD={rnd:S.rnd,d:D[me]||[]};tT=Date.now();pub();S.pl.forEach(p=>{if(p.id!==me&&p.c>0)net.sendTo(p.id,{k:'d',rnd:S.rnd,d:D[p.id]})});rollAnim()}
 function hAct(id,d,auto){if(!S||S.ph!=='bid'||d.rnd!==S.rnd)return;const p=S.pl[S.t];if(!p||p.id!==id)return;
  if(d.k==='bid'){const n=d.n|0,f=d.f|0;if(!legal(S.bid,n,f,tot(S)))return;S.bid={n,f,by:id};if(auto)S.bid.auto=1;S.hist.push(S.bid);S.t=nxt(S.t);tT=Date.now();beep(500,.05,'triangle',.03);pub();return true}
  else if(d.k==='bluf'&&S.bid){const cnt=count(D,S.bid.f),loser=cnt>=S.bid.n?id:S.bid.by,lp=S.pl.find(p=>p.id===loser);
   if(lp){lp.c--;if(!lp.c)S.out.push({id:lp.id,n:lp.n,r:S.rnd+1})}S.rev={dice:Object.assign({},D),bid:S.bid,caller:id,cnt,loser};S.ph='rev';tR=Date.now();pub();return true}}
 const revTime=()=>2600+(S.rev?Object.values(S.rev.dice).flat().length:0)*180;
 function nextRound(){if(!S||S.ph!=='rev')return;const A=act(S);if(A.length<=1){S.ph='fin';S.win=A[0]?A[0].id:null;S.rev=null;pub();[0,1,2].forEach(i=>setTimeout(()=>beep(523*Math.pow(1.26,i),.12,'triangle',.05),i*120));return}
  const li=S.pl.findIndex(p=>p.id===S.rev.loser);S.t=li>=0&&S.pl[li].c>0?li:nxt(li>=0?li:S.t);S.rnd++;S.bid=null;S.hist=[];S.rev=null;S.ph='bid';roll()}
 function auto(){const p=S.pl[S.t];if(!p)return;const m=minRaise(S.bid,tot(S));notes.push('⏱ '+pn(p.id,p.n)+' was te laat');if(m)hAct(p.id,{k:'bid',n:m.n,f:m.f,rnd:S.rnd},1);else hAct(p.id,{k:'bluf',rnd:S.rnd})}
 bNext.onclick=()=>{if(isH)nextRound()};
 function tick(){if(!S)return;if(S.ph==='bid'&&Date.now()-tT>=TURN)auto();else if(S.ph==='rev'&&Date.now()-tR>=revTime())nextRound()}
 function rollAnim(){clearInterval(rollT);let n=0;rollT=setInterval(()=>{if(++n>=7){clearInterval(rollT);rollT=0}if(S)renderMine()},70);beep(300,.05,'triangle',.03)}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(isH){if(d.k==='hi'&&S)net.sendTo(from,S);else{const ok=hAct(from,d);if(net.isBot(from)){if(ok)BT.ok++;else BT.bad.push(d)}}}
  else if(d.k==='s'){const nr=!S||S.rnd!==d.rnd;S=d;render();if(nr&&S.ph==='bid'&&myD.rnd===S.rnd)rollAnim()}
  else if(d.k==='d'&&Array.isArray(d.d)){myD={rnd:d.rnd,d:d.d.map(v=>v|0)};if(S&&S.rnd===d.rnd)rollAnim()}});
 const offP=net.onPlayers(ps=>{const ids=new Set(ps.map(p=>p.id));
  Object.keys(known).forEach(id=>{if(!ids.has(id)){notes.push('⚠️ '+known[id]+' heeft het spel verlaten');delete known[id];
   if(isH&&S){const i=S.pl.findIndex(p=>p.id===id);if(i>=0){const wasCur=i===S.t;S.pl.splice(i,1);delete D[id];if(i<S.t)S.t--;if(S.t>=S.pl.length)S.t=0;
    if(S.ph==='bid'){if(wasCur){if(!S.pl[S.t]||!S.pl[S.t].c)S.t=nxt(S.t);tT=Date.now()}if(act(S).length<=1){S.ph='rev';S.rev={dice:{},bid:{n:0,f:2,by:id},caller:id,cnt:0,loser:id};nextRound();return}}}}}});
  ps.forEach(p=>{if(!known[p.id]){known[p.id]=net.pname(p);notes.push('👋 '+net.pname(p)+' kijkt mee')}});
  if(isH&&S)pub();else render()});
 const inp=input(st,[],k=>{if(!myTurn())return;if(k==='ArrowUp')step(1);else if(k==='ArrowDown')step(-1);else if(k>='1'&&k<='6'){const f=+k;if(legal(S.bid,selN,f,tot(S))){selF=f;renderPick()}}else if(k==='Enter')doBid();else if(k==='b'||k==='B')doBluf()});
 const stopLoop=loop(()=>{if(!S||S.ph!=='bid')return;const s=Math.max(0,Math.ceil((lEnd-performance.now())/1000));const t=(who.dataset.base||'')+' · ⏱ '+s+' s';if(who.textContent!==t)who.textContent=t;who.style.color=s<=5?'#e5383b':'var(--tx)'});
 // ---- bots (alleen host): schatten het verwachte aantal uit eigen stenen + (stenen van de anderen × 1/3, of 1/6 voor enen);
 //      roepen Bluf! als het bod daar duidelijk boven zit, anders het "veiligste" minimale bod (liefst op een waarde die ze zelf hebben) ----------
 const BT=window.__spzBot||(window.__spzBot={sent:0,ok:0,bad:[]}),bT={};
 const botKey=id=>S&&S.ph==='bid'&&S.pl[S.t]&&S.pl[S.t].id===id&&D[id]?'B|'+S.rnd+'|'+S.hist.length:null;
 function botSched(){if(!isH)return;net.bots().forEach(b=>{const k=botKey(b.id),o=bT[b.id];if(o&&o.k===k)return;if(o)clearTimeout(o.tm);delete bT[b.id];if(!k)return;
  bT[b.id]={k,tm:setTimeout(()=>{delete bT[b.id];if(botKey(b.id)!==k){botSched();return}botDo(b.id)},BT.fast?30+R(50):900+R(1300))}})}
 function botDo(id){const mine=D[id]||[],T=tot(S),others=T-mine.length,own=f=>mine.filter(v=>v===f||(f!==1&&v===1)).length,E_=f=>own(f)+others*(f===1?1/6:1/3),b=S.bid,margin=.6+Math.random()*1.2;
  let d=null;if(b&&b.n>E_(b.f)+margin)d={k:'bluf',rnd:S.rnd};
  else{let best=null,bv=-1e9;for(let f=1;f<=6;f++){let n=1;while(n<=T&&!legal(b,n,f,T))n++;if(n>T)continue;
     const v=E_(f)-n+own(f)*.25+(f===1?-.4:0)+Math.random()*.6;if(v>bv){bv=v;best={n,f}}
     if(!b&&f!==1){const n2=Math.max(1,Math.floor(E_(f)-Math.random()));const v2=E_(f)-n2+own(f)*.25+Math.random()*.6+(n2>n?.3:0);if(legal(b,n2,f,T)&&v2>bv){bv=v2;best={n:n2,f}}}}
   if(!best||(b&&bv<-margin))d=b?{k:'bluf',rnd:S.rnd}:null;else d={k:'bid',n:best.n,f:best.f,rnd:S.rnd}}
  if(d){BT.sent++;net.botAct(id,d)}}
 window.__dbg={get S(){return S},get D(){return isH?D:null},get my(){return myD},legal,minRaise,force:()=>{if(isH&&S&&S.ph==='bid')auto()},next:()=>{if(isH)nextRound()}};const dbg=window.__dbg;
 if(isH){S={k:'s',ph:'bid',rnd:0,t:0,bid:null,hist:[],rev:null,out:[],win:null,left:TURN,pl:net.players.map(p=>({id:p.id,n:p.name,c:5}))};tm=setInterval(tick,200);roll()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{st.style.minHeight='';off();offP();inp.stop();stopLoop();clearInterval(tm);clearInterval(revT);clearInterval(rollT);Object.values(bT).forEach(o=>clearTimeout(o.tm));if(window.__dbg===dbg)delete window.__dbg}}},
