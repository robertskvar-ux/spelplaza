{id:'drawteams',n:'Tekenen & raden in teams',e:'🖍️',c:'Samen',g:'#e5383b,#2f80ed',min:2,max:8,run(st,net){
 // Pictionary in twee teams (host-authoritatief). Eén team tekent per beurt: de tekenaar (wisselt binnen het team) kiest uit 3 woorden,
 // alleen de eigen teamgenoten raden (60 s). Juist = +1, binnen 20 s +1 bonus. Teams wisselen om; host kiest 3 of 5 beurten per team.
 const EASY='aap,appel,auto,baby,bal,banaan,bank,bed,bij,bloem,boek,boom,boot,bord,bril,brood,brug,bus,cactus,camera,clown,computer,dak,deur,dolfijn,draak,drum,eend,egel,ei,fiets,fles,gitaar,glas,haai,hamer,hand,hart,hoed,hond,huis,ijsje,jas,kaars,kaas,kameel,kasteel,kat,kerk,kers,ketting,kikker,kip,klok,koe,koffer,konijn,krab,kroon,laars,ladder,lamp,leeuw,lepel,maan,mes,mier,molen,muis,muts,neus,olifant,oog,paard,paddenstoel,pan,papegaai,paraplu,piano,pijl,pinguïn,pizza,planeet,pop,raket,regenboog,ring,robot,schaar,schaap,schip,schoen,schildpad,slak,slang,sleutel,sneeuwpop,sok,spin,spook,ster,stoel,strand,tafel,tand,tandenborstel,tent,tijger,tomaat,toren,tractor,trein,trommel,trui,uil,varken,veer,vis,vlag,vlieger,vlinder,voet,vork,vuur,vuurtoren,walvis,wolk,wortel,zaag,zebra,zee,zeilboot,zon,zwaan,zwaard,ananas,emmer,gieter,heks,kameleon,ketel,koekje,krokodil,kwast,lantaarn,pannenkoek,puzzel,schommel,sleutelbos,snor,taart,telefoon,thee,vliegtuig,vogelhuisje'.split(',');
 const HARD='achtbaan,astronaut,bliksem,boomhut,brandweerman,dinosaurus,duikbril,eiland,fietspomp,gevangenis,glijbaan,luchtballon,ijsbeer,kampvuur,kangoeroe,kermis,kerstman,kompas,koptelefoon,lieveheersbeestje,magneet,microscoop,mummie,duikboot,parachute,piraat,regenjas,ridder,rolstoel,rups,satelliet,skelet,sneeuwvlok,spinnenweb,standbeeld,stofzuiger,supermarkt,tandarts,telescoop,tornado,tovenaar,tuinkabouter,verjaardag,vulkaan,waterval,windmolen,woestijn,zandkasteel,zeemeermin,zonnebril,zwembad,kapper,bibliotheek,ziekenhuis,aquarium,trampoline,vogelverschrikker,wasmachine,brievenbus,stoplicht,iglo,hangmat,schatkist,eenhoorn,kwal,octopus,pauw,neushoorn,lift,rugzak,dartbord,schaakbord,vliegende schotel,draaimolen,hoefijzer,kruiwagen,sneeuwman,ruimteschip,onweer,dromen'.split(',');
 const PC=['#1b1d2a','#e74c3c','#2e86de','#27ae60','#f39c12','#8e5a3c'],SZ=[3,7,14],TL=60000,BON=20000,W=360,H=300,isH=net.isHost,me=net.me.id;
 const TN=['rood','blauw'],TE=['🔴','🔵'],TC=['#e5383b','#2f80ed'];
 const norm=s=>String(s).toLowerCase().trim().replace(/\s+/g,' ');
 const sc=E('div','sc'),note=E('div','hint'),setup=E('div','dtsetup'),game=E('div','dtgame');setup.style.cssText='max-width:380px;margin:6px auto';
 const banner=E('div','dtban');banner.style.cssText='font-weight:800;color:#fff;border-radius:12px;padding:6px 10px;margin:4px auto 6px;max-width:360px;font-size:15px';
 const board=E('div','dtboard');board.style.cssText='display:flex;flex-direction:column;gap:4px;align-items:center;margin:2px 0 6px';
 const word=E('div','dtword');word.style.cssText='font-size:22px;font-weight:800;letter-spacing:.15em;min-height:32px;margin:4px 0;font-variant-numeric:tabular-nums';
 const barW=E('div');barW.style.cssText='height:6px;border-radius:99px;background:var(--bg);overflow:hidden;max-width:360px;margin:0 auto 8px';const bar=E('div');bar.style.cssText='height:100%;width:100%;border-radius:99px;background:#38d9a9';barW.append(bar);
 st.append(sc,note,setup,game);
 const c=mkCanvas(st,W,H),x=c.getContext('2d',{willReadFrequently:true});c.style.background='#fffdf7';c.style.cursor='crosshair';
 const tools=E('div','dttools');tools.style.cssText='display:none;gap:6px;justify-content:center;align-items:center;flex-wrap:wrap;margin:8px 0';
 let col=0,sz=1;const cbs=PC.map((cc,i)=>{const b=E('button');b.style.cssText='width:30px;height:30px;border-radius:50%;border:3px solid transparent;background:'+cc+';cursor:pointer';b.onclick=()=>{col=i;toolUI()};tools.append(b);return b});
 const sbs=SZ.map((s,i)=>{const b=E('button','btn');b.style.cssText='width:36px;height:36px;padding:0;border-radius:50%;background:var(--bg);color:var(--tx);display:flex;align-items:center;justify-content:center';const d=E('span');d.style.cssText='display:block;border-radius:50%;background:currentColor;width:'+(s+4)+'px;height:'+(s+4)+'px';b.append(d);b.onclick=()=>{sz=i;toolUI()};tools.append(b);return b});
 const bClr=E('button','btn','🗑️ Wis');bClr.style.cssText='background:var(--bg);color:var(--tx)';bClr.onclick=()=>{if(!amDrawer())return;clear();if(isH)strokes=[];net.send({k:'clr'})};tools.append(bClr);
 const pick=E('div','dtpick');pick.style.cssText='display:none;gap:8px;justify-content:center;flex-wrap:wrap;margin:10px 0';
 const gRow=E('div','dtg');gRow.style.cssText='display:none;gap:6px;justify-content:center;margin:8px auto;max-width:360px';
 const gIn=E('input');gIn.maxLength=30;gIn.placeholder='Wat tekent je teamgenoot?';gIn.autocomplete='off';gIn.style.cssText='flex:1;min-width:0;padding:10px 12px;border:1px solid var(--ln,#ccc);border-radius:12px;background:var(--bg);color:var(--tx);font:inherit;font-size:16px';
 const gBtn=E('button','btn','Raad!');gRow.append(gIn,gBtn);
 const feed=E('div');feed.style.cssText='max-width:360px;margin:6px auto 0;text-align:left;font-size:13px;min-height:20px;line-height:1.5';
 const info=E('div');info.style.cssText='font-weight:700;min-height:22px;margin-top:6px';
 game.append(banner,board,word,barW,pick,tools,c,gRow,info,feed);
 st.append(E('div','hint','Teken met je vinger of muis · alleen je eigen team raadt (typ + Enter) · binnen 20 s geraden = bonuspunt · de andere ploeg kijkt mee en mag reageren'));
 let S=null,notes=[],known={},lEnd=0,lKey='',drawing=0,pend=[],last=null,flushT=0,chosen=-1,tms=[],scBase='',podDone=0;
 net.players.forEach(p=>known[p.id]=net.pname(p));
 const amDrawer=()=>S&&S.ph==='draw'&&S.dr===me,teamOf=id=>S?S.T[0].includes(id)?0:S.T[1].includes(id)?1:-1:-1;
 const nm=(id,n)=>{const q=net.players.find(x=>x.id===id);if(q)return net.pname(q);const p=S&&S.pl.find(p=>p.id===id);return p?p.n:(n||'…')};
 function clear(){x.fillStyle='#fffdf7';x.fillRect(0,0,W,H)}
 function seg(ci,w,p){x.strokeStyle=PC[ci]||PC[0];x.lineWidth=SZ[w]||SZ[1];x.lineCap=x.lineJoin='round';x.beginPath();x.moveTo(p[0],p[1]);if(p.length===2)x.lineTo(p[0]+.1,p[1]);for(let i=2;i<p.length;i+=2)x.lineTo(p[i],p[i+1]);x.stroke()}
 function toolUI(){cbs.forEach((b,i)=>b.style.borderColor=i===col?'var(--ac)':'transparent');sbs.forEach((b,i)=>{b.style.background=i===sz?'var(--ac)':'var(--bg)';b.style.color=i===sz?'#fff':'var(--tx)'})}
 function chip(id,txt){const q=net.players.find(x=>x.id===id),pc=q&&q.col||'var(--mu)',on=id===me,d=E('div');
  d.style.cssText='display:inline-flex;align-items:center;padding:2px 9px 2px 2px;margin:2px;border-radius:99px;font-size:13px;font-weight:'+(on?'700':'600')+';color:var(--tx);border:2px solid '+pc+';background:'+(on?'color-mix(in srgb,'+pc+' 18%,var(--bg))':'var(--bg)');
  const av=E('span','pav s');av.style.setProperty('--c',pc);av.textContent=q&&q.av||'🙂';const t=E('span');t.textContent=txt;d.append(av,t);return d}
 const pn=id=>{const q=net.players.find(x=>x.id===id),p=S.pl.find(p=>p.id===id);return q?q.name:p?p.n:'…'};
 function mmss(ms){const s=Math.max(0,Math.ceil(ms/1000));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
 const mkB=(t,f,on)=>{const b=E('button','btn'+(on===0?' sec':''),t);b.onclick=f;b.style.margin='3px';return b};
 function renderSetup(){setup.replaceChildren();const cols=E('div');cols.style.cssText='display:flex;gap:8px;justify-content:center';
  [0,1].forEach(t=>{const box=E('div');box.dataset.team=t;box.style.cssText='flex:1;min-width:0;border:2px solid '+TC[t]+';border-radius:14px;padding:6px 4px;background:color-mix(in srgb,'+TC[t]+' 8%,var(--card,var(--bg)))';
   const h=E('div');h.style.cssText='font-weight:800;color:'+TC[t]+';margin-bottom:4px';h.textContent=TE[t]+' Team '+TN[t]+' ('+S.T[t].length+')';box.append(h);
   S.T[t].forEach(id=>{const d=chip(id,pn(id)+(id===me?' (jij)':''));d.style.maxWidth='100%';box.append(d)});cols.append(box)});
  setup.append(cols);const row=E('div');row.style.cssText='margin:8px 0;display:flex;flex-wrap:wrap;justify-content:center';
  if(teamOf(me)>=0)row.append(mkB('⇄ Wissel van team',()=>{if(isH)hSwitch(me);else net.send({k:'sw'})},0));setup.append(row);
  if(isH){const seg2=(lab,opts,cur,set)=>{const r=E('div');r.style.cssText='display:flex;align-items:center;justify-content:center;gap:4px;margin:4px 0;flex-wrap:wrap';const l=E('span','hint');l.style.cssText='min-width:110px;text-align:right;margin:0 4px 0 0';l.textContent=lab;r.append(l);
    opts.forEach(([t,v])=>{const b=mkB(t,()=>set(v),cur===v?1:0);b.style.cssText='margin:0;padding:6px 12px;font-size:14px';r.append(b)});setup.append(r)};
   seg2('Beurten per team',[['3',3],['5',5]],S.R,v=>{S.R=v;pub()});seg2('Woorden',[['😊 Makkelijk',0],['🧠 Moeilijk',1]],S.hard,v=>{S.hard=v;pub()});
   row.prepend(mkB('🔀 Schudden',hShuffle,0));
   const go=mkB('▶ Start',hStart,1);go.style.cssText='margin:10px auto 0;display:block;font-size:17px;padding:10px 28px';setup.append(go)}
  else{const p=E('p','wait');p.textContent='⏳ Wachten tot de host start · '+S.R+' beurten per team · '+(S.hard?'moeilijke':'makkelijke')+' woorden';setup.append(p)}}
 function render(){if(!S)return;const key=S.t+':'+S.ph;const dr=S.dr===me,myT=teamOf(me);
  if(key!==lKey){lKey=key;lEnd=performance.now()+(S.tl||0);if(S.ph==='pick'){clear();chosen=-1;gIn.value=''}}
  const ns=notes.slice(-2);if(S.pl.length<4&&S.ph!=='fin')ns.unshift('Met minder dan 4 spelers is dit een testpotje (een team van 1 laat de andere ploeg raden) — vanaf 4 wordt het echt leuk');
  note.textContent=ns.join(' · ');note.style.display=ns.length?'':'none';
  setup.style.display=S.ph==='team'?'':'none';game.style.display=S.ph==='team'?'none':'';
  if(S.ph==='team'){sc.textContent=scBase='Teams kiezen · '+S.pl.length+' spelers';renderSetup();return}
  sc.textContent=scBase=TE[0]+' Rood '+S.sc[0]+' – '+S.sc[1]+' Blauw '+TE[1]+(S.ph==='fin'?' · klaar!':' · beurt '+(S.t+1)+'/'+2*S.R);
  board.replaceChildren(...[0,1].map(t=>{const r=E('div');r.style.cssText='display:flex;flex-wrap:wrap;justify-content:center;align-items:center;'+(S.ph!=='fin'&&t!==S.team?'opacity:.6':'');const l=E('b');l.style.cssText='color:'+TC[t]+';margin-right:4px';l.textContent=TE[t]+' '+S.sc[t];r.append(l);
   S.T[t].forEach(id=>r.append(chip(id,(id===S.dr&&S.ph!=='fin'?'🖌️ ':'')+pn(id)+(id===me?' (jij)':'')+(id===S.ok?' ✅':''))));return r}));
  const tm=S.team;banner.style.background=TC[tm];banner.style.display=S.ph==='fin'?'none':'';
  const gt=S.gt==null?tm:S.gt;banner.textContent=(gt===tm?TE[tm]+' Team '+TN[tm]+' raadt':TE[tm]+' '+TN[tm]+' tekent · '+TE[gt]+' '+TN[gt]+' raadt (oefenen)')+(dr?' · jij tekent!':myT===gt?' · raad mee!':myT>=0?' · jullie kijken mee 👀':'');
  tools.style.display=dr&&S.ph==='draw'?'flex':'none';pick.style.display=dr&&S.ph==='pick'?'flex':'none';gRow.style.display=!dr&&S.ph==='draw'&&myT===S.gt?'flex':'none';barW.style.visibility=S.ph==='draw'?'visible':'hidden';
  word.style.letterSpacing='0';
  if(S.ph==='fin'){const t=S.sc[0]===S.sc[1]?-1:S.sc[0]>S.sc[1]?0:1;word.textContent=t<0?'🤝 Gelijkspel!':TE[t]+' Team '+TN[t]+' wint!';info.textContent='';feed.replaceChildren();clear();
   if(!podDone){podDone=1;const scores={};S.T.forEach((m,i)=>m.forEach(id=>scores[id]=S.sc[i]));net.result({winner:null,scores,unit:' pt',title:t<0?'Gelijkspel 🤝':TE[t]+' Team '+TN[t]+' wint!',text:'Rood '+S.sc[0]+' – '+S.sc[1]+' Blauw'})}return}
  if(S.ph==='pick'){word.textContent=dr?'Kies een woord':nm(S.dr)+' kiest een woord…';info.textContent='';if(dr&&chosen<0){pick.replaceChildren(...(S.ch||[]).map((w,i)=>{const b=E('button','btn',w);b.style.fontSize='16px';b.onclick=()=>{chosen=i;if(isH)hChoose(me,i);else net.send({k:'ch',i})};return b}))}}
  else if(S.ph==='draw'){word.textContent=dr?'Teken: '+S.w:S.mask.split('').join(' ');word.style.letterSpacing=dr?'0':'.15em';info.textContent=dr?'Alleen team '+TN[S.gt]+' raadt':''}
  else{word.textContent='Het woord was: '+S.w;info.textContent=S.ok?'✅ '+nm(S.ok)+' raadde het · +'+(S.bon?2:1)+' voor team '+TN[tm]+(S.bon?' (snel! bonus)':''):'⏱ Niet geraden — geen punt'}
  feed.replaceChildren(...(S.feed||[]).slice(-8).map(f=>{const d=E('div');d.textContent=f.ok?'✅ '+nm(f.id,f.n)+' heeft het geraden!':nm(f.id,f.n)+': '+f.t;d.style.color=f.ok?'#27ae60':'var(--tx)';return d}))}
 // ---- tekenen (zelfde batching als Tekenen & raden: elke 50 ms een stukje lijn) ----
 const pos=e=>{const r=c.getBoundingClientRect();return[Math.round((e.clientX-r.left)*W/r.width),Math.round((e.clientY-r.top)*H/r.height)]};
 function flush(){if(!pend.length)return;const p=last?[...last,...pend]:pend,msg={k:'st',c:col,w:sz,p};if(isH)strokes.push(msg);net.send(msg);last=pend.slice(-2);pend=[]}
 c.onpointerdown=e=>{if(!amDrawer())return;e.preventDefault();try{c.setPointerCapture(e.pointerId)}catch(x){}drawing=1;const q=pos(e);pend=q;last=null;seg(col,sz,q);clearInterval(flushT);flushT=setInterval(flush,50)};
 c.onpointermove=e=>{if(!drawing)return;e.preventDefault();const q=pos(e);const prev=pend.length?pend.slice(-2):last;if(prev)seg(col,sz,[...prev,...q]);pend.push(...q)};
 c.onpointerup=c.onpointercancel=e=>{if(!drawing)return;drawing=0;clearInterval(flushT);flush();last=null};
 function guess(){const t=norm(gIn.value);if(!t||!S||S.ph!=='draw'||amDrawer()||teamOf(me)!==S.gt)return;gIn.value='';if(isH)hGuess(me,t);else net.send({k:'g',t})}
 gBtn.onclick=guess;gIn.onkeydown=e=>{if(e.key==='Enter')guess()};
 // ---- host ----
 let strokes=[],t0=0,hints=0,tm=0,rng=net.rng(),wq=[[],[]];
 const shuf=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
 function pub(){if(S.ph==='draw')S.tl=Math.max(0,TL-(Date.now()-t0));const out=Object.assign({},S);delete out.ch;if(S.ph==='pick'||S.ph==='draw')delete out.w;net.send(out);
  if(S.dr&&S.dr!==me){if(S.ph==='draw')net.sendTo(S.dr,Object.assign({},out,{w:S.w}));if(S.ph==='pick')net.sendTo(S.dr,Object.assign({},out,{ch:S.ch}))}render()}
 function hSwitch(id){if(S.ph!=='team')return;const t=teamOf(id);if(t<0)return;S.T[t]=S.T[t].filter(x=>x!==id);S.T[1-t].push(id);pub()}
 function hShuffle(){if(S.ph!=='team')return;const ids=shuf(S.pl.map(p=>p.id));S.T=[[],[]];ids.forEach((id,i)=>S.T[i%2].push(id));pub()}
 function hStart(){if(S.ph!=='team')return;if(!S.T[0].length||!S.T[1].length){notes.push('Elk team heeft minstens één speler nodig');render();return}
  wq=[shuf(EASY.slice()),shuf(HARD.slice())];S.sc=[0,0];S.t=0;startTurn()}
 function startTurn(){tms.forEach(clearTimeout);tms=[];S.team=S.t%2;const m=S.T[S.team];if(!m.length||!S.T[1-S.team].length){S.ph='fin';S.dr=null;pub();return}
  S.dr=m[Math.floor(S.t/2)%m.length];S.gt=m.length>1?S.team:1-S.team;S.ph='pick';S.ok=null;S.bon=0;S.feed=[];const q=wq[S.hard?1:0];if(q.length<3)q.push(...shuf((S.hard?HARD:EASY).slice()));S.ch=[q.pop(),q.pop(),q.pop()];S.w='';S.mask='';strokes=[];hints=0;clear();pub();
  const t=S.t;tms.push(setTimeout(()=>{if(S.ph==='pick'&&S.t===t)hChoose(S.dr,0)},20000))}
 function hChoose(id,i){if(S.ph!=='pick'||id!==S.dr||!(i>=0&&i<3))return;S.w=S.ch[i];S.mask=S.w.replace(/[^ ]/g,'_');S.ph='draw';t0=Date.now();pub()}
 function hGuess(id,t){if(S.ph!=='draw'||id===S.dr||teamOf(id)!==S.gt)return;// alleen het radende team (= tekenende team) telt
  const p=S.pl.find(p=>p.id===id);if(!p)return;
  if(t===norm(S.w)){const el=Date.now()-t0;S.ok=id;S.bon=el<=BON?1:0;S.sc[S.team]+=1+S.bon;S.feed.push({n:p.n,id,ok:1});beep(880,.15,'triangle',.05);endTurn()}
  else{S.feed.push({n:p.n,id,t:t.slice(0,30)});S.feed=S.feed.slice(-10);pub()}}
 function next(){S.t++;if(S.t>=2*S.R){S.ph='fin';S.dr=null;pub()}else startTurn()}
 function endTurn(){if(S.ph!=='draw')return;S.ph='end';pub();tms.push(setTimeout(next,4500))}
 function tick(){if(!S||S.ph!=='draw')return;const tl=TL-(Date.now()-t0);if(tl<=0){endTurn();return}
  if(!hints&&tl<TL/2&&S.w.replace(/ /g,'').length>=4){const idx=[];for(let i=0;i<S.w.length;i++)if(S.mask[i]==='_')idx.push(i);if(idx.length){const i=idx[Math.floor(rng()*idx.length)];S.mask=S.mask.slice(0,i)+S.w[i]+S.mask.slice(i+1)}hints=1;pub()}}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(d.k==='st'){if(from!=='host'&&(!S||from!==S.dr||S.ph!=='draw'))return;if(d.by===me)return;if(Array.isArray(d.p)&&d.p.length<=400){seg(d.c|0,d.w|0,d.p.map(v=>+v||0));if(isH){strokes.push(d);if(strokes.length>400)strokes.shift();net.send(Object.assign({by:from},d))}}return}
  if(d.k==='clr'){if(from!=='host'&&(!S||from!==S.dr))return;clear();if(isH){strokes=[];net.send({k:'clr'})}return}
  if(isH){if(!S)return;if(d.k==='g')hGuess(from,norm(d.t));else if(d.k==='ch')hChoose(from,d.i|0);else if(d.k==='sw')hSwitch(from);
   else if(d.k==='hi'){const out=Object.assign({},S);delete out.w;delete out.ch;if(S.ph==='end'||S.ph==='fin')out.w=S.w;if(S.ph==='draw')out.tl=Math.max(0,TL-(Date.now()-t0));net.sendTo(from,out);for(let i=0;i<strokes.length;i+=25)net.sendTo(from,{k:'all',s:strokes.slice(i,i+25)})}}
  else if(d.k==='s'){const was=S&&S.ph;if(S&&d.t===S.t&&d.ph!=='team'){if(d.w==null&&S.w)d.w=S.w;if(!d.ch&&S.ch)d.ch=S.ch}S=d;if(S.ph==='end'&&was!=='end')beep(S.ok?660:200,.15,'triangle',.04);render()}
  else if(d.k==='all'&&Array.isArray(d.s))d.s.forEach(s=>seg(s.c|0,s.w|0,s.p))});
 const offP=net.onPlayers(ps=>{const ids=new Set(ps.map(p=>p.id));
  Object.keys(known).forEach(id=>{if(!ids.has(id)){notes.push('⚠️ '+known[id]+' heeft het spel verlaten');delete known[id];
   if(isH&&S){const wasDr=id===S.dr;S.pl=S.pl.filter(p=>p.id!==id);S.T=S.T.map(m=>m.filter(x=>x!==id));
    if(S.ph!=='team'&&S.ph!=='fin'&&(!S.T[0].length||!S.T[1].length)){tms.forEach(clearTimeout);S.ph='fin';S.dr=null}
    else if(wasDr&&S.ph==='draw')endTurn();else if(wasDr&&S.ph==='pick')next()}}});
  ps.forEach(p=>{if(!known[p.id]){known[p.id]=net.pname(p);if(isH&&S&&!S.pl.some(x=>x.id===p.id)){S.pl.push({id:p.id,n:p.name});const t=S.T[0].length<=S.T[1].length?0:1;S.T[t].push(p.id)}}});
  if(isH&&S)pub();else render()});
 const stopLoop=loop(()=>{if(!S||S.ph!=='draw')return;const f=Math.max(0,(lEnd-performance.now())/TL);bar.style.width=f*100+'%';bar.style.background=`hsl(${Math.round(f*120)},70%,50%)`;
  sc.textContent=scBase+' · ⏱ '+mmss(lEnd-performance.now())});
 clear();toolUI();st.dt={get S(){return S},strokes:()=>strokes.length};
 if(isH){S={k:'s',ph:'team',t:0,R:3,hard:0,team:0,dr:null,ok:null,bon:0,sc:[0,0],T:[[],[]],pl:net.players.map(p=>({id:p.id,n:p.name})),feed:[],mask:''};
  net.players.forEach((p,i)=>S.T[i%2].push(p.id));tm=setInterval(tick,250);pub()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{off();offP();stopLoop();clearInterval(tm);clearInterval(flushT);tms.forEach(clearTimeout);c.onpointerdown=c.onpointermove=c.onpointerup=c.onpointercancel=null}}},
