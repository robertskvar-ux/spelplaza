{id:'jeopardy',n:'Jeopardy-quiz',e:'🏆',c:'Samen',g:'#060c5c,#3a4bd6',min:2,max:8,bots:true,run(st,net){
 // Jeopardy (host-authoritatief): 5 categorieën × 5 bedragen. De juiste antwoorden blijven op de host tot de onthulling.
 // Bank: 'Categorie@vraag|antwoord[|fout|fout|fout]@…' — 5 vragen per categorie, oplopend in moeilijkheid. Zonder eigen foute
 // antwoorden worden de afleiders gekozen uit de andere antwoorden van dezelfde categorie.
 const BANK=['Hoofdsteden@Wat is de hoofdstad van Frankrijk?|Parijs@Wat is de hoofdstad van Spanje?|Madrid@Wat is de hoofdstad van Portugal?|Lissabon@Wat is de hoofdstad van Canada?|Ottawa@Wat is de hoofdstad van Australië?|Canberra',
  'Jaartallen@In welk jaar eindigde de Tweede Wereldoorlog?|1945@In welk jaar werd België onafhankelijk?|1830@In welk jaar viel de Berlijnse Muur?|1989@In welk jaar bereikte Columbus Amerika?|1492@In welk jaar vond de Guldensporenslag plaats?|1302',
  'Dierenjongen@Hoe heet het jong van een koe?|Kalf@Hoe heet het jong van een schaap?|Lam@Hoe heet het jong van een paard?|Veulen@Hoe heet het jong van een varken?|Big@Hoe heet het jong van een kikker?|Kikkervisje',
  'Dierenrecords@Wat is het snelste landdier?|Jachtluipaard@Welk dier heeft de langste nek?|Giraf@Wat is de grootste vogel ter wereld?|Struisvogel@Wat is het grootste dier dat ooit leefde?|Blauwe vinvis@Welk zoogdier kan echt vliegen?|Vleermuis',
  'Het lichaam@Welk orgaan pompt je bloed rond?|Hart@Wat is het grootste orgaan van je lichaam?|Huid@Welk orgaan filtert je bloed en maakt urine?|Nieren@Welk orgaan maakt gal?|Lever@Welk orgaan maakt insuline?|Alvleesklier',
  'Planeten@Welke planeet noemen we de rode planeet?|Mars@Welke planeet is de grootste van ons zonnestelsel?|Jupiter@Welke planeet is beroemd om zijn grote ringen?|Saturnus@Welke planeet staat het dichtst bij de zon?|Mercurius@Welke planeet is de heetste?|Venus',
  'Scheikunde@Welk element heeft het symbool O?|Zuurstof@Welk element heeft het symbool Fe?|IJzer@Welk element heeft het symbool Au?|Goud@Welk element heeft het symbool Ag?|Zilver@Welk element heeft het symbool Na?|Natrium',
  'Belgische steden@Welke stad heeft de grootste haven van België?|Antwerpen@Welke stad noemt men het Venetië van het Noorden?|Brugge@In welke stad staat de oudste universiteit van België?|Leuven@In welke stad staat de Menenpoort?|Ieper@In welke stad trekt het Ros Beiaard door de straten?|Dendermonde',
  'Beroemde Belgen@Wie bedacht Kuifje?|Hergé@Wie bedacht de Smurfen?|Peyo@Welke wielrenner won vijf keer de Tour de France?|Eddy Merckx@Wie zong ‘Ne me quitte pas’?|Jacques Brel@Welke Belgische priester bedacht de oerknaltheorie?|Georges Lemaître',
  'Acteurs@Wie speelde Jack in ‘Titanic’?|Leonardo DiCaprio@Wie speelde ‘The Terminator’?|Arnold Schwarzenegger@Wie speelde Forrest Gump?|Tom Hanks@Welke Belgische acteur heet ‘The Muscles from Brussels’?|Jean-Claude Van Damme@Wie speelde Donna in ‘Mamma Mia!’?|Meryl Streep',
  'Animatiefilms@Hoe heet de groene oger met een ezel als vriend?|Shrek@Hoe heet de leeuwenwelp in ‘De Leeuwenkoning’?|Simba@Hoe heet de cowboy in ‘Toy Story’?|Woody@Hoe heet de rat die kok wil worden in ‘Ratatouille’?|Remy@Hoe heet de vader van Nemo?|Marlin',
  'Instrumenten@Welk instrument heeft meestal zes snaren?|Gitaar@Welk instrument heeft 88 toetsen?|Piano@Welk instrument bedacht de Belg Adolphe Sax?|Saxofoon@Welk groot snaarinstrument heeft pedalen en zo’n 47 snaren?|Harp@Welk lang blaasinstrument komt van de Aboriginals in Australië?|Didgeridoo',
  'Popmuziek@Wie zong ‘Thriller’?|Michael Jackson@Welke Zweedse groep zong ‘Dancing Queen’?|ABBA@Wie zong ‘Shape of You’?|Ed Sheeran@Welke Belg zong ‘Alors on danse’?|Stromae@Welke band zong ‘Bohemian Rhapsody’?|Queen',
  'Welke sport?@Welke sport speel je op Wimbledon?|Tennis@In welke sport rijdt men de Ronde van Vlaanderen?|Wielrennen@In welke sport maak je een slam dunk?|Basketbal@In welke sport bestaat een scrum?|Rugby@In welke sport veeg je met een bezem over het ijs?|Curling',
  'Sportgetallen@Hoeveel spelers staan per ploeg op het veld bij voetbal?|11@Hoeveel holes heeft een standaard golfbaan?|18@Hoeveel kilometer is een marathon (afgerond)?|42@Hoeveel spelers staan per ploeg op het veld bij handbal?|7@Tot hoeveel punten speel je een gewone set volleybal?|25',
  'Wereldkeuken@Uit welk land komt de pizza?|Italië@Uit welk land komt sushi?|Japan@Uit welk land komt paella?|Spanje@Uit welk land komt moussaka?|Griekenland@Uit welk land komt goulash?|Hongarije',
  'Eten@Wat is het hoofdingrediënt van frietjes?|Aardappel@Wat is het hoofdingrediënt van guacamole?|Avocado@Van welke vrucht maak je kriekenbier?|Kers@Wat is het hoofdingrediënt van hummus?|Kikkererwt@Welke dure specerij komt uit de krokus?|Saffraan',
  'Belgische keuken@Wat eet je traditioneel bij mosselen?|Friet@Wat bak je in een ijzer met ruitjes?|Wafel@Hoe heet gestampte aardappel met groenten?|Stoemp@Welk Gents gerecht is een romige stoofpot met kip of vis?|Waterzooi@Welk Luiks gerecht zijn gehaktballen in zoete stroopsaus?|Boulets',
  'Frans → Nederlands@Wat betekent ‘chat’?|Kat@Wat betekent ‘chien’?|Hond@Wat betekent ‘pomme’?|Appel@Wat betekent ‘fromage’?|Kaas@Wat betekent ‘grenouille’?|Kikker',
  'Engels → Nederlands@Wat betekent ‘butterfly’?|Vlinder@Wat betekent ‘strawberry’?|Aardbei@Wat betekent ‘squirrel’?|Eekhoorn@Wat betekent ‘hedgehog’?|Egel@Wat betekent ‘dragonfly’?|Libel',
  'Spreekwoorden@De appel valt niet ver van de …|Boom@Als de kat van huis is, dansen de …|Muizen@Beter één vogel in de hand dan tien in de …|Lucht@Een ezel stoot zich geen twee keer aan dezelfde …|Steen@Wie het onderste uit de kan wil, krijgt het … op zijn neus|Deksel',
  'Uitvinders@Wie bedacht de relativiteitstheorie?|Albert Einstein@Wie beschreef de zwaartekracht na een vallende appel?|Isaac Newton@Wie maakte de eerste bruikbare gloeilamp?|Thomas Edison@Wie geldt als uitvinder van de telefoon?|Alexander Graham Bell@Wie ontdekte penicilline?|Alexander Fleming',
  'Eenheden@In welke eenheid meet je elektrische spanning?|Volt@In welke eenheid meet je vermogen?|Watt@In welke eenheid meet je kracht?|Newton@In welke eenheid meet je stroomsterkte?|Ampère@In welke eenheid meet je elektrische weerstand?|Ohm',
  'Rivieren@Welke rivier stroomt door Antwerpen?|Schelde@Welke rivier stroomt door Parijs?|Seine@Welke rivier stroomt door Londen?|Theems@Wat is de langste rivier van Afrika?|Nijl@Welke rivier stroomt door Wenen en Boedapest?|Donau',
  'Bergen@Wat is de hoogste berg ter wereld?|Mount Everest@Wat is de hoogste berg van Afrika?|Kilimanjaro@Welk gebergte ligt tussen Frankrijk en Spanje?|Pyreneeën@Wat is de hoogste berg van West-Europa?|Mont Blanc@Wat is het hoogste punt van België?|Signaal van Botrange',
  'Vlaggen@Welk land heeft een zwart-geel-rode vlag met verticale banen?|België@Welk land heeft een rode cirkel op een witte vlag?|Japan@Welk land heeft een esdoornblad op de vlag?|Canada@Welk land heeft een wit kruis op een rode vlag?|Zwitserland@Welk land heeft een rode draak op de vlag?|Wales',
  'Bekende gebouwen@In welke stad staat het Atomium?|Brussel@In welke stad staat de Eiffeltoren?|Parijs@In welke stad staat de Big Ben?|Londen@In welke stad staat de Sagrada Família?|Barcelona@In welke stad staat de Taj Mahal?|Agra',
  'Historische figuren@Wie zette als eerste mens voet op de maan?|Neil Armstrong@Welke Franse keizer verloor bij Waterloo?|Napoleon@Welke Egyptische koningin had een relatie met Julius Caesar?|Cleopatra@Wie zat 27 jaar gevangen en werd president van Zuid-Afrika?|Nelson Mandela@Wie was de eerste koning der Belgen?|Leopold I',
  'Mythologie@Wie is de oppergod van de Griekse goden?|Zeus@Wie is de Noorse god van de donder?|Thor@Wie is de Griekse god van de zee?|Poseidon@Welke Griekse held was alleen kwetsbaar aan zijn hiel?|Achilles@Wie is de Romeinse god van de oorlog?|Mars',
  'Kleuren mengen@Blauw + geel = ?|Groen@Rood + geel = ?|Oranje@Rood + blauw = ?|Paars@Zwart + wit = ?|Grijs@Rood + wit = ?|Roze',
  'Strips@Hoe heet de hond van Kuifje?|Bobbie@Wie is de beste vriend van Asterix?|Obelix@Hoe heet de tante van Suske en Wiske?|Sidonia@Wie is de leider van de Smurfen?|Grote Smurf@Hoe heet de domme hond in Lucky Luke?|Rataplan',
  'Technologie@Welk bedrijf maakt de iPhone?|Apple@Welk bedrijf maakt Windows?|Microsoft@Welk bedrijf maakt de PlayStation?|Sony@Welk automerk maakt de Model 3?|Tesla@Welk bedrijf bedacht Super Mario?|Nintendo',
  'Dierengeluiden@Welk dier knort?|Varken@Welk dier blaat?|Schaap@Welk dier hinnikt?|Paard@Welk dier balkt?|Ezel@Welk dier burlt in de herfst?|Hert',
  'Getallen@Hoeveel poten heeft een spin?|8|6|10|12@Hoeveel kaarten telt een spel zonder jokers?|52|54|48|56@Hoeveel vakjes heeft een schaakbord?|64|81|100|49@Hoeveel dagen telt een schrikkeljaar?|366|365|364|367@Hoeveel seconden zitten in een uur?|3600|6000|360|1800',
  'Sprookjes@Wie at van een vergiftigde appel?|Sneeuwwitje@Wie verloor haar glazen muiltje?|Assepoester@Welk meisje droeg een rode kap?|Roodkapje@Wiens neus groeide als hij loog?|Pinokkio@Wie liet haar lange haar uit de toren zakken?|Rapunzel',
  'Talen@Welke taal spreekt men in Oostenrijk?|Duits@Welke taal spreekt men in Mexico?|Spaans@Welke taal spreekt men in Brazilië?|Portugees@Welke taal spreekt men in Egypte?|Arabisch@Welke taal spreekt men in Iran?|Perzisch'];
 const isH=net.isHost,me=net.me.id,LSK='sp_jeop_own',TB=15000,TA=10000,TR=3500;
 const css=E('style','',`.jp-pl{display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:0 0 8px}.jp-ch{display:inline-flex;align-items:center;padding:2px 10px 2px 2px;border-radius:99px;border:2px solid var(--c);background:var(--bg);font-size:13px;font-weight:700}
 .jp-ch.on{background:color-mix(in srgb,var(--c) 22%,var(--bg))}.jp-st{font-weight:700;margin:6px 0;min-height:22px}
 .jp-b{display:grid;grid-template-columns:repeat(5,1fr);gap:4px;max-width:560px;margin:6px auto}.jp-h{font-size:11px;font-weight:800;line-height:1.1;display:flex;align-items:center;justify-content:center;min-height:44px;padding:2px;border-radius:8px;background:#060c5c;color:#fff;word-break:break-word;hyphens:auto}
 .jp-t{min-height:48px;border:0;border-radius:8px;background:#2336b8;color:#ffd166;font:inherit;font-size:18px;font-weight:900;cursor:pointer}.jp-t:disabled{cursor:default}.jp-t.u{background:var(--bg);color:transparent;border:1px dashed var(--ln)}
 .jp-q{border-radius:16px;padding:14px;background:linear-gradient(135deg,#060c5c,#2336b8);color:#fff;margin:6px 0}.jp-q small{color:#ffd166;font-weight:800}.jp-q p{font-size:19px;font-weight:700;margin:8px 0 0;line-height:1.3}
 .jp-bz{width:150px;height:150px;border-radius:50%;border:0;margin:10px auto;display:block;font:inherit;font-size:22px;font-weight:900;color:#fff;background:radial-gradient(circle at 35% 30%,#ff6b6b,#c1121f);box-shadow:0 8px 0 #7a0c14;cursor:pointer;touch-action:manipulation}
 .jp-bz:active{transform:translateY(4px);box-shadow:0 4px 0 #7a0c14}.jp-bz:disabled{filter:grayscale(1);opacity:.5;cursor:default}
 .jp-o{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:8px 0}.jp-o .btn{white-space:normal;min-height:52px;font-size:15px}.jp-o .btn.x{background:#9a9aa5;text-decoration:line-through}.jp-o .btn.ok{background:#2a9d8f}
 .jp-row{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:8px 0}.jp-in{padding:9px 10px;border:1px solid var(--ln);border-radius:10px;background:var(--bg);color:var(--tx);font:inherit;font-size:15px;min-width:0;width:100%;box-sizing:border-box}
 .jp-ed{text-align:left;max-width:560px;margin:0 auto}.jp-ed .qq{border-top:1px solid var(--ln);padding:8px 0;display:grid;gap:4px}.jp-ed b{font-size:13px;color:var(--ac)}`);
 const plRow=E('div','jp-pl'),sc=E('div','sc'),stat=E('div','jp-st'),main=E('div');
 st.append(css,sc,plRow,stat,main,E('div','hint','Wie aan de beurt is kiest een vakje · iedereen buzzt (knop of spatie) · 1–4 kiest een antwoord'));
 let V=null,lEnd=0,podDone=0,edC=0,mode=null;
 const pn=id=>{const q=V&&V.pl.find(p=>p.id===id);return q?q.av+' '+q.n:net.pname(id)};
 const B=(l,fn,cls)=>{const b=E('button','btn'+(cls?' '+cls:''),l);b.onclick=fn;return b};
 // ---------- render ----------
 function render(){if(!V)return;const v=V,mine=v.pl.find(p=>p.id===me);
  plRow.replaceChildren(...v.pl.slice().sort((a,b)=>b.sc-a.sc).map(p=>{const d=E('div','jp-ch'+(p.id===v.ctl?' on':''));d.style.setProperty('--c',p.col);const a=E('span','pav s');a.style.setProperty('--c',p.col);a.textContent=p.av;
   const t=E('span');t.textContent=(p.id===v.ctl&&v.ph!=='end'?'👉 ':'')+p.n+(p.id===me?' (jij)':'')+' · '+p.sc;d.append(a,t);return d}));
  sc.textContent=mine?'Jij: '+net.pname(me)+' · '+mine.sc+' pt':v.ph==='setup'?'':'👀 Je kijkt mee';main.replaceChildren();
  if(v.ph==='setup'){if(!isH){stat.textContent='⏳ De host kiest de vragen…';return}stat.textContent='Kies de vragen';if(mode==='ed')return editor();
   const r=E('div','jp-row');r.append(B('▶ Start met ingebouwde vragen',()=>hStart(0)),B('✏️ Eigen vragen',()=>{mode='ed';render()},'sec'));main.append(r,E('p','hint','Ingebouwd: 5 willekeurige categorieën uit '+BANK.length+'.'));return}
  if(v.ph==='board'||v.ph==='end'){const my=v.ctl===me&&v.ph==='board';stat.textContent=v.ph==='end'?'🏁 Het bord is leeg!':my?'👉 Jij mag een vakje kiezen':pn(v.ctl)+' kiest een vakje…';
   if(v.msg)main.append(Object.assign(E('p','hint'),{textContent:v.msg}));
   const b=E('div','jp-b');b.style.gridTemplateColumns='repeat('+v.cats.length+',1fr)';v.cats.forEach(c=>{const h=E('div','jp-h');h.textContent=c;if(v.cats.length>3){const L=Math.max(...c.split(' ').map(w=>w.length));h.style.fontSize=L>11?'8.5px':L>8?'9.5px':''}b.append(h)});
   for(let r=0;r<5;r++)v.cats.forEach((c,ci)=>{const t=E('button','jp-t'),ok=v.has[ci][r]&&!v.used[ci][r];t.textContent=ok?(r+1)*100:'';if(!ok)t.classList.add('u');t.disabled=!(ok&&my);if(!t.disabled)t.onclick=()=>send({k:'pk',c:ci,r});b.append(t)});
   main.append(b);if(v.ph==='end'&&!podDone){podDone=1;const s={};v.pl.forEach(p=>s[p.id]=p.sc);const top=v.pl.slice().sort((a,b)=>b.sc-a.sc);net.result({winner:top.length&&(top.length<2||top[0].sc>top[1].sc)?top[0].id:null,scores:s,unit:' pt'})}return}
  const c=v.cur,q=E('div','jp-q');q.innerHTML='<small></small><p></p>';q.querySelector('small').textContent=v.cats[c.c]+' · '+c.val;q.querySelector('p').textContent=c.q;main.append(q);
  const amB=v.buzz===me,locked=(v.locked||[]).includes(me);
  if(v.ph==='buzz'){stat.innerHTML='🔔 Buzz als je het weet! <span class="tm"></span>';const z=E('button','jp-bz','BUZZ!');z.disabled=!mine||locked;z.onclick=()=>send({k:'bz'});main.append(z);if(locked)main.append(E('p','hint','Jij hebt al geantwoord op deze vraag'))}
  else if(v.ph==='ans'){stat.innerHTML='';stat.textContent=(amB?'⚡ Jij mag antwoorden!':'⚡ '+pn(v.buzz)+' antwoordt…');stat.append(Object.assign(E('span','tm'),{textContent:''}))}
  else if(v.ph==='judge'){stat.textContent='⚖️ '+(isH?'Is het antwoord van '+pn(v.buzz)+' juist?':'De host beoordeelt het antwoord…')}
  else if(v.ph==='rev'){stat.textContent=v.res&&v.res.ok?'✅ '+pn(v.res.id)+' had het juist! +'+c.val:'Het juiste antwoord was:'}
  if(c.opts&&(v.ph==='ans'||v.ph==='buzz'&&(v.wrong||[]).length||v.ph==='rev')){const o=E('div','jp-o');c.opts.forEach((t,i)=>{const b=B((i+1)+'. '+t,()=>send({k:'an',i}));
    if((v.wrong||[]).includes(i))b.classList.add('x');if(v.ph==='rev'&&v.sol===t)b.classList.add('ok');b.disabled=!(v.ph==='ans'&&amB)||(v.wrong||[]).includes(i);o.append(b)});main.append(o)}
  if(!c.opts&&v.ph==='ans'&&amB){const r=E('div','jp-row'),i=E('input','jp-in');i.maxLength=40;i.placeholder='Typ je antwoord';i.autocomplete='off';const go=()=>send({k:'an',t:i.value});i.onkeydown=e=>{if(e.key==='Enter')go()};r.append(i,B('Antwoord',go));main.append(r);setTimeout(()=>i.focus(),0)}
  if(v.ph==='judge'){main.append(Object.assign(E('p'),{textContent:'Antwoord: “'+(v.typed||'')+'”'}));if(isH&&v.sol!=null){main.append(Object.assign(E('p','hint'),{textContent:'Juist antwoord: '+v.sol}));const r=E('div','jp-row');r.append(B('✔ Juist',()=>send({k:'ju',ok:1})),B('✘ Fout',()=>send({k:'ju',ok:0}),'sec'));main.append(r)}}
  if(v.ph==='rev'&&!(c.opts)){main.append(Object.assign(E('p','jp-st'),{textContent:'💡 '+v.sol}))}
  if(v.ph==='rev'&&c.opts&&!(v.res&&v.res.ok))main.append(Object.assign(E('p','jp-st'),{textContent:'💡 '+v.sol}));
  if((v.log||[]).length)main.append(Object.assign(E('p','hint'),{textContent:v.log.join(' · ')}));tick()}
 function tick(){const t=st.querySelector('.jp-st .tm');if(t){const s=Math.max(0,Math.ceil((lEnd-performance.now())/1000));t.textContent=' ⏱ '+s}}
 // ---------- editor (alleen host, opgeslagen in localStorage) ----------
 function loadOwn(){let d=null;try{d=JSON.parse(localStorage.getItem(LSK)||'null')}catch(e){}if(!Array.isArray(d))d=[];for(let i=0;i<5;i++){d[i]=d[i]||{n:'',q:[]};for(let j=0;j<5;j++)d[i].q[j]=d[i].q[j]||{q:'',a:'',w:''}}return d.slice(0,5)}
 let OWN=null;const save=()=>{try{localStorage.setItem(LSK,JSON.stringify(OWN))}catch(e){}};
 function editor(){OWN=OWN||loadOwn();const ed=E('div','jp-ed'),tabs=E('div','jp-row');for(let i=0;i<5;i++){const t=B(OWN[i].n?OWN[i].n.slice(0,8):'Cat. '+(i+1),()=>{edC=i;render()},i===edC?'':'sec');t.style.padding='8px 10px';tabs.append(t)}
  const c=OWN[edC],inp=(val,ph,set)=>{const x=E('input','jp-in');x.value=val;x.placeholder=ph;x.maxLength=120;x.oninput=()=>{set(x.value);save()};return x};
  ed.append(tabs,inp(c.n,'Naam van categorie '+(edC+1),v=>c.n=v));
  c.q.forEach((q,j)=>{const d=E('div','qq');d.append(Object.assign(E('b'),{textContent:(j+1)*100+' punten'}),inp(q.q,'Vraag',v=>q.q=v),inp(q.a,'Juist antwoord',v=>q.a=v),inp(q.w,'3 foute antwoorden, gescheiden door ; (leeg = open vraag)',v=>q.w=v));ed.append(d)});
  const r=E('div','jp-row');r.append(B('▶ Start met eigen vragen',()=>hStart(1)),B('‹ Terug',()=>{mode=null;render()},'sec'));
  main.append(ed,r,E('p','hint','Lege vragen en categorieën worden overgeslagen. Bij een open vraag typt de speler het antwoord en beoordeel jij met ✔/✘.'))}
 function send(d){if(isH)act(me,d);else net.send(d)}
 // ---------- host ----------
 let H=null,rnd=null;const by=id=>H.pl.find(p=>p.id===id);
 function pubV(){const c=H.cur,v={k:'s',ph:H.ph,pl:H.pl,cats:H.cats.map(x=>x.n),has:H.cats.map(x=>x.q.map(Boolean)),used:H.used,ctl:H.ctl,buzz:H.buzz,locked:H.locked,wrong:H.wrong,typed:H.typed,res:H.res,msg:H.msg,log:H.log,tl:Math.max(0,H.end-Date.now())};
  if(c)v.cur={c:c.c,r:c.r,val:c.val,q:c.q.q,opts:c.q.opts||null};if(H.ph==='rev')v.sol=c.q.a;return v}
 function pub(){const v=pubV();net.send(v);if(H.ph==='judge')v.sol=H.cur.q.a;V=v;lEnd=performance.now()+v.tl;render();botsJ()}
 // bots (host): kiezen als ze aan de beurt zijn een willekeurig vrij vakje, buzzen (~75%) na een willekeurige vertraging en antwoorden ~55% juist.
 // Eén timerset, opnieuw gepland zodra de toestand verandert (window.__botT = tempo voor tests).
 let bKey='',bTm=[];
 function botsJ(){const k=[H.ph,H.ctl,H.cur?H.cur.c+'.'+H.cur.r:'',H.buzz,H.locked.length,H.wrong.length].join('|');if(k===bKey)return;bKey=k;bTm.forEach(clearTimeout);bTm=[];
  const f=window.__botT>0?window.__botT:1,later=(ms,fn)=>bTm.push(setTimeout(()=>{if(bKey===k&&H)fn()},ms*f));
  if(H.ph==='board'&&net.isBot(H.ctl))later(900+Math.random()*1600,()=>{const fr=[];H.cats.forEach((c,ci)=>c.q.forEach((q,r)=>{if(q&&!H.used[ci][r])fr.push([ci,r])}));if(fr.length){const[c,r]=fr[Math.floor(Math.random()*fr.length)];net.botAct(H.ctl,{k:'pk',c,r})}});
  else if(H.ph==='buzz')H.pl.forEach(p=>{if(!net.isBot(p.id)||H.locked.includes(p.id)||Math.random()<.25)return;later(1200+Math.random()*5500,()=>net.botAct(p.id,{k:'bz'}))});
  else if(H.ph==='ans'&&net.isBot(H.buzz)){const id=H.buzz,q=H.cur.q;later(1000+Math.random()*2500,()=>{
   if(q.opts){const ok=Math.random()<.55,wr=q.opts.map((t,i)=>i).filter(i=>q.opts[i]!==q.a&&!H.wrong.includes(i));net.botAct(id,{k:'an',i:ok||!wr.length?q.opts.indexOf(q.a):wr[Math.floor(Math.random()*wr.length)]})}
   else net.botAct(id,{k:'an',t:Math.random()<.55?q.a:'Geen idee'})})}}
 const shuf=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
 function hStart(own){let cats;
  if(own){OWN=OWN||loadOwn();cats=OWN.map(c=>({n:c.n.trim(),q:c.q.map(q=>{if(!q.q.trim()||!q.a.trim())return null;const w=q.w.split(/[;\n]/).map(s=>s.trim()).filter(Boolean).slice(0,3);return{q:q.q.trim(),a:q.a.trim(),opts:w.length===3?shuf([q.a.trim(),...w]):null}})})).filter(c=>c.n&&c.q.some(Boolean));
   if(!cats.length){stat.textContent='⚠️ Vul minstens één categorie met een naam en een vraag + antwoord in';return}}
  else cats=shuf(BANK.slice()).slice(0,5).map(s=>{const[n,...qs]=s.split('@'),qa=qs.map(x=>x.split('|'));return{n,q:qa.map(([q,a,...w])=>{const pool=w.length===3?w:shuf(qa.map(x=>x[1]).filter(x=>x!==a)).slice(0,3);return{q,a,opts:shuf([a,...pool])}})}});
  H.cats=cats;H.used=cats.map(()=>[0,0,0,0,0]);H.ph='board';H.ctl=H.pl[Math.floor(rnd()*H.pl.length)].id;H.msg='';mode=null;pub()}
 function left(){return H.cats.some((c,i)=>c.q.some((q,j)=>q&&!H.used[i][j]))}
 function toRev(res){H.ph='rev';H.res=res;if(res&&res.ok)H.ctl=res.id;H.end=Date.now()+TR;pub()}
 function wrongAns(id,i){const p=by(id);if(p)p.sc-=H.cur.val;H.log.push('❌ '+(p?p.av+' '+p.n:'?')+' −'+H.cur.val);H.locked.push(id);if(i!=null)H.wrong.push(i);H.buzz=null;reopen()}
 function reopen(){const free=H.pl.filter(p=>!H.locked.includes(p.id));if(!free.length||(H.cur.q.opts&&H.wrong.length>=3))return toRev(null);H.ph='buzz';H.end=Date.now()+TA;pub()}
 function act(from,d){if(!H||!d)return;const p=by(from);if(!p)return;
  if(d.k==='pk'&&H.ph==='board'&&from===H.ctl){const c=d.c|0,r=d.r|0,q=H.cats[c]&&H.cats[c].q[r];if(!q||H.used[c][r])return;H.used[c][r]=1;H.cur={c,r,val:(r+1)*100,q};H.locked=[];H.wrong=[];H.buzz=null;H.typed='';H.res=null;H.log=[];H.ph='buzz';H.end=Date.now()+TB;pub()}
  else if(d.k==='bz'&&H.ph==='buzz'&&!H.locked.includes(from)){H.buzz=from;H.ph='ans';H.end=Date.now()+TA;beep(880,.12,'square',.05);pub()}
  else if(d.k==='an'&&H.ph==='ans'&&from===H.buzz){if(H.cur.q.opts){const i=d.i|0;if(i<0||i>3||H.wrong.includes(i))return;if(H.cur.q.opts[i]===H.cur.q.a){p.sc+=H.cur.val;toRev({id:from,ok:1})}else wrongAns(from,i)}
   else{H.typed=String(d.t||'').slice(0,40);H.ph='judge';pub()}}
  else if(d.k==='ju'&&H.ph==='judge'&&from===me){if(d.ok){const b=by(H.buzz);if(b)b.sc+=H.cur.val;toRev({id:H.buzz,ok:1})}else wrongAns(H.buzz,null)}}
 function hTick(){if(!H||Date.now()<H.end)return;if(H.ph==='buzz')toRev(null);else if(H.ph==='ans')wrongAns(H.buzz,null);
  else if(H.ph==='rev'){H.cur=null;H.res=null;H.log=[];H.msg='';if(left()){H.ph='board';pub()}else{H.ph='end';pub()}}}
 const keyH=e=>{if(e.target.tagName==='INPUT'||!V)return;if(e.key===' '&&V.ph==='buzz'){e.preventDefault();send({k:'bz'})}else if(/^[1-4]$/.test(e.key)&&V.ph==='ans'&&V.buzz===me&&V.cur.opts)send({k:'an',i:+e.key-1})};addEventListener('keydown',keyH);
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;if(isH){if(d.k==='hi'){if(H)net.sendTo(from,pubV())}else act(from,d)}else if(d.k==='s'){const ch=!V||V.ph!==d.ph;V=d;lEnd=performance.now()+(d.tl||0);if(ch&&d.ph==='ans')beep(880,.1,'square',.04);render()}});
 const offP=net.onPlayers(ps=>{if(!isH||!H)return;const ids=new Set(ps.map(p=>p.id)),gone=H.pl.filter(p=>!ids.has(p.id));if(!gone.length)return pub();
  H.pl=H.pl.filter(p=>ids.has(p.id));gone.forEach(p=>H.msg='🚪 '+p.av+' '+p.n+' heeft het spel verlaten');if(!H.pl.length)return;
  if(gone.some(p=>p.id===H.ctl))H.ctl=H.pl[0].id;if(H.ph==='setup')return pub();
  if((H.ph==='ans'||H.ph==='judge')&&gone.some(p=>p.id===H.buzz)){H.buzz=null;return reopen()}if(H.ph==='buzz')return reopen();pub()});
 const ti=setInterval(tick,250);let tm=0;
 if(isH){rnd=net.rng();H={ph:'setup',pl:net.players.map(p=>({id:p.id,n:p.name,av:p.av,col:p.col,sc:0})),cats:[],used:[],ctl:me,cur:null,locked:[],wrong:[],buzz:null,typed:'',res:null,msg:'',log:[],end:0};
  if(window.SPZ_PEER)window.__dbg={get H(){return H}};tm=setInterval(hTick,200);pub()}
 else{net.send({k:'hi'});sc.textContent='Wachten op de host…'}
 return()=>{off();offP();clearInterval(ti);clearInterval(tm);bTm.forEach(clearTimeout);removeEventListener('keydown',keyH);if(window.__dbg)delete window.__dbg}}},
