{id:'tanks',n:'Tankgevecht',e:'🪖',c:'Samen',g:'#3a6186,#89253e',min:2,max:2,bots:true,run(st,net){
 // Top-down tankduel: host start linksonder, joiner rechtsboven; elke tank in de spelerskleur. Host simuleert; joiner stuurt een toetsenmasker + schietcommando's.
 const W=360,H=360,TR=13,WIN=5,me=net.myIndex(),HOST=net.isHost;
 const COL=['#2f80ed','#f4a261'],names=['…','…'],ids=[null,null];
 const hx=h=>[1,3,5].map(i=>parseInt(String(h).slice(i,i+2),16)||0),mix=(h,t)=>'rgb('+hx(h).map(q=>Math.round(q+(255-q)*t)).join(',')+')';
 const WALLS=[[150,150,60,60],[70,100,16,60],[274,200,16,60],[100,70,60,16],[200,274,60,16]],SPAWN=[[45,315,-Math.PI/2],[315,45,Math.PI/2]];
 const sc=E('div','sc'),c=mkCanvas(st,W,H),x=c.getContext('2d');st.prepend(sc);
 st.append(E('div','hint','↺ ↻ draaien · ▲ ▼ rijden (of pijltjes / WASD) · spatie / 🔥 schieten (1× stuiteren) · eerste tot 5 treffers wint'));
 const clamp=(v,a,b)=>v<a?a:v>b?b:v;let gone=0,left='',last=null,fl=0,parts=[],acc=0,sentM=-1,ended=0;
 const mkT=i=>({x:SPAWN[i][0],y:SPAWN[i][1],a:SPAWN[i][2],l:3,inv:2,dead:0,cool:0});
 let S={t:[mkT(0),mkT(1)],sh:[],s:[0,0],w:-1,h:0,f:0},mask=[0,0],req=[0,0],vel=[];
 const inp=input(st,[['↺','ArrowLeft'],['▲','ArrowUp'],['▼','ArrowDown'],['↻','ArrowRight'],['🔥',' ']],k=>{if(k===' '||k==='f'){if(HOST)req[0]=1;else net.send({k:'f'})}});
 const sub=()=>HOST?'Druk op 🔄 Opnieuw voor een nieuw spel':'De host kan opnieuw starten';
 function ov(big,small){if(!big){overlay(st,c,'');return}const o=overlay(st,c,' ');o.replaceChildren();const a=E('div');a.textContent=big;const b=E('div');b.style.cssText='font-size:15px;font-weight:600';b.textContent=small||'';o.append(a,b);o.style.pointerEvents='none'}
 function refresh(){if(gone)ov(left?'⚠️ '+left+' heeft het spel verlaten':'Wachten op speler…',sub());else ov('')}
 function line(){sc.replaceChildren();[0,1].forEach(i=>{const s=E('span');s.style.color=COL[i];s.textContent=(i?'♥'.repeat(S.t[1].l)+' ':'')+names[i]+(i===me?' (jij)':'')+(i?'':' '+'♥'.repeat(S.t[0].l));sc.append(s);if(!i){const m=E('span');m.textContent='  '+S.s[0]+' – '+S.s[1]+'  ';sc.append(m)}});
  if(S.w>=0){const w=E('span');w.style.color='var(--mu)';w.textContent=' · 🏆 '+names[S.w]+' wint';sc.append(w)}}
 function conn(){net.players.forEach((p,i)=>{if(i>1)return;names[i]=net.pname(p);COL[i]=net.pcol(p);ids[i]=p.id});const was=gone;if(net.players.length<2){gone=1;if(!was)left=names[1-me]==='…'?'':names[1-me]}else{gone=0;left=''}refresh();line()}
 function endCheck(){if(S.w<0||ended)return;ended=1;line();net.result({winner:ids[S.w],scores:{[ids[0]]:S.s[0],[ids[1]]:S.s[1]},unit:' treffers',text:'Eerste tot '+WIN+' treffers'})}
 const hitW=(px,py,r)=>{if(px<r||px>W-r||py<r||py>H-r)return 1;for(const[wx,wy,ww,wh]of WALLS){const dx=px-clamp(px,wx,wx+ww),dy=py-clamp(py,wy,wy+wh);if(dx*dx+dy*dy<r*r)return 1}return 0};
 function fire(i){const t=S.t[i];if(t.dead>0||t.cool>0||S.sh.filter(s=>s.o===i).length>=3)return;t.cool=.45;
  S.sh.push({x:t.x+Math.cos(t.a)*(TR+8),y:t.y+Math.sin(t.a)*(TR+8),vx:Math.cos(t.a)*270,vy:Math.sin(t.a)*270,b:1,o:i,tl:3});S.f++}
 function boom(i,by){const t=S.t[i];t.l--;t.dead=1.2;S.h++;S.s[by]++;if(S.s[by]>=WIN)S.w=by}
 function step(dt){for(let i=0;i<2;i++){const t=S.t[i],m=mask[i];t.cool-=dt;
   if(t.dead>0){t.dead-=dt;if(t.dead<=0){t.dead=0;if(t.l<=0)t.l=3;const sp=SPAWN[i];t.x=sp[0];t.y=sp[1];t.a=sp[2];t.inv=2;line()}continue}
   t.inv-=dt;if(m&1)t.a-=3.2*dt;if(m&2)t.a+=3.2*dt;
   const v=(m&4?110:0)-(m&8?75:0);if(v){const nx=t.x+Math.cos(t.a)*v*dt,ny=t.y+Math.sin(t.a)*v*dt,o=S.t[1-i];
    if(!hitW(nx,t.y,TR)&&!(o.dead<=0&&Math.hypot(nx-o.x,t.y-o.y)<2*TR))t.x=nx;if(!hitW(t.x,ny,TR)&&!(o.dead<=0&&Math.hypot(t.x-o.x,ny-o.y)<2*TR))t.y=ny}
   if(req[i]||(m&16)){req[i]=0;fire(i)}}
  for(const s of S.sh){s.tl-=dt;const nx=s.x+s.vx*dt,ny=s.y+s.vy*dt;
   if(hitW(nx,s.y,3)){s.vx=-s.vx;s.b--}else s.x=nx;if(hitW(s.x,ny,3)){s.vy=-s.vy;s.b--}else s.y=ny;
   if(s.b<0||s.tl<=0){s.tl=0;continue}
   for(let i=0;i<2;i++){const t=S.t[i];if(t.dead>0||t.inv>0||s.o===i)continue;if(Math.hypot(s.x-t.x,s.y-t.y)<TR+3){s.tl=0;boom(i,s.o);break}}}
  S.sh=S.sh.filter(s=>s.tl>0)}
 const snap=()=>({h:S.h,f:S.f,w:S.w,d:S.t.map(t=>t.dead>0),s:S.s.join()});
 function fx(){const n=snap();if(last){
  if(n.f!==last.f)beep(900,.05,'square',.025);
  if(n.h!==last.h){fl=1;n.d.forEach((d,i)=>{if(d&&!last.d[i]){const t=S.t[i];beep(i===me?140:520,.3,'sawtooth',.05);for(let k=0;k<26;k++){const a=Math.random()*7,v=40+Math.random()*160;parts.push({x:t.x,y:t.y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:.5+Math.random()*.6,c:k%3?(k%2?COL[i]:mix(COL[i],.4)):'#fff'})}}})}
  if(n.s!==last.s)line();if(n.w!==last.w)beep(n.w===me?880:220,.4,'triangle',.05)}last=n;endCheck()}
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;
  if(HOST){if(from!==net.players[1]?.id)return;if(d.k==='i')mask[1]=(+d.m||0)&31;else if(d.k==='f')req[1]=1}
  else if(d.k==='s'){const v=d.t;S.t=[0,1].map(i=>({x:v[i*6],y:v[i*6+1],a:v[i*6+2],l:v[i*6+3],inv:v[i*6+4],dead:v[i*6+5],cool:0}));
   S.sh=[];for(let i=0;i<d.sh.length;i+=3)S.sh.push({x:d.sh[i],y:d.sh[i+1],o:d.sh[i+2]});S.s=d.s;S.w=d.w;S.h=d.h;S.f=d.f}});
 const offP=net.onPlayers(conn);
 function tank(t,i){if(t.dead>0)return;const col=COL[i],lt=mix(col,.5);x.save();x.translate(t.x,t.y);x.rotate(t.a);if(t.inv>0)x.globalAlpha=Math.floor(t.inv*10)%2?.35:.8;
  x.fillStyle='#232848';x.fillRect(-13,-13,26,6);x.fillRect(-13,7,26,6);x.strokeStyle='#3b4270';x.lineWidth=1;x.strokeRect(-12.5,-12.5,25,5);x.strokeRect(-12.5,7.5,25,5);
  x.shadowColor=mix(col,.2);x.shadowBlur=10;x.fillStyle=col;x.beginPath();x.roundRect(-11,-9,22,18,4);x.fill();x.shadowBlur=0;x.strokeStyle=lt;x.lineWidth=1.5;x.beginPath();x.roundRect(-11,-9,22,18,4);x.stroke();
  x.fillStyle='rgba(0,0,0,.35)';x.fillRect(-4,-2,22,4);x.fillStyle='#fff';x.fillRect(-3,-2,22,3);x.fillStyle=col;x.beginPath();x.arc(0,0,7,0,7);x.fill();x.strokeStyle=lt;x.lineWidth=1.5;x.stroke();x.fillStyle='rgba(255,255,255,.45)';x.beginPath();x.arc(-2,-2,3,0,7);x.fill();x.restore()}
 function draw(dt){x.fillStyle='#0e1020';x.fillRect(0,0,W,H);x.strokeStyle='#161b36';x.lineWidth=1;x.beginPath();for(let i=30;i<W;i+=30){x.moveTo(i+.5,0);x.lineTo(i+.5,H);x.moveTo(0,i+.5);x.lineTo(W,i+.5)}x.stroke();
  for(const[wx,wy,ww,wh]of WALLS){x.fillStyle='#3b4270';x.beginPath();x.roundRect(wx,wy,ww,wh,3);x.fill();x.fillStyle='#515a8f';x.fillRect(wx+2,wy+2,ww-4,3)}
  x.strokeStyle='#3b4270';x.lineWidth=4;x.strokeRect(2,2,W-4,H-4);
  S.t.forEach(tank);
  for(const s of S.sh){x.shadowColor=mix(COL[s.o],.3);x.shadowBlur=12;x.fillStyle=mix(COL[s.o],.7);x.beginPath();x.arc(s.x,s.y,3.5,0,7);x.fill();x.shadowBlur=0}
  for(const p of parts){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.96;p.vy*=.96;p.l-=dt;x.globalAlpha=Math.min(1,p.l*2);x.fillStyle=p.c;x.fillRect(p.x-2,p.y-2,4,4)}x.globalAlpha=1;parts=parts.filter(p=>p.l>0);
  if(fl>0){x.fillStyle='rgba(255,255,255,'+(fl*.15)+')';x.fillRect(0,0,W,H);fl-=dt*3}
  x.font='bold 12px system-ui,sans-serif';x.shadowColor='#000';x.shadowBlur=4;x.fillStyle=mix(COL[0],.4);x.textAlign='left';x.fillText(names[0],8,H-8);x.fillStyle=mix(COL[1],.4);x.textAlign='right';x.fillText(names[1],W-8,16);x.shadowBlur=0}
 // ---- bot (alleen op de host): mikt met een zwevende fout, rijdt via een tussenpunt naar zicht op de tegenstander, houdt afstand,
 // ontwijkt muren en schiet als hij ongeveer gericht staat. Stuurt hetzelfde toetsenmasker {k:'i',m} als een joiner (max. 10×/s).
 let bT=0,bM=-1,bErr=0,bErrT=0,wp=null,wpT=0,bRev=0,bLast=null,bStuck=0;
 const angN=a=>Math.atan2(Math.sin(a),Math.cos(a));
 const los=(ax,ay,bx,by,r)=>{const d=Math.hypot(bx-ax,by-ay),n=Math.ceil(d/5);for(let k=1;k<n;k++){const f=k/n;if(hitW(ax+(bx-ax)*f,ay+(by-ay)*f,r))return 0}return 1};
 function pickWp(t,o){let best=null,bs=1e9;for(let px=24;px<=W-24;px+=21)for(let py=24;py<=H-24;py+=21){if(hitW(px,py,TR+4))continue;
   const sh=los(px,py,o.x,o.y,4),pa=los(t.x,t.y,px,py,TR-2);if(!pa)continue;const sc=Math.hypot(px-t.x,py-t.y)+(sh?0:400)+Math.abs(Math.hypot(px-o.x,py-o.y)-150)*.5+Math.random()*30;if(sc<bs){bs=sc;best=[px,py]}}
  return best||[W/2+(Math.random()-.5)*200,H/2+(Math.random()-.5)*200]}
 function botTick(dt){const b=net.players[1];if(!b||!net.isBot(b.id)||gone||S.w>=0)return;bT+=dt;if(bT<.1)return;const st=bT;bT=0;
  const t=S.t[1],o=S.t[0];let m=0;
  if(t.dead<=0){bErrT-=st;if(bErrT<=0){bErrT=.5+Math.random()*.9;bErr=(Math.random()-.5)*.28}
   const dx=o.x-t.x,dy=o.y-t.y,dist=Math.hypot(dx,dy),see=o.dead<=0&&los(t.x,t.y,o.x,o.y,4);let goal=t.a,mv=0;
   if(bRev>0){bRev-=st;m=8|(bRev>.25?2:0)}
   else{if(see){wp=null;goal=Math.atan2(dy,dx)+bErr;const e=angN(goal-t.a);if(dist>200&&Math.abs(e)<.5)mv=1;else if(dist<95&&Math.abs(e)<.9)mv=-1;if(Math.abs(e)<.2&&o.inv<=0)m|=16}
    else{wpT-=st;if(!wp||wpT<=0||Math.hypot(wp[0]-t.x,wp[1]-t.y)<16){wp=pickWp(t,o);wpT=3}goal=Math.atan2(wp[1]-t.y,wp[0]-t.x);if(Math.abs(angN(goal-t.a))<.55)mv=1}
    const e=angN(goal-t.a);if(e>.16)m|=2;else if(e<-.16)m|=1;
    if(mv>0&&hitW(t.x+Math.cos(t.a)*20,t.y+Math.sin(t.a)*20,TR)){mv=0;wp=null}
    if(mv>0)m|=4;else if(mv<0&&!hitW(t.x-Math.cos(t.a)*20,t.y-Math.sin(t.a)*20,TR))m|=8;
    // vast? even achteruit en draaien
    if(bLast&&(m&12)&&Math.hypot(t.x-bLast[0],t.y-bLast[1])<.8){if((bStuck+=st)>.6){bStuck=0;bRev=.6;wp=null}}else bStuck=0}
   bLast=[t.x,t.y]}
  if(m!==bM){bM=m;net.botAct(b.id,{k:'i',m})}}
 const stop=loop(dt=>{
  const m=(inp.has('ArrowLeft')||inp.has('a')?1:0)|(inp.has('ArrowRight')||inp.has('d')?2:0)|(inp.has('ArrowUp')||inp.has('w')?4:0)|(inp.has('ArrowDown')||inp.has('s')?8:0)|(inp.has(' ')?16:0);
  if(HOST){mask[0]=m;if(!gone&&S.w<0){step(dt);botTick(dt)}acc+=dt;if(acc>=.04){acc=Math.min(acc-.04,.04);const r1=v=>Math.round(v*10)/10;
    net.send({k:'s',t:S.t.flatMap(t=>[r1(t.x),r1(t.y),Math.round(t.a*100)/100,t.l,r1(t.inv),r1(t.dead)]),sh:S.sh.flatMap(s=>[r1(s.x),r1(s.y),s.o]),s:S.s,w:S.w,h:S.h,f:S.f})}}
  else if(m!==sentM){sentM=m;net.send({k:'i',m})}
  fx();draw(dt)});
 conn();line();window.__dbg={s:()=>JSON.parse(JSON.stringify(S)),mask:()=>mask.slice()};
 return()=>{stop();inp.stop();off();offP();delete window.__dbg}}},
