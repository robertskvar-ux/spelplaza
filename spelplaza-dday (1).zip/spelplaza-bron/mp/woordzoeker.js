{id:'woordzoeker',n:'Woordzoeker samen',e:'🔍',c:'Samen',g:'#ee9ca7,#ffdde1',min:2,max:4,bots:true,run(st,net){
 // Woordzoeker-race: host kiest categorie, iedereen zoekt in hetzelfde 12×12 rooster (seed), host valideert en crediteert (patroon A).
 const TH={
  'Dieren':'HOND,PAARD,SCHAAP,GEIT,KONIJN,OLIFANT,GIRAF,LEEUW,TIJGER,ZEBRA,PANDA,VOGEL,VLINDER,SLANG,KIKKER,DOLFIJN,WALVIS,HAAI,BEER,WOLF,EGEL,MUIS,EEND,HERT,KROKODIL,SCHILDPAD,KAMEEL,PAPEGAAI',
  'Eten & drinken':'BROOD,KAAS,APPEL,PEER,BANAAN,MELK,KOFFIE,THEE,WATER,SOEP,PIZZA,PASTA,RIJST,AARDAPPEL,WORTEL,TOMAAT,KOMKOMMER,SUIKER,BOTER,CHOCOLADE,KOEKJE,TAART,FRIET,SALADE,YOGHURT,HONING,DRUIF,CITROEN,SPINAZIE,KERS',
  'Natuur':'BOOM,BLOEM,GRAS,RIVIER,BERG,STRAND,WOLK,REGEN,SNEEUW,STORM,WIND,STEEN,ZAND,EILAND,BLAD,WOUD,HEUVEL,VULKAAN,WATERVAL,OCEAAN,WOESTIJN,REGENBOOG,BLIKSEM,DONDER,MAAN,STER,LUCHT,AARDE,DAUW,MIST,KUST,DUIN,POLDER,WEIDE,AKKER',
  'Sport':'VOETBAL,TENNIS,HOCKEY,ZWEMMEN,FIETSEN,LOPEN,SCHAATSEN,BASKETBAL,VOLLEYBAL,GOLF,JUDO,KARATE,BOKSEN,TURNEN,DANSEN,RUGBY,HANDBAL,HONKBAL,SURFEN,ZEILEN,ROEIEN,KLIMMEN,WIELRENNEN,ATLETIEK,BADMINTON,DARTS,DUIKEN,WANDELEN,SPRINTEN,SCHERMEN,SKATEN',
  'Huis':'KEUKEN,BADKAMER,SLAAPKAMER,ZOLDER,KELDER,GARAGE,TUIN,DEUR,RAAM,STOEL,TAFEL,BANK,KAST,LAMP,SPIEGEL,TAPIJT,GORDIJN,KUSSEN,DEKEN,KACHEL,OVEN,KOELKAST,DOUCHE,TOILET,TRAP,MUUR,VLOER,PLAFOND,BALKON,GANG,VENSTER,BUREAU,WASMACHINE,BOEKENKAST,SCHUUR'};
 // Kleuren: elke speler krijgt zijn profielkleur (net.players[i].col), vastgelegd in S.P bij registratie zodat gevonden woorden hun kleur houden als iemand vertrekt.
 const N=12,WANT=10,DIRS=[[0,1],[1,0],[1,1],[-1,1],[0,-1],[-1,0],[-1,-1],[1,-1]];
 const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
 // ---------- DOM ----------
 const sc=E('div','sc'),pan=E('div'),info=E('div','hint'),chips=E('div');pan.style.cssText=chips.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:2px 0 6px';info.style.cssText='min-height:18px;margin:0 0 4px';
 const wrap=E('div');wrap.style.cssText='position:relative;width:min(360px,100%);margin:0 auto';
 const box=E('div');box.style.cssText='position:relative;width:100%;aspect-ratio:1;touch-action:none;user-select:none;-webkit-user-select:none;cursor:pointer;background:var(--bg);border-radius:12px;overflow:hidden';
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox',`0 0 ${N} ${N}`);svg.style.cssText='position:absolute;inset:0;width:100%;height:100%;pointer-events:none';
 const grid=E('div');grid.style.cssText=`position:relative;display:grid;grid-template-columns:repeat(${N},1fr);width:100%;height:100%;font-weight:700;font-size:clamp(13px,4.4vw,19px);color:var(--tx)`;
 const cells=[];for(let i=0;i<N*N;i++){const d=E('div');d.style.cssText='display:flex;align-items:center;justify-content:center;pointer-events:none';cells.push(d);grid.append(d)}
 const ph=E('div','hint','🔍<br>Het rooster verschijnt zodra de categorie gekozen is');ph.style.cssText='position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:15px;padding:20px';box.append(svg,grid,ph);wrap.append(box);
 const list=E('div');list.style.cssText='display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin:10px 0 4px;font-weight:600;font-size:14px';
 st.append(sc,pan,info,chips,wrap,list,E('div','hint','Sleep over een woord (ook schuin) of tik op de eerste en de laatste letter · wie vindt de meeste woorden?'));
 // ---------- toestand ----------
 const me=net.me.id,S={th:null,found:[],P:{},won:0};let g=null,words=[],place=[],t0=0,tm,gone={},drag=null,tapStart=null,temp=null,podDone=0;
 const reg=(q,c)=>({n:q.name,c,av:q.av||'🙂',col:q.col||net.pcol(q),ok:0});
 net.players.forEach((q,k)=>{S.P[q.id]=reg(q,k%4)});
 const colOf=id=>S.P[id]&&S.P[id].col||net.pcol(id),myCol=()=>S.P[me]?colOf(me):'#fff',secs=()=>S.won?S.won:S.th?Math.floor((performance.now()-t0)/1000):0;
 function gen(th){const rnd=net.rng(),R=n=>Math.floor(rnd()*n);
  const build=()=>{const pool=TH[th].split(',');for(let k=pool.length-1;k>0;k--){const j=R(k+1);[pool[k],pool[j]]=[pool[j],pool[k]]}g=Array.from({length:N},()=>Array(N).fill(''));place=[];
   for(const w of pool){if(place.length>=WANT)break;if(w.length>N)continue;let ok=0;
    for(let a=0;a<120&&!ok;a++){const[dr,dc]=DIRS[R(8)],r0=R(N),c0=R(N),r1=r0+dr*(w.length-1),c1=c0+dc*(w.length-1);if(r1<0||r1>=N||c1<0||c1>=N)continue;let f=1;
     for(let i=0;i<w.length;i++){const ch=g[r0+dr*i][c0+dc*i];if(ch&&ch!==w[i]){f=0;break}}if(!f)continue;
     for(let i=0;i<w.length;i++)g[r0+dr*i][c0+dc*i]=w[i];place.push({w,r0,c0,r1,c1});ok=1}}
   return place.length>=WANT};
  while(!build());
  const L='AABCDEEEEGHIIJKLMNNOOPRRSSTTUVWZ';for(let r=0;r<N;r++)for(let c=0;c<N;c++)if(!g[r][c])g[r][c]=L[R(L.length)];
  words=place.map(p=>p.w).sort();ph.remove();for(let r=0;r<N;r++)for(let c=0;c<N;c++)cells[r*N+c].textContent=g[r][c]}
 function setTheme(th){if(S.th||!TH[th])return;S.th=th;t0=performance.now();gen(th);chips.replaceChildren();draw();if(net.isHost)net.bots().forEach(b=>botGo(b.id))}
 // bots (host): vinden elke 10–20 s een nog niet gevonden woord (soms van achter naar voor aangeduid), via {k:'f'} zoals een joiner;
 // stoppen zodra alles gevonden is (window.__botT = tempo voor tests).
 const bTm={};
 function botGo(id){clearTimeout(bTm[id]);bTm[id]=setTimeout(()=>{if(S.won||!g||!net.isBot(id))return;const todo=place.filter(p=>!S.found.some(f=>f.w===p.w));
   if(todo.length){const p=todo[Math.floor(Math.random()*todo.length)],rv=Math.random()<.3;net.botAct(id,rv?{k:'f',r0:p.r1,c0:p.c1,r1:p.r0,c1:p.c0}:{k:'f',r0:p.r0,c0:p.c0,r1:p.r1,c1:p.c1})}
   botGo(id)},(10000+Math.random()*10000)*(window.__botT>0?window.__botT:1))}
 const wordAt=(a,b)=>{const dr=Math.sign(b.r-a.r),dc=Math.sign(b.c-a.c),n=Math.max(Math.abs(b.r-a.r),Math.abs(b.c-a.c))+1;let s='';for(let i=0;i<n;i++)s+=g[a.r+dr*i][a.c+dc*i];const rv=[...s].reverse().join('');
  return words.find(w=>(w===s||w===rv)&&!S.found.some(f=>f.w===w))||null};
 const pack=()=>({k:'s',th:S.th,found:S.found,P:S.P,won:S.won,el:S.th?(performance.now()-t0)/1000:0});
 function unpack(d){if(d.th&&!S.th){S.th=d.th;gen(d.th);chips.replaceChildren()}S.found=d.found;S.P=d.P;S.won=d.won;if(S.th&&!S.won)t0=performance.now()-d.el*1000;draw()}
 function act(d){if(net.isHost)apply(d,me);else net.send(d)}
 function apply(d,id){if(!d||typeof d!=='object'||!S.P[id]||S.won||d.k!=='f'||!g)return;const a={r:d.r0|0,c:d.c0|0},b={r:d.r1|0,c:d.c1|0};
  if([a.r,a.c,b.r,b.c].some(v=>v<0||v>=N))return;const dr=Math.abs(b.r-a.r),dc=Math.abs(b.c-a.c);if(dr&&dc&&dr!==dc)return;
  const w=wordAt(a,b);if(!w)return;S.found.push({w,r0:a.r,c0:a.c,r1:b.r,c1:b.c,c:S.P[id].c,id});S.P[id].ok++;
  if(S.found.length===words.length){S.won=Math.max(1,secs());[1,2,3].forEach(i=>setTimeout(()=>beep(440*Math.pow(1.26,i),.12,'triangle',.05),i*110))}
  draw();net.send(pack())}
 // ---------- tekenen ----------
 // naam met avatar uit S.P (blijft kloppen als de speler al weg is), anders via net
 const pn=id=>{const q=S.P[id];return q?(q.av||'🙂')+' '+q.n:net.pname(id)};
 function line(r0,c0,r1,c1,col,op){const l=document.createElementNS('http://www.w3.org/2000/svg','line');l.setAttribute('x1',c0+.5);l.setAttribute('y1',r0+.5);l.setAttribute('x2',c1+.5);l.setAttribute('y2',r1+.5);l.setAttribute('stroke',col);l.setAttribute('stroke-width',.82);l.setAttribute('stroke-linecap','round');l.setAttribute('opacity',op);svg.append(l);return l}
 function panel(){pan.replaceChildren();for(const id in S.P){const q=S.P[id],live=net.players.some(x=>x.id===id),on=id===me,ch=E('span');
  ch.style.cssText='display:inline-flex;align-items:center;padding:2px 9px 2px 2px;border-radius:99px;font-size:13px;font-weight:'+(on?'700':'600')+';color:var(--tx);border:2px solid '+q.col+';background:'+(on?'color-mix(in srgb,'+q.col+' 18%,var(--bg))':'var(--bg)')+(live?'':';opacity:.45');
  const av=E('span','pav s');av.style.setProperty('--c',q.col);av.textContent=q.av||'🙂';const nm=E('span');nm.textContent=q.n+(on?' (jij)':'');const ok=E('span','','🔍 '+q.ok);ok.style.marginLeft='6px';ch.append(av,nm,ok);pan.append(ch)}}
 function draw(){panel();[...svg.querySelectorAll('line[data-f]')].forEach(l=>l.remove());
  for(const f of S.found)line(f.r0,f.c0,f.r1,f.c1,colOf(f.id),.55).dataset.f=1;
  list.replaceChildren();for(const w of words){const s=E('span');s.textContent=w;const f=S.found.find(x=>x.w===w);s.style.cssText='padding:4px 9px;border-radius:99px;background:var(--bg);color:var(--tx)'+(f?';text-decoration:line-through;opacity:.8;background:color-mix(in srgb,'+colOf(f.id)+' 35%,var(--bg))':'');list.append(s)}
  sc.textContent=S.th?(S.won?'🎉 Alles gevonden in '+fmt(S.won):'⏱ '+fmt(secs()))+' · '+S.th+' · '+S.found.length+'/'+words.length+' gevonden':'🔍 Woordzoeker samen';
  if(!S.th)info.textContent=net.isHost?'Kies een categorie:':'⏳ Wachten tot de host een categorie kiest…';else if(!gone._msg)info.textContent='';
  // einde: gedeeld podium (coöp -> geen winnaar, ieders bijdrage = gevonden woorden; de tekst noemt wie er de meeste vond)
  if(S.won&&!podDone){podDone=1;const scores={};for(const id in S.P)scores[id]=S.P[id].ok;const best=Math.max(...Object.values(S.P).map(q=>q.ok)),tops=Object.keys(S.P).filter(id=>S.P[id].ok===best);
   net.result({winner:null,scores,unit:' woorden',title:'Gelukt! 🎉',text:(tops.length===1?pn(tops[0])+' vond de meeste woorden ('+best+')':'Gelijkspel · '+best+' woorden elk')+' · tijd '+fmt(S.won)})}}
 // ---------- aanwijzen ----------
 function cellAt(e){const r=box.getBoundingClientRect();const c=Math.floor((e.clientX-r.left)/r.width*N),rw=Math.floor((e.clientY-r.top)/r.height*N);return c<0||c>=N||rw<0||rw>=N?null:{r:rw,c}}
 function snap(a,b){let dr=b.r-a.r,dc=b.c-a.c;if(!dr&&!dc)return{r:a.r,c:a.c};const k=Math.round(Math.atan2(dr,dc)/(Math.PI/4));const dy=Math.round(Math.sin(k*Math.PI/4)),dx=Math.round(Math.cos(k*Math.PI/4));let len=dx&&dy?Math.max(Math.abs(dr),Math.abs(dc)):dx?Math.abs(dc):Math.abs(dr);
  while(len>0&&(a.r+dy*len<0||a.r+dy*len>=N||a.c+dx*len<0||a.c+dx*len>=N))len--;return{r:a.r+dy*len,c:a.c+dx*len}}
 function showTemp(a,b,col){temp&&temp.remove();temp=line(a.r,a.c,b.r,b.c,col||myCol(),.4)}
 function commit(a,b){temp&&temp.remove();temp=null;tapStart=null;if(S.won||!g)return;const w=wordAt(a,b);
  if(w){beep(520+S.found.length*40,.08,'triangle',.05);showTemp(a,b);act({k:'f',r0:a.r,c0:a.c,r1:b.r,c1:b.c})}
  else{const l=line(a.r,a.c,b.r,b.c,'#ff3b3b',.4);setTimeout(()=>l.remove(),250);beep(180,.08,'sawtooth',.03)}}
 box.onpointerdown=e=>{e.preventDefault();try{box.setPointerCapture(e.pointerId)}catch(x){}const c=cellAt(e);if(!c||S.won||!g)return;drag={a:c,moved:0,id:e.pointerId};showTemp(tapStart||c,c)};
 box.onpointermove=e=>{if(!drag||e.pointerId!==drag.id)return;const c=cellAt(e);if(!c)return;if(c.r!==drag.a.r||c.c!==drag.a.c)drag.moved=1;drag.b=snap(drag.a,c);showTemp(drag.a,drag.b)};
 box.onpointerup=e=>{if(!drag)return;const d=drag;drag=null;if(d.moved)commit(d.a,d.b||d.a);else if(tapStart){if(tapStart.r===d.a.r&&tapStart.c===d.a.c){tapStart=null;temp&&temp.remove();temp=null}else commit(tapStart,snap(tapStart,d.a))}else{tapStart=d.a;showTemp(d.a,d.a,'#ffd43b')}};
 box.onpointercancel=()=>{drag=null;tapStart=null;temp&&temp.remove();temp=null};
 // ---------- net ----------
 const off=net.on((d,from)=>{if(!d||typeof d!=='object')return;if(net.isHost)apply(d,from);else if(d.k==='s')unpack(d)});
 const offP=net.onPlayers(pl=>{for(const id in S.P)if(!pl.some(x=>x.id===id)&&!gone[id]){gone[id]=1;gone._msg=1;info.textContent='⚠️ '+pn(id)+' heeft het spel verlaten'}
  if(net.isHost){const used=new Set(Object.values(S.P).map(q=>q.c));let add=0;for(const q of pl)if(!S.P[q.id]){let c=0;while(used.has(c)&&c<4)c++;used.add(c%4);S.P[q.id]=reg(q,c%4);add=1}if(add)net.send(pack())}draw()});
 if(net.isHost){[...Object.keys(TH),'🎲 Willekeurig'].forEach(t=>{const b=E('button','btn',t);b.style.cssText='padding:7px 11px;font-size:13px;border-radius:99px';b.onclick=()=>{const th=TH[t]?t:Object.keys(TH)[Math.floor(Math.random()*5)];setTheme(th);net.send(pack())};chips.append(b)})}
 tm=setInterval(()=>{if(S.th&&!S.won)sc.textContent=sc.textContent.replace(/⏱ [\d:]+/,'⏱ '+fmt(secs()))},500);
 window.__dbg={place:()=>place.slice(),words:()=>words.slice(),grid:()=>g&&g.map(r=>r.join('')).join('/'),found:()=>S.found.slice(),P:()=>JSON.parse(JSON.stringify(S.P)),state:()=>({th:S.th,won:S.won}),box,setTheme:t=>{if(net.isHost){setTheme(t);net.send(pack())}}};
 draw();return()=>{for(const id in bTm)clearTimeout(bTm[id]);clearInterval(tm);off();offP();box.onpointerdown=box.onpointermove=box.onpointerup=box.onpointercancel=null;delete window.__dbg}}},
